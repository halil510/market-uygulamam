import 'package:shared_preferences/shared_preferences.dart';
import 'package:market_uygulamasi/servisler/yazdirma_servisi.dart';
import 'package:market_uygulamasi/servisler/etiket_motoru_zpl.dart';
import 'package:market_uygulamasi/servisler/etiket_motoru_tspl.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/widgetlar/barcode_widget.dart';
import 'package:market_uygulamasi/widgetlar/tarih_secici.dart';
import 'package:market_uygulamasi/widgetlar/barkod_tarayici.dart';

class BarkodYazdirmaEkrani extends StatefulWidget {
  const BarkodYazdirmaEkrani({super.key});

  @override
  _BarkodYazdirmaEkraniState createState() => _BarkodYazdirmaEkraniState();
}

class _BarkodYazdirmaEkraniState extends State<BarkodYazdirmaEkrani> {
  final UrunRepoSitory _urunRepo = UrunRepoSitory();
  List<Urun> _tumUrunler = [];
  List<Urun> _filtrelenmisUrunler = [];
  List<Urun> _seciliUrunler = [];
  List<String> _anagruplar = [];
  List<String> _alan1ler = [];
  String? _seciliAnagrup;
  String? _seciliAlan1;
  DateTime? _seciliTarih;
  final TextEditingController _aramaController = TextEditingController();
  bool _tumunuSec = false;
  bool _yazdiriliyor = false;

  // Etiket ayarları
  double _etiketGenislik = 50.0;
  double _etiketYukseklik = 30.0;
  String _etiketDili = 'ZPL';
  bool _kullanBartender = false;
  String _bartenderIp = '192.168.1.100';
  int _bartenderPort = 9100;

  @override
  void initState() {
    super.initState();
    _urunleriYukle();
    _ayarlariYukle();
  }

  Future<void> _ayarlariYukle() async {
    final sp = await SharedPreferences.getInstance();
    setState(() {
      _etiketGenislik = double.tryParse(sp.getString('etiket_w') ?? '50') ?? 50.0;
      _etiketYukseklik = double.tryParse(sp.getString('etiket_h') ?? '30') ?? 30.0;
      _etiketDili = sp.getString('etiket_dil') ?? 'ZPL';
      _kullanBartender = sp.getBool('kullan_bartender') ?? false;
      _bartenderIp = sp.getString('bartender_ip') ?? '192.168.1.100';
      _bartenderPort = int.tryParse(sp.getString('bartender_port') ?? '9100') ?? 9100;
    });
  }

  Future<void> _urunleriYukle() async {
    final urunler = await _urunRepo.tumUrunleriGetir();
    if (!mounted) return;
    setState(() {
      _tumUrunler = urunler;
      _filtrelenmisUrunler = [];
      _anagruplar = urunler.map((u) => u.anagrup).whereType<String>().toSet().toList();
      _alan1ler = urunler.map((u) => u.alan1).whereType<String>().toSet().toList();
    });
  }

  void _filtrele() {
    List<Urun> sonuc = _tumUrunler;

    if (_seciliTarih != null) {
      final tarihStr = DateFormat('yyyy-MM-dd').format(_seciliTarih!);
      sonuc = sonuc.where((u) => u.fiyatGuncellemeTarihi == tarihStr).toList();
    }
    if (_seciliAnagrup != null) {
      sonuc = sonuc.where((u) => u.anagrup == _seciliAnagrup).toList();
    }
    if (_seciliAlan1 != null) {
      sonuc = sonuc.where((u) => u.alan1 == _seciliAlan1).toList();
    }
    if (_aramaController.text.isNotEmpty) {
      final query = _aramaController.text.toLowerCase();
      sonuc = sonuc.where((u) =>
          u.ad.toLowerCase().contains(query) ||
          u.barkod.toLowerCase().contains(query) ||
          u.kod.toLowerCase().contains(query)
      ).toList();
    }
    setState(() {
      _filtrelenmisUrunler = sonuc;
      if (_tumunuSec) _seciliUrunler = List.from(_filtrelenmisUrunler);
    });
  }

  Future<void> _barkodOku() async {
    final barkod = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => BarkodTarayici()),
    );
    if (barkod != null) {
      final urun = await _urunRepo.barkodlaUrunGetir(barkod);
      setState(() {
        if (urun != null) {
          _filtrelenmisUrunler.add(urun);
        } else {
          _filtrelenmisUrunler.add(Urun(
            id: 0,
            barkod: barkod,
            ad: "Bilinmeyen Ürün",
            satisFiyat: 0,
          ));
        }
      });
    }
  }

  void _barkodDialogAc(Urun urun) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(urun.ad, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              SizedBox(
                width: 250,
                height: 150,
                child: BarcodeWidget(
                  barkod: urun.barkod,
                  width: 250,
                  height: 150,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Kapat"),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _yazdir() async {
    if (_seciliUrunler.isEmpty || _yazdiriliyor) return;
    setState(() => _yazdiriliyor = true);

    int basarili = 0;
    int hatali = 0;
    String? hataMesaji;

    for (var urun in _seciliUrunler) {
      try {
        String komut = (_etiketDili == 'ZPL')
            ? ZplEtiketMotoru.olustur(
                genislikMm: _etiketGenislik,
                yukseklikMm: _etiketYukseklik,
                barkod: urun.barkod,
                ad: urun.ad,
                fiyat: urun.satisFiyat.toStringAsFixed(2),
              )
            : TsplEtiketMotoru.olustur(
                genislikMm: _etiketGenislik,
                yukseklikMm: _etiketYukseklik,
                barkod: urun.barkod,
                ad: urun.ad,
                fiyat: urun.satisFiyat.toStringAsFixed(2),
              );

        if (_kullanBartender) {
          await YazdirmaServisi.bartenderIleYazdir(komut, _bartenderIp, port: _bartenderPort);
        } else {
          await YazdirmaServisi.hamKomutYazdir(komut, YaziciKategori.etiket);
        }

        basarili++;
      } catch (e) {
        hatali++;
        hataMesaji = e.toString();
      }
    }

    setState(() => _yazdiriliyor = false);

    if (!mounted) return;

    if (basarili > 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("$basarili ürün başarıyla yazdırıldı")),
      );
    }
    if (hatali > 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("$hatali ürün yazdırılamadı. Hata: $hataMesaji")),
      );
    }
  }

  void _listeyiKaydet() {
    if (_seciliUrunler.isEmpty) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("${_seciliUrunler.length} ürün kaydedildi")),
    );
  }

  void _listeyiTemizle() {
    setState(() {
      _filtrelenmisUrunler.clear();
      _seciliUrunler.clear();
      _tumunuSec = false;
    });
  }

  void _tumunuSecDegistir(bool? secili) {
    setState(() {
      _tumunuSec = secili ?? false;
      if (_tumunuSec) {
        _seciliUrunler = List.from(_filtrelenmisUrunler);
      } else {
        _seciliUrunler.clear();
      }
    });
  }

  void _etiketAyarDialogAc() async {
    final sp = await SharedPreferences.getInstance();
    final genislikController = TextEditingController(text: _etiketGenislik.toString());
    final yukseklikController = TextEditingController(text: _etiketYukseklik.toString());
    final ipController = TextEditingController(text: _bartenderIp);
    final portController = TextEditingController(text: _bartenderPort.toString());

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text("Etiket ve Yazıcı Ayarları"),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text("Etiket Boyutu (mm):", style: TextStyle(fontWeight: FontWeight.bold)),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: genislikController,
                          decoration: const InputDecoration(labelText: "Genişlik"),
                          keyboardType: TextInputType.number,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: yukseklikController,
                          decoration: const InputDecoration(labelText: "Yükseklik"),
                          keyboardType: TextInputType.number,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text("Yazıcı Dili:", style: TextStyle(fontWeight: FontWeight.bold)),
                  DropdownButton<String>(
                    value: _etiketDili,
                    items: const [
                      DropdownMenuItem(value: 'ZPL', child: Text('ZPL')),
                      DropdownMenuItem(value: 'TSPL', child: Text('TSPL')),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _etiketDili = value);
                        sp.setString('etiket_dil', value);
                      }
                    },
                  ),
                  const SizedBox(height: 16),
                  const Text("Yazıcı Seçimi:", style: TextStyle(fontWeight: FontWeight.bold)),
                  Row(
                    children: [
                      const Text("Normal Yazıcı"),
                      Switch(
                        value: _kullanBartender,
                        onChanged: (value) {
                          setState(() => _kullanBartender = value);
                          sp.setBool('kullan_bartender', value);
                        },
                      ),
                      const Text("BarTender"),
                    ],
                  ),
                  if (_kullanBartender) ...[
                    const SizedBox(height: 16),
                    const Text("BarTender Ayarları:", style: TextStyle(fontWeight: FontWeight.bold)),
                    TextField(
                      controller: ipController,
                      decoration: const InputDecoration(labelText: "IP Adresi"),
                    ),
                    TextField(
                      controller: portController,
                      decoration: const InputDecoration(labelText: "Port"),
                      keyboardType: TextInputType.number,
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("İptal"),
              ),
              ElevatedButton(
                onPressed: () async {
                  final genislik = double.tryParse(genislikController.text) ?? 50.0;
                  final yukseklik = double.tryParse(yukseklikController.text) ?? 30.0;
                  final ip = ipController.text;
                  final port = int.tryParse(portController.text) ?? 9100;

                  await sp.setString('etiket_w', genislik.toString());
                  await sp.setString('etiket_h', yukseklik.toString());
                  await sp.setString('bartender_ip', ip);
                  await sp.setString('bartender_port', port.toString());

                  setState(() {
                    _etiketGenislik = genislik;
                    _etiketYukseklik = yukseklik;
                    _bartenderIp = ip;
                    _bartenderPort = port;
                  });

                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Ayarlar kaydedildi")),
                  );
                },
                child: const Text("Kaydet"),
              ),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Barkod Yazdırma"),
        actions: [
          IconButton(
            icon: const Icon(Icons.print),
            onPressed: _yazdiriliyor ? null : _yazdir,
          ),
          IconButton(icon: const Icon(Icons.save), onPressed: _listeyiKaydet),
          IconButton(icon: const Icon(Icons.cleaning_services), onPressed: _listeyiTemizle),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: "Etiket ve Yazıcı Ayarları",
            onPressed: _etiketAyarDialogAc,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Text("Tarih:", style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TarihSecici(
                            onTarihSecildi: (baslangic, bitis) {
                              setState(() {
                                _seciliTarih = baslangic;
                                _filtrele();
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: _seciliAnagrup,
                            decoration: const InputDecoration(
                              labelText: "Ana Grup",
                              border: OutlineInputBorder(),
                            ),
                            items: _anagruplar.map((grup) => DropdownMenuItem(value: grup, child: Text(grup))).toList(),
                            onChanged: (value) {
                              setState(() {
                                _seciliAnagrup = value;
                                _filtrele();
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: _seciliAlan1,
                            decoration: const InputDecoration(
                              labelText: "Alan1",
                              border: OutlineInputBorder(),
                            ),
                            items: _alan1ler.map((alan) => DropdownMenuItem(value: alan, child: Text(alan))).toList(),
                            onChanged: (value) {
                              setState(() {
                                _seciliAlan1 = value;
                                _filtrele();
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _aramaController,
                            decoration: InputDecoration(
                              labelText: "Ürün Ara",
                              border: const OutlineInputBorder(),
                              suffixIcon: IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  _aramaController.clear();
                                  _filtrele();
                                },
                              ),
                            ),
                            onChanged: (value) => _filtrele(),
                          ),
                        ),
                        const SizedBox(width: 10),
                        IconButton(
                          icon: const Icon(Icons.qr_code_scanner),
                          tooltip: "Barkod Okut",
                          onPressed: _barkodOku,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Checkbox(
                      value: _tumunuSec,
                      onChanged: _tumunuSecDegistir,
                    ),
                    const Text("Tümünü Seç", style: TextStyle(fontSize: 14)),
                  ],
                ),
                Text(
                  "Seçili: ${_seciliUrunler.length}",
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filtrelenmisUrunler.length,
              itemBuilder: (context, index) {
                final urun = _filtrelenmisUrunler[index];
                final secili = _seciliUrunler.contains(urun);

                return Dismissible(
                  key: Key(urun.id.toString()),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete, color: Colors.white, size: 30),
                  ),
                  onDismissed: (_) {
                    setState(() {
                      _filtrelenmisUrunler.removeAt(index);
                      _seciliUrunler.remove(urun);
                    });
                  },
                  child: GestureDetector(
                    onLongPress: () {
                      setState(() {
                        if (_seciliUrunler.contains(urun)) {
                          _seciliUrunler.remove(urun);
                        } else {
                          _seciliUrunler.add(urun);
                        }
                      });
                    },
                    onTap: () => _barkodDialogAc(urun),
                    child: Card(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: ListTile(
                        title: Text(urun.ad),
                        subtitle: SizedBox(
                          width: double.infinity,
                          height: 80,
                          child: BarcodeWidget(
                            barkod: urun.barkod,
                            width: double.infinity,
                            height: 80,
                            fontSize: 14,
                          ),
                        ),
                        trailing: secili
                            ? const Icon(Icons.check, color: Colors.green)
                            : null,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}