// lib/yardimci/convert_helper.dart
import 'dart:convert';

class ConvertHelper {
  /// Güvenli double dönüşümü
  static double? toDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) {
      String clean = value.trim().replaceAll(',', '.');
      return double.tryParse(clean);
    }
    return null;
  }

  /// Güvenli int dönüşümü
  static int? toInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value.trim());
    return null;
  }

  /// Güvenli String dönüşümü
  static String toStringSafe(dynamic value) {
    if (value == null) return '';
    return value.toString();
  }

  /// Güvenli bool dönüşümü (1/0, "true"/"false", true/false)
  static bool? toBool(dynamic value) {
    if (value == null) return null;
    if (value is bool) return value;
    if (value is int) return value == 1;
    if (value is String) {
      final lower = value.trim().toLowerCase();
      if (lower == 'true' || lower == '1') return true;
      if (lower == 'false' || lower == '0') return false;
      return null;
    }
    return null;
  }

  /// JSON safe parse
  static T? fromJson<T>(String? json, T Function(Map<String, dynamic>) fromMap) {
    if (json == null || json.isEmpty) return null;
    try {
      final map = jsonDecode(json) as Map<String, dynamic>;
      return fromMap(map);
    } catch (e) {
      return null;
    }
  }

  static String? toJson(dynamic obj, Map<String, dynamic> Function() toMap) {
    try {
      return jsonEncode(toMap());
    } catch (e) {
      return null;
    }
  }

  /// Sayıyı formatla (virgüllü)
  static String formatDouble(double? value, {int decimals = 2, String empty = '0'}) {
    if (value == null) return empty;
    return value.toStringAsFixed(decimals).replaceAll('.', ',');
  }

  /// String'ten double parse (virgüllü)
  static double parseDouble(String value, {double defaultValue = 0.0}) {
    final cleaned = value.trim().replaceAll(',', '.');
    return double.tryParse(cleaned) ?? defaultValue;
  }
}