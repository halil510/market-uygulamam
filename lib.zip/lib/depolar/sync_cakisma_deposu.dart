// lib/depolar/sync_cakisma_deposu.dart
//
// NOT: sync_cakismalar tablosu KASITLI OLARAK buluta senkronize EDİLMİYOR
// (global_id yok, BulutManager çağrılmıyor) — bu, çakışmayı YAŞAYAN
// cihazın yerel bir denetim/inceleme kaydıdır, iş verisi değildir.
import 'package:sqflite/sqflite.dart';
import '../cekirdek/sabitler/db_sabitleri.dart';
import '../modeller/sync_cakisma_model.dart';
import '../servisler/kolon_haritalama.dart';
import '../servisler/log_servisi.dart';
import '../servisler/bulut/bulut_manager.dart';
import '../veri/database/veritabani.dart';
import '../veri/database/sync_cakisma_tespit.dart';

class SyncCakismaDeposu {
  final Veritabani _db = Veritabani();
  Future<Database> get _d async => _db.db;

  Future<int> ekle(SyncCakismaModel c) async {
    try {
      final db = await _d;
      final m = c.toMap()..remove('id');
      return await db.insert(DbSabitler.syncCakismalar, m);
    } catch (e, st) {
      LogServisi().hata('SyncCakismaDeposu.ekle', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<List<SyncCakismaModel>> listele({bool sadeceCozulmemis = true, int limit = 200}) async {
    try {
      final db = await _d;
      final rows = await db.query(
        DbSabitler.syncCakismalar,
        where: sadeceCozulmemis ? 'cozuldu = 0' : null,
        orderBy: 'tarih DESC',
        limit: limit,
      );
      return rows.map(SyncCakismaModel.fromMap).toList();
    } catch (e, st) {
      LogServisi().hata('SyncCakismaDeposu.listele', hata: e, yigin: st);
      return [];
    }
  }

  /// Çözülmemiş çakışmaları güncel tespit kurallarıyla yeniden değerlendirir
  /// ve artık gerçek çakışma olmayanları (ondalık/tarih biçimi farkı, cihaz
  /// kimliği, canlı masa durumu, sadece boş alan dolması) otomatik kapatır.
  /// "Sadece boşluk dolduran" kayıtlarda gelen değer yerelde boş alana
  /// yazılır (yerelde kaybolacak değer yoktur). Kapatılan sayı döner.
  Future<int> sahteleriTemizle() async {
    var kapatilan = 0;
    try {
      final db = await _d;
      final rows = await db.query(DbSabitler.syncCakismalar, where: 'cozuldu = 0');
      for (final r in rows) {
        final c = SyncCakismaModel.fromMap(r);
        final yerel = c.yerelKayit, gelen = c.gelenKayit;
        if (yerel == null || gelen == null || c.kayitGlobalId == null) continue;
        final farklar = SyncCakismaTespit.farklariBul(yerel, gelen);
        final sahte = c.tablo == 'masalar' ||
            farklar.isEmpty ||
            SyncCakismaTespit.sadeceBoslukDoldurma(farklar);
        if (!sahte) continue;
        if (farklar.isNotEmpty && c.tablo != 'masalar') {
          // Yalnızca yerelde hâlâ boş olan alanları doldur.
          for (final e in farklar.entries) {
            if (!RegExp(r'^[a-z0-9_]+$').hasMatch(e.key)) continue;
            final deger = (e.value as Map)['gelen'];
            await db.rawUpdate(
                'UPDATE ${c.tablo} SET ${e.key} = ? WHERE global_id = ? '
                "AND (${e.key} IS NULL OR ${e.key} = '')",
                [deger, c.kayitGlobalId]);
          }
        }
        await _cozumIsaretle(c.id!, tip: 'otomatik', kullanici: 'sistem');
        kapatilan++;
      }
    } catch (e, st) {
      LogServisi().hata('SyncCakismaDeposu.sahteleriTemizle', hata: e, yigin: st);
    }
    return kapatilan;
  }

  /// Salt okunur sayım. 🔴 ÖNCEDEN burada önce [sahteleriTemizle]
  /// çağrılıyordu: "sayım" adı altında tüm çakışmalar JSON'dan çözülüp iş
  /// tablolarına UPDATE yazılıyor, Veri Sağlığı'nın diğer sorgularını da
  /// bekletiyordu. Temizlik isteyen ekran onu ayrıca, açıkça çağırır.
  Future<int> cozulmemisSayisi() async {
    try {
      final db = await _d;
      final rows = await db.rawQuery(
          'SELECT COUNT(*) as n FROM ${DbSabitler.syncCakismalar} WHERE cozuldu = 0');
      return (rows.first['n'] as num?)?.toInt() ?? 0;
    } catch (e, st) {
      LogServisi().hata('SyncCakismaDeposu.cozulmemisSayisi', hata: e, yigin: st);
      rethrow;
    }
  }

  /// Çakışmayı "gelen" (buluttan gelen) değerle çözer.
  ///
  /// 🔴 FAZ 3 (madde 4, 2026-09-21): ÖNCEDEN bu fonksiyon veriye hiç
  /// dokunmuyordu — TÜM tablolarda LWW zaten otomatik uygulanmış
  /// olduğu varsayılıyordu, burası sadece kaydı "çözüldü" işaretliyordu.
  /// Artık "işlem verisi" tablolarında (bkz. SyncCakismaTespit.
  /// islemVerisiMi) Veritabani.supaKayitlariGuncelle() gerçek bir
  /// çakışmada otomatik üzerine YAZMIYOR — yani gelen_kayit henüz hiç
  /// uygulanmamış olabilir. Bu fonksiyon artık [yerelIleCoz] ile AYNI
  /// desende, gelen_kayit'i gerçekten tabloya yazıyor. "Master veri"
  /// tablolarında (LWW zaten uygulanmıştı) bu, AYNI içeriği tekrar
  /// yazmak anlamına gelir — zararsız (idempotent).
  Future<void> gelenIleCoz(int id, {required String kullanici}) async {
    final db = await _d;
    final rows = await db.query(DbSabitler.syncCakismalar, where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return;
    final c = SyncCakismaModel.fromMap(rows.first);
    // 🔴 DÜZELTME (Bulut Veri Güvenliği Raporu 2026-10-07, Bulgu 12):
    // gelen kayıt okunamıyorsa (bozuk JSON / boş) ÖNCEDEN hiçbir şey
    // uygulanmadan "çözüldü" işaretleniyordu — kullanıcı gelen değerin
    // yazıldığını sanıyordu. Artık hata verir; kayıt açık kalır.
    if (c.gelenKayit == null || c.kayitGlobalId == null) {
      throw StateError('Gelen kayıt okunamadı — çakışma "gelen" ile çözülemez');
    }
    final uygulanacak = await _yerelKolonlaraSinirla(db, c.tablo, c.gelenKayit!);
    if (uygulanacak.isNotEmpty) {
      await db.update(c.tablo, uygulanacak,
          where: 'global_id = ?', whereArgs: [c.kayitGlobalId]);
    }
    await _cozumIsaretle(id, tip: 'gelen', kullanici: kullanici);
  }

  /// Kaydedilmiş satırı yerel tablonun GERÇEK sütunlarıyla sınırlar; id ve
  /// türetilmiş alanlar (stok/bakiye — hareketlerden hesaplanır) atılır.
  /// ÖNCEDEN bulutta olup yerelde olmayan tek bir sütun (ör. sunucu_zamani)
  /// tüm UPDATE'i "no such column" ile düşürüyor, çakışma hiç çözülemiyordu.
  Future<Map<String, dynamic>> _yerelKolonlaraSinirla(
      Database db, String tablo, Map<String, dynamic> satir) async {
    final kolonlar = {
      for (final r in await db.rawQuery('PRAGMA table_info($tablo)')) r['name'].toString(),
    };
    final turetilmis = KolonHaritalama.turetilmisAlanlar[tablo] ?? const <String>{};
    return {
      for (final e in satir.entries)
        if (e.key != 'id' && kolonlar.contains(e.key) && !turetilmis.contains(e.key))
          e.key: e.value is bool ? ((e.value as bool) ? 1 : 0) : e.value,
    };
  }

  /// Çakışmayı "yerel" (üzerine yazılmadan önceki) değerle çözer —
  /// kaydedilmiş eski satırı ilgili tabloya GERİ YAZAR ve kaydı kapatır.
  Future<void> yerelIleCoz(int id, {required String kullanici}) async {
    final db = await _d;
    final rows = await db.query(DbSabitler.syncCakismalar, where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return;
    final c = SyncCakismaModel.fromMap(rows.first);
    if (c.yerelKayit != null && c.kayitGlobalId != null) {
      final geriYazilacak = await _yerelKolonlaraSinirla(db, c.tablo, c.yerelKayit!);
      // Geri yazılan kayıt "şimdi" değiştirilmiş sayılsın ki bir sonraki
      // pull'da tekrar eski (gelen) değerle ezilmesin.
      geriYazilacak['last_updated'] = DateTime.now().toIso8601String();
      await db.update(c.tablo, geriYazilacak,
          where: 'global_id = ?', whereArgs: [c.kayitGlobalId]);
      // 🔴 DÜZELTME (2026-09-27): ekran "bir sonraki senkronda buluta
      // gönderilir" diyordu ama satır kuyruğa hiç yazılmıyordu — otomatik
      // gönderim görmüyor, diğer kasalar buluttaki (eski) değerde kalıyordu.
      final satir = await db.query(c.tablo,
          where: 'global_id = ?', whereArgs: [c.kayitGlobalId], limit: 1);
      if (satir.isNotEmpty) {
        BulutManager().upsert(c.tablo, Map<String, dynamic>.from(satir.first));
      }
    }
    await _cozumIsaretle(id, tip: 'yerel', kullanici: kullanici);
  }

  /// Manuel düzenleme sonrası (kullanıcı ilgili kaydı kendi ekranından
  /// düzenledi) — sadece kaydı kapatır, veriye dokunmaz.
  Future<void> manuelCoz(int id, {required String kullanici}) =>
      _cozumIsaretle(id, tip: 'manuel', kullanici: kullanici);

  /// Birden çok çakışmayı AYNI yöntemle çözer ([tip]: 'yerel' | 'gelen' |
  /// 'manuel'). Biri hata verirse diğerleri devam eder; başarılı sayı döner.
  Future<int> topluCoz(List<int> idler,
      {required String tip, required String kullanici}) async {
    var basarili = 0;
    for (final id in idler) {
      try {
        switch (tip) {
          case 'yerel':
            await yerelIleCoz(id, kullanici: kullanici);
          case 'gelen':
            await gelenIleCoz(id, kullanici: kullanici);
          default:
            await manuelCoz(id, kullanici: kullanici);
        }
        basarili++;
      } catch (e, st) {
        LogServisi().hata('SyncCakismaDeposu.topluCoz($tip, #$id)', hata: e, yigin: st);
      }
    }
    return basarili;
  }

  Future<void> _cozumIsaretle(int id, {required String tip, required String kullanici}) async {
    try {
      final db = await _d;
      await db.update(
        DbSabitler.syncCakismalar,
        {
          'cozuldu': 1,
          'cozum_tipi': tip,
          'cozen_kullanici': kullanici,
          'cozum_tarihi': DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e, st) {
      LogServisi().hata('SyncCakismaDeposu._cozumIsaretle', hata: e, yigin: st);
      rethrow;
    }
  }
}
