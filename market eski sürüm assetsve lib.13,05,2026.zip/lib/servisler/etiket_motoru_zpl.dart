// lib/servisler/etiket_motoru_zpl.dart
class ZplEtiketMotoru {
  /// mm cinsinden genişlik & yükseklik, DPI varsayılan 203 (Zebra için tipik)
  static String olustur({
    required double genislikMm,
    required double yukseklikMm,
    required String barkod,
    String? ad,
    String? fiyat,
    int dpi = 203,
  }) {
    // mm -> dots
    int w = (genislikMm / 25.4 * dpi).round();
    int h = (yukseklikMm / 25.4 * dpi).round();

    // Basit yerleşim: üstte ürün adı, ortada barkod, altta fiyat
    final buffer = StringBuffer();
    buffer.writeln('^XA');
    buffer.writeln('^PW$w'); // page width
    buffer.writeln('^LL$h'); // label length

    int y = 20; // üst boşluk
    if (ad != null && ad.trim().isNotEmpty) {
      buffer.writeln('^FO20,$y^A0N,28,28^FD${_escape(ad)}^FS');
      y += 40;
    }

    // CODE128 barkod (yükseklik 60 dot)
    buffer.writeln('^FO20,$y^BY2');
    buffer.writeln('^BCN,60,Y,N,N');
    buffer.writeln('^FD${_escape(barkod)}^FS');
    y += 80;

    if (fiyat != null && fiyat.trim().isNotEmpty) {
      buffer.writeln('^FO20,$y^A0N,34,34^FD${_escape(fiyat)}^FS');
    }

    buffer.writeln('^XZ');
    return buffer.toString();
  }

  static String _escape(String v) => v.replaceAll('^', '');
}