# PDFium (chromium/5200, win-x64) — GitHub kesintisi sırasında yerel olarak
# hazırlandı (2026-11-08): DLL nuget.org bblanchon.PDFium.Win32 106.0.5200,
# başlıklar pdfium.googlesource.com chromium/5200 public/, içe aktarma
# kütüphanesi DLL dışa aktarımlarından MSVC lib.exe ile üretildi.
# bblanchon/pdfium-binaries PDFiumConfig.cmake ile aynı hedefi/değişkenleri tanımlar.
set(PDFium_VERSION "5200")
set(PDFium_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/include")
set(PDFium_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/bin/pdfium.dll")
set(PDFium_IMPLIB "${CMAKE_CURRENT_LIST_DIR}/lib/pdfium.dll.lib")

if(NOT TARGET pdfium)
  add_library(pdfium SHARED IMPORTED)
  set_target_properties(pdfium PROPERTIES
    IMPORTED_LOCATION "${PDFium_LIBRARY}"
    IMPORTED_IMPLIB "${PDFium_IMPLIB}"
    INTERFACE_INCLUDE_DIRECTORIES "${PDFium_INCLUDE_DIR};${PDFium_INCLUDE_DIR}/cpp"
  )
endif()

set(PDFium_FOUND TRUE)
