import 'dart:io';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:market_uygulamasi/servisler/excel_servisi.dart';
import 'package:open_file/open_file.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:market_uygulamasi/modern_ui/widgets/modern_button.dart';

class VeriYedeklemeEkrani extends StatefulWidget {
  @override
  _VeriYedeklemeEkraniState createState() => _VeriYedeklemeEkraniState();
}

class _VeriYedeklemeEkraniState extends State<VeriYedeklemeEkrani> {
  final ExcelServisi _excelServisi = ExcelServisi();
  bool _yukleniyor = false;
  String? _sonucMesaji;
  List<String> _hataDetaylari = [];
  File? _seciliDosya;

  Future<void> _yedekle() async {
    setState(() {
      _yukleniyor = true;
      _sonucMesaji = null;
      _hataDetaylari = [];
    });

    try {
      final dosya = await _excelServisi.urunleriExceleDisariAktar();
      if (dosya != null) {
        setState(() => _sonucMesaji = 'Yedekleme başarılı: ${dosya.path}');
        OpenFile.open(dosya.path);
      } else {
        setState(() => _sonucMesaji = 'Yedekleme başarısız');
      }
    } catch (e) {
      setState(() => _sonucMesaji = 'Hata: $e');
    } finally {
      setState(() => _yukleniyor = false);
    }
  }

  Future<void> _dosyaSec() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );

    if (result != null && result.files.single.path != null) {
      setState(() => _seciliDosya = File(result.files.single.path!));
    }
  }

  Future<void> _urunleriIceriAl() async {
    if (_seciliDosya == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lütfen önce bir dosya seçin')),
      );
      return;
    }

    setState(() {
      _yukleniyor = true;
      _sonucMesaji = null;
      _hataDetaylari = [];
    });

    try {
      final sonuc = await _excelServisi.urunleriExceldenIceriAl(_seciliDosya!);

      setState(() {
        _sonucMesaji = 'İşlem tamamlandı: '
            '${sonuc['eklenen']} yeni, '
            '${sonuc['guncellenen']} güncellendi, '
            '${sonuc['hatali']} hatalı';

        _hataDetaylari = List<String>.from(sonuc['detaylar'] ?? []);
      });
    } catch (e) {
      setState(() => _sonucMesaji = 'İçe aktarma hatası: $e');
    } finally {
      setState(() => _yukleniyor = false);
    }
  }

  Future<void> _veritabaniYedekle() async {
    try {
      final dbPath = await getDatabasesPath();
      final kaynakDb = File(p.join(dbPath, 'market.db'));
      final externalDir = await getExternalStorageDirectory();
      if (externalDir == null) {
        _gosterSnackbar('❌ Dış depolama dizini bulunamadı.');
        return;
      }
      final hedefDb = File(p.join(externalDir.path, 'market_yedek.db'));

      if (await kaynakDb.exists()) {
        await kaynakDb.copy(hedefDb.path);
        _gosterSnackbar('✅ Veritabanı yedeklendi:\n${hedefDb.path}');
      } else {
        _gosterSnackbar('❌ Orijinal veritabanı bulunamadı.');
      }
    } catch (e) {
      _gosterSnackbar('⚠️ Yedekleme hatası: $e');
    }
  }

  Future<void> _veritabaniYukle() async {
    try {
      final externalDir = await getExternalStorageDirectory();
      if (externalDir == null) {
        _gosterSnackbar('❌ Dış depolama dizini bulunamadı.');
        return;
      }
      final kaynakDb = File(p.join(externalDir.path, 'market_yedek.db'));

      if (!await kaynakDb.exists()) {
        _gosterSnackbar('❌ Yedek veritabanı bulunamadı:\n${kaynakDb.path}');
        return;
      }

      final dbPath = await getDatabasesPath();
      final hedefDb = File(p.join(dbPath, 'market.db'));

      final onay = await _onayAl('Mevcut veritabanının üzerine yazılacak. Devam edilsin mi?');
      if (!onay) return;

      await kaynakDb.copy(hedefDb.path);
      _gosterSnackbar('✅ Veritabanı geri yüklendi:\n${hedefDb.path}');
    } catch (e) {
      _gosterSnackbar('⚠️ Yükleme hatası: $e');
    }
  }

  Future<void> _veritabaniSifirla() async {
    final onay = await _onayAl('Veritabanı tamamen sıfırlanacak. Devam edilsin mi?');
    if (!onay) return;

    try {
      final dbPath = await getDatabasesPath();
      final dbFile = File(p.join(dbPath, 'market.db'));
      if (await dbFile.exists()) {
        await dbFile.delete();
        _gosterSnackbar('🗑️ Veritabanı sıfırlandı. Uygulamayı yeniden başlatın.');
      } else {
        _gosterSnackbar('❗ Veritabanı zaten yok.');
      }
    } catch (e) {
      _gosterSnackbar('⚠️ Sıfırlama hatası: $e');
    }
  }

  Future<bool> _onayAl(String mesaj) async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Onay'),
            content: Text(mesaj),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: Text('Hayır')),
              ElevatedButton(onPressed: () => Navigator.pop(context, true), child: Text('Evet')),
            ],
          ),
        ) ??
        false;
  }

  void _gosterSnackbar(String mesaj) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mesaj), duration: Duration(seconds: 4)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Veri Yönetimi')),
      body: _yukleniyor
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Card(
                      elevation: 6,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          children: [
                            Text(
                              'Ürünleri Dışa Aktar',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleLarge
                                  ?.copyWith(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 20),
                            ModernButton(
                              icon: Icons.cloud_download,
                              text: 'Excel Olarak İndir',
                              onPressed: _yedekle,
                              width: double.infinity,
                              borderRadius: 16,
                            ),
                            if (_sonucMesaji != null) ...[
                              SizedBox(height: 16),
                              Text(
                                _sonucMesaji!,
                                style: TextStyle(color: Colors.green),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 30),
                    Card(
                      elevation: 6,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          children: [
                            Text(
                              'Ürünleri İçe Aktar',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleLarge
                                  ?.copyWith(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 20),
                            ModernButton(
                              icon: Icons.attach_file,
                              text:
                                  _seciliDosya?.path.split(Platform.pathSeparator).last ??
                                      'Excel Dosyası Seç',
                              onPressed: _dosyaSec,
                              width: double.infinity,
                              borderRadius: 16,
                            ),
                            if (_seciliDosya == null) ...[
                              SizedBox(height: 8),
                              Text('Lütfen önce bir dosya seçin',
                                  style: TextStyle(
                                      color: Colors.redAccent, fontSize: 12)),
                            ],
                            SizedBox(height: 16),
                            ModernButton(
                              icon: Icons.system_update,
                              text: 'Tam İçe Aktar',
                              onPressed: _seciliDosya == null ? null : () => _urunleriIceriAl(),
                              width: double.infinity,
                              borderRadius: 16,
                              gradientColors: _seciliDosya == null
                                  ? [Colors.grey.shade400, Colors.grey.shade600]
                                  : null,
                            ),
                            if (_sonucMesaji != null) ...[
                              SizedBox(height: 16),
                              Text(
                                _sonucMesaji!,
                                style: TextStyle(
                                  color: _hataDetaylari.isEmpty
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                            if (_hataDetaylari.isNotEmpty) ...[
                              SizedBox(height: 8),
                              Text('Hatalı Satırlar: ${_hataDetaylari.length}',
                                  style:
                                      TextStyle(fontWeight: FontWeight.bold)),
                              Container(
                                height: 120,
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: ListView.builder(
                                  itemCount: _hataDetaylari.length,
                                  itemBuilder: (context, index) {
                                    return Text('• ${_hataDetaylari[index]}');
                                  },
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 30),

                    ModernButton(
                      icon: Icons.backup,
                      text: 'DB Veritabanı Yedekle',
                      onPressed: _veritabaniYedekle,
                      width: double.infinity,
                      borderRadius: 16,
                    ),
                    SizedBox(height: 30),

                    ModernButton(
                      icon: Icons.restore,
                      text: 'DB Veritabanı İçe Al',
                      onPressed: _veritabaniYukle,
                      width: double.infinity,
                      borderRadius: 16,
                    ),
                    SizedBox(height: 30),

                    ModernButton(
                      icon: Icons.restart_alt,
                      text: '🔁 Veritabanını Sıfırla',
                      onPressed: _veritabaniSifirla,
                      width: double.infinity,
                      borderRadius: 16,
                      gradientColors: [
                        Colors.redAccent.shade700,
                        Colors.redAccent.shade400,
                      ],
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
