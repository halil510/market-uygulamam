import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/ekranlar/iade/barkodlu_iade_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/barkod/etiket_tasarim_ekrani.dart';

class Rotalar {
  static const String giris = '/giris';
  static const String anaEkran = '/';
  static const String urunListe = '/urunListe';
  static const String urunDetay = '/urunDetay';
  static const String stokListe = '/stokListe';
  static const String hizliSatis = '/hizliSatis';
  static const String sepet = '/sepet';
  static const String BarkodYazdirmaEkrani = '/BarkodYazdirmaEkrani';
  static const String fiyatGuncelle = '/fiyatGuncelle';
  static const String veriYedekle = '/veriYedekle';
  static const String sifreDegistir = '/sifreDegistir';
  static const String ayarlar = '/ayarlar';
  static const String yaziciAyar = '/yaziciAyar';
  static const String gunSonuRapor = '/gunSonuRapor';
  static const String veritabaniYonetimi = '/veritabaniYonetimi';
  static const String cariler = '/cariler';
  static const String TOPLU_ISLEM = '/topluIslem';
  static const String barkodluIade = '/barkodluIade';
  static const String etiketTasarim = '/etiket-tasarim';
  static const String stokSayim = '/stokSayim';
  static const String dashboard = '/dashboard'; // Yeni eklenen
static const String promosyon = '/promosyon';
}