import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/modeller/satis_kalem.dart';
import 'package:market_uygulamasi/modeller/musteri.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';

class SatisServisi {
  final UrunRepoSitory _urunRepo = UrunRepoSitory();

  // ================= SATIŞ YAP =================
  Future<void> satisYap(Satis satis, List<SatisKalem> kalemler) async {
    final db = await VeritabaniYardimcisi.getDatabase();

    await db.transaction((txn) async {
      // STOK DÜŞ
      for (final kalem in kalemler) {
        final urun = await _urunRepo.urunGetir(kalem.urunId);
        if (urun != null) {
          final yeniStok = (urun.stokMiktari ?? 0) - kalem.miktar;
          await _urunRepo.stokGuncelle(
            urun.id!,
            yeniStok < 0 ? 0 : yeniStok,
          );
        }
      }

      // SATIŞ EKLE (tablo adı düzeltildi)
      final satisMap = satis.toMap();
      satisMap.remove('id');
      final satisId = await txn.insert('satislar', satisMap);

      // SATIŞ KALEMLERİ (tablo adı düzeltildi)
      for (final kalem in kalemler) {
        final kalemMap = kalem.copyWith(satisId: satisId).toMap();
        await txn.insert('satis_detay', kalemMap);
      }
    });
  }

  // ================= CARİ SATIŞ HAREKETLERİ =================
  Future<List<Satis>> cariHareketleri(Musteri musteri) async {
    final db = await VeritabaniYardimcisi.getDatabase();

    final satisListesi = await db.query(
      'satislar',
      where: 'cariId = ?',
      whereArgs: [musteri.id],
      orderBy: 'tarih DESC',
    );

    List<Satis> satislar = [];

    for (final satisMap in satisListesi) {
      final kalemlerMap = await db.query(
        'satis_detay',
        where: 'satisId = ?',
        whereArgs: [satisMap['id']],
      );

      final List<SatisKalem> kalemler =
          kalemlerMap.map((k) => SatisKalem.fromMap(k)).toList();

      final satis = Satis(
        id: satisMap['id'] as int?,
        tarih: DateTime.tryParse(satisMap['tarih']?.toString() ?? '') ?? DateTime.now(),
        cariId: satisMap['cariId'] as int?,
        toplamTutar: (satisMap['toplamTutar'] as num?)?.toDouble() ?? 0.0,
        odenenTutar: (satisMap['odenenTutar'] as num?)?.toDouble() ?? 0.0,
        odemeYontemi: satisMap['odemeYontemi']?.toString() ?? '',
        kalemler: kalemler,
        fisTipi: satisMap['fisTipi']?.toString() ?? 'Satış',
      );

      satislar.add(satis);
    }

    return satislar;
  }

  // ================= TÜM SATIŞLAR =================
  Future<List<Satis>> tumSatislar() async {
    final db = await VeritabaniYardimcisi.getDatabase();

    final satisListesi = await db.query(
      'satislar',
      orderBy: 'tarih DESC',
    );

    List<Satis> satislar = [];

    for (final satisMap in satisListesi) {
      final kalemlerMap = await db.query(
        'satis_detay',
        where: 'satisId = ?',
        whereArgs: [satisMap['id']],
      );

      final List<SatisKalem> kalemler =
          kalemlerMap.map((k) => SatisKalem.fromMap(k)).toList();

      final satis = Satis(
        id: satisMap['id'] as int?,
        tarih: DateTime.tryParse(satisMap['tarih']?.toString() ?? '') ?? DateTime.now(),
        cariId: satisMap['cariId'] as int?,
        toplamTutar: (satisMap['toplamTutar'] as num?)?.toDouble() ?? 0.0,
        odenenTutar: (satisMap['odenenTutar'] as num?)?.toDouble() ?? 0.0,
        odemeYontemi: satisMap['odemeYontemi']?.toString() ?? '',
        kalemler: kalemler,
        fisTipi: satisMap['fisTipi']?.toString() ?? 'Satış',
      );

      satislar.add(satis);
    }

    return satislar;
  }
}