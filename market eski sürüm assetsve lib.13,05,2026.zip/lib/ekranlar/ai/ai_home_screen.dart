import 'package:flutter/material.dart';
import 'package:market_uygulamasi/ai/advanced_ai.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';

class AIHomeScreen extends StatefulWidget {
  const AIHomeScreen({super.key});

  @override
  State<AIHomeScreen> createState() => _AIHomeScreenState();
}

class _AIHomeScreenState extends State<AIHomeScreen> {
  final AdvancedAI _ai = AdvancedAI();
  final TextEditingController _soruController = TextEditingController();
  final List<Map<String, String>> _sohbet = [];
  bool _isLoading = false;
  Map<String, dynamic>? _analiz;
  List<Map<String, dynamic>> _siparisOnerileri = [];
  Map<String, dynamic>? _tahmin;

  // Grafik kontrolü
  bool _showChart = false;
  String _chartType = '';

  late stt.SpeechToText _speech;
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _verileriYukle();
    _speech = stt.SpeechToText();
    _initSpeech();
  }

  Future<void> _initSpeech() async {
    var status = await Permission.microphone.request();
    if (status.isGranted) {
      await _speech.initialize(
        onStatus: (status) => print('Speech status: $status'),
        onError: (error) => print('Speech error: $error'),
      );
    }
  }

  Future<void> _listen() async {
    if (!_isListening) {
      bool available = await _speech.initialize(
        onStatus: (status) {
          if (status == 'done' && mounted) {
            setState(() => _isListening = false);
          }
        },
        onError: (error) => print('Speech error: $error'),
      );
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (result) {
            setState(() {
              _soruController.text = result.recognizedWords;
            });
          },
          listenFor: const Duration(seconds: 10),
          pauseFor: const Duration(seconds: 3),
          partialResults: true,
          localeId: 'tr_TR',
        );
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  Future<void> _verileriYukle() async {
    setState(() => _isLoading = true);
    try {
      final analiz = await _ai.analizEt();
      final oneriler = await _ai.siparisOnerileri();
      final tahmin = await _ai.tahminEt(gunSayisi: 7);
      setState(() {
        _analiz = analiz;
        _siparisOnerileri = oneriler;
        _tahmin = tahmin;
      });
    } catch (e) {
      _sohbetEkle('ai', 'Veriler yüklenirken hata oluştu: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _sohbetEkle(String tip, String mesaj) {
    setState(() {
      _sohbet.add({'tip': tip, 'mesaj': mesaj});
    });
  }

  Future<void> _soruSor() async {
    final soru = _soruController.text.trim();
    if (soru.isEmpty) return;

    _sohbetEkle('user', soru);
    _soruController.clear();
    setState(() {
      _isLoading = true;
      _showChart = false; // yeni soruda grafiği kapat
    });

    try {
      final cevap = await _ai.soruyuCoz(soru);
      
      // Grafik isteği kontrolü
      if (cevap.startsWith('CHART:')) {
        setState(() {
          _showChart = true;
          _chartType = cevap.substring(6); // 'gunluk' gibi
          _isLoading = false;
        });
      } else {
        _sohbetEkle('ai', cevap);
        setState(() => _isLoading = false);
      }
    } catch (e) {
      _sohbetEkle('ai', 'Bir hata oluştu: $e');
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Akıllı Asistan'),
        backgroundColor: Colors.blue.shade800,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _verileriYukle,
            tooltip: 'Yenile',
          ),
        ],
      ),
      body: _isLoading && _analiz == null
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Mikrofon ve metin girişi
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(
                    children: [
                      IconButton(
                        icon: Icon(
                          _isListening ? Icons.mic : Icons.mic_none,
                          color: _isListening ? Colors.red : Colors.blue,
                        ),
                        onPressed: _listen,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: _soruController,
                          decoration: const InputDecoration(
                            hintText: 'Sorunuzu yazın veya mikrofonla söyleyin...',
                            border: OutlineInputBorder(),
                          ),
                          onSubmitted: (_) => _soruSor(),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _isLoading
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : ElevatedButton(
                              onPressed: _soruSor,
                              child: const Text('Gönder'),
                            ),
                    ],
                  ),
                ),
                // Grafik alanı (showChart true ise)
                if (_showChart && _analiz != null)
                  Container(
                    height: 250,
                    padding: const EdgeInsets.all(8),
                    child: _buildChart(),
                  ),
                // Sipariş önerileri (her zaman üstte)
                if (_siparisOnerileri.isNotEmpty && !_showChart)
                  Container(
                    height: 80,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _siparisOnerileri.length,
                      itemBuilder: (context, index) {
                        final o = _siparisOnerileri[index];
                        return GestureDetector(
                          onTap: () {
                            _soruController.text = '${o['urunAdi']} stoğu';
                            _soruSor();
                          },
                          child: Card(
                            color: Colors.orange.shade50,
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Row(
                                children: [
                                  const Icon(Icons.warning, color: Colors.orange),
                                  const SizedBox(width: 8),
                                  Text(
                                    '${o['urunAdi']}: ${o['mevcutStok']} stok',
                                    style: const TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                const Divider(),
                // Sohbet geçmişi
                Expanded(
                  child: ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.all(12),
                    itemCount: _sohbet.length,
                    itemBuilder: (context, index) {
                      final msg = _sohbet[_sohbet.length - 1 - index];
                      final isAI = msg['tip'] == 'ai';
                      return Align(
                        alignment: isAI ? Alignment.centerLeft : Alignment.centerRight,
                        child: Container(
                          constraints: BoxConstraints(
                              maxWidth: MediaQuery.of(context).size.width * 0.8),
                          padding: const EdgeInsets.all(12),
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          decoration: BoxDecoration(
                            color: isAI ? Colors.blue.shade50 : Colors.green.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            msg['mesaj']!,
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildChart() {
    if (_chartType == 'gunluk') {
      final zamanSerisi = _analiz!['zamanSerisi']?['gunluk'];
      if (zamanSerisi == null || (zamanSerisi as List).isEmpty) {
        return const Center(child: Text('Grafik için yeterli veri yok'));
      }
      final List<Map<String, dynamic>> chartData = 
          List<Map<String, dynamic>>.from(zamanSerisi);

      return SfCartesianChart(
        primaryXAxis: CategoryAxis(),
        series: <CartesianSeries>[
          LineSeries<Map<String, dynamic>, String>(
            dataSource: chartData,
            xValueMapper: (data, _) => data['tarih'],
            yValueMapper: (data, _) => data['toplam'],
            dataLabelSettings: const DataLabelSettings(isVisible: true),
          )
        ],
        title: const ChartTitle(text: 'Son 30 Günlük Satış Trendi'),
      );
    }
    // İleride başka grafik tipleri eklenebilir
    return const Center(child: Text('Grafik türü desteklenmiyor'));
  }
}