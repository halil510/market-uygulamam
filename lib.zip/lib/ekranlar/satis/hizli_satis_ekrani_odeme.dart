// ignore_for_file: invalid_use_of_protected_member
// lib/ekranlar/satis/hizli_satis_ekrani_odeme.dart
// hizli_satis_ekrani.dart'ın parçası — bkz.
// hizli_satis_ekrani_barkod.dart başındaki not. Bu dosya: indirim
// düzenleme, müşteri seçme, ödeme yöntemi seçme, nakit üstü hesabı,
// fiş güncelleme, SATIŞI TAMAMLAMA (_satisiTamamla — asıl checkout),
// sepet miktar düzenleme, tedarikçiye aktarma, askıya alma.
part of 'hizli_satis_ekrani.dart';

extension _HizliSatisOdemeExt on _HizliSatisEkraniState {
  // ── İndirim Dialog ───────────────────────────────────────────────────────────
  // Oran (%), tutar (₺) ve yeni toplam birbirini hesaplar; liste fiyatı
  // üzerinden çalışır (bkz. widgetlar/ortak/iskonto_dialogu.dart).
  Future<void> _indirimDuzenle(SepetKalem k, int index) async {
    if (!mounted) return;
    _dialogAcik = true;
    _islemAktif = true;
    if (_kameraAcik) { try { _scanCtrl.stop(); } catch (e) { /* ignore */ } }

    final yeniToplam = await iskontoDialoguGoster(
      context,
      baslik: k.urun.urunAdi,
      brutToplam: k.brutTutar,
    );

    _dialogAcik = false;
    _islemAktif = false;
    if (_kameraAcik && mounted) { try { _scanCtrl.start(); } catch (e) { /* ignore */ } }
    if (yeniToplam == null || !mounted || k.miktar <= 0) return;
    // Birim fiyat 6 hane: ör. 3 adet / 100 ₺ → 33,333333 × 3 = 100.
    final yeniBirim = (yeniToplam / k.miktar * 1000000).round() / 1000000;
    if (yeniBirim > 0) {
      ref.read(sepetProvider.notifier).fiyatGuncelle(index, yeniBirim);
    }
  }

  // ── Müşteri Seç ──────────────────────────────────────────────────────────────
  Future<void> _musteriSec() async {
    if (_islemAktif || _dialogAcik) return; // çift-tıklama koruması
    _islemBasladi();
    try {
      final cariler = await _cariDepo.tumunuGetir();
      if (!mounted) return;
      // Windows: seçim, tam Cariler listesinden (arama/filtre/tablo) yapılır.
      final secilen = Platform.isWindows
          ? await cariListesindenSec(context, const CariListeEkrani())
          : await showModalBottomSheet<CariModel>(
              context: context,
              isScrollControlled: true,
              backgroundColor: Colors.transparent,
              builder: (_) => MusteriSecimPaneli(cariler: cariler),
            );
      if (secilen == null || !mounted) return;

      final tedarikciMi = secilen.cariTipi.contains('edarik');
      if (tedarikciMi) {
        if (ref.read(sepetProvider).bos) {
          BildirimServisi.bilgi(context,
              '${secilen.unvan} bir Tedarikçi. Sepet boş olduğu için doğrudan Alım ekranına yönlendiriliyorsunuz.');
          if (mounted) context.push('/tedarik/alim', extra: secilen);
          return;
        }
        await _sepetiAlimaAktar(secilen);
        return;
      }

      ref.read(sepetProvider.notifier).musteriSec(secilen);
    } catch (e) {
      if (kDebugMode) debugPrint('Müşteri seçme hatası: $e');
      if (mounted) BildirimServisi.hata(context, 'Müşteri listesi yüklenemedi: $e');
    } finally {
      _islemBitti();
    }
  }

  // ── Hızlı Nakit (masaüstü F1) ────────────────────────────────────────────────
  // F12 ödeme penceresini açar; F1 ise pencere/tutar sormadan satışı DOĞRUDAN
  // Nakit olarak, tam sepet tutarı alınmış kabul edip bitirir (para üstü 0).
  // Çift satışı önlemek için F12 akışıyla AYNI korumalar (_islemAktif/_dialogAcik).
  Future<void> _hizliNakitSat() async {
    // Bayi seçimi sonrası fiyatlar arka planda güncelleniyorsa bitsin.
    await ref.read(sepetProvider.notifier).fiyatlarHazir();
    if (!mounted) return;
    final sepet = ref.read(sepetProvider);
    if (sepet.bos || sepet.satisIsleniyor || _islemAktif || _dialogAcik) return;
    _islemBasladi();
    try {
      await _satisiTamamla('Nakit', sepet.genelToplam, 0.0);
    } catch (e) {
      if (kDebugMode) debugPrint('Hızlı nakit satış hatası: $e');
      if (mounted) BildirimServisi.hata(context, 'Satış hatası: $e');
    } finally {
      _islemBitti();
    }
  }

  // ── Ödeme Akışı ──────────────────────────────────────────────────────────────
  Future<void> _odemeYontemiSec() async {
    // Bayi seçimi sonrası fiyatlar arka planda güncelleniyorsa bitsin —
    // ödeme penceresindeki tutar kaydedilen satışla aynı olsun.
    await ref.read(sepetProvider.notifier).fiyatlarHazir();
    if (!mounted) return;
    final sepet  = ref.read(sepetProvider);
    // 🔴🔴 KRİTİK DÜZELTME (hızlı satış derin analizi, 2026-09-14): bu
    // fonksiyon çift-tıklamaya karşı HİÇ korunmuyordu — barkod okutma
    // (_barkodOkutIsle) '_islemAktif'i zaten kontrol ediyordu ama "Ödeme
    // Al" butonu bunu hiç yapmıyordu. Aynı anda iki kez tetiklenirse AYNI
    // sepet için İKİ AYRI satış tamamlanabilir (çift stok düşümü, çift
    // kasa/cari hareketi) — bkz. satis_alt_panel.dart'taki eşlik eden
    // düzeltme (buton görsel olarak da devre dışı bırakılıyor artık).
    if (sepet.bos || _islemAktif || _dialogAcik) return;
    _islemBasladi();

    try {
      final odemeSheet = _OdemeSecimSheet(
          toplam: sepet.genelToplam, musteriSecili: sepet.musteri != null);
      final yontem = Platform.isWindows
          ? await showDialog<String>(
              context: context,
              builder: (_) => Dialog(
                backgroundColor: Colors.transparent,
                elevation: 0,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 520),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(24),
                    child: odemeSheet,
                  ),
                ),
              ),
            )
          : await showModalBottomSheet<String>(
              context: context,
              backgroundColor: Colors.transparent,
              builder: (_) => odemeSheet,
            );
      if (!mounted || yontem == null) return;

      if (yontem == 'Karma') {
        final karmaEkran = CokluOdemeEkrani(
          toplamTutar: sepet.genelToplam,
          cariMevcut: sepet.musteri != null,
        );
        final sonuc = Platform.isWindows
            ? await showDialog<Map<String, dynamic>>(
                context: context,
                // Saydam çerçeve: kartı CokluOdemeEkrani kendisi çiziyor —
                // Dialog'un beyaz zemini "ekran içinde ekran" görüntüsü veriyordu.
                builder: (_) => Dialog(
                  insetPadding: const EdgeInsets.all(24),
                  backgroundColor: Colors.transparent,
                  surfaceTintColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  elevation: 0,
                  child: SizedBox(
                    width: 820,
                    height: (MediaQuery.of(context).size.height * 0.9)
                        .clamp(420.0, 760.0),
                    child: karmaEkran,
                  ),
                ),
              )
            : await showModalBottomSheet<Map<String, dynamic>>(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (_) => SizedBox(
                  height: MediaQuery.of(context).size.height * 0.94,
                  child: karmaEkran,
                ),
              );
        if (!mounted || sonuc == null) return;
        final kalemler = (sonuc['kalemler'] as List).cast<Map<String, dynamic>>();
        final toplamOdenen = (sonuc['toplam_odenen'] as num?)?.toDouble() ?? sepet.genelToplam;
        final paraUstu = (sonuc['para_ustu'] as num?)?.toDouble() ?? 0.0;
        final odemeYontemiEtiketi = kalemler.length == 1
            ? (kalemler.first['yontem'] as String) : 'Karma';
        await _satisiTamamla(odemeYontemiEtiketi, toplamOdenen, paraUstu,
            karmaKalemler: kalemler);
      } else if (yontem == 'Nakit') {
        final alinan = await _nakitAlintiSor(sepet.genelToplam);
        if (!mounted || alinan == null) return;
        final paraUstu = alinan - sepet.genelToplam;
        await _satisiTamamla('Nakit', alinan, paraUstu > 0 ? paraUstu : 0.0);
      } else {
        await _satisiTamamla(yontem, sepet.genelToplam, 0.0);
      }
    } catch (e) {
      if (kDebugMode) debugPrint('Ödeme akışı hatası: $e');
      if (mounted) BildirimServisi.hata(context, 'Ödeme işlemi başarısız: $e');
    } finally {
      _islemBitti();
    }
  }

  // 🔴🔴 KRİTİK DÜZELTME (kullanıcı bulgusu — "hızlı satıştan Nakit ile
  // satış yaptım, Satış Listesi'ne aynı sepet İKİ KEZ eklendi"): bu
  // dialog, HÂLÂ AKTİF olan _odemeYontemiSec() akışının (ki kendi
  // _islemBasladi()'sını zaten çağırmıştı) İÇİNDE açılıyor — "Tamam"a
  // basılınca dialog kapanır ama _satisiTamamla() (asıl satışı yazan
  // çağrı) henüz BAŞLAMAMIŞTIR, _odemeYontemiSec() içindeki await
  // zincirinde biraz daha sürer. Önceden burada (ve İptal/geri tuşunda)
  // _islemAktif SESSİZCE false'a çekiliyordu — bu, "Tamam"a basıp
  // _satisiTamamla() tamamlanmadan ÖNCEKİ kısa pencerede kullanıcı
  // tekrar "Ödeme Al"a basarsa (veya kuyruktaki bir barkod işlenirse)
  // _islemAktif kontrolünün bunu ENGELLEMEMESİNE yol açıyordu — AYNI
  // sepet ikinci kez satışa dönüşebiliyordu (çift stok düşümü, çift
  // fiş). _islemAktif artık burada DOKUNULMUYOR — tek sahibi
  // _odemeYontemiSec()'in kendi finally{_islemBitti()} bloğu (akış
  // iptalle de, satışla da bitse, en sonda ZATEN çağrılıyor).
  Future<double?> _nakitAlintiSor(double toplam) async {
    _dialogAcik = true;
    final ctrl = TextEditingController();
    final sonuc = await showDialog<double?>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => PopScope(
        canPop: true,
        onPopInvokedWithResult: (didPop, result) { _dialogAcik = false; },
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Nakit Ödeme'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Toplam: ${ParaUtils.formatla(toplam)}',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            TextField(
              controller: ctrl,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
              // Enter ile onay (klavye/masaüstü).
              onSubmitted: (_) {
                final txt = ctrl.text.trim().replaceAll(',', '.');
                final val = txt.isEmpty ? toplam : double.tryParse(txt);
                _dialogAcik = false;
                Navigator.pop(ctx, val);
              },
              decoration: const InputDecoration(
                hintText: 'Boş → tam tutar',
                labelText: 'Alınan Tutar (₺)',
                prefixIcon: Icon(Icons.payments),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.calculate_outlined, size: 18),
                label: const Text('Para Üstü Hesapla'),
                onPressed: () async {
                  final alinan = await Navigator.push<double>(
                    ctx,
                    MaterialPageRoute(
                      builder: (_) =>
                          ParaUstuEkrani(odenmesiGereken: toplam),
                    ),
                  );
                  if (alinan != null) {
                    ctrl.text = alinan.toStringAsFixed(2);
                  }
                },
              ),
            ),
          ]),
          actions: [
            TextButton(
              onPressed: () { _dialogAcik = false; Navigator.pop(ctx); },
              child: const Text('İptal'),
            ),
            FilledButton(
              onPressed: () {
                final txt = ctrl.text.trim().replaceAll(',', '.');
                final val = txt.isEmpty ? toplam : double.tryParse(txt);
                _dialogAcik = false;
                Navigator.pop(ctx, val);
              },
              child: const Text('Tamam'),
            ),
          ],
        ),
      ),
    ).whenComplete(() => dialogSonrasiBirak([ctrl]));
    return sonuc;
  }

  // ── Satış Tamamla ────────────────────────────────────────────────────────────
  //
  // 🔴 DÜZELTME (derin analiz 2026-10-07, B5): sepet keepAlive bir sağlayıcı.
  // Kayıt sürerken ekran kapanırsa (Windows'ta F-tuşu/menüyle ekran değişimi)
  // yalnız `mounted` iken çağrılan satisGitti()/temizle() atlanıyor; sepet
  // "satış işleniyor" durumunda ve SATILMIŞ ürünlerle kalıyordu. Ödeme butonu
  // uygulama yeniden başlatılana kadar kilitli kalıyor, fiş güncellemede ise
  // aynı ürünler yeni bir satış gibi tekrar satılabiliyordu. Sepet notifier'ı
  // ve provider container'ı artık beklemelerden ÖNCE yakalanıyor; kayıt
  // kalıcı olunca sepet, ekranın durumundan bağımsız olarak boşaltılıyor.

  /// Kayıt sonrası panoyu ve (varsa) carinin detayını tazeler. Ekran kapanmış
  /// olsa da çalışır (container, ekrandan bağımsızdır).
  void _satisSonrasiYenile(ProviderContainer container, {int? cariId}) {
    container.read(dashboardProvider.notifier).yenile();
    if (cariId != null) container.invalidate(cariDetayProvider(cariId));
  }

  static String _tutarFarkiOzeti(double fark) {
    if (fark > 0) return '+${ParaUtils.formatla(fark)}';
    if (fark < 0) return '-${ParaUtils.formatla(-fark)}';
    return 'tutar değişmedi';
  }

  Future<void> _fisiGuncelle({
    String? odemeYontemi,
    double? odenenTutar,
    List<Map<String, dynamic>>? karmaKalemler,
  }) async {
    final satis = _guncellenenSatis;
    if (satis == null || satis.id == null) return;

    final sepetNotifier = ref.read(sepetProvider.notifier);
    final container = ProviderScope.containerOf(context, listen: false);
    final sepet = ref.read(sepetProvider);
    final kalemler = List<SepetKalem>.from(sepet.kalemler);
    if (kalemler.isEmpty) {
      BildirimServisi.uyari(context,
          'Sepet boş. Fişi tamamen iptal etmek için Satışlar ekranını kullanın.');
      return;
    }

    _islemBasladi();
    try {
      final kullanici = await AuthServisi().mevcutKullanici();
      if (!mounted) return; // kayıttan önce çıkıldı: hiçbir şey yazılmadı

      // Kalemler + stok farkı + cari/kasa hareketi — hepsi
      // SatisTamamlamaServisi.fisiGuncelle()'de TEK transaction'da atomik.
      final sonuc = await _satisTamamlamaServisi.fisiGuncelle(
        satis: satis,
        yeniKalemler: kalemler,
        yeniGenelToplam: sepet.genelToplam,
        kullanici: kullanici,
        musteri: sepet.musteri,
        odemeYontemi: odemeYontemi,
        odenenTutar: odenenTutar,
        karmaKalemler: karmaKalemler,
        subeId: AktifSubeServisi().subeId,
      );
      // Satışı biten alışveriş sekmesi kapanır (sekme 1 ise boşalır).
      sepetNotifier.satisTamamlandi();
      _satisSonrasiYenile(container, cariId: satis.cariId);
      if (!mounted) return;

      setState(() {
        _sonSatis = sonuc.guncelSatis; // manuel yazdırma için
        _guncellenenSatis = null;
      });
      BildirimServisi.basari(context,
          'Fiş ${sonuc.guncelSatis.fisNo ?? satis.fisNo} güncellendi (${_tutarFarkiOzeti(sonuc.tutarFarki)})');
    } catch (e) {
      if (mounted) BildirimServisi.hata(context, 'Fiş güncellenemedi: ${kullaniciyaHataMetni(e)}\n[Teknik detay: $e]');
    } finally {
      _islemBitti();
    }
  }

  Future<void> _satisiTamamla(
      String odemeYontemi, double odenenTutar, double paraUstu,
      {List<Map<String, dynamic>>? karmaKalemler}) async {
    if (!mounted) return;

    if (_guncellenenSatis != null) {
      await _fisiGuncelle(
        odemeYontemi: odemeYontemi,
        odenenTutar: odenenTutar,
        karmaKalemler: karmaKalemler,
      );
      return;
    }

    final sepetNotifier = ref.read(sepetProvider.notifier);
    final container = ProviderScope.containerOf(context, listen: false);
    final sepet = ref.read(sepetProvider);
    final musteri = sepet.musteri;
    final kalemler = List<SepetKalem>.from(sepet.kalemler);
    final genelTop = sepet.genelToplam;

    _islemBasladi();
    sepetNotifier.satisBasladi();
    try {
      final kullanici = await AuthServisi().mevcutKullanici();
      if (!mounted) return; // kayıttan önce çıkıldı: hiçbir şey yazılmadı

      // Satış kaydı + stok düşümü + kasa/cari hareketi + bulut senkronu +
      // puan — hepsi SatisTamamlamaServisi'nde (tek transaction, atomik).
      final sonuc = await _satisTamamlamaServisi.tamamla(
        kalemler:      kalemler,
        musteri:       musteri,
        genelToplam:   genelTop,
        odemeYontemi:  odemeYontemi,
        odenenTutar:   odenenTutar,
        karmaKalemler: karmaKalemler,
        kullanici:     kullanici,
        subeId:        AktifSubeServisi().subeId,
      );
      // Satış kalıcı: ekran kapanmış olsa bile sepet boşaltılır; ek
      // alışveriş sekmesiyse sekme kapanır (sekme 1 hazır bekler).
      sepetNotifier.satisTamamlandi();
      _satisSonrasiYenile(container, cariId: musteri?.id);
      _yuksekIskontoBildir(sepet, satisId: sonuc.satisId, fisNo: sonuc.fisNo);
      if (_nakitAlindi(odemeYontemi, karmaKalemler)) _kasaCekmecesiniAc();
      if (!mounted) return;

      setState(() {
        // Son satış — appBar'daki yazıcı ikonuyla manuel yazdırma için.
        // (Kullanıcı isteği: satış sonrası "Fişi Gör" bildirimi ve otomatik
        // yazdırma kaldırıldı; sepetin anında boşalması görsel onaydır.)
        _sonSatis = SatisModel(
          id: sonuc.satisId,
          fisNo: sonuc.fisNo,
          tarih: sonuc.tarih,
          odemeYontemi: odemeYontemi,
          genelToplam: genelTop,
          odenenTutar: odenenTutar,
          kalemler: sonuc.kalemler,
          cariId: musteri?.id,
          cariAdi: musteri?.unvan,
        );
        _bekleyenSayiFuture = BekleyenFislerEkrani.bekleyenSayi();
      });
    } catch (e) {
      if (mounted) BildirimServisi.hata(context, 'Satış hatası: ${kullaniciyaHataMetni(e)}');
    } finally {
      // Ekran durumundan bağımsız: kilit her koşulda açılır.
      sepetNotifier.satisGitti();
      _islemBitti();
    }
  }

  /// FAZ 9 — Onay Merkezi (bildirim tipi): satış ENGELLENMEDİ, zaten
  /// tamamlandı — genel iskonto eşiği aşıyorsa sonradan incelenebilsin diye
  /// kayda düşülür.
  void _yuksekIskontoBildir(SepetDurum sepet, {required int satisId, required String fisNo}) {
    OnayMerkeziServisi().kaydet(
      tur: OnayTuru.yuksekIskonto,
      tutar: sepet.genelIskontoYuzde,
      esikTutar: OnayEsikleri.yuksekIskontoOrani,
      referansTuru: 'satis',
      referansId: satisId,
      aciklama: 'Fiş $fisNo: %${sepet.genelIskontoYuzde.toStringAsFixed(0)} iskonto',
    );
  }

  static bool _nakitAlindi(String odemeYontemi, List<Map<String, dynamic>>? karmaKalemler) =>
      odemeYontemi == 'Nakit' ||
      (karmaKalemler?.any((k) => k['yontem'] == 'Nakit') ?? false);

  /// Windows kasa: nakit alınan satışta çekmeceyi açar (yazıcı/çekmece
  /// yoksa sessizce yok sayılır).
  static void _kasaCekmecesiniAc() {
    if (!Platform.isWindows) return;
    YazdirmaServisi().kasaCekmecesiAc().catchError((_) {});
  }

  // ── Sepet Kalem Düzenleme ────────────────────────────────────────────────────
  Future<void> _sepetKalemMiktarDuzenle(SepetKalem k, int index) async {
    if (_kgBirimMi(k.urun.birimAdi)) { await _kgIleEkle(k.urun); return; }
    _dialogAcik = true;
    _islemAktif = true;
    if (_kameraAcik) { try { _scanCtrl.stop(); } catch (e) { /* ignore */ } }

    final ctrl = TextEditingController(text: k.miktar.toInt().toString());
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(k.urun.urunAdi,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800),
          decoration: InputDecoration(
            labelText: 'Miktar',
            border: const OutlineInputBorder(),
            suffixText: k.urun.birimAdi,
          ),
          onSubmitted: (_) => Navigator.pop(ctx, true),
        ),
        actions: [
          TextButton(
            onPressed: () { _dialogAcik = false; _islemAktif = false; Navigator.pop(ctx, false); },
            child: const Text('İptal'),
          ),
          FilledButton(
            onPressed: () { _dialogAcik = false; _islemAktif = false; Navigator.pop(ctx, true); },
            child: const Text('Tamam'),
          ),
        ],
      ),
    ).whenComplete(() => dialogSonrasiBirak([ctrl]));

    // Pencere Esc/dışarı tıklamayla da kapanabilir (butonlar çalışmaz) —
    // bayraklar burada kesin sıfırlanır, yoksa Ödeme/barkod sessizce kilitlenir.
    _dialogAcik = false;
    _islemAktif = false;
    if (_kameraAcik && mounted) { try { _scanCtrl.start(); } catch (e) { /* ignore */ } }
    if (ok != true || !mounted) return;
    final yeniMiktar = ParaUtils.sayiCoz(ctrl.text);
    if (yeniMiktar == null || yeniMiktar <= 0) {
      ref.read(sepetProvider.notifier).sil(index);
    } else {
      ref.read(sepetProvider.notifier).miktarGuncelle(index, yeniMiktar);
    }
    _kuyruktakiBarkodlariIsle();
  }

  // ── Askıya Al ────────────────────────────────────────────────────────────────
  Future<void> _sepetiAlimaAktar(CariModel tedarikci) async {
    final sepet = ref.read(sepetProvider);
    if (sepet.bos || !mounted) return;

    final sepetKalemler = sepet.kalemler.map((k) => {
      'urunId':    k.urun.id,
      'urunAdi':   k.urun.urunAdi,
      'miktar':    k.miktar,
      'alisFiyat': k.urun.alisFiyat > 0 ? k.urun.alisFiyat : k.urun.satisFiyati,
    }).toList();

    ref.read(sepetProvider.notifier).temizle();
    if (!mounted) return;

    await context.push('/tedarik/alim',
        extra: {'tedarikci': tedarikci, 'kalemler': sepetKalemler});
    if (mounted) setState(() {});
  }

  Future<void> _tedarikciyeAktar() async {
    final sepet = ref.read(sepetProvider);
    if (sepet.bos || _islemAktif || _dialogAcik) return; // çift-tıklama koruması
    _islemBasladi();
    try {
      final list = await CariDeposu().tumunuGetir().then((l) => l.where((x) =>
          x.cariTipi.contains('edarik') || x.cariTipi.contains('Hem ')).toList());
      if (!mounted) { _islemBitti(); return; }
      final tedarikci = await showDialog<CariModel>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Row(children: [
            Icon(Icons.shopping_basket_outlined, color: TsRenk.vurguTurkuaz),
            SizedBox(width: 8),
            Text('Tedarikçi Seç'),
          ]),
          contentPadding: const EdgeInsets.fromLTRB(12, 16, 12, 0),
          content: SizedBox(
            width: double.maxFinite, height: 360,
            child: list.isEmpty
              ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.person_off_outlined, size: 48, color: context.textSecondary),
                  const SizedBox(height: 8),
                  Text('Tedarikçi bulunamadı', style: TextStyle(color: context.textSecondary)),
                  const SizedBox(height: 4),
                  Text('Cari menüsünden Tedarikçi ekleyin',
                      style: TextStyle(fontSize: 12, color: context.textSecondary), textAlign: TextAlign.center),
                ]))
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final t = list[i];
                    return ListTile(
                      dense: true,
                      leading: CircleAvatar(radius: 18,
                        backgroundColor: TsRenk.zemin(TsRenk.vurguTurkuaz),
                        child: Text(t.unvan.isNotEmpty ? t.unvan[0].toUpperCase() : '?',
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: TsRenk.vurguTurkuaz))),
                      title: Text(t.unvan, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      subtitle: t.telefon != null ? Text(t.telefon!) : null,
                      onTap: () => Navigator.pop(ctx, t),
                    );
                  }),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal'))],
        ),
      );
      _islemBitti();
      if (tedarikci == null || !mounted) return;
      await _sepetiAlimaAktar(tedarikci);
    } catch (e) {
      _islemBitti();
      if (mounted) BildirimServisi.hata(context, kullaniciyaHataMetni(e));
    }
  }

  Future<void> _askiyaAl() async {
    final sepet = ref.read(sepetProvider);
    if (sepet.bos || _islemAktif || _dialogAcik) return; // çift-tıklama koruması
    _islemBasladi();

    try {
      await BekleyenFislerEkrani.askiyaAl(
        sepet:   sepet.kalemler,
        musteri: sepet.musteri,
      );

      ref.read(sepetProvider.notifier).temizle();
      if (mounted) setState(() => _bekleyenSayiFuture = BekleyenFislerEkrani.bekleyenSayi());

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Satış askıya alındı'),
            backgroundColor: TsRenk.uyari,
          ),
        );
      }
    } catch (e) {
      if (kDebugMode) debugPrint('Askıya alma hatası: $e');
      if (mounted) BildirimServisi.hata(context, 'Askıya alınamadı: $e');
    } finally {
      _islemBitti();
    }
  }

}
