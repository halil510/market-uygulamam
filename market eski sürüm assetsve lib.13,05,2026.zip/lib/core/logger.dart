// Singleton logger
import 'package:logger/logger.dart';
final Logger appLogger = Logger();
