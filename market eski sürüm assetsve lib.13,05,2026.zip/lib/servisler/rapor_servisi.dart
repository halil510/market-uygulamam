import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/modeller/satis_kalem.dart';
import 'package:market_uygulamasi/repozitory/satis_repo.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:convert';
import 'package:market_uygulamasi/core/logger.dart';

class RaporServisi {
  final SatisRepository _satisRepo = SatisRepository();
  final UrunRepoSitory _urunRepo = UrunRepoSitory();
  Database? _db;

  Future<Database> _getDatabase() async {
    if (_db != null) return _db!;
    String path = join(await getDatabasesPath(), "market.db");

    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE IF NOT EXISTS gun_sonu_raporlari (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tarih TEXT,
            rapor_json TEXT
          )
        ''');
      },
    );
    return _db!;
  }

  // Güvenli parse yardımcıları
  double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  Future<Map<String, dynamic>> _raporOlustur(
      List<Satis> satislar, DateTime baslangic, DateTime bitis) async {
    double toplamTutar = 0.0;
    double nakitToplam = 0.0;
    double krediKartiToplam = 0.0;
    double tahsilatToplam = 0.0;
    double odemeToplam = 0.0;
    double toplamMaliyet = 0.0;

    final db = await _getDatabase();

    final List<Map<String, dynamic>> tahsilatlar = await db.rawQuery('''
      SELECT SUM(alacak) as toplamAlacak 
      FROM CariHareket 
      WHERE fis_tipi = 'Tahsilat' 
      AND datetime(tarih) BETWEEN datetime(?) AND datetime(?)
    ''', [baslangic.toIso8601String(), bitis.toIso8601String()]);

    final List<Map<String, dynamic>> odemeler = await db.rawQuery('''
      SELECT SUM(borc) as toplamBorc 
      FROM CariHareket 
      WHERE fis_tipi = 'Ödeme' 
      AND datetime(tarih) BETWEEN datetime(?) AND datetime(?)
    ''', [baslangic.toIso8601String(), bitis.toIso8601String()]);

    tahsilatToplam = (tahsilatlar.first['toplamAlacak'] as num?)?.toDouble() ?? 0.0;
    odemeToplam = (odemeler.first['toplamBorc'] as num?)?.toDouble() ?? 0.0;

    final tumUrunler = await _urunRepo.tumUrunleriGetir();
    final urunMap = {for (var urun in tumUrunler) urun.id!: urun};

    for (final satis in satislar) {
      if (satis.odemeYontemi == 'Nakit') {
        nakitToplam += satis.toplamTutar;
      } else if (satis.odemeYontemi == 'Kredi Kartı') {
        krediKartiToplam += satis.toplamTutar;
      }

      if (satis.fisTipi == 'Satış') {
        toplamTutar += satis.toplamTutar;
        for (SatisKalem kalem in satis.kalemler) {
          final urun = urunMap[kalem.urunId];
          if (urun != null) {
            // KDV'siz alış fiyatını kullan (varsayılan)
            double maliyet = urun.alisFiyat ?? 0.0;
            toplamMaliyet += maliyet * kalem.miktar;
          }
        }
      }
    }

    double kar = toplamTutar - toplamMaliyet;

    return {
      'satislar': satislar,
      'toplamTutar': toplamTutar,
      'nakitToplam': nakitToplam,
      'krediKartiToplam': krediKartiToplam,
      'tahsilatToplam': tahsilatToplam,
      'odemeToplam': odemeToplam,
      'kar': kar,
    };
  }

  Future<List<Satis>> gunlukSatislariGetir(DateTime tarih) async {
    final baslangic = DateTime(tarih.year, tarih.month, tarih.day);
    final bitis = DateTime(tarih.year, tarih.month, tarih.day, 23, 59, 59);
    return await _satisRepo.tariheGoreSatislariGetir(baslangic, bitis);
  }

  Future<Map<String, dynamic>> gunSonuRaporuGetir(DateTime tarih) async {
    try {
      final satislar = await gunlukSatislariGetir(tarih);
      final baslangic = DateTime(tarih.year, tarih.month, tarih.day);
      final bitis = DateTime(tarih.year, tarih.month, tarih.day, 23, 59, 59);
      return await _raporOlustur(satislar, baslangic, bitis);
    } catch (e) {
      appLogger.i('Rapor oluşturma hatası: $e');
      return {
        'satislar': [],
        'toplamTutar': 0.0,
        'nakitToplam': 0.0,
        'krediKartiToplam': 0.0,
        'tahsilatToplam': 0.0,
        'odemeToplam': 0.0,
        'kar': 0.0,
      };
    }
  }

  Future<Map<String, dynamic>> aralikRaporuGetir({
    required DateTime baslangic,
    required DateTime bitis,
  }) async {
    try {
      final adjustedBitis = bitis.hour == 0 && bitis.minute == 0
          ? DateTime(bitis.year, bitis.month, bitis.day, 23, 59, 59)
          : bitis;
      final satislar = await _satisRepo.tariheGoreSatislariGetir(baslangic, adjustedBitis);
      return await _raporOlustur(satislar, baslangic, adjustedBitis);
    } catch (e) {
      appLogger.i('Aralık rapor hatası: $e');
      return {
        'satislar': [],
        'toplamTutar': 0.0,
        'nakitToplam': 0.0,
        'krediKartiToplam': 0.0,
        'tahsilatToplam': 0.0,
        'odemeToplam': 0.0,
        'kar': 0.0,
      };
    }
  }

  Future<void> gunSonuRaporuKaydet(DateTime tarih) async {
    final rapor = await gunSonuRaporuGetir(tarih);
    final db = await _getDatabase();
    await db.insert(
      "gun_sonu_raporlari",
      {
        "tarih": tarih.toIso8601String(),
        "rapor_json": jsonEncode(rapor),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    appLogger.i("✅ Gün sonu raporu kaydedildi: ${tarih.toIso8601String()}");
  }

  Future<List<Map<String, dynamic>>> kayitliRaporlariGetir() async {
    final db = await _getDatabase();
    return await db.query("gun_sonu_raporlari", orderBy: "tarih DESC");
  }
}