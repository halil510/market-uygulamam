import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'modern_sizes.dart';

class ModernQuantitySelector extends StatelessWidget {
  final int quantity;
  final VoidCallback onIncrement;
  final VoidCallback onDecrement;
  final bool isLoading;

  const ModernQuantitySelector({
    super.key,
    required this.quantity,
    required this.onIncrement,
    required this.onDecrement,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.border),
        borderRadius: BorderRadius.circular(ModernSizes.radius),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildButton(Icons.remove, onDecrement),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(
                    quantity.toString(),
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
          ),
          _buildButton(Icons.add, onIncrement),
        ],
      ),
    );
  }

  Widget _buildButton(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(12)),
        ),
        child: Icon(icon, size: 20, color: AppColors.primary),
      ),
    );
  }
}