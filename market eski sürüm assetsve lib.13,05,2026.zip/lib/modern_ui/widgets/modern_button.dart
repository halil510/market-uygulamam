// 📁 lib/modern_ui/widgets/modern_button.dart
import 'package:flutter/material.dart';

/// Modern ve şık bir buton widget'ı
/// - Icon ve metin desteği
/// - Gölge ve yumuşak geçiş efekti
/// - Hover (üzerine gelince) ve tıklama animasyonu
class ModernButton extends StatefulWidget {
  final String text; // Buton üzerinde görünecek yazı
   final VoidCallback? onPressed; // nullable // Butona tıklanınca çalışacak fonksiyon
  final IconData? icon; // Opsiyonel ikon
  final double? width; // Buton genişliği (verilmezse otomatik)
  final List<Color>? gradientColors; // Arkaplan için gradyan renkler
  final double borderRadius; // Köşe yuvarlaklığı

  const ModernButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.icon,
    this.width,
    this.gradientColors,
    this.borderRadius = 12,
  });

  @override
  State<ModernButton> createState() => _ModernButtonState();
}

class _ModernButtonState extends State<ModernButton>
    with SingleTickerProviderStateMixin {
  bool _isHovered = false; // Üzerine gelince değişen durum

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true), // Mouse üzerine geldi
      onExit: (_) => setState(() => _isHovered = false), // Mouse ayrıldı
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250), // Geçiş animasyonu süresi
        width: widget.width ?? double.infinity, // Genişlik ayarı
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(widget.borderRadius),
          gradient: LinearGradient(
            colors: widget.gradientColors ??
                [
                  Theme.of(context).primaryColor,
                  Theme.of(context).primaryColor.withOpacity(0.8),
                ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: _isHovered
              ? [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [],
        ),
        child: Material(
          color: Colors.transparent, // Şeffaf arka plan
          child: InkWell(
            borderRadius: BorderRadius.circular(widget.borderRadius),
            onTap: widget.onPressed,
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.icon != null) ...[
                    Icon(widget.icon, size: 20, color: Colors.white),
                    const SizedBox(width: 8),
                  ],
                  Text(
                    widget.text,
                    style: Theme.of(context)
                        .textTheme
                        .labelLarge
                        ?.copyWith(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
