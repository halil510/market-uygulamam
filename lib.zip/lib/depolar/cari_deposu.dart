// lib/depolar/cari_deposu.dart
// ✅ DÜZELTİLDİ:
//   1. hareketEkle: bakiye artık trigger ile güncelleniyor (veri tutarsızlığı yok)
//   2. bakiyeYenidenHesapla metodu eklendi
//   3. Arama geliştirildi
//   4. Çift sil metodu düzeltildi
//   5. KRİTİK: hareketEkle içinde bakiye güncelleme EKLENDİ
import 'package:sqflite/sqflite.dart';
import '../cekirdek/utils/metin_arama.dart';
import 'package:uuid/uuid.dart';

import '../servisler/log_servisi.dart';
import '../servisler/bulut/bulut_manager.dart';
import '../servisler/bulut/sync_kuyruk_yazici.dart';
import '../servisler/auth_servisi.dart';
import '../veri/database/veritabani.dart';
import '../modeller/cari_model.dart';
import '../modeller/cari_hareket_model.dart';
import '../modeller/kasa_hareket_model.dart';
import '../modeller/banka_hareket_model.dart';
import '../cekirdek/utils/para_utils.dart';
import 'kasa_deposu.dart';
import 'banka_hareket_deposu.dart';
import 'kredi_karti_deposu.dart';

class CariDeposu {
  final Veritabani _db = Veritabani();
  Future<Database> get _d async => _db.db;

  // Kullanıcı isteği: "toptan satış — Ülker gibi firmaların kullandığı
  // profesyonel sistem." Araştırma sonucu: kredi limiti/risk limiti
  // kontrolü, B2B toptan satış sistemlerinin olmazsa olmazı.
  //
  // 🔴 ÖNEMLİ BULGU: CariModel'de 'limitTutari' alanı ZATEN VARDI ve
  // ekranda GÖSTERİLİYORDU ama HİÇBİR YERDE KONTROL EDİLMİYORDU —
  // yani bir cariye "5.000 TL limit" yazsanız bile, satış sırasında
  // bu limit hiçbir şekilde uygulanmıyordu. Artık bu fonksiyon, yeni
  // bir satış öncesi çağrılarak limit aşımını tespit ediyor.
  //
  // NOT: Bilinçli olarak sert bir ENGELLEME değil, UYARI döndürüyor —
  // çağıran ekran, kullanıcıya onay sorup devam etmesine izin
  // verebilir (birçok işletme "limit aşıldı ama güvenilir müşteri,
  // yine de satayım" esnekliğini ister).
  Future<({bool asildi, double mevcutBakiye, double limit, double asimTutari})>
      limitKontrolEt(int cariId, double eklenecekTutar) async {
    try {
      final cari = await idileGetir(cariId);
      if (cari == null || cari.limitTutari <= 0) {
        // Limit hiç tanımlanmamışsa (0 veya negatif) kontrol devre dışı.
        return (asildi: false, mevcutBakiye: cari?.bakiye ?? 0.0, limit: 0.0, asimTutari: 0.0);
      }
      final yeniBakiye = cari.bakiye + eklenecekTutar;
      final asildi = yeniBakiye > cari.limitTutari;
      return (
        asildi: asildi,
        mevcutBakiye: cari.bakiye,
        limit: cari.limitTutari,
        asimTutari: asildi ? yeniBakiye - cari.limitTutari : 0.0,
      );
    } catch (e, st) {
      LogServisi().hata('Cari.limitKontrolEt', hata: e, yigin: st);
      return (asildi: false, mevcutBakiye: 0.0, limit: 0.0, asimTutari: 0.0);
    }
  }

  /// Kullanıcı sorusu: "2 mobil cihaz var, orada da aynı kodu atadı,
  /// veritabanı tek, o zaman nasıl olacak?" — İki cihaz İNTERNETSİZ
  /// (veya henüz senkronize olmadan) aynı anda yeni cari eklerse,
  /// ikisi de kendi yerel verisine bakıp AYNI "sıradaki numarayı"
  /// hesaplayabilir — bu, gerçek zamanlı koordinasyon olmadan
  /// %100 önlenemeyen, dağıtık sistemlerin bilinen bir sorunudur.
  ///
  /// Gerçek kimlik zaten `global_id` (UUID) — o her zaman benzersiz.
  /// `cari_kodu` sadece görünen bir etiket. Bu fonksiyon, senkronizasyon
  /// SONRASI çağrılarak aynı kodu taşıyan (ama global_id'si FARKLI,
  /// yani gerçekten farklı) carileri tespit edip, en eski olan HARİÇ
  /// diğerlerine otomatik yeni, benzersiz bir kod veriyor — kullanıcı
  /// hiçbir şey yapmadan, sessizce düzeltiliyor.
  Future<int> mukerrerKodlariDuzelt() async {
    try {
      final db = await _d;
      final mukerrerler = await db.rawQuery('''
        SELECT cari_kodu FROM cari
        WHERE cari_kodu IS NOT NULL AND is_deleted = 0
        GROUP BY cari_kodu HAVING COUNT(*) > 1
      ''');
      var duzeltilen = 0;
      for (final grup in mukerrerler) {
        final kod = grup['cari_kodu'] as String;
        // Aynı kodu taşıyan tüm carileri, oluşturulma tarihine göre
        // eskiden yeniye sırala — en eski kodu korur, diğerleri
        // yeniden numaralanır.
        // 🔴 DÜZELTME (2026-09-27, çoklu terminal): ikincil sıralama
        // ÖNCEDEN yerel 'id' idi — id her kasada farklı olduğundan iki kasa
        // AYNI çakışmada FARKLI cariyi "asıl" sayıp birbirinin tersini
        // yeniden adlandırabiliyordu. global_id her kasada aynıdır.
        // Ayrıca yeni kod ÖNCEDEN buluta hiç gönderilmiyordu (her kasa
        // kendi başına, farklı kodlarla düzeltiyordu) — artık gönderiliyor.
        final ayniKodlular = await db.query('cari',
            where: 'cari_kodu = ? AND is_deleted = 0', whereArgs: [kod],
            orderBy: 'olusturma_tarihi ASC, global_id ASC');
        for (var i = 1; i < ayniKodlular.length; i++) {
          final yeniNo = await sonrakiCariNo();
          final id = ayniKodlular[i]['id'];
          await db.update('cari', {
            'cari_kodu': 'CARIO-$yeniNo',
            'last_updated': DateTime.now().toIso8601String(),
          }, where: 'id = ?', whereArgs: [id]);
          final satir = await db.query('cari', where: 'id = ?', whereArgs: [id], limit: 1);
          if (satir.isNotEmpty) {
            BulutManager().upsert('cari', Map<String, dynamic>.from(satir.first));
          }
          duzeltilen++;
        }
      }
      if (duzeltilen > 0) {
        LogServisi().bilgi('$duzeltilen mükerrer cari kodu otomatik düzeltildi');
      }
      return duzeltilen;
    } catch (e, st) {
      LogServisi().hata('Cari.mukerrerKodlariDuzelt', hata: e, yigin: st);
      return 0;
    }
  }

  Future<int> ekle(CariModel cari) async {
    try {
      final db = await _d;
      final m = cari.toMap();
      m.remove('id');
      m['global_id'] ??= const Uuid().v4();
      // Otomatik cari kodu üret (boşsa) — artık gerçekten benzersiz
      // olan sonrakiCariNo() kullanılıyor (bkz. o fonksiyondaki not).
      if (!m.containsKey('cari_kodu') || m['cari_kodu'] == null) {
        final no = await sonrakiCariNo();
        m['cari_kodu'] = 'CARIO-$no';
      }
      final id = await db.insert('cari', m);
      // 🔴 Derin analizde bulundu: bu fonksiyon dosyadaki TEK yazma
      // metoduydu ve yeni kaydı buluta hiç bildirmiyordu — bir işlem
      // görmeden önce bir cari asla diğer cihazlara/Supabase'e ulaşmıyordu.
      final yeniSatir = await db.query('cari', where: 'id = ?', whereArgs: [id], limit: 1);
      if (yeniSatir.isNotEmpty) {
        BulutManager().upsert('cari', Map<String, dynamic>.from(yeniSatir.first));
      }
      return id;
    } catch (e, st) {
      LogServisi().hata('Cari.ekle', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<void> guncelle(CariModel cari) async {
    try {
      final db = await _d;
      final m = cari.toMap();
      // 🔴 DÜZELTME (Madde 9 — Cari Mutabakat denetimi, 2026-09-16):
      // 'bakiye' ÖNCEDEN bu profil-düzenleme metoduyla da yazılıyordu —
      // ama kanonik bakiye cari_hareket toplamından bir DB trigger'ı
      // (trg_cari_hareket_bakiye) ile hesaplanır, hiçbir uygulama
      // kodunun doğrudan yazmaması gerekir. Somut bozulma senaryosu:
      // kullanıcı bir cariyi düzenlemek için ekranı açar (bakiyesi o an
      // belleğe okunur), form açıkken BAŞKA bir cihazdan/şubeden aynı
      // cariye satış/tahsilat girilirse trigger bakiyeyi günceller —
      // ama kullanıcı "Kaydet"e basınca elindeki BAYAT bakiye değeri bu
      // TAZE değerin üzerine yazılır (kayıp güncelleme / stale-read
      // race). 'bakiye' artık bu yazımdan tamamen çıkarıldı.
      m.remove('bakiye');
      m['last_updated'] = DateTime.now().toIso8601String();
      await db.update('cari', m, where: 'id = ?', whereArgs: [cari.id]);
      final guncelSatir = await db.query('cari', where: 'id = ?', whereArgs: [cari.id], limit: 1);
      if (guncelSatir.isNotEmpty) {
        BulutManager().upsert('cari', Map<String, dynamic>.from(guncelSatir.first));
      }
    } catch (e, st) {
      LogServisi().hata('Cari.guncelle', hata: e, yigin: st);
      rethrow;
    }
  }

  /// GİB mükellef sorgusu sonucunu (efatura/earsiv/null) önbelleğe alır —
  /// her fatura kesiminde tekrar sorgulamamak için.
  Future<void> mukellefDurumuGuncelle(int cariId, String? durum) async {
    try {
      final db = await _d;
      final now = DateTime.now().toIso8601String();
      await db.update('cari', {
        'mukellef_durumu': durum,
        'mukellef_sorgu_tarihi': now,
        'last_updated': now,
      }, where: 'id = ?', whereArgs: [cariId]);
      final guncelSatir = await db.query('cari', where: 'id = ?', whereArgs: [cariId], limit: 1);
      if (guncelSatir.isNotEmpty) {
        BulutManager().upsert('cari', Map<String, dynamic>.from(guncelSatir.first));
      }
    } catch (e, st) {
      LogServisi().hata('Cari.mukellefDurumuGuncelle', hata: e, yigin: st);
    }
  }

  Future<void> sil(int id) async {
    try {
      final db = await _d;
      final now = DateTime.now().toIso8601String();
      // 🔴 ÖNEMLİ DÜZELTME: silinen bir cari (müşteri/tedarikçi)
      // önceden diğer cihazlarda aktif görünmeye devam ederdi.
      await db.update('cari', {'is_deleted': 1, 'last_updated': now},
          where: 'id = ?', whereArgs: [id]);
      final guncelSatir = await db.query('cari', where: 'id = ?', whereArgs: [id], limit: 1);
      if (guncelSatir.isNotEmpty) {
        BulutManager().upsert('cari', Map<String, dynamic>.from(guncelSatir.first));
      }
    } catch (e, st) {
      LogServisi().hata('Cari.sil', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<CariModel?> idileGetir(int id) async {
    try {
      final db = await _d;
      final rows = await db.query('cari',
          where: 'id = ? AND is_deleted = 0', whereArgs: [id]);
      if (rows.isEmpty) return null;
      return CariModel.fromMap(rows.first);
    } catch (e, st) {
      LogServisi().hata('Cari.idileGetir', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<List<CariModel>> tumunuGetir({String? tip, int limit = 500}) async {
    try {
      final db = await _d;
      // 🔴 DÜZELTME: 'cari_tipi = ?' TAM eşleşme kullanıyordu — bu
      // yüzden "Hem Müşteri Hem Tedarikçi" tipindeki bir cari, ne
      // "Müşteri" sekmesinde ne "Tedarikçi" sekmesinde HİÇ
      // görünmüyordu (istatistikler()'de bulduğum AYNI hata sınıfı).
      // LIKE ile her iki kategoriye de dahil ediliyor.
      final where = tip != null
          ? 'cari_tipi LIKE ? AND is_deleted = 0 AND aktif = 1'
          : 'is_deleted = 0 AND aktif = 1';
      final args = tip != null ? ['%$tip%'] : null;
      // ÖNCEDEN "limit" parametresi TANIMLIYDI ama sorguda hiç
      // KULLANILMIYORDU — bu fonksiyon her zaman TÜM kayıtları
      // getiriyordu (limit'in hiçbir etkisi yoktu). Çok sayıda cari
      // olan bir işletmede (binlerce kayıt) bu, Cari Liste ekranının
      // yavaşlamasına/donmasına yol açabilirdi. Artık gerçekten
      // uygulanıyor.
      final rows = await db.query('cari',
          where: where, whereArgs: args, orderBy: 'unvan ASC', limit: limit);
      return rows.map(CariModel.fromMap).toList();
    } catch (e, st) {
      LogServisi().hata('Cari.metod', hata: e, yigin: st);
      rethrow;
    }
  }

  // 🔴 DEEP_AUDIT (kendi-keşif turu, 2026-09-21 — FAZ 4 devir mekanizması
  // ikinci-göz denetimi): DonemDevirServisi._cariSnapshotAl() (yıl sonu
  // devir kapanış anlık görüntüsü) bu dosyadaki tumunuGetir()'i
  // kullanıyordu — o metod is_deleted=0 AND aktif=1 filtreli. Ama
  // DonemArsivServisi.aktifTablolardanSilVeAcilisYaz() silinecek cari
  // kimliklerini DOĞRUDAN cari_hareket'ten (FİLTRESİZ) topluyor. Sonuç:
  // dönem içinde hareketi olan ama devir anında pasif/silinmiş bir cari
  // varsa, hareketleri silinirdi ama hiç kapanış snapshot'ı (dolayısıyla
  // "kalan bakiye" açılış satırı) alamazdı — o cari daha sonra tekrar
  // aktif edilirse bakiyeMutabakatYap() kalıcı olarak yanlış hesaplardı.
  // Bu metod SADECE devir/arşiv gibi "eksiksiz olmalı" senaryoları için —
  // normal ekranlar (Cari Liste vb.) tumunuGetir()'i kullanmaya devam eder.
  Future<List<CariModel>> tumunuGetirFiltresiz() async {
    try {
      final db = await _d;
      final rows = await db.query('cari', orderBy: 'id ASC');
      return rows.map(CariModel.fromMap).toList();
    } catch (e, st) {
      LogServisi().hata('Cari.tumunuGetirFiltresiz', hata: e, yigin: st);
      rethrow;
    }
  }

  /// Cari kodundan TAM eşleşmeyle cari bulur — Excel içe aktarımda
  /// "bu cari kodu zaten kayıtlı mı" (güncelle-veya-yeni-ekle) kararı
  /// için. cari_kodu sütunu COLLATE NOCASE olduğundan bu eşleşme
  /// otomatik olarak büyük/küçük harf duyarsızdır.
  Future<CariModel?> kodlaGetir(String kod) async {
    try {
      final db = await _d;
      final rows = await db.query('cari',
          where: 'cari_kodu = ? AND is_deleted = 0', whereArgs: [kod], limit: 1);
      return rows.isEmpty ? null : CariModel.fromMap(rows.first);
    } catch (e, st) {
      LogServisi().hata('Cari.kodlaGetir', hata: e, yigin: st);
      rethrow;
    }
  }

  /// Aynı unvanlı (büyük/küçük harf ve fazla boşluk duyarsız) aktif cari var mı?
  /// Excel içe aktarmada, kodu farklı yazılmış (ör. CARI0 / CARIO) ya da
  /// henüz buluttan çekilmemiş kopya carileri yakalamak için.
  Future<CariModel?> unvanlaGetir(String unvan) async {
    try {
      final db = await _d;
      final rows = await db.query('cari',
          where: 'UPPER(TRIM(unvan)) = UPPER(TRIM(?)) AND is_deleted = 0',
          whereArgs: [unvan.replaceAll(RegExp(r'\s+'), ' ')],
          limit: 1);
      return rows.isEmpty ? null : CariModel.fromMap(rows.first);
    } catch (e, st) {
      LogServisi().hata('Cari.unvanlaGetir', hata: e, yigin: st);
      rethrow;
    }
  }

  /// Excel dışa aktarım için: TÜM carileri (pasif dahil), her birinin
  /// toplam borç/alacak tutarı (cari_hareket'ten SUM) ve varsayılan
  /// adresiyle birlikte döner. cari.bakiye zaten (borç-alacak) olduğu
  /// için ayrıca hesaplamaya gerek yok, satır olarak da dönüyor.
  Future<List<Map<String, dynamic>>> tumunuBorcAlacakAdresIle() async {
    try {
      final db = await _d;
      return await db.rawQuery('''
        SELECT c.*,
          COALESCE(h.toplam_borc, 0) AS toplam_borc,
          COALESCE(h.toplam_alacak, 0) AS toplam_alacak,
          ca.adres AS adres
        FROM cari c
        LEFT JOIN (
          SELECT cari_id, SUM(borc) AS toplam_borc, SUM(alacak) AS toplam_alacak
          FROM cari_hareket WHERE is_deleted = 0 GROUP BY cari_id
        ) h ON h.cari_id = c.id
        LEFT JOIN cari_adres ca ON ca.cari_id = c.id AND ca.varsayilan = 1
        WHERE c.is_deleted = 0
        ORDER BY c.unvan ASC
      ''');
    } catch (e, st) {
      LogServisi().hata('Cari.tumunuBorcAlacakAdresIle', hata: e, yigin: st);
      rethrow;
    }
  }

  // 🔴 DÜZELTME (performans denetiminde bulundu): urunler.ara()'nın
  // aksine bu fonksiyonun hiç LIMIT'i yoktu — büyük bir cari tabanında
  // (binlerce müşteri/tedarikçi) kısa/genel bir arama terimi TÜM
  // eşleşen satırları tek seferde belleğe çekebiliyordu.
  // tumunuGetir()'deki AYNI varsayılan (500) ile tutarlı tutuldu.
  Future<List<CariModel>> ara(String sorgu, {String? tip, int limit = 500}) async {
    try {
      if (sorgu.isEmpty) return await tumunuGetir(tip: tip, limit: limit);
      final db = await _d;
      final q = '%${aramaNormalize(sorgu)}%';
      // 🔴 DÜZELTME: 'cari_tipi = ...' hem TAM eşleşme (dual-tip
      // carileri dışlıyordu, tumunuGetir()'deki AYNI hata) hem de
      // doğrudan string enjeksiyonuydu (parametreli değildi) hem de
      // 'aktif = 1' filtresi eksikti (tumunuGetir ile tutarsız).
      final params = <Object?>[q, q, q, q, q];
      final tipFilt = tip != null ? " AND cari_tipi LIKE ?" : '';
      if (tip != null) params.add('%$tip%');
      params.add(limit);
      final rows = await db.rawQuery(
        '''SELECT * FROM cari
           WHERE (${aramaSqlKolon('unvan')} LIKE ? OR ${aramaSqlKolon('cari_kodu')} LIKE ? OR telefon LIKE ? OR vergi_no LIKE ? OR ${aramaSqlKolon('email')} LIKE ?)
           AND is_deleted = 0 AND aktif = 1$tipFilt
           ORDER BY unvan ASC LIMIT ?''',
        params,
      );
      return rows.map(CariModel.fromMap).toList();
    } catch (e, st) {
      LogServisi().hata('Cari.metod', hata: e, yigin: st);
      rethrow;
    }
  }

  /// ÖNCEDEN BURADA, bu oturumda fatura numarasında bulup düzelttiğim
  /// AYNI hata sınıfı vardı: `COUNT(*)+1` kullanılıyordu — bu, cari
  /// SİLİNDİĞİNDE (sayı azalır, eski bir kod tekrar üretilir) VEYA
  /// senkronizasyon sonrası (başka cihazlardan gelen cariler sayıyı
  /// etkiler ama kodun kendisini değil) MÜKERRER "CARIO-N" kodları
  /// üretiyordu — kullanıcının paylaştığı gerçek veride 3 farklı
  /// müşterinin "CARIO-1" koduna sahip olması tam olarak buydu. Artık
  /// veritabanında KAYITLI EN YÜKSEK "CARIO-N" numarası bulunup bir
  /// fazlası veriliyor — gerçekten benzersiz.
  Future<int> sonrakiCariNo() async {
    try {
      final db = await _d;
      final rows = await db.rawQuery(
        "SELECT cari_kodu FROM cari WHERE cari_kodu LIKE 'CARIO-%' "
        "ORDER BY CAST(SUBSTR(cari_kodu, 7) AS INTEGER) DESC LIMIT 1",
      );
      if (rows.isEmpty) return 1;
      final kod = rows.first['cari_kodu'] as String?;
      final sayiKismi = kod?.replaceFirst('CARIO-', '');
      final sonNo = int.tryParse(sayiKismi ?? '') ?? 0;
      return sonNo + 1;
    } catch (e, st) {
      LogServisi().hata('Cari.sonrakiCariNo', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<void> bakiyeGuncelle(int cariId) async {
    try {
      final db = await _d;
      await db.rawUpdate(
        'UPDATE cari SET bakiye = ROUND((SELECT COALESCE(SUM(borc),0) - COALESCE(SUM(alacak),0) FROM cari_hareket WHERE cari_id = ? AND is_deleted = 0), 2) WHERE id = ?',
        [cariId, cariId]);
      final satir = await db.query('cari', where: 'id = ?', whereArgs: [cariId], limit: 1);
      if (satir.isNotEmpty) {
        BulutManager().upsert('cari', Map<String, dynamic>.from(satir.first));
      }
    } catch (e, st) {
      LogServisi().hata('Cari.bakiyeGuncelle', hata: e, yigin: st);
      rethrow;
    }
  }

  // ✅ DÜZELTİLDİ: hareket ekledikten sonra bakiye güncelleniyor
  Future<void> hareketEkle(CariHareketModel hareket) async {
    try {
      final db = await _d;
      final globalId = await db.transaction((txn) => hareketEkleTxn(txn, hareket));
      final hareketSatir = await db.query('cari_hareket',
          where: 'global_id = ?', whereArgs: [globalId], limit: 1);
      if (hareketSatir.isNotEmpty) {
        BulutManager().upsert('cari_hareket', Map<String, dynamic>.from(hareketSatir.first));
      }
      final cariSatir = await db.query('cari', where: 'id = ?', whereArgs: [hareket.cariId], limit: 1);
      if (cariSatir.isNotEmpty) {
        BulutManager().upsert('cari', Map<String, dynamic>.from(cariSatir.first));
      }
    } catch (e, st) {
      LogServisi().hata('Cari.hareketEkle', hata: e, yigin: st);
      rethrow;
    }
  }

  /// [hareketEkle] ile AYNI mantık, VERİLEN transaction içinde çalışır —
  /// kendi transaction'ını açmaz. BulutManager bildirimi YAPMAZ (dış
  /// transaction commit olmadan buluta göndermek riskli — bkz. KasaDeposu
  /// .hareketEkleTxn'deki aynı not). Bildirim çağıranın sorumluluğunda.
  /// Geriye eklenen kaydın global_id'sini döner — çağıran bu id ile
  /// transaction kapandıktan sonra TAM OLARAK eklenen satırı bulabilir.
  Future<String> hareketEkleTxn(dynamic txn, CariHareketModel hareket) async {
    final hm = hareket.toMap();
    hm.remove('id');
    final globalId = (hm['global_id'] as String?) ?? const Uuid().v4();
    hm['global_id'] = globalId;
    await txn.insert('cari_hareket', hm);
    await txn.rawUpdate('''
      UPDATE cari SET bakiye = ROUND((SELECT COALESCE(SUM(borc), 0) - COALESCE(SUM(alacak), 0)
        FROM cari_hareket WHERE cari_id = ? AND is_deleted = 0
      ), 2) WHERE id = ?
    ''', [hareket.cariId, hareket.cariId]);
    // Madde 5 sertleştirmesi: hareket kaydı VE etkilediği cari bakiyesi
    // AYNI transaction içinde kuyruğa yazılıyor — ikisi de business
    // data ile atomik (bkz. SyncKuyrukYazici yorumu).
    await SyncKuyrukYazici.ekleTxn(txn, tablo: 'cari_hareket', veri: hm);
    final guncelCariSatiri = await txn.query('cari',
        where: 'id = ?', whereArgs: [hareket.cariId], limit: 1);
    if (guncelCariSatiri.isNotEmpty) {
      await SyncKuyrukYazici.ekleTxn(txn,
          tablo: 'cari', veri: Map<String, dynamic>.from(guncelCariSatiri.first));
    }
    return globalId;
  }

  Future<void> bakiyeYenidenHesapla(int cariId) async {
    try {
      final db = await _d;
      // 🔴🔴 KRİTİK DÜZELTME (kullanıcı isteği — "veri sağlığı merkezine
      // düzgün bak"): StokDeposu.stokMutabakatYap()'ta AYNI hata sınıfı
      // daha önce bulunup düzeltilmişti ama buraya (Cari Mutabakat)
      // hiç uygulanmamıştı — last_updated hiç bümlenmiyor, BulutManager
      // hiç çağrılmıyordu. Sonuç: Veri Sağlığı Merkezi'nden "Cari
      // Mutabakat" düzeltmesi çalıştırıldığında, düzeltilen bakiye
      // SADECE bu cihazda kalıyordu — normal "Hızlı Gönder" (delta,
      // last_updated'a bakar) bunu ASLA yakalamıyor, diğer cihazlar/
      // bulut hâlâ eski (hatalı) bakiyeyi görmeye devam ediyordu.
      final now = DateTime.now().toIso8601String();
      await db.rawUpdate('''
        UPDATE cari SET bakiye = ROUND((SELECT COALESCE(SUM(borc), 0) - COALESCE(SUM(alacak), 0)
          FROM cari_hareket WHERE cari_id = ? AND is_deleted = 0
        ), 2), last_updated = ? WHERE id = ?
      ''', [cariId, now, cariId]);
      final satir = await db.query('cari', where: 'id = ?', whereArgs: [cariId], limit: 1);
      if (satir.isNotEmpty) {
        BulutManager().upsert('cari', Map<String, dynamic>.from(satir.first));
      }
    } catch (e, st) {
      LogServisi().hata('Cari.bakiyeYenidenHesapla', hata: e, yigin: st);
      rethrow;
    }
  }

  /// Veri Sağlığı Merkezi (protokol §13/§8) için: HER carinin bakiyesini
  /// cari_hareket'ten yeniden hesaplayıp gerçekte tutmayanları düzeltir.
  /// stokMutabakatYap() ile aynı desen — hangi sırayla senkron olursa
  /// olsun sonuç her zaman doğru olur.
  Future<int> bakiyeMutabakatYap() async {
    try {
      final db = await _d;
      final uyumsuzlar = await db.rawQuery('''
        SELECT c.id FROM cari c
        WHERE c.is_deleted = 0 AND ABS(c.bakiye - (
          SELECT COALESCE(SUM(borc), 0) - COALESCE(SUM(alacak), 0)
          FROM cari_hareket WHERE cari_id = c.id AND is_deleted = 0
        )) > 0.01
      ''');
      for (final r in uyumsuzlar) {
        await bakiyeYenidenHesapla(r['id'] as int);
      }
      return uyumsuzlar.length;
    } catch (e, st) {
      LogServisi().hata('Cari.bakiyeMutabakatYap', hata: e, yigin: st);
      rethrow;
    }
  }

  /// Yalnızca SAYIYI döner, düzeltme yapmaz — Veri Sağlığı Merkezi'nde
  /// "kontrol et" adımında (henüz düzeltme onayı almadan) durumu
  /// göstermek için.
  Future<int> bakiyeUyumsuzlukSayisi() async {
    try {
      final db = await _d;
      final rows = await db.rawQuery('''
        SELECT COUNT(*) as n FROM cari c
        WHERE c.is_deleted = 0 AND ABS(c.bakiye - (
          SELECT COALESCE(SUM(borc), 0) - COALESCE(SUM(alacak), 0)
          FROM cari_hareket WHERE cari_id = c.id AND is_deleted = 0
        )) > 0.01
      ''');
      return (rows.first['n'] as int?) ?? 0;
    } catch (e, st) {
      LogServisi().hata('Cari.bakiyeUyumsuzlukSayisi', hata: e, yigin: st);
      rethrow; // 0 dönmek Veri Sağlığı'nda sahte "uyumlu" gösteriyordu
    }
  }

  Future<List<CariHareketModel>> hareketleriniGetir(int cariId,
      {DateTime? basTarih, DateTime? bitTarih, String? fisTipi, int limit = 100}) async {
    final db = await _d;
    final whereParts = ['cari_id = ?', 'is_deleted = 0'];
    final args = <dynamic>[cariId];

    if (basTarih != null) {
      whereParts.add('datetime(tarih) >= datetime(?)');
      args.add(basTarih.toIso8601String());
    }
    if (bitTarih != null) {
      whereParts.add('datetime(tarih) <= datetime(?)');
      args.add(bitTarih.toIso8601String());
    }
    if (fisTipi != null) {
      whereParts.add('fis_tipi = ?');
      args.add(fisTipi);
    }

    final rows = await db.rawQuery(
      'SELECT * FROM cari_hareket WHERE ${whereParts.join(' AND ')} ORDER BY tarih DESC LIMIT $limit',
      args,
    );
    return rows.map(CariHareketModel.fromMap).toList();
  }

  /// Ekstre için DEVREDEN bakiye: [tarih]ten ÖNCEKİ tüm (iptal edilmemiş)
  /// hareketlerin borç − alacak toplamı. Listeleme limitinden bağımsız,
  /// doğrudan SQL ile.
  Future<double> devredenBakiye(int cariId, DateTime tarih) async {
    final db = await _d;
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(borc),0) - COALESCE(SUM(alacak),0) AS b
      FROM cari_hareket
      WHERE cari_id = ? AND is_deleted = 0 AND datetime(tarih) < datetime(?)
    ''', [cariId, tarih.toIso8601String()]);
    return (rows.first['b'] as num?)?.toDouble() ?? 0;
  }

  /// Belirli bir cari_hareket satırının YAZILDIĞI ANDAKİ bakiyesini
  /// (sonBakiye) ve ondan hemen önceki bakiyesini (oncekiBakiye) geriye
  /// dönük hesaplar — makbuz YENİDEN yazdırma için (kullanıcı isteği
  /// 2026-09-22: Cari Hareketler'den bir Tahsilat/Ödeme'yi seçip tekrar
  /// bastırabilme). Sıralama, hareketleriniGetir()'deki (tarih DESC)
  /// ile TUTARLI olsun diye 'tarih, sonra id' kullanır.
  Future<({double oncekiBakiye, double sonBakiye})> bakiyeHareketAninda(
      CariHareketModel h) async {
    final db = await _d;
    final tarihStr = h.tarih.toIso8601String();
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(borc),0) - COALESCE(SUM(alacak),0) AS b
      FROM cari_hareket
      WHERE cari_id = ? AND is_deleted = 0
        AND (datetime(tarih) < datetime(?) OR (datetime(tarih) = datetime(?) AND id <= ?))
    ''', [h.cariId, tarihStr, tarihStr, h.id]);
    final sonBakiye = (rows.first['b'] as num?)?.toDouble() ?? 0;
    final oncekiBakiye = sonBakiye - (h.borc - h.alacak);
    return (oncekiBakiye: oncekiBakiye, sonBakiye: sonBakiye);
  }

  /// Bir cari hareketi iptal eder: orijinal kayıt SOFT-DELETE edilir
  /// (is_deleted=1, hard-delete edilmez — bulut senkron için gerekli),
  /// audit-trail amaçlı borc=0/alacak=0 bir "... İptali" kaydı eklenir,
  /// bakiye hareketlerden yeniden hesaplanır (her zaman is_deleted=0
  /// filtresiyle — kanonik kural), ve varsa bağlı (referans_turu=
  /// 'cari_hareket') NAKİT kasa/Banka/Kredi Kartı hareketi otomatik ters
  /// çevrilir.
  ///
  /// 🔴 DEEP_AUDIT (kendi-keşif turu, 2026-09-21): Banka/Kredi Kartı
  /// tarafı ÖNCEDEN otomatik geri alınmıyordu (bilinçli, dokümante
  /// edilmiş bir sınırlamaydı — o tabloların referans_id/referans_turu
  /// kolonu HİÇ yoktu, bu yüzden hangi satırın iptal edilen cari
  /// hareketine ait olduğu güvenilir şekilde bulunamıyordu). Migrasyon
  /// v72 bu kolonları ekledi, CariTahsilatOdemeServisi.kaydet() artık
  /// bunları dolduruyor — artık kasa ile AYNI desende otomatik tersine
  /// çevriliyor.
  ///
  /// Ters kaydın borc=0/alacak=0 olması BİLİNÇLİDİR: orijinal kayıt zaten
  /// bakiye SUM'ından (is_deleted=0 filtresiyle) dışlandığı için, sıfır
  /// olmayan bir ters tutar eklemek bakiyeyi orijinal tutarın TERSİ kadar
  /// kaydırırdı (10 TL'lik hareket silinince bakiye 0'a değil +10'a giderdi).
  Future<void> hareketIptalEt(CariHareketModel h) async {
    if (h.id == null) throw Exception('Hareket id boş olamaz');
    try {
      final db = await _d;
      String? tersCariGid;
      int? tersKasaId;
      int? tersBankaId;
      int? tersKrediId;
      await db.transaction((txn) async {
        final guncelRows = await txn
            .query('cari_hareket', where: 'id = ?', whereArgs: [h.id]);
        if (guncelRows.isEmpty) throw Exception('Hareket bulunamadı');
        final guncel = guncelRows.first;
        if ((guncel['is_deleted'] as int? ?? 0) == 1) {
          throw Exception('Bu hareket zaten iptal edilmiş');
        }
        // 🔴 DÜZELTME (kullanıcı bulgusu, 2026-09-21 — ekran görüntüsü:
        // cari kartında "Tahsilat İptali İptali İptali" diye üç kere
        // üst üste yapışmış, tutarı ₺0,00 bir hareket): bu fonksiyon
        // KENDİSİNİN oluşturduğu ters kayıt (fis_tipi sonu "İptali" ile
        // biten satır) üzerinde TEKRAR çağrılabiliyordu — is_deleted
        // kontrolü SADECE aynı kaydı ikinci kez iptal etmeyi engelliyordu,
        // bir iptal kaydının ÜZERİNE bina edilen YENİ bir iptal kaydını
        // engellemiyordu. Kullanıcı, aynı satırı temizlemeye çalışırken
        // her tıklamada bir öncekini gizleyip üzerine "İptali" ekleyen
        // yeni, ₺0 tutarlı bir hayalet satır oluşuyordu. Bir ters kayıt
        // zaten bakiyeye 0 etki eder (borc=alacak=0) — onu "iptal etmek"
        // anlamsızdır, artık açıkça engelleniyor.
        final mevcutFisTipi = guncel['fis_tipi'] as String? ?? '';
        if (mevcutFisTipi.endsWith('İptali')) {
          throw Exception(
              'Bu kayıt zaten bir iptal/ters kaydıdır, tekrar iptal edilemez.');
        }
        // Belge kökenli hareket bu genel iptalle silinirse yalnız cari geri
        // döner, stok/belge bozuk kalır — kendi iptal akışı kullanılmalı
        // (IadeIslemServisi.tedarikciIadesiniIptalEt).
        if (mevcutFisTipi == 'Tedarikçi İadesi') {
          throw Exception('Bu hareket bir tedarikçi iadesinden geliyor — '
              'iadenin kendisi iptal edilmeli (stok da geri yüklenir).');
        }
        final now = DateTime.now().toIso8601String();

        await txn.update('cari_hareket',
            {'is_deleted': 1, 'last_updated': now},
            where: 'id = ?', whereArgs: [h.id]);

        final tersGid = const Uuid().v4();
        await txn.insert('cari_hareket', {
          'global_id': tersGid,
          'cari_id': h.cariId,
          'tarih': now,
          'fis_tipi': '${h.fisTipi} İptali',
          'fis_id': h.id,
          'fis_no': h.fisNo,
          'aciklama': 'İptal: ${h.aciklama} '
              '(${ParaUtils.formatla(h.borc > 0 ? h.borc : h.alacak)})',
          'borc': 0,
          'alacak': 0,
          'odeme_turu': h.odemeTuru,
          'kullanici': AuthServisi().aktifAd,
          'last_updated': now,
          'is_deleted': 0,
        });
        tersCariGid = tersGid;

        await txn.rawUpdate('''
          UPDATE cari SET bakiye = ROUND((SELECT COALESCE(SUM(borc),0) - COALESCE(SUM(alacak),0)
            FROM cari_hareket WHERE cari_id = ? AND is_deleted = 0
          ), 2), last_updated = ?
          WHERE id = ?
        ''', [h.cariId, now, h.cariId]);

        final kasaRows = await txn.query('kasa_hareketleri',
            where:
                'referans_turu = ? AND referans_id = ? AND deleted_at IS NULL',
            whereArgs: ['cari_hareket', h.id]);
        if (kasaRows.isNotEmpty) {
          final orijinalKasa = kasaRows.first;
          final orijinalTip = orijinalKasa['hareket_tipi'] as String? ?? '';
          final orijinalTutar =
              (orijinalKasa['tutar'] as num?)?.toDouble() ?? 0;
          final tersTip = orijinalTip == 'Tahsilat'
              ? 'Tahsilat İptali'
              : orijinalTip == 'Ödeme'
                  ? 'Ödeme Girişi'
                  : null;
          if (tersTip != null && orijinalTutar > 0) {
            tersKasaId = await KasaDeposu().hareketEkleTxn(
                txn,
                KasaHareketModel(
                  hareketTipi: tersTip,
                  tutar: orijinalTutar,
                  referansId: h.id,
                  referansTuru: 'cari_hareket_iptal',
                  tarih: DateTime.parse(now),
                  aciklama: 'İptal: ${h.aciklama}',
                ));
          }
        }

        // 🔴 DEEP_AUDIT (kendi-keşif turu, 2026-09-21): Banka tarafı —
        // kasa bloğuyla AYNI desen, sadece kaynak tablo/yön isimleri farklı.
        final bankaRows = await txn.query('banka_hareketler',
            where:
                'referans_turu = ? AND referans_id = ? AND (is_deleted IS NULL OR is_deleted = 0)',
            whereArgs: ['cari_hareket', h.id]);
        if (bankaRows.isNotEmpty) {
          final orijinalBanka = bankaRows.first;
          final orijinalTip = orijinalBanka['islem_tipi'] as String? ?? '';
          final orijinalTutar =
              (orijinalBanka['tutar'] as num?)?.toDouble() ?? 0;
          final bankaHesapId = orijinalBanka['banka_hesap_id'] as int?;
          // Ters yön: para GİTMİŞSE (Giden) geri GELİR (Gelen) ve tam tersi.
          final tersTip = orijinalTip == 'Giden'
              ? 'Gelen'
              : orijinalTip == 'Gelen'
                  ? 'Giden'
                  : null;
          if (tersTip != null && orijinalTutar > 0 && bankaHesapId != null) {
            tersBankaId = await BankaHareketDeposu().ekleTxn(
                txn,
                BankaHareketModel(
                  bankaHesapId: bankaHesapId,
                  islemTipi: tersTip,
                  tutar: orijinalTutar,
                  referansId: h.id,
                  referansTuru: 'cari_hareket_iptal',
                  tarih: DateTime.parse(now),
                  aciklama: 'İptal: ${h.aciklama}',
                ));
          }
        }

        // Kredi kartı tarafı — 'yon' (harcama/odeme) tersine çevrilir.
        final kkRows = await txn.query('kredi_karti_hareket',
            where:
                'referans_turu = ? AND referans_id = ? AND is_deleted = 0',
            whereArgs: ['cari_hareket', h.id]);
        if (kkRows.isNotEmpty) {
          final orijinalKk = kkRows.first;
          final orijinalYon = orijinalKk['yon'] as String? ?? '';
          final orijinalTutar = (orijinalKk['tutar'] as num?)?.toDouble() ?? 0;
          final krediKartiId = orijinalKk['kredi_karti_id'] as int?;
          if (orijinalTutar > 0 && krediKartiId != null) {
            // limitDegistirTxn: pozitif delta = harcama (limit artar),
            // negatif = ödeme (limit azalır) — orijinali TERSİNE çeviriyoruz.
            final tersDelta =
                orijinalYon == 'harcama' ? -orijinalTutar : orijinalTutar;
            tersKrediId = await KrediKartiDeposu().limitDegistirTxn(
                txn, krediKartiId, tersDelta,
                aciklama: 'İptal: ${h.aciklama}',
                referansId: h.id,
                referansTuru: 'cari_hareket_iptal');
          }
        }
      });

      final orijinalSatir = await db.query('cari_hareket',
          where: 'id = ?', whereArgs: [h.id], limit: 1);
      if (orijinalSatir.isNotEmpty) {
        BulutManager().upsert(
            'cari_hareket', Map<String, dynamic>.from(orijinalSatir.first));
      }
      if (tersCariGid != null) {
        final satir = await db.query('cari_hareket',
            where: 'global_id = ?', whereArgs: [tersCariGid], limit: 1);
        if (satir.isNotEmpty) {
          BulutManager()
              .upsert('cari_hareket', Map<String, dynamic>.from(satir.first));
        }
      }
      final cariSatir = await db.query('cari',
          where: 'id = ?', whereArgs: [h.cariId], limit: 1);
      if (cariSatir.isNotEmpty) {
        BulutManager()
            .upsert('cari', Map<String, dynamic>.from(cariSatir.first));
      }
      if (tersKasaId != null) {
        final kasaSatir = await db.query('kasa_hareketleri',
            where: 'id = ?', whereArgs: [tersKasaId], limit: 1);
        if (kasaSatir.isNotEmpty) {
          BulutManager().upsert(
              'kasa_hareketleri', Map<String, dynamic>.from(kasaSatir.first));
        }
      }
      if (tersBankaId != null) {
        final bankaSatir = await db.query('banka_hareketler',
            where: 'id = ?', whereArgs: [tersBankaId], limit: 1);
        if (bankaSatir.isNotEmpty) {
          BulutManager().upsert(
              'banka_hareketler', Map<String, dynamic>.from(bankaSatir.first));
          final hesapId = bankaSatir.first['banka_hesap_id'];
          final hesapSatir = await db.query('banka_hesaplar',
              where: 'id = ?', whereArgs: [hesapId], limit: 1);
          if (hesapSatir.isNotEmpty) {
            BulutManager().upsert(
                'banka_hesaplar', Map<String, dynamic>.from(hesapSatir.first));
          }
        }
      }
      if (tersKrediId != null) {
        final kkSatir = await db.query('kredi_karti_hareket',
            where: 'id = ?', whereArgs: [tersKrediId], limit: 1);
        if (kkSatir.isNotEmpty) {
          BulutManager().upsert(
              'kredi_karti_hareket', Map<String, dynamic>.from(kkSatir.first));
          final kartId = kkSatir.first['kredi_karti_id'];
          final kartSatir = await db.query('kredi_kartlari',
              where: 'id = ?', whereArgs: [kartId], limit: 1);
          if (kartSatir.isNotEmpty) {
            BulutManager().upsert(
                'kredi_kartlari', Map<String, dynamic>.from(kartSatir.first));
          }
        }
      }
    } catch (e, st) {
      LogServisi().hata('Cari.hareketIptalEt', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<Map<String, double>> istatistikler() async {
    try {
      final db = await _d;
      final res = await db.rawQuery(
        "SELECT COUNT(*) as toplam, "
        // 🔴 DÜZELTME: "Hem Müşteri Hem Tedarikçi" tipi (bu oturumda
        // cari ekle ekranına eklenen 3. seçenek) ne 'musteri' ne
        // 'tedarikci' sayısına dahil edilmiyordu — tam eşleşme (=)
        // yerine LIKE ile her iki kategoriye de sayılıyor.
        "COUNT(CASE WHEN cari_tipi LIKE '%Müşteri%' THEN 1 END) as musteri, "
        "COUNT(CASE WHEN cari_tipi LIKE '%Tedarikçi%' THEN 1 END) as tedarikci, "
        "SUM(CASE WHEN bakiye > 0 THEN bakiye ELSE 0 END) as toplam_alacak, "
        "SUM(CASE WHEN bakiye < 0 THEN ABS(bakiye) ELSE 0 END) as toplam_borc "
        "FROM cari WHERE is_deleted = 0",
      );
      if (res.isEmpty) return {};
      final r = res.first;
      return {
        'toplam': (r['toplam'] as num?)?.toDouble() ?? 0,
        'musteri': (r['musteri'] as num?)?.toDouble() ?? 0,
        'tedarikci': (r['tedarikci'] as num?)?.toDouble() ?? 0,
        'toplam_alacak': (r['toplam_alacak'] as num?)?.toDouble() ?? 0,
        'toplam_borc': (r['toplam_borc'] as num?)?.toDouble() ?? 0,
      };
    } catch (e, st) {
      LogServisi().hata('Cari.metod', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<List<CariModel>> vadesiGecmisler() async {
    try {
      final db = await _d;
      // 🔴 DÜZELTME (cari ekranları derin analizi, 2026-09-14): ch.tarih
      // DateTime.now().toIso8601String() ile (CİHAZIN YEREL SAATİYLE, UTC
      // DEĞİL) yazılıyor — ama datetime('now') SQLite'ta VARSAYILAN OLARAK
      // UTC döner. Bu ikisini karşılaştırmak, Türkiye'de (+3) sistematik
      // ~3 saatlik bir kaymaya yol açıyordu — bir alacak, gerçekte vadesi
      // geçtikten SAATLER SONRA "vadesi geçmiş" listesine düşüyordu. Aynı
      // hata sınıfı bu oturumdan önce 6 ayrı yerde bulunup 'localtime'
      // değiştiricisiyle düzeltilmişti (bkz. rapor_deposu.dart,
      // kar_zarar_provider.dart vb.) — bu yedinci örnek o turda
      // kapsanmamış.
      // 🔴 DÜZELTME (2026-09-27): ÖNCEDEN "vadesi geçmiş HERHANGİ bir borç
      // satırı var mı" soruluyordu — 3 ay önceki borcunu çoktan ödemiş,
      // bugün vadesi içinde yeni alışveriş yapmış müşteri de listeye
      // düşüyordu. Artık ödemeler en eski borçtan düşülür (FIFO): bakiyenin,
      // vadesi HENÜZ DOLMAMIŞ borçlarla karşılanamayan kısmı vadesi
      // geçmiş sayılır.
      final rows = await db.rawQuery('''
        SELECT c.* FROM cari c
        WHERE c.is_deleted = 0 AND c.aktif = 1 AND c.bakiye > 0
          AND c.vade_gun > 0
          AND c.bakiye - COALESCE((
            SELECT SUM(ch.borc) FROM cari_hareket ch
            WHERE ch.cari_id = c.id AND ch.borc > 0 AND ch.is_deleted = 0
            AND datetime(ch.tarih, '+' || c.vade_gun || ' days') >= datetime('now', 'localtime')
          ), 0) > 0.01
        ORDER BY c.bakiye DESC
      ''');
      return rows.map(CariModel.fromMap).toList();
    } catch (e, st) {
      LogServisi().hata('Cari.metod', hata: e, yigin: st);
      rethrow;
    }
  }
}