import 'package:flutter/foundation.dart';
import 'package:market_plus/cekirdek/utils/hata_utils.dart';
import 'package:market_plus/cekirdek/utils/metin_arama.dart';
import 'package:go_router/go_router.dart';
// lib/ekranlar/satis/iade_ekrani.dart
// Eski uygulamanın BarkodluIadeEkrani mantığı yeni altyapıya tam entegre edildi

import 'dart:async';
import 'package:flutter/material.dart';
import '../../cekirdek/utils/denetleyici_birak.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../saglayicilar/riverpod/cari_provider.dart';
import '../../saglayicilar/riverpod/kasa_rapor_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import 'iade/iade_arama_widget.dart';
import 'iade/iade_urun_formu.dart';
import 'iade/iade_gecmis_widget.dart';
import 'iade/iade_cari_dialog.dart';
import 'iade/cari_iade_kurali.dart';
import 'iade/iade_kaydet_butonu.dart';
import 'iade/iade_gecmis_sekmesi.dart';
import '../../uygulama/tema/uygulama_temasi.dart';
import '../../tasarim_sistemi/tasarim_sistemi.dart';
import '../../modeller/urun_model.dart';
import '../../modeller/cari_model.dart';
import '../../modeller/fatura_model.dart';
import '../../servisler/faturalandirma_servisi.dart';
import '../../depolar/fatura_deposu.dart';
import '../../widgetlar/ortak/onay_dialog.dart';
import '../../modeller/satis_model.dart';
import '../../modeller/satis_kalem_model.dart';
import '../../depolar/urun_deposu.dart';
import '../../depolar/cari_deposu.dart';
import '../../depolar/satis_deposu.dart';
import '../../depolar/iade_deposu.dart';
import '../../servisler/auth_servisi.dart';
import '../../servisler/belge_no_servisi.dart';
import '../../servisler/barkod_servisi.dart';
import '../../servisler/bildirim_servisi.dart';
import '../../servisler/excel_servisi.dart';
import '../../cekirdek/utils/para_utils.dart';
import '../../servisler/onay_merkezi_servisi.dart';
import '../../servisler/iade_islem_servisi.dart';
import '../../widgetlar/ortak/app_widgetlar.dart';
import '../../widgetlar/ortak/donanim_barkod_dinleyici.dart';

part 'iade_ekrani_gecmis.dart';
part 'iade_ekrani_fis.dart';
part 'iade_ekrani_hizli.dart';
part 'iade_ekrani_excel.dart';
part 'iade_ekrani_arama.dart';
part 'iade_ekrani_kaydet.dart';
part 'iade_ekrani_oturum.dart';

// ─── Renk paleti ─────────────────────────────────────────────────────────────
class _R {
  static const primary = TsRenk.primary;
  static const orange = TsRenk.uyari;
  static const blue = TsRenk.bilgi;

  static Color textL(BuildContext c) => TsRenk.metinIkincil(c);
}

// ─── Hızlı mod öğesi ─────────────────────────────────────────────────────────
class _HizliItem {
  final UrunModel urun;
  int adet;
  _HizliItem({required this.urun}) : adet = 1;
}

class IadeEkrani extends ConsumerStatefulWidget {
  final List<UrunModel>? baslangicUrunleri;
  final bool otomatikKapat;
  final String? baslangicFisNo;
  const IadeEkrani(
      {super.key,
      this.baslangicUrunleri,
      this.otomatikKapat = false,
      this.baslangicFisNo});

  @override
  ConsumerState<IadeEkrani> createState() => _IadeEkraniState();
}

class _IadeEkraniState extends ConsumerState<IadeEkrani>
    with TickerProviderStateMixin {
  final _aciklamaCtrl = TextEditingController();
  final _urunDepo = UrunDeposu();
  final _cariDepo = CariDeposu();
  final _satisDepo = SatisDeposu();
  final _barkodSrv = BarkodServisi();
  final _excelSrv = ExcelServisi();

  // Veriler
  List<UrunModel> _tumUrunler = [];
  List<CariModel> _cariler = [];
  CariModel? _secilenCari;

  // İade geçmişi
  List<Map<String, dynamic>> _gecmisIadeler = [];
  bool _gecmisYukleniyor = false;
  DateTime? _gecmisTarihBaslangic;
  DateTime? _gecmisTarihBitis;
  CariModel? _gecmisCariFiltre;
  final _gecmisFisCtrl = TextEditingController();

  // Form state
  UrunModel? _secilenUrun;
  double _miktar = 1;
  double _orijinalFiyat = 0;
  bool _yukleniyor = false;
  String _iadeOdemeYontemi = 'Nakit';

  // Hızlı mod
  final Map<int, _HizliItem> _hizliMap = {};

  // İade listesi (bu oturumda yapılanlar)
  final List<Map<String, dynamic>> _iadeListesi = [];

  // Müşteri oturum iadesi (tek fiş altında toplama)
  int? _oturumIadeId;
  String _oturumFisNo = '';

  // 🔴 YENİ (2026-10-13): tedarikçi/bayi oturum belgesi — tek fiş modeli.
  // İlk kayıtta belge açılır, sonraki kayıtlar AYNI belgeye kalem olarak
  // gider. Aynı gün + aynı cari + aynı tür kombinasyonunda geçerlidir.
  int? _cariOturumIadeId;
  String _cariOturumFisNo = '';
  CariIadeTuru? _cariOturumTuru;
  int? _cariOturumCariId;
  // 🔴 YENİ: oturumun açıldığı tarih. Uygulama gece açık kaldıysa
  // (dün akşam TDI-0001 açıldı, bugün hâlâ bellekte), ertesi gün
  // otomatik yeni belge açılsın diye gün karşılaştırması yapılır.
  DateTime? _cariOturumTarih;

  // Düzenleme modu
  int? _duzenlemeModuIadeId;
  String? _duzenlemeModuFisNo;

  // Arama
  List<UrunModel> _aramaListesi = [];
  Timer? _debounce;

  // Fiş arama
  SatisModel? _bulunanSatis;
  Map<int, double> _fisIadeEdilenMiktar = {};
  bool _fisIadeIsleniyor = false;

  // Controllers
  final _aramaCtrl = TextEditingController();
  final _miktarCtrl = TextEditingController(text: '1');
  final _fiyatCtrl = TextEditingController();
  final _iskontoCtrl = TextEditingController(text: '0');
  final _fisNoCtrl = TextEditingController();
  final _aramaFocus = FocusNode();

  late final TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
    _yeniFisNoOlustur();
    _tab.addListener(() {
      if (_tab.index == 3) _gecmisYukle();
    });
    _aramaCtrl.addListener(_aramaDebounce);
    _miktarCtrl.addListener(() {
      final v = ParaUtils.sayiCoz(_miktarCtrl.text) ?? 1;
      if (v == _miktar) return;
      setState(() => _miktar = v);
      if (_cariIadeTuru == CariIadeTuru.bayi) _iadeFiyatiniGuncelle();
    });
    _verileriYukle();
    if (widget.baslangicFisNo != null && widget.baslangicFisNo!.isNotEmpty) {
      _fisNoCtrl.text = widget.baslangicFisNo!;
      _tab.index = 2;
      WidgetsBinding.instance.addPostFrameCallback((_) => _fisBul());
    }

    if (widget.baslangicUrunleri?.isNotEmpty == true) {
      for (final u in widget.baslangicUrunleri!) {
        if (u.id == null) continue;
        _hizliMap.containsKey(u.id)
            ? _hizliMap[u.id]!.adet++
            : _hizliMap[u.id!] = _HizliItem(urun: u);
      }
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _aramaCtrl.dispose();
    _miktarCtrl.dispose();
    _fiyatCtrl.dispose();
    _iskontoCtrl.dispose();
    _fisNoCtrl.dispose();
    _aramaFocus.dispose();
    _tab.dispose();
    _gecmisFisCtrl.dispose();
    _aciklamaCtrl.dispose();
    super.dispose();
  }

  Future<void> _verileriYukle() async {
    try {
      _gecmisYukle();
      final results =
          await Future.wait([_urunDepo.tumunuGetir(), _cariDepo.tumunuGetir()]);
      if (!mounted) return;
      _tumUrunler = results[0] as List<UrunModel>;
      _cariler = results[1] as List<CariModel>;
      if (mounted) setState(() {});
    } catch (e) {
      if (kDebugMode) debugPrint('Hata: $e');
      if (mounted) {
        BildirimServisi.hata(
            context, 'Veriler yüklenemedi, lütfen tekrar deneyin');
      }
    }
  }

  Future<void> _yeniFisNoOlustur() async {
    try {
      final no = await BelgeNoServisi().uret('iade');
      if (mounted) {
        setState(() {
          _oturumFisNo = no;
        });
      }
    } catch (_) {
      _oturumFisNo =
          'IAD-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    }
  }

  void _formSifirla() {
    _secilenUrun = null;
    _miktar = 1;
    _orijinalFiyat = 0;
    _aramaListesi = [];
    _aramaCtrl.clear();
    _miktarCtrl.text = '1';
    _fiyatCtrl.clear();
    _iskontoCtrl.text = '0';
    _aciklamaCtrl.clear();
    if (mounted) setState(() {});
  }

  /// Yeni iade başlat — düzenleme modunu kapat, listeyi temizle, oturum
  /// belgelerini sıfırla. Bir sonraki kayıt YENİ belge açar.
  void _yeniIadeBaslat() {
    setState(() {
      _duzenlemeModuIadeId = null;
      _duzenlemeModuFisNo = null;
      _oturumIadeId = null;
      _oturumFisNo = '';
      // 🔴 YENİ: tedarikçi/bayi oturum belgesi de sıfırlanır.
      _cariOturumIadeId = null;
      _cariOturumFisNo = '';
      _cariOturumTuru = null;
      _cariOturumCariId = null;
      _cariOturumTarih = null;
      _iadeListesi.clear();
      _secilenCari = null;
      _iadeOdemeYontemi = 'Nakit';
    });
    _yeniFisNoOlustur();
    _formSifirla();
    _msg('Yeni iade başlatıldı', err: false);
  }

  void _msg(String s, {bool err = false}) {
    if (!mounted) return;
    if (err) {
      BildirimServisi.hata(context, s);
    } else {
      BildirimServisi.basari(context, s);
    }
  }

  @override
  Widget build(BuildContext context) {
    return DonanimBarkodDinleyici(
      onBarkod: (b) {
        if (_tab.index == 0) _barkodIsle(b);
      },
      child: Scaffold(
        backgroundColor: TsRenk.arkaplan(context),
        appBar: TsAppBar(
          baslikWidget: _duzenlemeModuIadeId != null
              ? Text('İade: ${_duzenlemeModuFisNo ?? ''}',
                  style: const TextStyle(fontSize: 15))
              : const Text('İade İşlemleri'),
          aksiyonlar: [
            if (_duzenlemeModuIadeId != null)
              TextButton.icon(
                icon: const Icon(Icons.add_circle_outline,
                    color: Colors.white, size: 16),
                label: const Text('Yeni',
                    style: TextStyle(color: Colors.white, fontSize: 11)),
                onPressed: _yeniIadeBaslat,
              ),
            PopupMenuButton<String>(
                icon: Image.asset("assets/images/excel_icon.png",
                    width: 22,
                    height: 22,
                    errorBuilder: (_, _, _) =>
                        const Icon(Icons.table_chart)),
                tooltip: 'Excel',
                onSelected: (v) =>
                    v == 'ice' ? _excelIceAl() : _excelDisaVer(),
                itemBuilder: (_) => const [
                      PopupMenuItem(
                          value: 'ice',
                          child: ListTile(
                              dense: true,
                              leading: Icon(Icons.file_download_outlined),
                              title: Text('Excel içeri al'))),
                      PopupMenuItem(
                          value: 'disa',
                          child: ListTile(
                              dense: true,
                              leading: Icon(Icons.file_upload_outlined),
                              title: Text('Excel dışarı ver'))),
                    ]),
            if (_secilenCari != null)
              Chip(
                  label: Text(_secilenCari!.unvan,
                      style: const TextStyle(fontSize: 11)),
                  deleteIcon: const Icon(Icons.close, size: 14),
                  onDeleted: _cariyiKaldir)
            else
              TextButton.icon(
                icon: const Icon(Icons.person_search,
                    color: Colors.white, size: 18),
                label: const Text('Cari Seç',
                    style: TextStyle(color: Colors.white, fontSize: 12)),
                onPressed: _musteriSec,
              ),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert),
              onSelected: (v) {
                if (v == 'musteri') _musteriSec();
              },
              itemBuilder: (_) => [
                const PopupMenuItem(
                    value: 'musteri',
                    child: ListTile(
                        dense: true,
                        leading:
                            Icon(Icons.person, color: AppRenkler.primary),
                        title: Text(
                            'Cari Seç (Müşteri / Tedarikçi / Bayi)'))),
              ],
            ),
          ],
          alt: TabBar(
            controller: _tab,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white60,
            indicatorColor: _R.orange,
            tabs: const [
              Tab(
                  icon: Icon(Icons.assignment_return, size: 18),
                  text: 'İade'),
              Tab(icon: Icon(Icons.list_alt, size: 18), text: 'Hızlı'),
              Tab(icon: Icon(Icons.receipt_long, size: 18), text: 'Fiş'),
              Tab(icon: Icon(Icons.history, size: 18), text: 'Geçmiş'),
            ],
          ),
          lider: BackButton(onPressed: () => context.go('/')),
          modul: TsModul.uyari,
        ),
        body: TabBarView(controller: _tab, children: [
          _iadeTab(),
          _hizliTab(),
          _fisTab(),
          _gecmisTab(),
        ]),
      ),
    );
  }

  // ── İade Sekmesi ──────────────────────────────────────────────────────────
  Widget _iadeTab() => Column(children: [
        _aramaKutusu(),
        if (_aramaListesi.isNotEmpty) _aramaPanel(),
        Expanded(
            child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  if (_secilenUrun != null) ...[
                    _urunFormu(),
                    const SizedBox(height: 16),
                    IadeKaydetButonu(yukleniyor: _yukleniyor, onTap: _kaydet),
                  ] else if (_aramaListesi.isNotEmpty)
                    const SizedBox.shrink()
                  else if (_iadeListesi.isNotEmpty)
                    _kisaIpucu()
                  else
                    _bosEkran(),
                  if (_iadeListesi.isNotEmpty) ...[
                    SizedBox(height: _secilenUrun != null ? 24 : 12),
                    _iadeGecmisi(),
                  ],
                ]))),
      ]);

  Widget _aramaKutusu() => IadeAramaKutusu(
        controller: _aramaCtrl,
        focusNode: _aramaFocus,
        onTemizle: _aramayiTemizle,
        onBarkod: _barkodOku,
        onGonder: _aramaGonder,
      );

  Widget _aramaPanel() => IadeAramaPanel(
        aramaListesi: _aramaListesi,
        onSec: (u) => _secilenUrunAyarla(u as dynamic),
      );
  Widget _urunFormu() => IadeUrunFormu(
        urun: _secilenUrun!,
        miktarCtrl: _miktarCtrl,
        fiyatCtrl: _fiyatCtrl,
        iskontoCtrl: _iskontoCtrl,
        miktar: _miktar,
        orijinalFiyat: _orijinalFiyat,
        onSifirla: _formSifirla,
        onDegisti: () {
          if (mounted) setState(() {});
        },
        odemeYontemi: _iadeOdemeYontemi,
        onOdemeYontemiChanged: (v) {
          if (mounted) setState(() => _iadeOdemeYontemi = v);
        },
        cariAdi: _secilenCari?.id != null ? _secilenCari!.unvan : null,
        fiyatKuraliAciklamasi: _cariIadeTuru.fiyatAciklamasi(_secilenCari),
        stokAzalir: _cariIadeTuru.stokAzalir,
        oncekiMiktar: _oncekiIadeMiktari,
      );

  Widget _bosEkran() => const Padding(
        padding: EdgeInsets.symmetric(vertical: 32),
        child: BosEkran(
          ikon: Icons.assignment_return_outlined,
          baslik: 'Ürün seçilmedi',
          aciklama:
              'İade almak için yukarıdaki kutudan ürün adı yazın,\nbarkod okutun veya "Hızlı" ve "Fiş" sekmelerini kullanın.',
          renk: _R.orange,
        ),
      );

  Widget _kisaIpucu() => Row(children: [
        const Icon(Icons.qr_code_scanner, size: 16, color: _R.orange),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
              'Yeni iade için yukarıdan ürün arayın veya barkod okutun',
              style: TextStyle(
                  fontSize: 12.5, color: TsRenk.metinIkincil(context))),
        ),
      ]);

  Widget _iadeGecmisi() => IadeGecmisWidget(
        iadeListesi: _iadeListesi,
        duzenlemeModuIadeId: _duzenlemeModuIadeId,
        duzenlemeModuFisNo: _duzenlemeModuFisNo,
        onSilOnay: _oturumIadeSilOnay,
        onSil: _oturumIadeSil,
        onDuzenle: _oturumIadeDuzenle,
        onExcel: _excelDisaVer,
      );
}