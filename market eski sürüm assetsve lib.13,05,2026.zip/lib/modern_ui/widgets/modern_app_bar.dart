import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';

class ModernAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final bool showBackButton;
  final List<Widget>? actions;
  final VoidCallback? onSearchTap;
  final VoidCallback? onCartTap;

  const ModernAppBar({
    super.key,
    required this.title,
    this.showBackButton = true,
    this.actions,
    this.onSearchTap,
    this.onCartTap,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.surface,
      elevation: 0,
      centerTitle: false,
      leading: showBackButton
          ? IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: AppColors.textPrimary),
              onPressed: () => Navigator.pop(context),
            )
          : null,
      title: Text(title, style: AppTextStyles.headline2),
      actions: actions ?? [
        if (onSearchTap != null)
          IconButton(
            icon: const Icon(Icons.search, color: AppColors.textPrimary),
            onPressed: onSearchTap,
          ),
        if (onCartTap != null)
          IconButton(
            icon: const Icon(Icons.shopping_cart_outlined, color: AppColors.textPrimary),
            onPressed: onCartTap,
          ),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}