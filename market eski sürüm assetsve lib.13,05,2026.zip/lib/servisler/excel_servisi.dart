// lib/servisler/excel_servisi.dart
// TAM UYUMLU - Sayısal hücreler "General" formatında, 3 ondalık
// Performans iyileştirmesi: Sütun indeksleri bir kere hesaplanır, her satırda doğrudan erişim.

import 'dart:io';
import 'package:excel/excel.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:path_provider/path_provider.dart';

class ExcelServisi {
  final UrunRepoSitory _urunRepo = UrunRepoSitory();

  // Barkomatik'teki sütun başlıkları (sıra önemli)
  static const List<String> BARKOMATIK_BASLIKLAR = [
    "Id", "Kod", "Barkod", "Barkodlar", "Ürün Adı", "Alternatif ürün adı",
    "Birim Adı", "Alış fiyat", "Alış fiyat kdv dahil", "Satış fiyatı",
    "Stok", "Stok değeri", "Toplam Maliyet", "Toplam Stok", "Toplam stok değeri",
    "Alış KDV Oran", "KDV Oran", "Ana Grup", "Alt Grup", "Aktif",
    "Seri no takibi", "Alan1", "Alan2", "Para Birimi", "Minimum Stok",
    "Maximum Stok", "Alan3", "Alan4", "Renk", "Beden", "Şube",
    "Üretici", "Marka", "Model", "Raf numarası", "Raf ömrü",
    "Plu numarası", "Puan Oranı", "Indirim Oranı", "İndirimli Fiyatı",
    "Lot Takibi", "Lot No", "Son alım indirim oran", "Muhasebe Kodu",
    "En", "Boy", "Yükseklik", "Hacim", "Ağırlık", "Eski kodu",
    "Kart Tipi", "Seri numarası", "Otomatik Indirim", "Güncelleme tarihi",
    "Kayıt tarihi", "Resim yolu", "Grup Sorumlusu", "Menşei",
    "Barkod Ölçü Birimi", "Kar oranı", "Muafiyet Kodu", "Resmi Bakiye",
    "Fiyat Güncelleme Tarih", "Fiyat Güncelleyen Kullanıcı",
    "Barkod Yazdırma Tarih", "Barkod Yazdıran Kullanıcı",
    "Maliyet Güncelleme Tarih", "Maliyet Güncelleyen Kullanıcı",
    "Maksimum Satır Miktarı", "Güncelleyen Kullanıcı", "Kaydeden Kullanıcı",
    "Son Kullanma Tarihi"
  ];

  // Sayıyı 3 ondalıklı double yap (hücre tipi sayı olur)
  double _to3Decimal(double? value) {
    if (value == null) return 0.0;
    return double.parse(value.toStringAsFixed(3));
  }

  Future<File?> urunleriExceleDisariAktar() async {
    final urunler = await _urunRepo.tumUrunleriGetir();
    final excel = Excel.createExcel();

    final defaultSheet = excel.getDefaultSheet();
    if (defaultSheet != null) {
      excel.delete(defaultSheet);
    }

    final sheet = excel['Sayfa1'];
    
    // Başlık satırı (metin)
    sheet.appendRow(BARKOMATIK_BASLIKLAR);

    for (final urun in urunler) {
      // Tüm sayısal değerleri 3 ondalıklı double yap
      final alisFiyat = _to3Decimal(urun.alisFiyat);
      final kdvOrani = _to3Decimal(urun.kdvOrani);
      final alisKdvDahil = _to3Decimal(urun.alisFiyatKdvDahil ?? alisFiyat * (1 + kdvOrani / 100));
      final satisFiyat = _to3Decimal(urun.satisFiyat);
      final stokMiktari = _to3Decimal(urun.stokMiktari);
      final alisKdvOrani = _to3Decimal(urun.alisKdvOrani);
      final indirimOrani = _to3Decimal(urun.indirimOrani);
      final indirimliFiyat = _to3Decimal(urun.indirimliFiyat ?? satisFiyat * (1 - indirimOrani / 100));
      
      double karOrani = 0.0;
      if (satisFiyat > 0 && alisFiyat > 0) {
        karOrani = _to3Decimal(((satisFiyat - alisFiyat) / alisFiyat) * 100);
      }

      // Satırı oluştur - SAYISAL DEĞERLER double, METİNLER String
      List<dynamic> row = [];
      
      for (int i = 0; i < BARKOMATIK_BASLIKLAR.length; i++) {
        final baslik = BARKOMATIK_BASLIKLAR[i];
        
        switch (baslik) {
          // === SAYISAL SÜTUNLAR (double olarak eklenecek) ===
          case "Id": row.add((urun.id ?? 0).toDouble()); break;
          case "Alış fiyat": row.add(alisFiyat); break;
          case "Alış fiyat kdv dahil": row.add(alisKdvDahil); break;
          case "Satış fiyatı": row.add(satisFiyat); break;
          case "Stok": row.add(stokMiktari); break;
          case "Stok değeri": row.add(0.0); break;
          case "Toplam Maliyet": row.add(0.0); break;
          case "Toplam Stok": row.add(0.0); break;
          case "Toplam stok değeri": row.add(0.0); break;
          case "Alış KDV Oran": row.add(alisKdvOrani); break;
          case "KDV Oran": row.add(kdvOrani); break;
          case "Minimum Stok": row.add(0.0); break;
          case "Maximum Stok": row.add(0.0); break;
          case "Puan Oranı": row.add(0.0); break;
          case "Indirim Oranı": row.add(indirimOrani); break;
          case "İndirimli Fiyatı": row.add(indirimliFiyat); break;
          case "Son alım indirim oran": row.add(0.0); break;
          case "Kar oranı": row.add(karOrani); break;
          case "Resmi Bakiye": row.add(0.0); break;
          case "En": case "Boy": case "Yükseklik": case "Hacim": 
          case "Ağırlık": case "Maksimum Satır Miktarı": row.add(0.0); break;
          
          // === METİN SÜTUNLAR (String olarak) ===
          case "Kod": row.add(urun.kod ?? ''); break;
          case "Barkod": row.add(urun.barkod ?? ''); break;
          case "Barkodlar": row.add(urun.barkodlar ?? ''); break;
          case "Ürün Adı": row.add(urun.ad ?? ''); break;
          case "Birim Adı": row.add(urun.birim ?? ''); break;
          case "Ana Grup": row.add(urun.anagrup ?? ''); break;
          case "Alt Grup": row.add(urun.altGrup ?? ''); break;
          case "Alan1": row.add(urun.alan1 ?? ''); break;
          case "Alan2": row.add(urun.alan2 ?? ''); break;
          case "Para Birimi": row.add(urun.paraBirimi ?? 'TL'); break;
          case "Marka": row.add(urun.marka ?? ''); break;
          case "Resim yolu": row.add(urun.resimYolu ?? ''); break;
          case "Menşei": row.add(urun.mens ?? ''); break;
          case "Fiyat Güncelleme Tarih": row.add(urun.fiyatGuncellemeTarihi ?? ''); break;
          case "Maliyet Güncelleme Tarih": row.add(urun.maliyetGuncellemeTarihi ?? ''); break;
          case "Aktif": row.add("True"); break;
          case "Seri no takibi": row.add("False"); break;
          case "Lot Takibi": row.add("False"); break;
          case "Otomatik Indirim": row.add("False"); break;
          case "Alternatif ürün adı": 
          case "Alan3": case "Alan4": case "Renk": case "Beden": case "Şube":
          case "Üretici": case "Model": case "Raf numarası": case "Raf ömrü":
          case "Plu numarası": case "Lot No": case "Muhasebe Kodu":
          case "Eski kodu": case "Kart Tipi": case "Seri numarası":
          case "Güncelleme tarihi": case "Kayıt tarihi": case "Grup Sorumlusu":
          case "Barkod Ölçü Birimi": case "Muafiyet Kodu":
          case "Fiyat Güncelleyen Kullanıcı": case "Barkod Yazdırma Tarih":
          case "Barkod Yazdıran Kullanıcı": case "Maliyet Güncelleyen Kullanıcı":
          case "Güncelleyen Kullanıcı": case "Kaydeden Kullanıcı":
          case "Son Kullanma Tarihi": row.add(""); break;
          
          default: row.add("");
        }
      }
      
      sheet.appendRow(row);
    }

    final directory = await getApplicationDocumentsDirectory();
    final dosyaAdi = 'urunler_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    final filePath = '${directory.path}/$dosyaAdi';
    final file = File(filePath);
    final bytes = excel.encode();
    
    if (bytes != null) {
      await file.writeAsBytes(bytes);
      return file;
    }
    return null;
  }

  // ===================== PERFORMANS İYİLEŞTİRMESİ YAPILMIŞ İÇE AKTARMA =====================
  Future<Map<String, dynamic>> urunleriExceldenIceriAl(File excelDosya) async {
    final bytes = await excelDosya.readAsBytes();
    final excel = Excel.decodeBytes(bytes);
    final sheet = excel.tables[excel.tables.keys.first]!;
    
    int eklenen = 0;
    int guncellenen = 0;
    int hatali = 0;
    List<String> detaylar = [];

    // 1. Başlık satırını al ve tüm sütun indekslerini bir kere hesapla
    final headerRow = sheet.rows[0];
    final Map<String, int> columnIndexes = {};
    
    for (int col = 0; col < headerRow.length; col++) {
      final cellValue = headerRow[col]?.value;
      if (cellValue != null) {
        final header = cellValue.toString().trim();
        if (header.isNotEmpty) {
          // Tam eşleşme yoksa küçük/büyük harf duyarsız eşleşme için birden fazla başlık aynı indekse denk gelebilir
          // ama önce tam eşleşmeyi ekleyelim, sonra ihtiyaç halinde case-insensitive bakacağız.
          columnIndexes[header] = col;
        }
      }
    }
    
    // Case-insensitive arama için yardımcı fonksiyon (indexOf yerine)
    int getColumnIndex(String header) {
      // Önce tam eşleşme ara
      if (columnIndexes.containsKey(header)) return columnIndexes[header]!;
      // Büyük/küçük harf duyarsız ara
      for (final entry in columnIndexes.entries) {
        if (entry.key.toLowerCase() == header.toLowerCase()) {
          return entry.value;
        }
      }
      return -1;
    }

    // Zorunlu sütunların indekslerini al
    final barkodIdx = getColumnIndex("Barkod");
    final urunAdiIdx = getColumnIndex("Ürün Adı");
    final satisFiyatIdx = getColumnIndex("Satış fiyatı");
    
    if (barkodIdx == -1 || urunAdiIdx == -1 || satisFiyatIdx == -1) {
      return {
        'eklenen': 0,
        'guncellenen': 0,
        'hatali': 1,
        'detaylar': ['Zorunlu başlıklar (Barkod, Ürün Adı, Satış fiyatı) bulunamadı.'],
      };
    }

    // İsteğe bağlı sütunların indekslerini al (opsiyonel, -1 olabilir)
    final kodIdx = getColumnIndex("Kod");
    final barkodlarIdx = getColumnIndex("Barkodlar");
    final birimIdx = getColumnIndex("Birim Adı");
    final alisFiyatIdx = getColumnIndex("Alış fiyat");
    final alisKdvDahilIdx = getColumnIndex("Alış fiyat kdv dahil");
    final stokIdx = getColumnIndex("Stok");
    final alisKdvOranIdx = getColumnIndex("Alış KDV Oran");
    final kdvOranIdx = getColumnIndex("KDV Oran");
    final anaGrupIdx = getColumnIndex("Ana Grup");
    final altGrupIdx = getColumnIndex("Alt Grup");
    final alan1Idx = getColumnIndex("Alan1");
    final alan2Idx = getColumnIndex("Alan2");
    final paraBirimiIdx = getColumnIndex("Para Birimi");
    final markaIdx = getColumnIndex("Marka");
    final indirimOranIdx = getColumnIndex("Indirim Oranı");
    final indirimliFiyatIdx = getColumnIndex("İndirimli Fiyatı");
    final boyIdx = getColumnIndex("Boy");
    final resimYoluIdx = getColumnIndex("Resim yolu");
    final mensIdx = getColumnIndex("Menşei");
    final karOranIdx = getColumnIndex("Kar oranı");
    final fiyatGuncellemeTarihiIdx = getColumnIndex("Fiyat Güncelleme Tarih");
    final maliyetGuncellemeTarihiIdx = getColumnIndex("Maliyet Güncelleme Tarih");
    final promosyonAktifIdx = getColumnIndex("Promosyon Aktif");

    // Satırları işle (ilk satır başlık, 1'den başla)
    for (int i = 1; i < sheet.rows.length; i++) {
      final row = sheet.rows[i];
      
      // Hücre değerlerini güvenli okumak için yardımcı inner fonksiyonlar (her satır için oluşmaz, derleme anında)
      String getString(int idx) {
        if (idx < 0 || idx >= row.length) return '';
        final val = row[idx]?.value;
        return val?.toString().trim() ?? '';
      }
      
      double? getDouble(int idx) {
        if (idx < 0 || idx >= row.length) return null;
        final val = row[idx]?.value;
        if (val == null) return null;
        if (val is num) return val.toDouble();
        if (val is String) {
          final cleaned = val.replaceAll(',', '.').trim();
          return double.tryParse(cleaned);
        }
        return null;
      }

      try {
        // Zorunlu alanları oku
        final barkod = getString(barkodIdx);
        final urunAdi = getString(urunAdiIdx);
        final satisFiyat = getDouble(satisFiyatIdx);
        
        if (barkod.isEmpty || urunAdi.isEmpty || satisFiyat == null) {
          hatali++;
          detaylar.add('Satır ${i + 1}: Zorunlu alanlar (Barkod, Ürün Adı, Satış fiyatı) eksik veya hatalı');
          continue;
        }

        // Diğer alanları oku (nullable)
        final kod = getString(kodIdx);
        final barkodlar = getString(barkodlarIdx);
        final birim = getString(birimIdx);
        final alisFiyat = getDouble(alisFiyatIdx);
        final alisFiyatKdvDahil = getDouble(alisKdvDahilIdx);
        final stokMiktari = getDouble(stokIdx) ?? 0.0;
        final alisKdvOrani = getDouble(alisKdvOranIdx);
        final kdvOrani = getDouble(kdvOranIdx) ?? 18.0;
        final anaGrup = getString(anaGrupIdx);
        final altGrup = getString(altGrupIdx);
        final alan1 = getString(alan1Idx);
        final alan2 = getString(alan2Idx);
        final paraBirimi = getString(paraBirimiIdx);
        final marka = getString(markaIdx);
        final indirimOrani = getDouble(indirimOranIdx) ?? 0.0;
        final indirimliFiyat = getDouble(indirimliFiyatIdx);
        final boy = getString(boyIdx);
        final resimYolu = getString(resimYoluIdx);
        final mens = getString(mensIdx);
        final karOrani = getDouble(karOranIdx);
        final fiyatGuncellemeTarihi = getString(fiyatGuncellemeTarihiIdx);
        final maliyetGuncellemeTarihi = getString(maliyetGuncellemeTarihiIdx);
        
        // Promosyon aktif: "evet" case-insensitive kontrol
        bool promosyonAktif = false;
        if (promosyonAktifIdx != -1) {
          final promosyonStr = getString(promosyonAktifIdx).toLowerCase();
          promosyonAktif = promosyonStr == 'evet' || promosyonStr == 'true' || promosyonStr == '1';
        }

        final yeniUrun = Urun(
          kod: kod.isNotEmpty ? kod : barkod, // Kod yoksa barkod'u kullan
          barkod: barkod,
          barkodlar: barkodlar,
          ad: urunAdi,
          birim: birim,
          alisFiyat: alisFiyat,
          alisFiyatKdvDahil: alisFiyatKdvDahil,
          satisFiyat: satisFiyat,
          stokMiktari: stokMiktari,
          alisKdvOrani: alisKdvOrani,
          kdvOrani: kdvOrani,
          anagrup: anaGrup,
          altGrup: altGrup,
          alan1: alan1,
          alan2: alan2,
          paraBirimi: paraBirimi.isNotEmpty ? paraBirimi : 'TL',
          marka: marka,
          indirimOrani: indirimOrani,
          indirimliFiyat: indirimliFiyat,
          boy: boy,
          resimYolu: resimYolu,
          mens: mens,
          karOrani: karOrani,
          fiyatGuncellemeTarihi: fiyatGuncellemeTarihi,
          maliyetGuncellemeTarihi: maliyetGuncellemeTarihi,
          promosyonAktif: promosyonAktif,
        );

        final mevcutUrun = await _urunRepo.barkodlaUrunGetir(barkod);
        if (mevcutUrun != null) {
          final updatedUrun = yeniUrun.copyWith(id: mevcutUrun.id);
          await _urunRepo.urunGuncelle(updatedUrun);
          guncellenen++;
        } else {
          await _urunRepo.urunEkle(yeniUrun);
          eklenen++;
        }
      } catch (e) {
        hatali++;
        detaylar.add('Satır ${i + 1}: Genel hata: $e');
      }
    }

    return {
      'eklenen': eklenen,
      'guncellenen': guncellenen,
      'hatali': hatali,
      'detaylar': detaylar,
    };
  }
}