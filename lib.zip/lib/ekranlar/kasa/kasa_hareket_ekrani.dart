// lib/ekranlar/kasa/kasa_hareket_ekrani.dart

import '../../cekirdek/utils/denetleyici_birak.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../uygulama/tema/uygulama_temasi.dart';
import '../../depolar/kasa_deposu.dart';
import '../../saglayicilar/riverpod/kasa_rapor_provider.dart';
import '../../modeller/kasa_hareket_model.dart';
import '../../cekirdek/utils/para_utils.dart';
import '../../tasarim_sistemi/tasarim_sistemi.dart';
import '../../widgetlar/masaustu/masaustu_tablo.dart';

class KasaHareketEkrani extends ConsumerStatefulWidget {
  const KasaHareketEkrani({super.key});
  @override
  ConsumerState<KasaHareketEkrani> createState() => _KasaHareketEkraniState();
}

class _KasaHareketEkraniState extends ConsumerState<KasaHareketEkrani> {
  final _depo = KasaDeposu();
  List<KasaHareketModel> _hareketler = [];
  KasaHareketModel? _seciliHareket; // masaüstü tablo seçimi
  bool _yukleniyor = true;
  double _bakiye = 0;
  Map<String, double> _gunlukOzet = {'giris': 0, 'cikis': 0};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _yukle());
  }

  Future<void> _yukle() async {
    _yukleniyor = true;

    if (mounted) setState(() {});
    try {
      final results = await Future.wait([
        _depo.guncelBakiye(),
        _depo.hareketleriniGetir(limit: 100),
        _depo.gunlukOzet(),
      ]);
      if (!mounted) return;
      _bakiye = results[0] as double;
      _hareketler = results[1] as List<KasaHareketModel>;
      _gunlukOzet = results[2] as Map<String, double>;
      _yukleniyor = false;
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  // 🔴🔴 FAZ 1 madde 4 (kullanıcı onayıyla): 'Tahsilat', 'Ödeme', 'Gider' ve
  // 'Banka Ödemesi' seçenekleri kaldırıldı — her biri, doğru şekilde
  // yapıldığında BAŞKA bir kaydı da güncellemesi gereken bir işlemi tek
  // taraflı (sadece kasa_hareketleri'ne yazarak) yapıyordu:
  //  - Tahsilat/Ödeme: cari_hareket'i hiç etkilemiyordu (tahsilat_odeme_ekrani.dart
  //    ikisini birlikte, tek transaction'da yapıyor).
  //  - Gider: gider tablosuna hiç kayıt açmıyordu (bkz. gider_deposu.dart —
  //    gider raporları bu tablodan besleniyor, buradan eklenen 'Gider' hareketi
  //    hiçbir gider raporunda görünmüyordu).
  //  - Banka Ödemesi: banka_hareketler'e karşılık gelen kaydı hiç açmıyordu
  //    (virman_ekrani.dart Kasa→Banka virmanını doğru şekilde iki taraflı yapıyor).
  // 'Kasa Sayım', 'AçılışKasa', 'KapanışKasa' bu üçünün aksine başka hiçbir
  // tabloya bağlı değil ve bu ekran dışında oluşturulan bir karşılıkları yok
  // (vardiya sistemi henüz bu hareketleri otomatik yaratmıyor — bkz. FAZ 1
  // madde 2, vardiya/kasa mutabakatı ayrı bir analiz gerektiriyor ve BURADA
  // DOKUNULMADI) — bu yüzden korundu.
  Future<void> _hareketEkle() async {
    String tip = 'Kasa Sayım';
    final ctrl = TextEditingController();
    final acCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
          builder: (ctx, ss) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                title: const Text('Kasa Manuel Düzeltme'),
                content: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: EdgeInsets.only(bottom: 8),
                      child: Text(
                        'Tahsilat/Ödeme için Cari ekranını, Gider için Gider '
                        'ekranını, Banka transferi için Virman ekranını kullanın.',
                        style: TextStyle(fontSize: 11, color: TsRenk.uyari),
                      ),
                    ),
                  ),
                  DropdownButtonFormField<String>(
                    initialValue: tip,
                    decoration: const InputDecoration(
                        labelText: 'Hareket Tipi',
                        border: OutlineInputBorder()),
                    items: ['Kasa Sayım', 'AçılışKasa', 'KapanışKasa']
                        .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                        .toList(),
                    onChanged: (v) => ss(() => tip = v!),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                      controller: ctrl,
                      autofocus: true,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                          labelText: 'Tutar (₺)',
                          border: OutlineInputBorder())),
                  const SizedBox(height: 10),
                  TextField(
                      controller: acCtrl,
                      decoration: const InputDecoration(
                          labelText: 'Açıklama', border: OutlineInputBorder())),
                ]),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('İptal')),
                  FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Kaydet')),
                ],
              )),
    ).whenComplete(() => dialogSonrasiBirak([ctrl, acCtrl]));
    if (ok != true) return;
    final tutar = ParaUtils.sayiCoz(ctrl.text) ?? 0;
    if (tutar <= 0) return;
    await _depo.hareketEkle(KasaHareketModel(
      hareketTipi: tip,
      tutar: tutar,
      tarih: DateTime.now(),
      aciklama: acCtrl.text.trim().isEmpty ? tip : acCtrl.text.trim(),
    ));
    await _yukle();
    // Aynı sınıf sorun: bu ekranın kendi listesi yenileniyordu ama
    // başka bir ekranda açık olabilecek Kasa Raporu yenilenmiyordu.
    ref.invalidate(kasaRaporProvider);
  }

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('dd.MM.yyyy HH:mm');
    final girisToplam = _gunlukOzet['giris'] ?? 0;
    final cikisToplam = _gunlukOzet['cikis'] ?? 0;

    return Scaffold(
      backgroundColor: context.scaffoldBg,
      appBar: TsAppBar(
        baslik: 'Kasa Hareketleri',
        aksiyonlar: [
          IconButton(
              icon: const Icon(Icons.add),
              tooltip: 'Hareket Ekle',
              onPressed: _hareketEkle),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _yukle),
        ],
        geriTusu: false,
        gradyanli: false,
      ),
      body: Column(children: [
        // Bakiye + özet
        Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [TsRenk.primaryKoyu, TsRenk.primary],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(16)),
          child: Column(children: [
            const Text('Güncel Bakiye',
                style: TextStyle(color: Colors.white60, fontSize: 13)),
            const SizedBox(height: 4),
            Text(ParaUtils.formatla(_bakiye),
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                  child: _ozetKart(
                      'Bugün Giriş', girisToplam, Colors.greenAccent)),
              const SizedBox(width: 12),
              Expanded(
                  child:
                      _ozetKart('Bugün Çıkış', cikisToplam, Colors.redAccent)),
              const SizedBox(width: 12),
              Expanded(
                  child: _ozetKart(
                      'Net',
                      girisToplam - cikisToplam,
                      girisToplam >= cikisToplam
                          ? Colors.lightGreenAccent
                          : Colors.orangeAccent)),
            ]),
          ]),
        ),
        Expanded(
          child: _yukleniyor
              ? const TsYukleniyor()
              : _hareketler.isEmpty
                  ? Center(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                          Icon(Icons.account_balance_wallet_outlined,
                              size: 56, color: context.textHint),
                          const SizedBox(height: 12),
                          Text('Henüz hareket yok',
                              style: TextStyle(color: context.textSecondary)),
                        ]))
                  : MediaQuery.sizeOf(context).width > 1100
                  ? _masaustuTablo(fmt)
                  : RefreshIndicator(
                      onRefresh: _yukle,
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: _hareketler.length,
                        itemBuilder: (_, i) {
                          final h = _hareketler[i];
                          final giris = KasaHareketModel.girisMi(h.hareketTipi);
                          final renk = giris ? TsRenk.basarili : TsRenk.hata;
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: TsKart.liste(
                              ikon: Icon(
                                  giris
                                      ? Icons.arrow_downward_rounded
                                      : Icons.arrow_upward_rounded,
                                  color: renk),
                              baslik: h.aciklama ?? h.hareketTipi,
                              altBaslik: fmt.format(h.tarih),
                              etiketler: [
                                TsBadge(
                                    metin: h.hareketTipi,
                                    tur: giris
                                        ? TsBadgeTuru.basarili
                                        : TsBadgeTuru.hata)
                              ],
                              sagAksiyon: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                        '${giris ? '+' : '-'}${ParaUtils.formatla(h.tutar)}',
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700,
                                            fontSize: 15,
                                            color: renk)),
                                    if (h.bakiyeSonrasi != null)
                                      Text(ParaUtils.formatla(h.bakiyeSonrasi!),
                                          style: TextStyle(
                                              fontSize: 10,
                                              color: context.textSecondary)),
                                  ]),
                            ),
                          );
                        },
                      )),
        ),
      ]),
      // Masaüstünde (tablo) üst çubuktaki + kullanılır; düğme son satırı örter.
      floatingActionButton: MediaQuery.sizeOf(context).width > 1100
          ? null
          : FloatingActionButton.extended(
        backgroundColor: TsRenk.primary,
        foregroundColor: Colors.white,
        elevation: 2,
        onPressed: _hareketEkle,
        icon: const Icon(Icons.add),
        label: const Text('Hareket Ekle'),
      ),
    );
  }

  /// Geniş pencere (masaüstü): sıralanabilir hareket tablosu.
  Widget _masaustuTablo(DateFormat fmt) {
    return MasaustuTablo<KasaHareketModel>(
      satirlar: _hareketler,
      kolonlar: [
        TabloKolon(
            baslik: 'Tarih',
            genislik: 140,
            deger: (h) => fmt.format(h.tarih),
            sirala: (h) => h.tarih),
        TabloKolon(
            baslik: 'Tür',
            genislik: 130,
            deger: (h) => h.hareketTipi,
            sirala: (h) => h.hareketTipi),
        TabloKolon(
            baslik: 'Açıklama',
            genislik: 280,
            esnek: true,
            deger: (h) => h.aciklama ?? '',
            sirala: (h) => (h.aciklama ?? '').toLowerCase()),
        TabloKolon(
            baslik: 'Ödeme Yöntemi',
            genislik: 120,
            deger: (h) => h.odemeYontemi ?? ''),
        TabloKolon(
            baslik: 'Giriş',
            genislik: 110,
            sagaYasli: true,
            deger: (h) => KasaHareketModel.girisMi(h.hareketTipi)
                ? ParaUtils.formatla(h.tutar, simge: '')
                : '',
            sirala: (h) => KasaHareketModel.girisMi(h.hareketTipi) ? h.tutar : 0.0,
            renk: (h) => TsRenk.basarili),
        TabloKolon(
            baslik: 'Çıkış',
            genislik: 110,
            sagaYasli: true,
            deger: (h) => KasaHareketModel.girisMi(h.hareketTipi)
                ? ''
                : ParaUtils.formatla(h.tutar, simge: ''),
            sirala: (h) => KasaHareketModel.girisMi(h.hareketTipi) ? 0.0 : h.tutar,
            renk: (h) => TsRenk.hata),
        TabloKolon(
            baslik: 'Bakiye',
            genislik: 120,
            sagaYasli: true,
            deger: (h) => h.bakiyeSonrasi == null
                ? ''
                : ParaUtils.formatla(h.bakiyeSonrasi!, simge: ''),
            sirala: (h) => h.bakiyeSonrasi ?? 0.0),
      ],
      secili: _seciliHareket,
      onSec: (h) => setState(() => _seciliHareket = h),
    );
  }

  Widget _ozetKart(String label, double val, Color renk) => Column(children: [
        Text(label,
            style: const TextStyle(color: Colors.white54, fontSize: 10)),
        const SizedBox(height: 2),
        Text(ParaUtils.formatla(val),
            style: TextStyle(
                color: renk, fontSize: 13, fontWeight: FontWeight.w700)),
      ]);
}
