﻿import 'package:flutter/material.dart';
import 'package:market_uygulamasi/servisler/auth_servisi.dart';
import 'package:market_uygulamasi/repozitory/kullanici_repo.dart';
import 'package:market_uygulamasi/rotalar.dart';
import 'package:market_uygulamasi/modeller/kullanici.dart';

class SifreDegistirEkrani extends StatefulWidget {
  @override
  _SifreDegistirEkraniState createState() => _SifreDegistirEkraniState();
}

class _SifreDegistirEkraniState extends State<SifreDegistirEkrani> {
  final AuthServisi _auth = AuthServisi();
  final KullaniciRepository _kullaniciRepo = KullaniciRepository();

  final _eskiSifreCtrl = TextEditingController();
  final _yeniSifreCtrl = TextEditingController();
  final _yeniSifreTekrarCtrl = TextEditingController();

  List<Kullanici> _kullanicilar = [];
  Kullanici? _seciliKullanici;

  bool _eskiGorunur = false;
  bool _yeniGorunur = false;
  bool _yeniTekrarGorunur = false;

  String _hata = "";
  bool _isProcessing = false;

  @override
  void initState() {
    super.initState();
    _kullanicilariYukle();
  }

  Future<void> _kullanicilariYukle() async {
    final liste = await _kullaniciRepo.kullaniciListesiGetir();
    if (!mounted) return;
    setState(() {
      _kullanicilar = liste;
      if (_seciliKullanici == null && liste.isNotEmpty) {
        _seciliKullanici = liste.firstWhere(
          (k) => k.kullaniciAdi == _auth.aktifKullanici?.kullaniciAdi,
          orElse: () => liste.first,
        );
      }
    });
  }

  Future<void> _sifreDegistir() async {
    if (_seciliKullanici == null) {
      setState(() => _hata = "Lütfen bir kullanıcı seçin");
      return;
    }

    final eski = _eskiSifreCtrl.text.trim();
    final yeni = _yeniSifreCtrl.text.trim();
    final yeniTekrar = _yeniSifreTekrarCtrl.text.trim();

    if (eski.isEmpty) {
      setState(() => _hata = "Eski şifre gerekli");
      return;
    }
    if (yeni.isEmpty || yeni.length < 4) {
      setState(() => _hata = "Yeni şifre en az 4 karakter olmalı");
      return;
    }
    if (yeni != yeniTekrar) {
      setState(() => _hata = "Yeni şifreler uyuşmuyor");
      return;
    }

    setState(() { _hata = ""; _isProcessing = true; });

    try {
      final basarili = await _kullaniciRepo.sifreDegistir(
        _seciliKullanici!.kullaniciAdi, eski, yeni,
      );

      if (!mounted) return;
      if (basarili) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Şifre başarıyla değiştirildi"), backgroundColor: Colors.green),
        );
        Navigator.pop(context);
      } else {
        setState(() => _hata = "Eski şifre hatalı");
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _hata = "Bir hata oluştu: $e");
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  Future<void> _kullaniciSil(Kullanici kullanici) async {
    if (kullanici.id == null) return;
    // Admin kullanıcısı silinemez
    if (kullanici.kullaniciAdi == 'admin') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Yönetici kullanıcı silinemez"), backgroundColor: Colors.red),
      );
      return;
    }

    final onay = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Kullanıcıyı Sil"),
        content: Text("${kullanici.kullaniciAdi} kullanıcısını silmek istediğinize emin misiniz?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text("İptal")),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text("Sil", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (onay == true) {
      await _kullaniciRepo.kullaniciSil(kullanici.id!);
      _kullanicilariYukle();
    }
  }

  Future<void> _yeniKullaniciEkle() async {
    final formKey = GlobalKey<FormState>();
    final adCtrl = TextEditingController();
    final sifreCtrl = TextEditingController();
    String? seciliRol = 'personel';

    final eklendi = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setStateDialog) => AlertDialog(
          title: const Text('Yeni Kullanıcı Ekle'),
          content: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: adCtrl,
                  decoration: const InputDecoration(labelText: 'Kullanıcı Adı', border: OutlineInputBorder()),
                  validator: (v) => v == null || v.isEmpty ? 'Zorunlu alan' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: sifreCtrl,
                  decoration: const InputDecoration(labelText: 'Şifre', border: OutlineInputBorder()),
                  obscureText: true,
                  validator: (v) => v == null || v.isEmpty ? 'Zorunlu alan' : null,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: seciliRol,
                  items: const [
                    DropdownMenuItem(value: 'admin', child: Text('Admin')),
                    DropdownMenuItem(value: 'personel', child: Text('Personel')),
                  ],
                  onChanged: (v) => setStateDialog(() => seciliRol = v),
                  decoration: const InputDecoration(labelText: 'Rol', border: OutlineInputBorder()),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')),
            ElevatedButton(
              onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(ctx, true); },
              child: const Text('Ekle'),
            ),
          ],
        ),
      ),
    );

    if (eklendi == true) {
      try {
        await _kullaniciRepo.kullaniciEkle(Kullanici(
          kullaniciAdi: adCtrl.text.trim(),
          sifre: sifreCtrl.text.trim(),
          rol: seciliRol ?? 'personel',
        ));
        _kullanicilariYukle();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Kullanıcı eklendi'), backgroundColor: Colors.green),
        );
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Hata: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text("Kullanıcı Yönetimi"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Kullanıcı seçim kartı
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Kullanıcı Seç", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<Kullanici>(
                      value: _seciliKullanici,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12),
                      ),
                      items: _kullanicilar.map((k) {
                        return DropdownMenuItem<Kullanici>(
                          value: k,
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 16,
                                backgroundColor: k.rol == 'admin' ? Colors.orange : Colors.grey,
                                child: Text(
                                  k.kullaniciAdi[0].toUpperCase(),
                                  style: const TextStyle(color: Colors.white, fontSize: 14),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Text(k.kullaniciAdi, style: const TextStyle(fontWeight: FontWeight.w600)),
                            ],
                          ),
                        );
                      }).toList(),
                      onChanged: (v) => setState(() => _seciliKullanici = v),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Kullanıcı listesi ve silme
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Kayıtlı Kullanıcılar", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        Text("${_kullanicilar.length} kullanıcı", style: TextStyle(color: Colors.grey[600])),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _kullanicilar.length,
                      itemBuilder: (ctx, i) {
                        final k = _kullanicilar[i];
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: k.rol == 'admin' ? Colors.orange.shade200 : Colors.green.shade200,
                            child: Text(k.kullaniciAdi[0].toUpperCase()),
                          ),
                          title: Text(k.kullaniciAdi),
                          subtitle: Text(k.rol, style: const TextStyle(fontSize: 12)),
                          trailing: k.kullaniciAdi == 'admin'
                              ? const Icon(Icons.shield, color: Colors.orange)
                              : IconButton(
                                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                                  onPressed: () => _kullaniciSil(k),
                                ),
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    // Yeni kullanıcı ekle butonu
                    if (_auth.isAdmin)
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _yeniKullaniciEkle,
                          icon: const Icon(Icons.person_add),
                          label: const Text('Yeni Kullanıcı Ekle'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Şifre değiştirme formu
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Şifre Değiştir', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 20),
                    TextField(
                      controller: _eskiSifreCtrl,
                      obscureText: !_eskiGorunur,
                      decoration: InputDecoration(
                        labelText: "Eski Şifre",
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          icon: Icon(_eskiGorunur ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => setState(() => _eskiGorunur = !_eskiGorunur),
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _yeniSifreCtrl,
                      obscureText: !_yeniGorunur,
                      decoration: InputDecoration(
                        labelText: "Yeni Şifre",
                        prefixIcon: const Icon(Icons.lock),
                        suffixIcon: IconButton(
                          icon: Icon(_yeniGorunur ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => setState(() => _yeniGorunur = !_yeniGorunur),
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _yeniSifreTekrarCtrl,
                      obscureText: !_yeniTekrarGorunur,
                      decoration: InputDecoration(
                        labelText: "Yeni Şifre (Tekrar)",
                        prefixIcon: const Icon(Icons.lock),
                        suffixIcon: IconButton(
                          icon: Icon(_yeniTekrarGorunur ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => setState(() => _yeniTekrarGorunur = !_yeniTekrarGorunur),
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 58,
                      child: ElevatedButton(
                        onPressed: _isProcessing ? null : _sifreDegistir,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue.shade700,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          elevation: 0,
                          minimumSize: const Size.fromHeight(48), // Yüksekliği garantiler
                        ),
                        child: _isProcessing
                            ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                            : const Center(
                                child: Text(
                                  'Şifre Değiştir',
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                      ),
                    ),
                    if (_hata.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: Text(_hata, style: const TextStyle(color: Colors.red, fontSize: 14), textAlign: TextAlign.center),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _eskiSifreCtrl.dispose();
    _yeniSifreCtrl.dispose();
    _yeniSifreTekrarCtrl.dispose();
    super.dispose();
  }
}