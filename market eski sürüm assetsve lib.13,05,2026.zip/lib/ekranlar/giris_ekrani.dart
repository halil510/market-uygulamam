import 'package:flutter/material.dart';
import 'package:market_uygulamasi/servisler/auth_servisi.dart';
import 'package:market_uygulamasi/rotalar.dart';
import 'package:market_uygulamasi/repozitory/kullanici_repo.dart';

class GirisEkrani extends StatefulWidget {
  @override
  _GirisEkraniState createState() => _GirisEkraniState();
}

class _GirisEkraniState extends State<GirisEkrani> {
  final TextEditingController _kullaniciController = TextEditingController(text: 'admin');
  String _hata = "";
  bool _girisYukleniyor = false;
  bool _sifreGorunur = false;
  final AuthServisi _authServisi = AuthServisi();

  // Şifreyi yönetmek için ValueNotifier
  final ValueNotifier<String> _sifre = ValueNotifier<String>("");

  List<String> _kullaniciListesi = [];
  bool _kullanicilarYuklendi = false;
  final FocusNode _kullaniciFocus = FocusNode();

  @override
  void initState() {
    super.initState();
    _kullaniciListesiniYukle();
  }

  @override
  void dispose() {
    _kullaniciController.dispose();
    _sifre.dispose();
    _kullaniciFocus.dispose();
    super.dispose();
  }

  Future<void> _kullaniciListesiniYukle() async {
    final repo = KullaniciRepository();
    final kullanicilar = await repo.kullaniciListesiGetir();
    if (mounted) {
      setState(() {
        _kullaniciListesi = kullanicilar.map((k) => k.kullaniciAdi).toList();
        _kullanicilarYuklendi = true;
      });
    }
  }

  void _kullaniciSec(String? kullaniciAdi) {
    if (kullaniciAdi != null) {
      _kullaniciController.text = kullaniciAdi;
      _kullaniciFocus.unfocus();
      setState(() {});
    }
  }

  void _rakamTiklandi(String rakam) {
    if (_sifre.value.length < 20) {
      _sifre.value += rakam;
    }
  }

  void _silTiklandi() {
    if (_sifre.value.isNotEmpty) {
      _sifre.value = _sifre.value.substring(0, _sifre.value.length - 1);
    }
  }

  Future<void> _girisYap() async {
    final kullaniciAdi = _kullaniciController.text.trim();
    final sifre = _sifre.value.trim();

    if (kullaniciAdi.isEmpty || sifre.isEmpty) {
      setState(() => _hata = "Kullanıcı adı ve şifre gerekli");
      return;
    }

    setState(() {
      _girisYukleniyor = true;
      _hata = "";
    });

    try {
      final basarili = await _authServisi.girisYap(kullaniciAdi, sifre);
      if (!mounted) return;
      if (basarili) {
        Navigator.pushReplacementNamed(context, Rotalar.anaEkran);
      } else {
        setState(() {
          _hata = "Kullanıcı adı veya şifre hatalı";
          _sifre.value = "";
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _hata = "Hata oluştu: ${e.toString().substring(0, 50)}");
    } finally {
      if (mounted) setState(() => _girisYukleniyor = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      // Logo
                      Container(
                        width: 110,
                        height: 84,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(24),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.15),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(24),
                          child: Image.asset(
                            'assets/images/logo.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      // Yazılı logo
                      Container(
                        margin: const EdgeInsets.only(top: -40),
                        height: 130,
                        width: 250,
                        child: Image.asset(
                          'assets/images/logoYazı.png',
                          fit: BoxFit.contain,
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Kullanıcı adı
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4))
                          ],
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: _kullaniciController,
                                focusNode: _kullaniciFocus,
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                decoration: InputDecoration(
                                  hintText: 'Kullanıcı Adı',
                                  hintStyle: TextStyle(color: Colors.grey[400], fontSize: 16),
                                  prefixIcon: const Icon(Icons.person_outline, color: Color(0xFF2E3A59), size: 22),
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                                  contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                                  filled: true,
                                  fillColor: Colors.white,
                                ),
                              ),
                            ),
                            PopupMenuButton<String>(
                              icon: const Icon(Icons.arrow_drop_down, color: Color(0xFF2E3A59), size: 32),
                              tooltip: 'Kayıtlı kullanıcılar',
                              onSelected: _kullaniciSec,
                              itemBuilder: (context) {
                                if (_kullaniciListesi.isEmpty) {
                                  return [
                                    const PopupMenuItem<String>(
                                      value: null,
                                      enabled: false,
                                      child: Text('Kayıtlı kullanıcı yok', style: TextStyle(color: Colors.grey)),
                                    ),
                                  ];
                                }
                                return _kullaniciListesi.map((ad) {
                                  return PopupMenuItem<String>(
                                    value: ad,
                                    child: Text(ad),
                                  );
                                }).toList();
                              },
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Şifre alanı
                      ValueListenableBuilder<String>(
                        valueListenable: _sifre,
                        builder: (context, sifreDegeri, child) {
                          return Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4))
                              ],
                            ),
                            child: TextField(
                              controller: TextEditingController(text: sifreDegeri),
                              readOnly: true,
                              obscureText: !_sifreGorunur,
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 8),
                              decoration: InputDecoration(
                                hintText: 'Şifre',
                                hintStyle: TextStyle(color: Colors.grey[400], fontSize: 16, letterSpacing: 0),
                                prefixIcon: const Icon(Icons.lock_outline, color: Color(0xFF2E3A59), size: 22),
                                suffixIcon: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                        icon: Icon(_sifreGorunur ? Icons.visibility : Icons.visibility_off,
                                            color: Colors.grey, size: 22),
                                        onPressed: () => setState(() => _sifreGorunur = !_sifreGorunur)),
                                    if (sifreDegeri.isNotEmpty)
                                      IconButton(
                                          icon: const Icon(Icons.backspace_outlined, color: Colors.grey, size: 22),
                                          onPressed: _silTiklandi),
                                  ],
                                ),
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                                contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                                filled: true,
                                fillColor: Colors.white,
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 30),
                      _buildNumpad(),
                    ],
                  ),
                ),
              ),
              if (_hata.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 8),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.red.shade200)),
                    child: Row(
                      children: [
                        Icon(Icons.error_outline, color: Colors.red.shade400, size: 20),
                        const SizedBox(width: 8),
                        Expanded(child: Text(_hata, style: TextStyle(color: Colors.red.shade700, fontSize: 14))),
                      ],
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(28, 16, 28, 20),
                child: SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: ElevatedButton(
                    onPressed: _girisYukleniyor ? null : _girisYap,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2E3A59),
                      disabledBackgroundColor: const Color(0xFF2E3A59).withOpacity(0.6),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      elevation: 4,
                      shadowColor: const Color(0xFF2E3A59).withOpacity(0.4),
                    ),
                    child: _girisYukleniyor
                        ? const SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
                        : const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.login_rounded, size: 24, color: Colors.white),
                              SizedBox(width: 10),
                              Text('GİRİŞ YAP',
                                  style: TextStyle(
                                      fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 1)),
                            ],
                          ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNumpad() {
    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.4,
      children: [
        _numButton('1'),
        _numButton('2'),
        _numButton('3'),
        _numButton('4'),
        _numButton('5'),
        _numButton('6'),
        _numButton('7'),
        _numButton('8'),
        _numButton('9'),
        _numButton('⌫', isAction: true, isDelete: true),
        _numButton('0'),
        _numButton('✔', isAction: true, isConfirm: true),
      ],
    );
  }

  Widget _numButton(String num, {bool isAction = false, bool isConfirm = false, bool isDelete = false}) {
    final Color normalBg = Colors.green.shade50;
    final Color deleteBg = Colors.grey.shade200;
    final Color confirmBg = Colors.green.shade600;

    return Material(
      color: isConfirm ? confirmBg : (isDelete ? deleteBg : normalBg),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: () {
          if (isAction) {
            if (isConfirm) {
              _girisYap();
            } else if (isDelete) {
              _silTiklandi();
            }
          } else {
            _rakamTiklandi(num);
          }
        },
        borderRadius: BorderRadius.circular(16),
        splashColor: isConfirm ? Colors.white.withOpacity(0.3) : Colors.green.withOpacity(0.2),
        highlightColor: isConfirm ? Colors.white.withOpacity(0.1) : Colors.green.withOpacity(0.1),
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Text(
            num,
            style: TextStyle(
              fontSize: isAction ? 28 : 26,
              fontWeight: isConfirm ? FontWeight.bold : FontWeight.w500,
              color: isConfirm ? Colors.white : Colors.black87,
            ),
          ),
        ),
      ),
    );
  }
}