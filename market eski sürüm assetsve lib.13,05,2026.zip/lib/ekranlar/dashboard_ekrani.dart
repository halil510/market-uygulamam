import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:flutter/services.dart';

import 'package:market_uygulamasi/repozitory/satis_repo.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/repozitory/stok_repo.dart';
import 'package:market_uygulamasi/repozitory/musteri_repo.dart';
import 'package:market_uygulamasi/repozitory/cari_hareket_repo.dart';
import 'package:market_uygulamasi/rotalar.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/modeller/cari_hareket.dart';
import '../modeller/musteri.dart';
import 'package:market_uygulamasi/core/logger.dart';


class DashboardEkrani extends StatefulWidget {
  @override
  _DashboardEkraniState createState() => _DashboardEkraniState();
}

class _DashboardEkraniState extends State<DashboardEkrani> {
  final SatisRepository _satisRepo = SatisRepository();
  final UrunRepoSitory _urunRepo = UrunRepoSitory();
  final StokRepository _stokRepo = StokRepository();
  final MusteriRepo _musteriRepo = MusteriRepo();
  final CariHareketRepo _cariHareketRepo = CariHareketRepo();

  int _toplamUrunSayisi = 0;
  double _gunlukCiro = 0.0;
  double _haftalikCiro = 0.0;
  double _aylikCiro = 0.0;
  double _yillikCiro = 0.0;
  int _dusukStokluUrunSayisi = 0;
  int _toplamMusteriSayisi = 0;
  int _toplamTedarikciSayisi = 0;
  double _toplamTahsilat = 0.0;
  double _toplamOdeme = 0.0;
  double _netKar = 0.0;
  double _toplamMusteriBakiyesi = 0.0;
  double _toplamTedarikciBakiyesi = 0.0;
  bool _yukleniyor = true;
  String _selectedPeriod = 'Günlük';

  List<SalesData> _ciroGrafikVerileri = [];
  List<StockData> _stokGrafikVerileri = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _verileriYukle();
      }
    });
  }

 // Değişiklik: selectedPeriodSales tanımlaması ve switch-case kaldırıldı.
// Doğrudan gerekli satış listesi kullanılıyor.
Future<void> _verileriYukle() async {
  setState(() => _yukleniyor = true);

  try {
    final urunler = await _urunRepo.tumUrunleriGetir();
    final musteriler = await _musteriRepo.tumMusterileriGetir();
    final tedarikciler = await _musteriRepo.tumTedarikcileriGetir();

    final bugun = DateTime.now();
    final baslangic = DateTime(bugun.year, bugun.month, bugun.day);
    final bitis = DateTime(bugun.year, bugun.month, bugun.day, 23, 59, 59);

    final haftaBaslangic = bugun.subtract(Duration(days: 6));
    final ayBaslangic = DateTime(bugun.year, bugun.month, 1);
    final yilBaslangic = DateTime(bugun.year, 1, 1);

    final gunlukSatislar = await _satisRepo.tariheGoreSatislariGetir(baslangic, bitis);
    final haftalikSatislar = await _satisRepo.tariheGoreSatislariGetir(
      DateTime(haftaBaslangic.year, haftaBaslangic.month, haftaBaslangic.day),
      bitis,
    );
    final aylikSatislar = await _satisRepo.tariheGoreSatislariGetir(ayBaslangic, bitis);
    final yillikSatislar = await _satisRepo.tariheGoreSatislariGetir(yilBaslangic, bitis);

    final dusukStokluUrunler = await _stokRepo.dusukStokluUrunleriGetir(5);

    final tahsilatlar = await _cariHareketRepo.hareketleriGetirByTarihAralik(baslangic, bitis, 'Tahsilat');
    final odemeler = await _cariHareketRepo.hareketleriGetirByTarihAralik(baslangic, bitis, 'Ödeme');

    // Müşteri ve tedarikçi bakiyelerini hesapla
    double musteriToplamBakiye = 0.0;
    double tedarikciToplamBakiye = 0.0;
    for (var musteri in musteriler) { musteriToplamBakiye += musteri.bakiye; }
    for (var tedarikci in tedarikciler) { tedarikciToplamBakiye += tedarikci.bakiye; }

    // Net kar hesapla (seçili periyoda göre)
    List<Satis> activeSales;
    switch (_selectedPeriod) {
      case 'Haftalık': activeSales = haftalikSatislar; break;
      case 'Aylık': activeSales = aylikSatislar; break;
      case 'Yıllık': activeSales = yillikSatislar; break;
      default: activeSales = gunlukSatislar;
    }

    double toplamTutar = 0.0;
    double toplamMaliyet = 0.0;
    for (var satis in activeSales) {
      if (satis.fisTipi == 'Satış') {
        toplamTutar += satis.toplamTutar;
        for (var kalem in satis.kalemler) {
          final urun = await _urunRepo.idyeGoreUrunGetir(kalem.urunId);
          final alisFiyati = urun?.alisFiyat ?? 0;
          toplamMaliyet += alisFiyati * kalem.miktar;
        }
      }
    }
    double netKar = toplamTutar - toplamMaliyet;

    // Grafik verilerini son 7 gün için hazırla
    _ciroGrafikVerileri.clear();
    final now = DateTime.now();
    for (int i = 6; i >= 0; i--) {
      final date = now.subtract(Duration(days: i));
      final gunSatislari = haftalikSatislar.where((satis) =>
          satis.tarih.year == date.year &&
          satis.tarih.month == date.month &&
          satis.tarih.day == date.day);
      final toplam = gunSatislari.fold(0.0, (sum, satis) => sum + satis.toplamTutar);
      _ciroGrafikVerileri.add(SalesData(
        DateFormat('dd/MM').format(date),
        toplam,
      ));
    }

    setState(() {
      _toplamUrunSayisi = urunler.length;
      _toplamMusteriSayisi = musteriler.length;
      _toplamTedarikciSayisi = tedarikciler.length;
      _gunlukCiro = gunlukSatislar.fold(0.0, (toplam, satis) => toplam + satis.toplamTutar);
      _haftalikCiro = haftalikSatislar.fold(0.0, (toplam, satis) => toplam + satis.toplamTutar);
      _aylikCiro = aylikSatislar.fold(0.0, (toplam, satis) => toplam + satis.toplamTutar);
      _yillikCiro = yillikSatislar.fold(0.0, (toplam, satis) => toplam + satis.toplamTutar);
      _dusukStokluUrunSayisi = dusukStokluUrunler.length;
      _toplamTahsilat = tahsilatlar.fold(0.0, (toplam, hareket) => toplam + (hareket.alacak ?? 0));
      _toplamOdeme = odemeler.fold(0.0, (toplam, hareket) => toplam + (hareket.borc ?? 0));
      _netKar = netKar;
      _toplamMusteriBakiyesi = musteriToplamBakiye;
      _toplamTedarikciBakiyesi = tedarikciToplamBakiye;
      _yukleniyor = false;
    });
  } catch (e) {
    appLogger.i("Veri yükleme hatası: $e");
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Veri yüklenirken hata oluştu: $e"))
      );
    }
    setState(() => _yukleniyor = false);
  }
}

  void _hazirGrafikVerileri(List<Satis> satislar) {
    _ciroGrafikVerileri.clear();
    final now = DateTime.now();

    for (int i = 6; i >= 0; i--) {
      final date = now.subtract(Duration(days: i));
      final gunSatislari = satislar.where((satis) =>
          satis.tarih.year == date.year &&
          satis.tarih.month == date.month &&
          satis.tarih.day == date.day);

      final toplam = gunSatislari.fold(0.0, (sum, satis) => sum + satis.toplamTutar);

      _ciroGrafikVerileri.add(SalesData(
        DateFormat('dd/MM').format(date),
        toplam,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Raporlar'),
        backgroundColor: Colors.blue.shade800,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: _verileriYukle,
          ),
          PopupMenuButton(
            itemBuilder: (context) => [
              PopupMenuItem(
                child: Text('Detaylı Rapor'),
                value: 'rapor',
              ),
              PopupMenuItem(
                child: Text('Verileri Dışa Aktar'),
                value: 'export',
              ),
            ],
            onSelected: (value) {
              if (value == 'rapor') {
                Navigator.pushNamed(context, Rotalar.gunSonuRapor);
              } else if (value == 'export') {
                _verileriDisaAktar();
              }
            },
          )
        ],
      ),
      body: _yukleniyor
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Genel Bakış', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 16),

                  Row(
                    children: [
                      Expanded(
                        child: _buildInfoCard(
                          'Toplam Ürün',
                          _toplamUrunSayisi.toString(),
                          Icons.inventory,
                          Colors.blue,
                          () => Navigator.pushNamed(context, Rotalar.urunListe),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: _buildInfoCard(
                          'Toplam Müşteri',
                          _toplamMusteriSayisi.toString(),
                          Icons.people,
                          Colors.green,
                          () => Navigator.pushNamed(context, Rotalar.cariler),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  
                  Row(
                    children: [
                      Expanded(
                        child: _buildInfoCard(
                          'Toplam Tedarikçi',
                          _toplamTedarikciSayisi.toString(),
                          Icons.business,
                          Colors.orange,
                          () => Navigator.pushNamed(context, Rotalar.cariler),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: _buildInfoCard(
                          'Düşük Stok',
                          _dusukStokluUrunSayisi.toString(),
                          Icons.warning,
                          Colors.red,
                          () => Navigator.pushNamed(context, Rotalar.stokListe),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),

                  // Periyot seçimi
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Finansal Göstergeler', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      DropdownButton<String>(
                        value: _selectedPeriod,
                        items: ['Günlük', 'Haftalık', 'Aylık', 'Yıllık'].map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          setState(() {
                            _selectedPeriod = newValue!;
                            _verileriYukle();
                          });
                        },
                      ),
                    ],
                  ),
                  SizedBox(height: 16),

                  // Finansal göstergeler - 4'lü kart
                  Row(
                    children: [
                      Expanded(
                        child: _buildInfoCard(
                          'Günlük Ciro',
                          '${_gunlukCiro.toStringAsFixed(2)} ₺',
                          Icons.attach_money,
                          Colors.purple,
                          () => Navigator.pushNamed(context, Rotalar.gunSonuRapor),
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: _buildInfoCard(
                          'Aylık Ciro',
                          '${_aylikCiro.toStringAsFixed(2)} ₺',
                          Icons.bar_chart,
                          Colors.indigo,
                          () => Navigator.pushNamed(context, Rotalar.gunSonuRapor),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildInfoCard(
                          'Net Kar',
                          '${_netKar.toStringAsFixed(2)} ₺',
                          Icons.trending_up,
                          _netKar >= 0 ? Colors.green : Colors.red,
                          () {},
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: _buildInfoCard(
                          'Düşük Stok',
                          _dusukStokluUrunSayisi.toString(),
                          Icons.warning,
                          Colors.orange,
                          () => Navigator.pushNamed(context, Rotalar.stokListe),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),
                  Text('Bakiye Durumu', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 16),

                  // Bakiye bilgileri - daha kompakt
                  Row(
                    children: [
                      Expanded(
                        child: _buildBalanceCard(
                          'Müşteri Bak.',
                          '${_toplamMusteriBakiyesi.toStringAsFixed(2)} ₺',
                          Icons.account_balance_wallet,
                          _toplamMusteriBakiyesi >= 0 ? Colors.blue : Colors.red,
                          () => _showBakiyeDetay('Müşteri'),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: _buildBalanceCard(
                          'Tedarikçi Bak.',
                          '${_toplamTedarikciBakiyesi.toStringAsFixed(2)} ₺',
                          Icons.account_balance,
                          _toplamTedarikciBakiyesi >= 0 ? Colors.green : Colors.orange,
                          () => _showBakiyeDetay('Tedarikçi'),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 24),
                  Text('Ciro Trendi (Son 7 Gün)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 16),

                  Container(
                    height: 200,
                    child: SfCartesianChart(
                      primaryXAxis: CategoryAxis(),
                      series: <CartesianSeries>[
                        LineSeries<SalesData, String>(
                          dataSource: _ciroGrafikVerileri,
                          xValueMapper: (SalesData sales, _) => sales.day,
                          yValueMapper: (SalesData sales, _) => sales.sales,
                          dataLabelSettings: DataLabelSettings(isVisible: true),
                        )
                      ],
                    ),
                  ),

                  SizedBox(height: 24),
                  Text('Nakit Akışı', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 16),

                  Row(
                    children: [
                      Expanded(
                        child: _buildFinanceCard(
                          'Tahsilatlar',
                          _toplamTahsilat,
                          Icons.arrow_downward,
                          Colors.green,
                          () => _showPaymentDetails('Tahsilat'),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: _buildFinanceCard(
                          'Ödemeler',
                          _toplamOdeme,
                          Icons.arrow_upward,
                          Colors.red,
                          () => _showPaymentDetails('Ödeme'),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 24),
                  Text('Hızlı Erişim', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 16),

                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _buildQuickActionButton('Satış Yap', Icons.point_of_sale, Colors.green,
                          () => Navigator.pushNamed(context, Rotalar.hizliSatis)),
                      _buildQuickActionButton('Tahsilat', Icons.payment, Colors.blue,
                          () => _navigateToPayment('Tahsilat')),
                      _buildQuickActionButton('Ödeme', Icons.money_off, Colors.red,
                          () => _navigateToPayment('Ödeme')),
                      _buildQuickActionButton('Stok Sayım', Icons.calculate, Colors.orange,
                          () => Navigator.pushNamed(context, Rotalar.stokSayim)),
                      _buildQuickActionButton('Raporlar', Icons.bar_chart, Colors.purple,
                          () => Navigator.pushNamed(context, Rotalar.gunSonuRapor)),
                      _buildQuickActionButton('Yedekle', Icons.backup, Colors.teal,
                          () => Navigator.pushNamed(context, Rotalar.veriYedekle)),
                    ],
                  ),

                  SizedBox(height: 20),
                ],
              ),
            ),
    );
  }

  double _getSelectedPeriodCiro() {
    switch (_selectedPeriod) {
      case 'Günlük':
        return _gunlukCiro;
      case 'Haftalık':
        return _haftalikCiro;
      case 'Aylık':
        return _aylikCiro;
      case 'Yıllık':
        return _yillikCiro;
      default:
        return _gunlukCiro;
    }
  }

  Widget _buildInfoCard(String title, String value, IconData icon, Color color, Function onTap) {
    return InkWell(
      onTap: () => onTap(),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: color, size: 24),
                  ),
                  Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
              SizedBox(height: 8),
              Text(title, style: TextStyle(color: Colors.grey[600])),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBalanceCard(String title, String value, IconData icon, Color color, Function onTap) {
    return InkWell(
      onTap: () => onTap(),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: color, size: 20),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(title, 
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),
              Text(value, 
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFinanceCard(String title, double amount, IconData icon, Color color, Function onTap) {
    return InkWell(
      onTap: () => onTap(),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: color, size: 20),
                  SizedBox(width: 8),
                  Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
              SizedBox(height: 8),
              Text('${amount.toStringAsFixed(2)} ₺',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActionButton(String text, IconData icon, Color color, Function onPressed) {
    return Material(
      borderRadius: BorderRadius.circular(12),
      color: color.withOpacity(0.1),
      child: InkWell(
        onTap: () => onPressed(),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 18),
              SizedBox(width: 8),
              Text(text, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  void _showPaymentDetails(String type) async {
    final bugun = DateTime.now();
    final baslangic = DateTime(bugun.year, bugun.month, bugun.day);
    final bitis = DateTime(bugun.year, bugun.month, bugun.day, 23, 59, 59);

    final hareketler = await _cariHareketRepo.hareketleriGetirByTarihAralik(baslangic, bitis, type);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('$type Detayları'),
        content: Container(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: hareketler.length,
            itemBuilder: (context, index) {
              final hareket = hareketler[index];
              return ListTile(
                title: Text(hareket.aciklama),
                subtitle: Text(DateFormat('dd/MM/yyyy HH:mm').format(hareket.tarih)),
                trailing: Text(
                    '${(type == 'Tahsilat' ? (hareket.alacak ?? 0) : (hareket.borc ?? 0)).toStringAsFixed(2)} ₺'),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Kapat'),
          ),
        ],
      ),
    );
  }

  void _showBakiyeDetay(String tip) async {
    List<Musteri> cariler = [];
    
    if (tip == 'Müşteri') {
      cariler = await _musteriRepo.tumMusterileriGetir();
    } else {
      cariler = await _musteriRepo.tumTedarikcileriGetir();
    }
    
    // Bakiye sıfır olanları filtrele
    cariler = cariler.where((cari) => cari.bakiye != 0).toList();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('$tip Bakiyeleri'),
        content: Container(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: cariler.length,
            itemBuilder: (context, index) {
              final cari = cariler[index];
              return ListTile(
                title: Text(cari.unvan),
                trailing: Text(
                  '${cari.bakiye.toStringAsFixed(2)} ₺',
                  style: TextStyle(
                    color: cari.bakiye >= 0 ? Colors.green : Colors.red,
                    fontWeight: FontWeight.bold
                  ),
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Kapat'),
          ),
        ],
      ),
    );
  }

  void _navigateToPayment(String type) {
    Navigator.pushNamed(context, Rotalar.cariler);
  }

  void _verileriDisaAktar() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Verileri Dışa Aktar"),
        content: const Text("Hangi formatta dışa aktarmak istersiniz?"),
        actions: [
          TextButton(
              onPressed: () {
                Navigator.pop(context);
                _csvOlarakDisaktar();
              },
              child: const Text("CSV")),
          TextButton(
              onPressed: () {
                Navigator.pop(context);
                _pdfOlarakDisaktar();
              },
              child: const Text("PDF")),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("İptal")),
        ],
      ),
    );
  }

  Future<void> _csvOlarakDisaktar() async {
    try {
      final buffer = StringBuffer();
      buffer.writeln("Gösterge,Değer");
      buffer.writeln("Toplam Ürün,$_toplamUrunSayisi");
      buffer.writeln("Toplam Müşteri,$_toplamMusteriSayisi");
      buffer.writeln("Toplam Tedarikçi,$_toplamTedarikciSayisi");
      buffer.writeln("Günlük Ciro,$_gunlukCiro");
      buffer.writeln("Haftalık Ciro,$_haftalikCiro");
      buffer.writeln("Aylık Ciro,$_aylikCiro");
      buffer.writeln("Yıllık Ciro,$_yillikCiro");
      buffer.writeln("Net Kar,$_netKar");
      buffer.writeln("Müşteri Bakiyeleri,$_toplamMusteriBakiyesi");
      buffer.writeln("Tedarikçi Bakiyeleri,$_toplamTedarikciBakiyesi");

      final dir = await getTemporaryDirectory();
      final file = File("${dir.path}/dashboard_${DateTime.now().millisecondsSinceEpoch}.csv");
      await file.writeAsString(buffer.toString());

      await Share.shareXFiles([XFile(file.path)], text: "Gösterge Raporu");
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("CSV hata: $e")));
      }
    }
  }

  Future<void> _pdfOlarakDisaktar() async {
    try {
      // Türkçe fontu yükle
      final fontData = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
      final ttf = pw.Font.ttf(fontData.buffer.asByteData());

      final pdf = pw.Document();
      
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text("Gösterge Raporu", 
                  style: pw.TextStyle(font: ttf, fontSize: 22, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 20),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Oluşturulma Tarihi:", style: pw.TextStyle(font: ttf, fontWeight: pw.FontWeight.bold)),
                    pw.Text(DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now()), style: pw.TextStyle(font: ttf)),
                  ],
                ),
                pw.Divider(),
                pw.SizedBox(height: 10),
                pw.Text("Genel Bakış", style: pw.TextStyle(font: ttf, fontSize: 18, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 10),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Toplam Ürün:", style: pw.TextStyle(font: ttf)),
                    pw.Text(_toplamUrunSayisi.toString(), style: pw.TextStyle(font: ttf)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Toplam Müşteri:", style: pw.TextStyle(font: ttf)),
                    pw.Text(_toplamMusteriSayisi.toString(), style: pw.TextStyle(font: ttf)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Toplam Tedarikçi:", style: pw.TextStyle(font: ttf)),
                    pw.Text(_toplamTedarikciSayisi.toString(), style: pw.TextStyle(font: ttf)),
                  ],
                ),
                pw.SizedBox(height: 20),
                pw.Text("Finansal Göstergeler", style: pw.TextStyle(font: ttf, fontSize: 18, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 10),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Günlük Ciro:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_gunlukCiro.toStringAsFixed(2)} ₺", style: pw.TextStyle(font: ttf)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Haftalık Ciro:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_haftalikCiro.toStringAsFixed(2)} ₺", style: pw.TextStyle(font: ttf)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Aylık Ciro:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_aylikCiro.toStringAsFixed(2)} ₺", style: pw.TextStyle(font: ttf)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Yıllık Ciro:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_yillikCiro.toStringAsFixed(2)} ₺", style: pw.TextStyle(font: ttf)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Net Kar:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_netKar.toStringAsFixed(2)} ₺", 
                      style: pw.TextStyle(
                        font: ttf, 
                        color: _netKar >= 0 ? PdfColors.green : PdfColors.red,
                        fontWeight: pw.FontWeight.bold
                      )),
                  ],
                ),
                pw.SizedBox(height: 20),
                pw.Text("Nakit Akışı", style: pw.TextStyle(font: ttf, fontSize: 18, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 10),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Tahsilatlar:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_toplamTahsilat.toStringAsFixed(2)} ₺", style: pw.TextStyle(font: ttf, color: PdfColors.green)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Ödemeler:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_toplamOdeme.toStringAsFixed(2)} ₺", style: pw.TextStyle(font: ttf, color: PdfColors.red)),
                  ],
                ),
                pw.SizedBox(height: 20),
                pw.Text("Bakiye Durumu", style: pw.TextStyle(font: ttf, fontSize: 18, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 10),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Müşteri Bakiyeleri:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_toplamMusteriBakiyesi.toStringAsFixed(2)} ₺", 
                      style: pw.TextStyle(
                        font: ttf, 
                        color: _toplamMusteriBakiyesi >= 0 ? PdfColors.green : PdfColors.red,
                      )),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Tedarikçi Bakiyeleri:", style: pw.TextStyle(font: ttf)),
                    pw.Text("${_toplamTedarikciBakiyesi.toStringAsFixed(2)} ₺", 
                      style: pw.TextStyle(
                        font: ttf, 
                        color: _toplamTedarikciBakiyesi >= 0 ? PdfColors.green : PdfColors.red,
                      )),
                  ],
                ),
                pw.SizedBox(height: 20),
                pw.Text("Stok Durumu", style: pw.TextStyle(font: ttf, fontSize: 18, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 10),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Düşük Stoklu Ürünler:", style: pw.TextStyle(font: ttf)),
                    pw.Text(_dusukStokluUrunSayisi.toString(), style: pw.TextStyle(font: ttf)),
                  ],
                ),
              ],
            );
          },
        ),
      );

      final dir = await getTemporaryDirectory();
      final file = File("${dir.path}/dashboard_${DateTime.now().millisecondsSinceEpoch}.pdf");
      await file.writeAsBytes(await pdf.save());

      await Share.shareXFiles([XFile(file.path)], text: "Dashboard Raporu (PDF)");
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("PDF oluşturma hatası: $e")));
      }
    }
  }
}

class SalesData {
  final String day;
  final double sales;
  SalesData(this.day, this.sales);
}

class StockData {
  final String product;
  final int quantity;
  StockData(this.product, this.quantity);
}