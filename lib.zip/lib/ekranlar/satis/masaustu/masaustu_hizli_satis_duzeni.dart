// lib/ekranlar/satis/masaustu/masaustu_hizli_satis_duzeni.dart
//
// Masaüstü Hızlı Satış — tüm parçaları birleştiren düzen (BarkoPOS benzeri):
//
//   ┌───────────────────────────────┬──────────────────┐
//   │ arama                         │  TOPLAM  0,00    │
//   │ sepet tablosu                 │  F12 Ödeme       │
//   │───────────────────────────────│  F tuşları       │
//   │ grup sekmeleri + ürün tuşları │  sayı tuşları    │
//   └───────────────────────────────┴──────────────────┘
//
// Sadece GÖRÜNÜM + klavye kısayolları: iş mantığı (ödeme, sepete ekleme,
// müşteri seçimi…) çağıran ekrandan geri-çağrı (callback) ile gelir.
import '../../../tasarim_sistemi/ts_token.dart';
import '../../../widgetlar/masaustu/ekran_ustte.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../modeller/sepet_model.dart';
import '../../../modeller/urun_model.dart';
import '../../../saglayicilar/riverpod/sepet_provider.dart';
import '../../../uygulama/tema/uygulama_temasi.dart';
import 'masaustu_f_tuslari.dart';
import '../../../widgetlar/ortak/iskonto_dialogu.dart';
import 'masaustu_sayi_tuslari.dart';
import 'masaustu_sepet_tablosu.dart';
import 'masaustu_toplam_karti.dart';
import 'masaustu_urun_izgarasi.dart';

class MasaustuHizliSatisDuzeni extends ConsumerStatefulWidget {
  final Widget aramaPaneli;

  /// Arama sonucu varsa (liste) tablo+ızgara yerine gösterilir.
  final Widget? aramaSonuclari;
  final ScrollController sepetScroll;
  final void Function(UrunModel urun) onUrunSec;
  final void Function(SepetKalem kalem, int index) onKalemDuzenle;
  final VoidCallback onOdeme;

  /// F1: ödeme penceresi açmadan satışı doğrudan Nakit olarak bitirir.
  final VoidCallback onHizliNakit;
  final VoidCallback onAramaOdak;
  final VoidCallback onStok;
  final VoidCallback onAskiyaAl;
  final VoidCallback? onSonFis; // null = henüz satış yok
  final VoidCallback onCari;
  final VoidCallback onFiyatGor;
  final VoidCallback onKasaAc;

  /// Fiş düzeltme modunda alışveriş sekmesi açılamaz/değiştirilemez.
  final bool sekmeKilitli;

  const MasaustuHizliSatisDuzeni({
    super.key,
    required this.aramaPaneli,
    required this.aramaSonuclari,
    required this.sepetScroll,
    required this.onUrunSec,
    required this.onKalemDuzenle,
    required this.onOdeme,
    required this.onHizliNakit,
    required this.onAramaOdak,
    required this.onStok,
    required this.onAskiyaAl,
    required this.onSonFis,
    required this.onCari,
    required this.onFiyatGor,
    required this.onKasaAc,
    this.sekmeKilitli = false,
  });

  @override
  ConsumerState<MasaustuHizliSatisDuzeni> createState() =>
      _MasaustuHizliSatisDuzeniState();
}

class _MasaustuHizliSatisDuzeniState
    extends ConsumerState<MasaustuHizliSatisDuzeni> {
  int? _secili;
  String _tampon = '';
  double _alinan = 0;
  int _gorulenSekme = 0;

  @override
  void initState() {
    super.initState();
    HardwareKeyboard.instance.addHandler(_tusGeldi);
  }

  @override
  void dispose() {
    HardwareKeyboard.instance.removeHandler(_tusGeldi);
    super.dispose();
  }

  // ── Klavye kısayolları ────────────────────────────────────────────────
  bool _metinKutusuOdakta() {
    final odak = FocusManager.instance.primaryFocus;
    return odak?.context?.widget is EditableText;
  }

  bool _tusGeldi(KeyEvent e) {
    if (e is! KeyDownEvent || !mounted) return false;
    // Üstte diyalog/başka ekran varsa dokunma.
    if (!ekranUstte(context)) return false;
    final k = e.logicalKey;
    final sepet = ref.read(sepetProvider);
    final odemeAktif = !sepet.bos && !sepet.satisIsleniyor;

    if (k == LogicalKeyboardKey.tab && HardwareKeyboard.instance.isControlPressed) {
      final n = ref.read(sepetProvider.notifier);
      _sekmeSec((n.aktifSekme + 1) % n.sekmeler.length);
    } else if (k == LogicalKeyboardKey.f1) {
      if (odemeAktif) widget.onHizliNakit();
    } else if (k == LogicalKeyboardKey.f2) {
      widget.onKasaAc();
    } else if (k == LogicalKeyboardKey.f3) {
      widget.onStok();
    } else if (k == LogicalKeyboardKey.f4) {
      if (!sepet.bos) widget.onAskiyaAl();
    } else if (k == LogicalKeyboardKey.f5) {
      widget.onSonFis?.call();
    } else if (k == LogicalKeyboardKey.f6) {
      _iskontoUygula();
    } else if (k == LogicalKeyboardKey.f7) {
      widget.onCari();
    } else if (k == LogicalKeyboardKey.f8) {
      widget.onFiyatGor();
    } else if (k == LogicalKeyboardKey.f9) {
      _sepetiTemizle();
    } else if (k == LogicalKeyboardKey.f10) {
      _yeniSekme();
    } else if (k == LogicalKeyboardKey.f12) {
      if (odemeAktif) widget.onOdeme();
    } else if (k == LogicalKeyboardKey.delete && !_metinKutusuOdakta()) {
      _seciliyiSil();
    } else if (k == LogicalKeyboardKey.escape && !_metinKutusuOdakta()) {
      setState(() {
        _tampon = '';
        _alinan = 0;
        _secili = null;
      });
    } else if (!_metinKutusuOdakta() &&
        (k == LogicalKeyboardKey.arrowDown || k == LogicalKeyboardKey.arrowUp)) {
      _seciliyiKaydir(k == LogicalKeyboardKey.arrowDown ? 1 : -1, sepet);
    } else {
      return false;
    }
    return true;
  }

  void _seciliyiKaydir(int yon, SepetDurum sepet) {
    if (sepet.bos) return;
    final son = sepet.kalemler.length - 1;
    setState(() => _secili = ((_secili ?? (yon > 0 ? -1 : son + 1)) + yon).clamp(0, son));
  }

  // ── Alışveriş sekmeleri ───────────────────────────────────────────────
  void _sekmeUyari(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  void _yeniSekme() {
    if (widget.sekmeKilitli) {
      _sekmeUyari('Fiş düzeltme modunda yeni alışveriş açılamaz');
      return;
    }
    final n = ref.read(sepetProvider.notifier);
    // Boş alışveriş açılmasın (kullanıcı isteği 2026-10-11): aktif sepet
    // boşsa zaten yeni müşteri için hazır; başka bir sekme boşsa ona geçilir.
    if (ref.read(sepetProvider).bos) {
      _sekmeUyari('Sepet boş — yeni müşteri için bu alışverişi kullanın');
      widget.onAramaOdak();
      return;
    }
    final bosSekme = n.sekmeler.indexWhere((s) => s.urunSayisi == 0);
    if (bosSekme >= 0) {
      _sekmeSec(bosSekme);
      _sekmeUyari('Boş olan Alışveriş ${n.sekmeler[bosSekme].no} açıldı');
      return;
    }
    if (n.sekmeler.length >= Sepet.maksSekme) {
      _sekmeUyari('En fazla ${Sepet.maksSekme} alışveriş açılabilir');
      return;
    }
    if (!n.yeniSekme()) _sekmeUyari('Satış işlenirken yeni alışveriş açılamaz');
    widget.onAramaOdak();
  }

  void _sekmeSec(int i) {
    final n = ref.read(sepetProvider.notifier);
    if (i == n.aktifSekme) return;
    if (widget.sekmeKilitli) {
      _sekmeUyari('Fiş düzeltme modunda alışveriş değiştirilemez');
      return;
    }
    if (!n.sekmeSec(i)) _sekmeUyari('Satış işlenirken alışveriş değiştirilemez');
    widget.onAramaOdak();
  }

  Future<void> _sekmeKapat(int i) async {
    final n = ref.read(sepetProvider.notifier);
    final s = n.sekmeler[i];
    if (s.urunSayisi > 0) {
      final onay = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: Text('Alışveriş ${s.no} kapatılsın mı?'),
          content: Text('Sepetteki ${s.urunSayisi} ürün silinecek (satış yapılmadan).'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Kapat')),
          ],
        ),
      );
      if (onay != true || !mounted) return;
    }
    n.sekmeKapat(i);
  }

  Widget _sekmeCubugu() {
    final n = ref.read(sepetProvider.notifier);
    final sekmeler = n.sekmeler;
    final aktif = n.aktifSekme;
    return Container(
      height: 42,
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
      decoration: BoxDecoration(
        color: context.cardBg,
        border: Border(bottom: BorderSide(color: context.borderColor)),
      ),
      child: Row(children: [
        // Tüm sekmeler HER ZAMAN sığar (canlı test 2026-10-09: 10 sekmede
        // 8-10 sağda gizli kalıyor, aktif sekme görünmüyordu). Sekme
        // daraldıkça etiket kısalır ("Alış. 7"), özet gizlenir.
        Expanded(
          child: Row(children: [
            for (var i = 0; i < sekmeler.length; i++) ...[
              if (i > 0) const SizedBox(width: 3),
              Flexible(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 230),
                  child: _sekmeKarti(sekmeler[i], i, i == aktif),
                ),
              ),
            ],
          ]),
        ),
        const SizedBox(width: 6),
        TextButton.icon(
          onPressed: sekmeler.length >= Sepet.maksSekme ? null : _yeniSekme,
          icon: const Icon(Icons.add, size: 18),
          label: Text(sekmeler.length > 4 ? 'F10' : 'F10 : Yeni Alışveriş',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
        ),
      ]),
    );
  }

  Widget _sekmeKarti(
      ({int no, int urunSayisi, double toplam, String? musteri}) s, int i, bool aktif) {
    const mavi = TsRenk.bilgi;
    final renk = aktif ? Colors.white : context.textSecondary;
    return Material(
      // Aktif sekme dolu renk — hangi müşteride olunduğu bir bakışta görülsün.
      color: aktif ? mavi : Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
        side: BorderSide(color: aktif ? mavi : context.borderColor),
      ),
      child: InkWell(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
        onTap: () => _sekmeSec(i),
        child: LayoutBuilder(builder: (context, c) {
          final dar = c.maxWidth < 125;
          final ozet = s.urunSayisi > 0 && c.maxWidth >= 170
              ? '  (${s.urunSayisi}) ${s.toplam.toStringAsFixed(2).replaceAll('.', ',')}'
                  '${s.musteri != null ? ' • ${s.musteri}' : ''}'
              : '';
          return Padding(
            padding: EdgeInsets.fromLTRB(dar ? 6 : 10, 4, 2, 4),
            child: Row(children: [
              Expanded(
                child: Text.rich(
                  TextSpan(children: [
                    TextSpan(
                        text: dar ? 'Alış. ${s.no}' : 'Alışveriş : ${s.no}',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: aktif ? FontWeight.w800 : FontWeight.w600)),
                    if (ozet.isNotEmpty)
                      TextSpan(text: ozet, style: const TextStyle(fontSize: 11)),
                    // Dar sekmede ürün varsa nokta işareti
                    if (dar && s.urunSayisi > 0)
                      const TextSpan(text: ' •', style: TextStyle(fontWeight: FontWeight.w900)),
                  ]),
                  style: TextStyle(color: renk),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (i > 0)
                InkWell(
                  onTap: () => _sekmeKapat(i),
                  borderRadius: BorderRadius.circular(10),
                  child: Padding(
                    padding: const EdgeInsets.all(2),
                    child: Icon(Icons.close, size: 13, color: renk),
                  ),
                ),
            ]),
          );
        }),
      ),
    );
  }

  // ── Sepet işlemleri ───────────────────────────────────────────────────
  void _seciliyiSil() {
    final s = _secili;
    if (s == null) return;
    ref.read(sepetProvider.notifier).sil(s);
    setState(() => _secili = null);
  }

  Future<void> _sepetiTemizle() async {
    if (ref.read(sepetProvider).bos) return;
    final onay = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Sepeti temizle'),
        content: const Text('Sepetteki tüm ürünler silinecek. Emin misiniz?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Temizle')),
        ],
      ),
    );
    if (onay == true && mounted) ref.read(sepetProvider.notifier).temizle();
  }

  // ── İskonto (F6) ─────────────────────────────────────────────────────
  // Seçili satır varsa yalnız ona, yoksa tüm sepete uygulanır. Oran (%),
  // tutar (TL) veya yeni toplam girilir (üçü birbirini hesaplar). Hesap
  // ürünün LİSTE fiyatı üzerinden yapılır; sepette Fiyat/Tutar aynı kalır,
  // fark İndirim sütununa yazılır, Net Tutar değişir. Fişe ürün birim
  // fiyatı düşürülerek (kalem iskontosu olarak) kaydolur.
  Future<void> _iskontoUygula() async {
    final sepet = ref.read(sepetProvider);
    if (sepet.bos || sepet.satisIsleniyor) return;
    final secili = (_secili != null && _secili! < sepet.kalemler.length)
        ? _secili
        : null;
    final brut = secili != null
        ? sepet.kalemler[secili].brutTutar
        : sepet.kalemler.fold<double>(0, (a, k) => a + k.brutTutar);
    final yeniToplam = await iskontoDialoguGoster(
      context,
      baslik: secili != null
          ? 'İskonto — ${sepet.kalemler[secili].urun.urunAdi}'
          : 'İskonto — Tüm Sepet',
      brutToplam: brut,
    );
    if (yeniToplam == null || !mounted) return;

    final guncel = ref.read(sepetProvider);
    if (guncel.bos || brut <= 0) return;
    final carpan = yeniToplam / brut;
    final notifier = ref.read(sepetProvider.notifier);
    final indeksler = secili != null && secili < guncel.kalemler.length
        ? [secili]
        : List<int>.generate(guncel.kalemler.length, (i) => i);
    for (final i in indeksler) {
      final k = guncel.kalemler[i];
      if (k.miktar <= 0) continue;
      // Birim fiyat 6 hane tutulur: ör. 3 adet / 100 TL → 33,333333 × 3 = 100.
      final yeniBirim =
          (k.listeFiyat * carpan * 1000000).round() / 1000000;
      if (yeniBirim > 0) notifier.fiyatGuncelle(i, yeniBirim);
    }
  }

  // ── Sayı tuş takımı ───────────────────────────────────────────────────
  double? get _tamponSayi => double.tryParse(_tampon.replaceAll(',', '.'));

  void _karakter(String c) {
    if (c == ',' && (_tampon.contains(',') || _tampon.isEmpty)) {
      if (_tampon.isEmpty) setState(() => _tampon = '0,');
      return;
    }
    if (_tampon.length >= 9) return;
    setState(() => _tampon += c);
  }

  void _miktarUygula() {
    final sepet = ref.read(sepetProvider);
    final n = _tamponSayi;
    if (sepet.bos || n == null || n <= 0) return;
    final i = _secili ?? sepet.kalemler.length - 1;
    ref.read(sepetProvider.notifier).miktarGuncelle(i, n);
    setState(() => _tampon = '');
  }

  void _alinanUygula() {
    final n = _tamponSayi;
    if (n == null) return;
    setState(() {
      _alinan = n;
      _tampon = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    final sepet = ref.watch(sepetProvider);
    final aktifSekme = ref.read(sepetProvider.notifier).aktifSekme;
    if (aktifSekme != _gorulenSekme) {
      // Başka alışverişe geçildi: satır seçimi/tampon o sepete ait değil.
      _gorulenSekme = aktifSekme;
      _secili = null;
      _tampon = '';
      _alinan = 0;
    }
    // Satış bitip sepet boşalınca yerel durumu sıfırla.
    ref.listen<SepetDurum>(sepetProvider, (onceki, yeni) {
      if (yeni.bos && (onceki?.bos == false)) {
        setState(() {
          _secili = null;
          _tampon = '';
          _alinan = 0;
        });
      } else if (_secili != null && _secili! >= yeni.kalemler.length) {
        setState(() => _secili = null);
      }
    });

    final odemeAktif = !sepet.bos && !sepet.satisIsleniyor;
    return Row(children: [
      Expanded(child: _sol(sepet)),
      VerticalDivider(width: 1, thickness: 1, color: context.borderColor),
      SizedBox(width: 350, child: _sag(sepet, odemeAktif)),
    ]);
  }

  Widget _sol(SepetDurum sepet) {
    return Column(children: [
      widget.aramaPaneli,
      _sekmeCubugu(),
      if (widget.aramaSonuclari != null)
        Expanded(child: SingleChildScrollView(child: widget.aramaSonuclari))
      else ...[
        Expanded(
          flex: 11,
          child: MasaustuSepetTablosu(
            kalemler: sepet.kalemler,
            seciliIndex: _secili,
            scrollController: widget.sepetScroll,
            onSec: (i) => setState(() => _secili = i),
            onDuzenle: widget.onKalemDuzenle,
            onSil: (i) {
              ref.read(sepetProvider.notifier).sil(i);
              setState(() => _secili = null);
            },
          ),
        ),
        Divider(height: 1, color: context.borderColor),
        Expanded(
          flex: 10,
          child: MasaustuUrunIzgarasi(onUrunSec: widget.onUrunSec),
        ),
      ],
    ]);
  }

  Widget _sag(SepetDurum sepet, bool odemeAktif) {
    return Column(children: [
      MasaustuToplamKarti(sepet: sepet, alinanPara: _alinan),
      MasaustuFTuslari(
        ana: FTus('F12', 'ÖDEME', TsRenk.hata,
            odemeAktif ? widget.onOdeme : null),
        tuslar: [
          FTus('F2', 'Kasa Aç', TsRenk.vurguMor, widget.onKasaAc),
          FTus('F3', 'Stok', TsRenk.hata, widget.onStok),
          FTus('F4', 'Askıya Al', TsRenk.basarili,
              sepet.bos ? null : widget.onAskiyaAl),
          FTus('F5', 'Son Fiş', TsRenk.vurguMor, widget.onSonFis),
          FTus('F6', 'İskonto', TsRenk.uyari,
              sepet.bos ? null : _iskontoUygula),
          FTus('F7', 'Cari', TsRenk.bilgi, widget.onCari),
          FTus('F9', 'Temizle', TsRenk.notr,
              sepet.bos ? null : _sepetiTemizle),
          FTus('F10', 'Yeni Alışveriş', TsRenk.vurguTurkuaz,
              ref.read(sepetProvider.notifier).sekmeler.length >= Sepet.maksSekme
                  ? null
                  : _yeniSekme),
          FTus('Del', 'Satır Sil', const Color(0xFF8D6E63),
              _secili == null ? null : _seciliyiSil),
        ],
      ),
      Expanded(
        child: MasaustuSayiTuslari(
          tampon: _tampon,
          onKarakter: _karakter,
          onGeri: () => setState(() {
            if (_tampon.isNotEmpty) _tampon = _tampon.substring(0, _tampon.length - 1);
          }),
          onTemizle: () => setState(() {
            _tampon = '';
            _alinan = 0;
          }),
          onMiktar: _miktarUygula,
          onAlinan: _alinanUygula,
          onHizliPara: (p) => setState(() => _alinan += p),
          onFiyatGor: widget.onFiyatGor,
        ),
      ),
    ]);
  }
}
