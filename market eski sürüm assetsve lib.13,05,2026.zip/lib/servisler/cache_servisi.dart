import 'dart:collection';

class CacheItem<T> {
  final T data;
  final DateTime expiry;
  CacheItem({required this.data, required this.expiry});
  bool get isExpired => DateTime.now().isAfter(expiry);
}

class CacheServisi {
  static final CacheServisi _instance = CacheServisi._internal();
  factory CacheServisi() => _instance;
  CacheServisi._internal();

  final _cache = HashMap<String, CacheItem<dynamic>>();
  static const Duration defaultExpiry = Duration(minutes: 5);

  T? get<T>(String key) {
    final item = _cache[key];
    if (item == null || item.isExpired) {
      _cache.remove(key);
      return null;
    }
    return item.data as T;
  }

  void set<T>(String key, T data, {Duration? expiry}) {
    _cache[key] = CacheItem<T>(
      data: data,
      expiry: DateTime.now().add(expiry ?? defaultExpiry),
    );
  }

  void remove(String key) => _cache.remove(key);
  void clear() => _cache.clear();
  void clearExpired() {
    _cache.removeWhere((_, item) => item.isExpired);
  }

  Future<T> getOrFetch<T>(
    String key, 
    Future<T> Function() fetcher, 
    {Duration? expiry}
  ) async {
    final cached = get<T>(key);
    if (cached != null) return cached;
    final data = await fetcher();
    set(key, data, expiry: expiry);
    return data;
  }
}