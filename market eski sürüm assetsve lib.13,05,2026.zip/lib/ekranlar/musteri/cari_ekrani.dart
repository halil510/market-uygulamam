// lib/ekranlar/musteri/cari_ekrani.dart
// Modern & kullanışlı cari ekranı — tüm mantık korundu, UI tamamen yenilendi.

import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:market_uygulamasi/modeller/musteri.dart';
import 'package:market_uygulamasi/repozitory/musteri_repo.dart';
import 'package:market_uygulamasi/ekranlar/musteri/cari_kayit_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/musteri/cari_hareket_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/musteri/tahsilat_odeme_ekrani.dart';
import 'package:market_uygulamasi/repozitory/cari_hareket_repo.dart';
import 'package:market_uygulamasi/modeller/cari_hareket.dart';
import 'package:file_picker/file_picker.dart';
import 'package:csv/csv.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:excel/excel.dart' as excel;

// ─────────────────────────────────────────────────────────────────────────────
// RENK PALETİ
// ─────────────────────────────────────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFFF5F6FA);
  static const surface   = Color(0xFFFFFFFF);
  static const primary   = Color(0xFF1A2E5A);
  static const accent    = Color(0xFF3D7EFF);
  static const musteri   = Color(0xFF3D7EFF);
  static const tedarikci = Color(0xFFFF8C42);
  static const borc      = Color(0xFFEF4444);
  static const alacak    = Color(0xFF22C55E);
  static const denge     = Color(0xFF94A3B8);
  static const textHead  = Color(0xFF0F172A);
  static const textSub   = Color(0xFF64748B);
  static const divider   = Color(0xFFE2E8F0);
  static const cardShad  = Color(0x14000000);
}

// ─────────────────────────────────────────────────────────────────────────────
// WIDGET
// ─────────────────────────────────────────────────────────────────────────────
class CariEkrani extends StatefulWidget {
  const CariEkrani({Key? key}) : super(key: key);

  @override
  State<CariEkrani> createState() => _CariEkraniState();
}

class _CariEkraniState extends State<CariEkrani>
    with SingleTickerProviderStateMixin {
  final MusteriRepo     _musteriRepo = MusteriRepo();
  final CariHareketRepo _hareketRepo = CariHareketRepo();

  List<Musteri> _tumCariler = [];
  List<Musteri> _filtreli   = [];
  Set<int>      _secili     = {};
  bool          _secimModu  = false;
  bool          _yukleniyor = false;
  String        _aramaMetni = '';
  String        _filtreTipi = 'Tümü';
  Timer?        _aramaDebounce;
  late pw.Font  _pdfFont;

  late final TabController _tabCtrl;
  final _aramaCtrl  = TextEditingController();
  final _aramaFocus = FocusNode();

  static const _tabs = ['Tümü', 'Müşteri', 'Tedarikçi'];

  // ── Yaşam döngüsü ─────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this)
      ..addListener(() {
        if (!_tabCtrl.indexIsChanging) {
          setState(() {
            _filtreTipi = _tabs[_tabCtrl.index];
            _uygula();
          });
        }
      });
    _aramaCtrl.addListener(_onArama);
    _yukle();
    _loadFont();
  }

  @override
  void dispose() {
    _aramaDebounce?.cancel();
    _aramaCtrl
      ..removeListener(_onArama)
      ..dispose();
    _aramaFocus.dispose();
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadFont() async {
    try {
      final data = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
      _pdfFont = pw.Font.ttf(data);
    } catch (_) {
      _pdfFont = pw.Font.courier();
    }
  }

  // ── Veri ──────────────────────────────────────────────────────────────────
  Future<void> _yukle() async {
    if (!mounted) return;
    setState(() => _yukleniyor = true);
    try {
      final m = await _musteriRepo.tumMusterileriGetir();
      final t = await _musteriRepo.tumTedarikcileriGetir();
      if (!mounted) return;
      setState(() {
        _tumCariler = [...m, ...t];
        _uygula();
      });
    } catch (e) {
      _msg('Veri yüklenemedi: $e', err: true);
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  void _uygula() {
    var list = List<Musteri>.from(_tumCariler);
    if (_aramaMetni.isNotEmpty) {
      final q = _aramaMetni.toLowerCase();
      list = list
          .where((m) =>
              m.unvan.toLowerCase().contains(q) ||
              m.cariKodu.toLowerCase().contains(q) ||
              (m.telefon ?? '').contains(q))
          .toList();
    }
    if (_filtreTipi != 'Tümü') {
      list = list.where((m) => m.cariTipi == _filtreTipi).toList();
    }
    _filtreli = list;
  }

  void _onArama() {
    _aramaDebounce?.cancel();
    _aramaDebounce = Timer(const Duration(milliseconds: 280), () {
      if (!mounted) return;
      setState(() {
        _aramaMetni = _aramaCtrl.text;
        _uygula();
      });
    });
  }

  // ── Özet ──────────────────────────────────────────────────────────────────
  double get _toplamBorc =>
      _filtreli.where((m) => m.bakiye > 0).fold(0.0, (s, m) => s + m.bakiye);
  double get _toplamAlacak =>
      _filtreli.where((m) => m.bakiye < 0).fold(0.0, (s, m) => s + m.bakiye.abs());

  // ── Seçim ─────────────────────────────────────────────────────────────────
  void _toggleSecim(Musteri m) {
    setState(() {
      if (_secili.contains(m.id)) {
        _secili.remove(m.id);
      } else {
        _secili.add(m.id!);
      }
      _secimModu = _secili.isNotEmpty;
    });
  }

  void _secimKapat() => setState(() {
        _secili.clear();
        _secimModu = false;
      });

  Future<void> _seciliSil() async {
    if (_secili.isEmpty) return;
    final n = _secili.length;
    final onay =
        await _onay('$n cariyi silmek istediğinize emin misiniz?');
    if (!onay) return;
    for (final id in Set<int>.from(_secili)) {
      await _musteriRepo.cariSil(id);
    }
    _secimKapat();
    await _yukle();
    _msg('$n cari silindi');
  }

  Future<bool> _onay(String s) async =>
      await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Onay'),
          content: Text(s),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Hayır')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: FilledButton.styleFrom(backgroundColor: _C.borc),
                child: const Text('Evet')),
          ],
        ),
      ) ??
      false;

  void _msg(String s, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(s),
      backgroundColor: err ? _C.borc : _C.alacak,
      behavior: SnackBarBehavior.floating,
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
    ));
  }

  // ── Navigasyon ────────────────────────────────────────────────────────────
  Future<void> _hareketlereGit(Musteri m) async {
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => CariHareketEkrani(cari: m)));
    _yukle();
  }

  Future<void> _yeniCari() async {
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => CariKayitEkrani()));
    _yukle();
  }

  Future<void> _duzenle(Musteri m) async {
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => CariKayitEkrani(duzenlenecekCari: m)));
    _yukle();
  }

  void _tahsilat(Musteri m) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            TahsilatOdemeEkrani(cari: m, onIslemTamamlandi: _yukle),
      ),
    ).then((_) => _secimKapat());
  }

  // ══════════════════════════════════════════════════════════════════════════
  // EXCEL İÇE AKTAR
  // ══════════════════════════════════════════════════════════════════════════
  Future<void> _excelIceri() async {
    try {
      final result = await FilePicker.platform.pickFiles(
          type: FileType.custom, allowedExtensions: ['xlsx', 'csv']);
      if (result == null) return;

      final file = File(result.files.single.path!);
      final ext = result.files.single.extension?.toLowerCase() ?? '';
      final mevcutlar = await _musteriRepo.tumCarileriGetir();
      final Map<String, Musteri> map = {
        for (var c in mevcutlar) c.cariKodu: c
      };

      int ok = 0, fail = 0;
      final errors = <String>[];
      final kodlar = <String>{};

      if (ext == 'csv') {
        await _csvIsle(file, map, kodlar, (b) => ok = b, (h) => fail = h, errors);
      } else if (ext == 'xlsx') {
        await _xlsxIsle(file, map, kodlar, (b) => ok = b, (h) => fail = h, errors);
      }

      await _yukle();
      if (!mounted) return;
      if (fail > 0) {
        _importSonuc(ok, fail, errors);
      } else {
        _msg('$ok cari içe aktarıldı');
      }
    } catch (e) {
      _msg('İçe aktarma hatası: $e', err: true);
    }
  }

  Future<void> _csvIsle(
      File file,
      Map<String, Musteri> map,
      Set<String> kodlar,
      Function(int) setOk,
      Function(int) setFail,
      List<String> errors) async {
    final bytes = await file.readAsBytes();
    String csv;
    try {
      csv = utf8.decode(bytes);
    } catch (_) {
      csv = latin1.decode(bytes);
    }
    final rows = const CsvToListConverter().convert(csv);
    if (rows.isEmpty) return;
    final idx = _headerIdx(rows[0]);
    if (idx['cariKod'] == -1 || idx['unvan'] == -1) {
      _msg('"Cari Kod" ve "Ünvan" sütunları zorunlu', err: true);
      return;
    }
    int ok = 0, fail = 0;
    for (int i = 1; i < rows.length; i++) {
      try {
        final r = rows[i];
        final kod = _cell(r, idx['cariKod']!)
            .replaceAll(RegExp(r'\s+'), ' ')
            .trim();
        if (kod.isEmpty) throw Exception('Kod boş');
        if (kodlar.contains(kod)) throw Exception('Tekrar eden kod');
        kodlar.add(kod);
        final unvan = _cell(r, idx['unvan']!).trim();
        if (unvan.isEmpty) throw Exception('Ünvan boş');
        await _kaydetVeBakiye(
          kod: kod,
          unvan: unvan,
          tip: idx['cariTip'] != -1
              ? _normTip(_cell(r, idx['cariTip']!))
              : 'Müşteri',
          borc: idx['borc'] != -1 ? _num(_cell(r, idx['borc']!)) : 0,
          alacak:
              idx['alacak'] != -1 ? _num(_cell(r, idx['alacak']!)) : 0,
          adres: idx['adres'] != -1 ? _cell(r, idx['adres']!) : null,
          telefon:
              idx['telefon'] != -1 ? _cell(r, idx['telefon']!) : null,
          email: idx['email'] != -1 ? _cell(r, idx['email']!) : null,
          vergiDairesi: idx['vergiDairesi'] != -1
              ? _cell(r, idx['vergiDairesi']!)
              : null,
          vergiNo:
              idx['vergiNo'] != -1 ? _cell(r, idx['vergiNo']!) : null,
          mevcutMap: map,
        );
        ok++;
      } catch (e) {
        fail++;
        errors.add('Satır ${i + 1}: $e');
      }
    }
    setOk(ok);
    setFail(fail);
  }

  Future<void> _xlsxIsle(
      File file,
      Map<String, Musteri> map,
      Set<String> kodlar,
      Function(int) setOk,
      Function(int) setFail,
      List<String> errors) async {
    final bytes = await file.readAsBytes();
    final wb = excel.Excel.decodeBytes(bytes);
    final sh = wb.tables[wb.tables.keys.first]!;
    if (sh.rows.isEmpty) return;
    final header =
        sh.rows[0].map((c) => c?.value?.toString().trim() ?? '').toList();
    final idx = _headerIdx(header);
    if (idx['cariKod'] == -1 || idx['unvan'] == -1) {
      _msg('"Cari Kod" ve "Ünvan" sütunları zorunlu', err: true);
      return;
    }
    int ok = 0, fail = 0;
    for (int i = 1; i < sh.rows.length; i++) {
      try {
        final r = sh.rows[i];
        final kod = _xCell(r, idx['cariKod']!).trim();
        if (kod.isEmpty) throw Exception('Kod boş');
        if (kodlar.contains(kod)) throw Exception('Tekrar eden kod');
        kodlar.add(kod);
        final unvan = _xCell(r, idx['unvan']!).trim();
        if (unvan.isEmpty) throw Exception('Ünvan boş');
        await _kaydetVeBakiye(
          kod: kod,
          unvan: unvan,
          tip: idx['cariTip'] != -1
              ? _normTip(_xCell(r, idx['cariTip']!))
              : 'Müşteri',
          borc:
              idx['borc'] != -1 ? _num(_xCell(r, idx['borc']!)) : 0,
          alacak: idx['alacak'] != -1
              ? _num(_xCell(r, idx['alacak']!))
              : 0,
          adres: idx['adres'] != -1 ? _xCell(r, idx['adres']!) : null,
          telefon: idx['telefon'] != -1
              ? _xCell(r, idx['telefon']!)
              : null,
          email:
              idx['email'] != -1 ? _xCell(r, idx['email']!) : null,
          vergiDairesi: idx['vergiDairesi'] != -1
              ? _xCell(r, idx['vergiDairesi']!)
              : null,
          vergiNo: idx['vergiNo'] != -1
              ? _xCell(r, idx['vergiNo']!)
              : null,
          mevcutMap: map,
        );
        ok++;
      } catch (e) {
        fail++;
        errors.add('Satır ${i + 1}: $e');
      }
    }
    setOk(ok);
    setFail(fail);
  }

  // ── Kaydet & bakiye (NULL FIX uygulandı) ──────────────────────────────────
  Future<void> _kaydetVeBakiye({
    required String kod,
    required String unvan,
    required String tip,
    required double borc,
    required double alacak,
    String? adres,
    String? telefon,
    String? email,
    String? vergiDairesi,
    String? vergiNo,
    required Map<String, Musteri> mevcutMap,
  }) async {
    String? e(String? s) =>
        (s == null || s.trim().isEmpty) ? null : s.trim();

    final base = Musteri(
      cariKodu: kod,
      unvan: unvan,
      cariTipi: tip,
      adres: e(adres),
      telefon: e(telefon),
      email: e(email),
      vergiDairesi: e(vergiDairesi),
      vergiNo: e(vergiNo),
      bakiye: 0.0,
    );

    int cariId;

    if (mevcutMap.containsKey(kod)) {
      // Güncelleme — Musteri immutable → copyWith
      final mid = mevcutMap[kod]?.id;
      if (mid == null) throw Exception('DB tutarsız: $kod');
      final guncel = base.copyWith(id: mid);
      await _musteriRepo.cariGuncelle(guncel);
      cariId = mid;
    } else {
      // Yeni ekleme — cariEkle void → DB'den id sorgula
      await _musteriRepo.cariEkle(base);
      final sorgu = await _idByKod(kod);
      if (sorgu == null) throw Exception('ID alınamadı: $kod');
      mevcutMap[kod] = base.copyWith(id: sorgu);
      cariId = sorgu;
    }

    await _hareketRepo.acilisHareketleriniSil(cariId);
    if (borc != 0 || alacak != 0) {
      await _hareketRepo.hareketEkle(CariHareket(
        cariId: cariId,
        tarih: DateTime(2000, 1, 1),
        fisTipi: 'Açılış',
        fisNo: 'ACL-$kod',
        aciklama: 'Excel açılış bakiyesi',
        borc: borc,
        alacak: alacak,
      ));
    }
  }

  Future<int?> _idByKod(String kod) async {
    try {
      final liste = await _musteriRepo.tumCarileriGetir();
      for (final m in liste) {
        if (m.cariKodu == kod) return m.id;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Map<String, int> _headerIdx(List<dynamic> headers) {
    final keys = {
      'cariKod': ['cari kod', 'cari_kodu', 'carikod', 'kod'],
      'unvan': ['ünvan', 'unvan', 'ad', 'firma'],
      'adres': ['adres', 'address'],
      'telefon': ['telefon', 'tel', 'phone'],
      'email': ['email', 'e-posta', 'mail'],
      'vergiDairesi': ['vergi dairesi', 'vergi_dairesi', 'vd'],
      'vergiNo': ['vergi no', 'vkn', 'tcno'],
      'borc': ['borç', 'borc', 'debit'],
      'alacak': ['alacak', 'credit'],
      'cariTip': ['cari türü', 'cari_tipi', 'tip', 'tür', 'type'],
    };
    final result = {for (var k in keys.keys) k: -1};
    for (int i = 0; i < headers.length; i++) {
      final h = headers[i].toString().toLowerCase().trim();
      for (final entry in keys.entries) {
        if (result[entry.key] == -1 &&
            entry.value.any((a) => h.contains(a))) {
          result[entry.key] = i;
        }
      }
    }
    return result;
  }

  String _normTip(String raw) {
    final s = raw.toLowerCase();
    if (s.contains('tedarik') ||
        s.contains('supplier') ||
        s.contains('vendor')) return 'Tedarikçi';
    return 'Müşteri';
  }

  String _cell(List r, int i) =>
      (i < 0 || i >= r.length) ? '' : r[i]?.toString().trim() ?? '';
  String _xCell(List<excel.Data?> r, int i) =>
      (i < 0 || i >= r.length) ? '' : r[i]?.value?.toString().trim() ?? '';

  double _num(dynamic v) {
    if (v == null) return 0;
    String s = v.toString().trim();
    if (s.contains(',') && s.contains('.')) {
      s = s.replaceAll('.', '').replaceAll(',', '.');
    } else {
      s = s.replaceAll(',', '.');
    }
    return double.tryParse(s) ?? 0;
  }

  void _importSonuc(int ok, int fail, List<String> errors) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('İçe Aktarma Sonucu'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            _badge('✓ $ok başarılı', _C.alacak),
            const SizedBox(width: 8),
            _badge('✗ $fail hatalı', _C.borc),
          ]),
          if (errors.isNotEmpty) ...[
            const SizedBox(height: 12),
            Container(
              height: 180,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: _C.bg,
                  borderRadius: BorderRadius.circular(12)),
              child: ListView(
                children: errors
                    .map((e) => Text('• $e',
                        style: const TextStyle(
                            fontSize: 12, color: _C.textSub)))
                    .toList(),
              ),
            ),
          ],
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Tamam'))
        ],
      ),
    );
  }

  Widget _badge(String s, Color c) => Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
            color: c.withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: c.withOpacity(0.3))),
        child: Text(s,
            style: TextStyle(
                color: c,
                fontWeight: FontWeight.bold,
                fontSize: 13)),
      );

  // ── Excel dışa ────────────────────────────────────────────────────────────
  Future<void> _excelDisari() async {
    if (_filtreli.isEmpty) {
      _msg('Aktarılacak cari yok', err: true);
      return;
    }
    final wb = excel.Excel.createExcel();
    wb.rename('Sheet1', 'Cariler');
    final sh = wb['Cariler'];
    sh.appendRow([
      'Cari Kod', 'Ünvan', 'Telefon', 'Adres', 'Email',
      'Vergi Dairesi', 'Vergi No', 'Borç', 'Alacak', 'Bakiye', 'Cari Türü'
    ]);
    for (var m in _filtreli) {
      final b = m.bakiye > 0 ? m.bakiye : 0.0;
      final a = m.bakiye < 0 ? m.bakiye.abs() : 0.0;
      sh.appendRow([
        m.cariKodu, m.unvan, m.telefon ?? '', m.adres ?? '',
        m.email ?? '', m.vergiDairesi ?? '', m.vergiNo ?? '',
        b, a, m.bakiye, m.cariTipi
      ]);
    }
    final dir = await getApplicationDocumentsDirectory();
    final path =
        '${dir.path}/cariler_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    final enc = wb.encode();
    if (enc == null) {
      _msg('Excel oluşturulamadı', err: true);
      return;
    }
    await File(path).writeAsBytes(enc);
    await OpenFile.open(path);
    _msg('${_filtreli.length} cari dışa aktarıldı');
  }

  // ── PDF dışa ──────────────────────────────────────────────────────────────
  Future<void> _pdfDisari() async {
    if (_filtreli.isEmpty) {
      _msg('Aktarılacak cari yok', err: true);
      return;
    }
    final pdf = pw.Document();
    pdf.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      theme: pw.ThemeData.withFont(base: _pdfFont),
      build: (ctx) => [
        pw.Table(
          border: pw.TableBorder.all(),
          columnWidths: {
            0: const pw.FlexColumnWidth(2),
            1: const pw.FlexColumnWidth(3),
            2: const pw.FlexColumnWidth(2),
            3: const pw.FlexColumnWidth(2),
            4: const pw.FlexColumnWidth(1.5),
          },
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(
                  color: PdfColors.blueGrey800),
              children: [
                _ph('Kod', bold: true, w: true),
                _ph('Ünvan', bold: true, w: true),
                _ph('Telefon', bold: true, w: true),
                _ph('Bakiye', bold: true, w: true),
                _ph('Tip', bold: true, w: true),
              ],
            ),
            ..._filtreli.map((m) => pw.TableRow(children: [
                  _ph(m.cariKodu),
                  _ph(m.unvan),
                  _ph(m.telefon ?? ''),
                  _ph('${m.bakiye.toStringAsFixed(2)} ₺',
                      renk: m.bakiye > 0
                          ? PdfColors.red
                          : m.bakiye < 0
                              ? PdfColors.green
                              : PdfColors.black),
                  _ph(m.cariTipi),
                ])),
          ],
        ),
      ],
    ));
    final dir = await getApplicationDocumentsDirectory();
    final path =
        '${dir.path}/cariler_${DateTime.now().millisecondsSinceEpoch}.pdf';
    await File(path).writeAsBytes(await pdf.save());
    await OpenFile.open(path);
  }

  pw.Widget _ph(String t,
          {bool bold = false, bool w = false, PdfColor renk = PdfColors.black}) =>
      pw.Padding(
        padding: const pw.EdgeInsets.all(4),
        child: pw.Text(t,
            style: pw.TextStyle(
              font: _pdfFont,
              fontSize: 9,
              fontWeight:
                  bold ? pw.FontWeight.bold : pw.FontWeight.normal,
              color: w ? PdfColors.white : renk,
            )),
      );

  // ══════════════════════════════════════════════════════════════════════════
  // UI HELPERS
  // ══════════════════════════════════════════════════════════════════════════
  Color _avatarRenk(Musteri m) {
    if (m.cariTipi == 'Tedarikçi') return _C.tedarikci;
    const colors = [
      Color(0xFF6366F1), Color(0xFF8B5CF6), Color(0xFFEC4899),
      Color(0xFFEF4444), Color(0xFFF97316), Color(0xFF10B981),
      Color(0xFF06B6D4), Color(0xFF3B82F6),
    ];
    final code = m.unvan.isNotEmpty ? m.unvan.codeUnitAt(0) : 0;
    return colors[code % colors.length];
  }

  String _bas(Musteri m) =>
      m.unvan.isNotEmpty ? m.unvan[0].toUpperCase() : '?';

  String _etiket(Musteri m) {
    if (m.bakiye.abs() < 0.01) return 'Dengede';
    if (m.bakiye > 0) {
      return m.cariTipi == 'Müşteri' ? 'Borçlu' : 'Ödeyeceğiz';
    }
    return m.cariTipi == 'Müşteri' ? 'Alacaklı' : 'Alacağımız';
  }

  Color _bRenk(Musteri m) {
    if (m.bakiye.abs() < 0.01) return _C.denge;
    return m.bakiye > 0 ? _C.borc : _C.alacak;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: _secimModu ? _secimGovde() : _normalGovde(),
      floatingActionButton: _secimModu ? null : _fab(),
    );
  }

  // ── Normal gövde ──────────────────────────────────────────────────────────
  Widget _normalGovde() {
    return NestedScrollView(
      headerSliverBuilder: (_, __) => [_sliverBar()],
      body: Column(children: [
        _aramaBar(),
        _tabBar(),
        _ozetBar(),
        Expanded(child: _liste()),
      ]),
    );
  }

  // ── Seçim gövdesi ─────────────────────────────────────────────────────────
  Widget _secimGovde() {
    return Column(children: [
      _secimBar(),
      Expanded(child: _liste()),
    ]);
  }

  // ── Sliver AppBar ─────────────────────────────────────────────────────────
  Widget _sliverBar() {
    return SliverAppBar(
      expandedHeight: 96,
      floating: true,
      snap: true,
      backgroundColor: _C.primary,
      foregroundColor: Colors.white,
     flexibleSpace: FlexibleSpaceBar(
  title: const Text(
    'Cariler',
    style: TextStyle(
      fontWeight: FontWeight.w700,
      letterSpacing: 0.5,
      color: Colors.white, // ← kesin beyaz
    ),
  ),
  centerTitle: false,
  titlePadding: const EdgeInsets.fromLTRB(20, 0, 0, 16),
),
      actions: [
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
          onSelected: (v) {
            if (v == 'import') _excelIceri();
            else if (v == 'export') _excelDisari();
            else _pdfDisari();
          },
          itemBuilder: (_) => [
            const PopupMenuItem(
              value: 'import',
              child: ListTile(
                  dense: true,
                  leading: Icon(Icons.upload_file),
                  title: Text("Excel'den İçe Aktar")),
            ),
            const PopupMenuItem(
              value: 'export',
              child: ListTile(
                  dense: true,
                  leading: Icon(Icons.download),
                  title: Text("Excel'e Dışa Aktar")),
            ),
            const PopupMenuItem(
              value: 'pdf',
              child: ListTile(
                  dense: true,
                  leading: Icon(Icons.picture_as_pdf),
                  title: Text("PDF Oluştur")),
            ),
          ],
        ),
      ],
    );
  }

  // ── Seçim bar ─────────────────────────────────────────────────────────────
  Widget _secimBar() {
    final tek = _secili.length == 1;
    final Musteri? sec = tek
        ? _tumCariler.cast<Musteri?>().firstWhere(
            (m) => m?.id == _secili.first,
            orElse: () => null)
        : null;

    return Container(
      color: _C.primary,
      padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top, bottom: 4),
      child: Row(children: [
        IconButton(
            icon: const Icon(Icons.close, color: Colors.white),
            onPressed: _secimKapat),
        Text('${_secili.length} seçildi',
            style: const TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.w600)),
        const Spacer(),
        if (tek && sec != null)
          IconButton(
              icon: const Icon(Icons.payment, color: Colors.white),
              tooltip: 'Tahsilat / Ödeme',
              onPressed: () => _tahsilat(sec)),
        if (tek && sec != null)
          IconButton(
              icon: const Icon(Icons.edit, color: Colors.white),
              tooltip: 'Düzenle',
              onPressed: () => _duzenle(sec)),
        IconButton(
            icon: const Icon(Icons.delete,
                color: Color(0xFFFF8080)),
            onPressed: _seciliSil),
      ]),
    );
  }

  // ── Arama bar ─────────────────────────────────────────────────────────────
  Widget _aramaBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(14),
          boxShadow: const [
            BoxShadow(
                color: _C.cardShad, blurRadius: 8, offset: Offset(0, 2))
          ],
        ),
        child: TextField(
          controller: _aramaCtrl,
          focusNode: _aramaFocus,
          style: const TextStyle(fontSize: 15, color: _C.textHead),
          decoration: InputDecoration(
            hintText: 'Cari adı, kodu veya telefon ara…',
            hintStyle:
                const TextStyle(color: _C.textSub, fontSize: 14),
            prefixIcon:
                const Icon(Icons.search_rounded, color: _C.textSub),
            suffixIcon: _aramaMetni.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.clear_rounded,
                        color: _C.textSub, size: 20),
                    onPressed: () {
                      _aramaCtrl.clear();
                      _aramaFocus.requestFocus();
                    })
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
                vertical: 14, horizontal: 4),
          ),
        ),
      ),
    );
  }

  // ── Tab bar ───────────────────────────────────────────────────────────────
  Widget _tabBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          color: _C.divider,
          borderRadius: BorderRadius.circular(12),
        ),
        child: TabBar(
          controller: _tabCtrl,
          indicator: BoxDecoration(
            color: _C.primary,
            borderRadius: BorderRadius.circular(10),
          ),
          indicatorSize: TabBarIndicatorSize.tab,
          dividerColor: Colors.transparent,
          labelColor: Colors.white,
          unselectedLabelColor: _C.textSub,
          labelStyle: const TextStyle(
              fontWeight: FontWeight.w600, fontSize: 13),
          tabs: const [
            Tab(text: 'Tümü'),
            Tab(text: 'Müşteri'),
            Tab(text: 'Tedarikçi'),
          ],
        ),
      ),
    );
  }

  // ── Özet bar ──────────────────────────────────────────────────────────────
  Widget _ozetBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_C.primary, Color(0xFF243B73)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: _C.primary.withOpacity(0.28),
                blurRadius: 14,
                offset: const Offset(0, 4))
          ],
        ),
        child: Row(children: [
          _ozetItem('Toplam Alacak', _toplamAlacak, _C.alacak),
          _div(),
          _ozetItem('Toplam Borç', _toplamBorc,
              const Color(0xFFFF8080)),
          _div(),
          _ozetItem('Cari Sayısı',
              _filtreli.length.toDouble(), Colors.white,
              isSayi: true),
        ]),
      ),
    );
  }

  Widget _ozetItem(String lbl, double val, Color vc,
      {bool isSayi = false}) =>
      Expanded(
        child: Column(children: [
          Text(lbl,
              style: const TextStyle(
                  color: Colors.white54,
                  fontSize: 10,
                  fontWeight: FontWeight.w500)),
          const SizedBox(height: 3),
          Text(
            isSayi
                ? val.toInt().toString()
                : '${val.toStringAsFixed(0)} ₺',
            style: TextStyle(
                color: vc,
                fontSize: 16,
                fontWeight: FontWeight.w800),
          ),
        ]),
      );

  Widget _div() => Container(
      width: 1,
      height: 34,
      color: Colors.white12,
      margin: const EdgeInsets.symmetric(horizontal: 6));

  // ── Liste ─────────────────────────────────────────────────────────────────
  Widget _liste() {
    if (_yukleniyor) {
      return const Center(
          child: CircularProgressIndicator(color: _C.accent));
    }
    if (_filtreli.isEmpty) {
      return Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(26),
                decoration: const BoxDecoration(
                    color: _C.divider, shape: BoxShape.circle),
                child: const Icon(Icons.business_center_outlined,
                    size: 52, color: _C.textSub),
              ),
              const SizedBox(height: 18),
              Text(
                _aramaMetni.isNotEmpty
                    ? '"$_aramaMetni" bulunamadı'
                    : 'Henüz cari yok',
                style: const TextStyle(
                    color: _C.textSub,
                    fontSize: 17,
                    fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 6),
              if (_aramaMetni.isEmpty)
                const Text('+ butonuna basarak ekleyin',
                    style: TextStyle(
                        color: _C.denge, fontSize: 13)),
            ]),
      );
    }

    return RefreshIndicator(
      onRefresh: _yukle,
      color: _C.accent,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        itemCount: _filtreli.length,
        itemBuilder: (_, i) => _kart(_filtreli[i]),
      ),
    );
  }

  // ── Cari kart ─────────────────────────────────────────────────────────────
  Widget _kart(Musteri m) {
    final secili = _secili.contains(m.id);
    final av     = _avatarRenk(m);
    final br     = _bRenk(m);
    final et     = _etiket(m);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onLongPress: () => _toggleSecim(m),
        onTap: () =>
            _secimModu ? _toggleSecim(m) : _hareketlereGit(m),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          decoration: BoxDecoration(
            color: secili ? _C.accent.withOpacity(0.07) : _C.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: secili ? _C.accent : Colors.transparent,
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: secili
                    ? _C.accent.withOpacity(0.12)
                    : _C.cardShad,
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              // ── Avatar ───────────────────────────────────────────
              Stack(clipBehavior: Clip.none, children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: secili ? _C.accent : av,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: secili
                      ? const Icon(Icons.check_rounded,
                          color: Colors.white, size: 24)
                      : Text(_bas(m),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w700)),
                ),
                Positioned(
                  bottom: -3,
                  right: -3,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                      color: m.cariTipi == 'Müşteri'
                          ? _C.musteri
                          : _C.tedarikci,
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: Colors.white, width: 1.5),
                    ),
                    child: Icon(
                      m.cariTipi == 'Müşteri'
                          ? Icons.person
                          : Icons.business,
                      size: 9,
                      color: Colors.white,
                    ),
                  ),
                ),
              ]),

              const SizedBox(width: 14),

              // ── İsim & bilgiler ──────────────────────────────────
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(m.unvan,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: _C.textHead)),
                    const SizedBox(height: 4),
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color: _C.bg,
                          borderRadius:
                              BorderRadius.circular(6),
                        ),
                        child: Text(m.cariKodu,
                            style: const TextStyle(
                                fontSize: 11,
                                color: _C.textSub,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0.3)),
                      ),
                      if (m.telefon != null &&
                          m.telefon!.isNotEmpty) ...[
                        const SizedBox(width: 6),
                        const Icon(Icons.phone_outlined,
                            size: 11, color: _C.textSub),
                        const SizedBox(width: 2),
                        Flexible(
                          child: Text(m.telefon!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 11,
                                  color: _C.textSub)),
                        ),
                      ],
                    ]),
                  ],
                ),
              ),

              const SizedBox(width: 10),

              // ── Bakiye + aksiyonlar ──────────────────────────────
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${m.bakiye.abs().toStringAsFixed(2)} ₺',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: br),
                  ),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: br.withOpacity(0.10),
                      borderRadius:
                          BorderRadius.circular(20),
                    ),
                    child: Text(et,
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: br)),
                  ),
                  if (!_secimModu) ...[
                    const SizedBox(height: 6),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _iconBtn(Icons.payment_outlined,
                            () => _tahsilat(m),
                            tooltip: 'Tahsilat / Ödeme'),
                        const SizedBox(width: 2),
                        _iconBtn(Icons.edit_outlined,
                            () => _duzenle(m),
                            tooltip: 'Düzenle'),
                      ],
                    ),
                  ],
                ],
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _iconBtn(IconData icon, VoidCallback onTap,
      {String? tooltip}) =>
      Tooltip(
        message: tooltip ?? '',
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: Icon(icon,
                size: 16, color: _C.textSub.withOpacity(0.7)),
          ),
        ),
      );

  // ── FAB ───────────────────────────────────────────────────────────────────
  Widget _fab() => FloatingActionButton.extended(
        onPressed: _yeniCari,
        backgroundColor: _C.primary,
        foregroundColor: Colors.white,
        elevation: 6,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Yeni Cari',
            style: TextStyle(fontWeight: FontWeight.w600)),
      );
}