import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';
import 'package:intl/intl.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/modeller/satis_kalem.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/satis_repo.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:share_plus/share_plus.dart';

class ExcelGunSonuServisi {
  // 🔹 Excel dışa aktar
  static Future<String> disariAktar(
      List<Satis> satislar, DateTime baslangic, DateTime bitis) async {
    if (satislar.isEmpty) {
      throw Exception("Seçilen tarih aralığında veri bulunamadı.");
    }

    var excel = Excel.createExcel();
    Sheet sheetObject = excel['Gun_Sonu_Raporu'];

    // Başlık satırı (Kod ve Barkod eklendi)
    sheetObject.appendRow([
      "Fiş No",
      "Tarih",
      "Kod",
      "Barkod",
      "Ürün Adı",
      "Miktar",
      "Birim",
      "Kdv li fiyat",
      "Kdv li tutar",
      "İndirim"
    ]);

    for (var satis in satislar) {
  for (var kalem in satis.kalemler) {
    final excelMap = kalem.toMapForExcel(); // <-- yeni ekleme
    sheetObject.appendRow([
      satis.id.toString(),
      DateFormat('yyyy-MM-dd HH:mm:ss').format(satis.tarih),
      excelMap['Kod'],
      excelMap['Barkod'],
      excelMap['Ürün Adı'],
      excelMap['Miktar'],
      excelMap['Birim'],
      excelMap['KDV li fiyat'],
      excelMap['KDV li tutar'],
      excelMap['İndirim'],
    ]);
  }
}


    final dir = await getApplicationDocumentsDirectory();
    final tarihEtiket = DateFormat('yyyyMMdd_HHmm').format(DateTime.now());
    final filePath = '${dir.path}/gunsonu_raporu_$tarihEtiket.xlsx';
    final fileBytes = excel.encode();
    final file = File(filePath)
      ..createSync(recursive: true)
      ..writeAsBytesSync(fileBytes!);

    return file.path;
  }

  // 🔹 Excel dosyasını paylaş
  static Future<void> dosyayiPaylas(String path) async {
    await Share.shareXFiles([XFile(path)], text: 'Gün Sonu Raporu');
  }
}
