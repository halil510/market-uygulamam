
import 'package:sqflite/sqflite.dart';
import '../modeller/cari_model.dart';
import '../servisler/veritabani_yardimcisi.dart';

class CariRepo {
  Future<Database> _db() async => await VeritabaniYardimcisi.db;

  Future<void> cariEkle(Cari cari) async {
    final db = await _db();
    await db.insert('cariler', cari.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Cari>> tumCarileriGetir() async {
    final db = await _db();
    final maps = await db.query('cariler');
    return maps.map((m) => Cari.fromMap(m)).toList();
  }

  Future<void> cariSil(int id) async {
    final db = await _db();
    await db.delete('cariler', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> cariGuncelle(Cari cari) async {
    final db = await _db();
    await db.update('cariler', cari.toMap(), where: 'id = ?', whereArgs: [cari.id]);
  }

  Future<void> borcEkle(int cariId, double tutar) async {
    final db = await _db();
    await db.rawUpdate('UPDATE cariler SET borc = borc + ? WHERE id = ?', [tutar, cariId]);
  }

  Future<void> alacakEkle(int cariId, double tutar) async {
    final db = await _db();
    await db.rawUpdate('UPDATE cariler SET alacak = alacak + ? WHERE id = ?', [tutar, cariId]);
  }
}
