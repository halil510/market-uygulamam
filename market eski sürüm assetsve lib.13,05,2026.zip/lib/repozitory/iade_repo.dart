import 'package:market_uygulamasi/modeller/iade_kaydi.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:sqflite/sqflite.dart';

class IadeRepository {
  final VeritabaniYardimcisi _dbHelper = VeritabaniYardimcisi();

  // Veritabanı bağlantısı
  Future<Database> get _db async => _dbHelper.db;

  // Tablo adı
  static const String _table = 'iade_kaydi';

  // Kolonların var olup olmadığını kontrol eden metot
  Future<void> _ensureColumns() async {
    final db = await _db;
    
    // KDV kolonu kontrolü
    var info = await db.rawQuery('PRAGMA table_info($_table)');
    if (!info.any((row) => row['name'] == 'kdv_orani')) {
      await db.execute('ALTER TABLE $_table ADD COLUMN kdv_orani REAL DEFAULT 0');
    }
    
    // Orijinal alış fiyatı kolonu kontrolü
    info = await db.rawQuery('PRAGMA table_info($_table)');
    if (!info.any((row) => row['name'] == 'orijinal_alis_fiyati')) {
      await db.execute('ALTER TABLE $_table ADD COLUMN orijinal_alis_fiyati REAL DEFAULT 0');
    }
  }

  // İade kaydını veritabanına kaydetme metodu
  Future<void> iadeKaydet(IadeKaydi kayit) async {
    final db = await _db;
    await _ensureColumns();

    final data = <String, Object?>{
      'urun_id': kayit.urunId,
      'urun_adi': kayit.urunAdi,
      'barkod': kayit.barkod,
      'alis_fiyati': kayit.alisFiyati,
      'satis_fiyati': kayit.satisFiyati,
      'iade_miktari': kayit.iadeMiktari,
      'kdv_orani': kayit.kdvOrani,
      'nedeni': kayit.nedeni,
      'indirim_notu': kayit.indirimNotu,
      'tarih': kayit.tarih.toIso8601String(),
      'tedarikci': kayit.tedarikci,
      'orijinal_alis_fiyati': kayit.orijinalAlisFiyati, // Yeni eklenen alan
    };

    await db.insert(_table, data, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // Tüm iade kayıtlarını getirme metodu
  Future<List<IadeKaydi>> tumIadeKayitlariniGetir() async {
    final db = await _db;
    await _ensureColumns();
    
    final rows = await db.query(
      _table,
      orderBy: 'datetime(tarih) DESC',
    );

    return rows.map(_fromDbMap).toList();
  }

  // İade kaydını silme metodu
  Future<void> iadeKaydiSil(int id) async {
    final db = await _db;
    await db.delete(_table, where: 'id = ?', whereArgs: [id]);
  }

  // İade kaydını güncelleme metodu
  Future<void> iadeKaydiGuncelle(IadeKaydi kayit) async {
    final db = await _db;
    await _ensureColumns();

    final data = <String, Object?>{
      'urun_id': kayit.urunId,
      'urun_adi': kayit.urunAdi,
      'barkod': kayit.barkod,
      'alis_fiyati': kayit.alisFiyati,
      'satis_fiyati': kayit.satisFiyati,
      'iade_miktari': kayit.iadeMiktari,
      'kdv_orani': kayit.kdvOrani,
      'nedeni': kayit.nedeni,
      'indirim_notu': kayit.indirimNotu,
      'tarih': kayit.tarih.toIso8601String(),
      'tedarikci': kayit.tedarikci,
      'orijinal_alis_fiyati': kayit.orijinalAlisFiyati, // Yeni eklenen alan
    };

    await db.update(
      _table,
      data,
      where: 'id = ?',
      whereArgs: [kayit.id],
    );
  }

  // Barkod ile son iade kaydını getirme metodu
  Future<IadeKaydi?> sonIadeKaydiniGetir(String barkod) async {
    final db = await _db; // `_database` yerine `_db` kullanılıyor
    final maps = await db.query(
      _table, // `_tableName` yerine `_table` kullanılıyor
      where: 'barkod = ?',
      whereArgs: [barkod],
      orderBy: 'tarih DESC',
      limit: 1,
    );
    
    if (maps.isNotEmpty) {
      return IadeKaydi.fromMap(maps.first);
    }
    return null;
  }

  // Veritabanından satırları alıp IadeKaydi nesnesine dönüştürme
  IadeKaydi _fromDbMap(Map<String, dynamic> m) {
    return IadeKaydi(
      id: m['id'] as int?,
      urunId: (m['urun_id'] as num).toInt(),
      urunAdi: (m['urun_adi'] as String?) ?? '',
      barkod: (m['barkod'] as String?) ?? '',
      alisFiyati: (m['alis_fiyati'] as num?)?.toDouble() ?? 0.0,
      satisFiyati: (m['satis_fiyati'] as num?)?.toDouble() ?? 0.0,
      iadeMiktari: (m['iade_miktari'] as num?)?.toDouble() ?? 0.0,
      kdvOrani: (m['kdv_orani'] as num?)?.toDouble() ?? 0.0,
      nedeni: (m['nedeni'] as String?) ?? '',
      tarih: DateTime.tryParse((m['tarih'] as String?) ?? '') ?? DateTime.now(),
      indirimNotu: m['indirim_notu'] as String?,
      tedarikci: (m['tedarikci'] as String?) ?? 'Bilinmiyor',
      orijinalAlisFiyati: (m['orijinal_alis_fiyati'] as num?)?.toDouble() ?? 0.0, // Yeni eklenen alan
    );
  }
}
