class Kullanici {
  final int? id;
  final String kullaniciAdi;
  final String sifre;
  final String? email;
  final String? telefon;
  final String? adSoyad;
  final String rol; // 'admin' veya 'personel'

  Kullanici({
    this.id,
    required this.kullaniciAdi,
    required this.sifre,
    this.email,
    this.telefon,
    this.adSoyad,
    this.rol = 'personel', // default değer
  });

  // Map'ten Kullanici nesnesi oluştur
  factory Kullanici.fromMap(Map<String, dynamic> map) {
    return Kullanici(
      id: map['id'] != null ? int.tryParse(map['id'].toString()) : null,
      kullaniciAdi: map['kullaniciAdi'] ?? '',
      sifre: map['sifre'] ?? '',
      email: map['email'],
      telefon: map['telefon'],
      adSoyad: map['adSoyad'],
      rol: map['rol']?.toString() ?? 'personel',
    );
  }

  // Kullanici nesnesini Map'e çevir
  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'kullaniciAdi': kullaniciAdi,
      'sifre': sifre,
      'rol': rol,
    };
    if (id != null) map['id'] = id;
    if (email != null) map['email'] = email;
    if (telefon != null) map['telefon'] = telefon;
    if (adSoyad != null) map['adSoyad'] = adSoyad;
    return map;
  }

  // Nesneyi kopyalayıp bazı alanları değiştirmek için
  Kullanici copyWith({
    int? id,
    String? kullaniciAdi,
    String? sifre,
    String? email,
    String? telefon,
    String? adSoyad,
    String? rol,
  }) {
    return Kullanici(
      id: id ?? this.id,
      kullaniciAdi: kullaniciAdi ?? this.kullaniciAdi,
      sifre: sifre ?? this.sifre,
      email: email ?? this.email,
      telefon: telefon ?? this.telefon,
      adSoyad: adSoyad ?? this.adSoyad,
      rol: rol ?? this.rol,
    );
  }
}