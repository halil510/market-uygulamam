// lib/modern_ui/widgets/modern_sizes.dart
class ModernSizes {
  static const double padding = 16.0;
  static const double radius = 16.0;
  static const double radiusLarge = 24.0;
  static const double iconSize = 22.0;
  static const double iconSizeLarge = 32.0;
  static const double buttonHeight = 58.0;
  static const double buttonSmallHeight = 44.0;
  static const double productCardWidth = 160.0;
  static const double productCardHeight = 220.0;
  static const double avatarSize = 48.0;
  static const double separatorHeight = 1.0;
}