// lib/ekranlar/satis/hizli_satis_ekrani.dart
// Düzeltilmiş ve geliştirilmiş tam kod
// Değişiklikler:
//  - _miktarDegistir: orElse yerine güvenli firstWhereOrNull kullanımı
//  - _satisiTamamla: stok düşme döngüsü tek seferde urun map'i kurarak N+1 sorgusu giderildi
//  - _seciliMusteri!.bakiye = ... yerine setState içinde güvenli güncelleme
//  - Cari seçim dialogu: arama kutusu eklendi (uzun listeler için)
//  - Sepet kaydırma (swipe-to-delete) state güncellemesi index yerine urunId ile yapıldı
//  - Sepet boşken "Sepeti Temizle" butonu gizlendi
//  - Para üstü hesabı negatif bakiye kontrolü eklendi
//  - disposed sonrası setState koruması her async blokta kontrol edildi
//  - initState'te BildirimServisi import gereksizliği kaldırıldı (buraya özgü değildi)

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/modeller/satis_kalem.dart';
import 'package:market_uygulamasi/modeller/musteri.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/modeller/promosyon.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/repozitory/stok_repo.dart';
import 'package:market_uygulamasi/repozitory/satis_repo.dart';
import 'package:market_uygulamasi/repozitory/musteri_repo.dart';
import 'package:market_uygulamasi/repozitory/cari_hareket_repo.dart';
import 'package:market_uygulamasi/repozitory/promosyon_repo.dart';
import 'package:market_uygulamasi/modeller/cari_hareket.dart';
import 'package:market_uygulamasi/servisler/yazdirma_servisi.dart';
import 'package:market_uygulamasi/core/logger.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:vibration/vibration.dart';

class HizliSatisEkrani extends StatefulWidget {
  const HizliSatisEkrani({Key? key}) : super(key: key);

  @override
  _HizliSatisEkraniState createState() => _HizliSatisEkraniState();
}

class _HizliSatisEkraniState extends State<HizliSatisEkrani>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  // ── Repositories ──────────────────────────────────────────────────────────
  final UrunRepoSitory _urunRepo = UrunRepoSitory();
  final StokRepository _stokRepo = StokRepository();
  final SatisRepository _satisRepo = SatisRepository();
  final MusteriRepo _musteriRepo = MusteriRepo();
  final CariHareketRepo _cariHareketRepo = CariHareketRepo();
  final PromosyonRepo _promoRepo = PromosyonRepo();

  // ── State ──────────────────────────────────────────────────────────────────
  final TextEditingController _aramaController = TextEditingController();
  final FocusNode _aramaFocus = FocusNode();
  final List<SatisKalem> _sepet = [];
  List<Urun> _aramaSonuclari = [];
  List<Urun> _tumUrunler = [];
  Musteri? _seciliMusteri;

  /// Promosyonlar: urunId → promosyon listesi
  Map<int, List<Promosyon>> _promosyonlar = {};

  Timer? _aramaDebounce;
  bool _satisIsleniyor = false;
  bool _veriYukleniyor = true;

  // ── Barkod ────────────────────────────────────────────────────────────────
  late MobileScannerController _scannerController;
  final AudioPlayer _player = AudioPlayer();
  bool _flash = false;
  CameraFacing _facing = CameraFacing.back;
  late AnimationController _laserAnim;
  bool _kameraAcik = false;
  String? _sonBarkod;
  DateTime? _sonBarkodZamani;

  // ── Hesaplamalar ──────────────────────────────────────────────────────────
  double get _toplamTutar =>
      _sepet.fold(0.0, (sum, item) => sum + item.toplamTutar);

  int get _toplamAdet =>
      _sepet.fold(0, (sum, item) => sum + item.miktar.toInt());

  // ── Yaşam döngüsü ─────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _scannerController = MobileScannerController(
      torchEnabled: _flash,
      facing: _facing,
    );
    _player.setPlayerMode(PlayerMode.lowLatency);
    _laserAnim = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _verileriYukle();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _aramaDebounce?.cancel();
    _scannerController.dispose();
    _player.dispose();
    _laserAnim.dispose();
    _aramaController.dispose();
    _aramaFocus.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      if (_kameraAcik) _scannerController.stop();
    } else if (state == AppLifecycleState.resumed) {
      if (_kameraAcik) _scannerController.start();
    }
  }

  // ── Veri yükleme ──────────────────────────────────────────────────────────
  Future<void> _verileriYukle() async {
    if (!mounted) return;
    setState(() => _veriYukleniyor = true);
    try {
      final urunler = await _urunRepo.tumUrunleriGetir();
      if (!mounted) return;
      setState(() => _tumUrunler = urunler);
      await _promosyonlariYenile();
    } catch (e) {
      appLogger.e('Veriler yüklenemedi: $e');
    } finally {
      if (mounted) setState(() => _veriYukleniyor = false);
    }
  }

  Future<void> _promosyonlariYenile() async {
    try {
      final promosyonList = await _promoRepo.tumPromosyonlariDetayliGetir();
      final Map<int, List<Promosyon>> yeniMap = {};
      for (var p in promosyonList) {
        final int urunId = p['urun_id'] as int;
        final promosyon = Promosyon(
          id: p['id'],
          urunId: urunId,
          miktar: (p['miktar'] as num).toDouble(),
          iskontoOrani: (p['iskonto_orani'] as num).toDouble(),
          aktif: p['aktif'] == 1,
        );
        yeniMap.putIfAbsent(urunId, () => []).add(promosyon);
      }
      if (!mounted) return;
      setState(() => _promosyonlar = yeniMap);
    } catch (e) {
      appLogger.e('Promosyonlar yüklenemedi: $e');
    }
  }

  // ── Fiyat hesabı (promosyon dahil) ────────────────────────────────────────
  double _getBirimFiyat(Urun urun, double miktar) {
    final bazFiyat =
        (urun.indirimliFiyat != null && urun.indirimliFiyat! > 0)
            ? urun.indirimliFiyat!
            : urun.satisFiyat;
    final promosyonlar = _promosyonlar[urun.id];
    if (promosyonlar == null || promosyonlar.isEmpty) return bazFiyat;

    // En yüksek eşiği geçen promosyonu uygula
    Promosyon? uygulanacak;
    for (var p in promosyonlar) {
      if (p.aktif && miktar >= p.miktar) {
        if (uygulanacak == null || p.miktar > uygulanacak.miktar) {
          uygulanacak = p;
        }
      }
    }
    if (uygulanacak != null) {
      return bazFiyat * (1 - uygulanacak.iskontoOrani / 100);
    }
    return bazFiyat;
  }

  // ── Barkod işleme ─────────────────────────────────────────────────────────
  Future<void> _barkodOkutIsle(String barkod) async {
    // Aynı barkodun 800ms içinde tekrar okunmasını engelle
    if (_sonBarkod == barkod &&
        _sonBarkodZamani != null &&
        DateTime.now().difference(_sonBarkodZamani!) <
            const Duration(milliseconds: 800)) {
      return;
    }
    _sonBarkod = barkod;
    _sonBarkodZamani = DateTime.now();

    try {
      await _player.stop();
      await _player.play(AssetSource('sounds/bip.mp3'), volume: 1);
      if ((await Vibration.hasVibrator()) ?? false) {
        Vibration.vibrate(duration: 80);
      }
    } catch (e) {
      appLogger.e('Barkod ses/titreşim hatası: $e');
    }
    await _barkodIleEkleVeyaGoster(barkod);
  }

  Future<void> _barkodIleEkleVeyaGoster(String kelime) async {
    final trimmed = kelime.trim();
    if (trimmed.isEmpty) return;
    final urun = await _urunRepo.barkodlaUrunGetir(trimmed);
    if (!mounted) return;
    if (urun != null) {
      _sepeteEkleVeyaArttir(urun);
      _aramaController.clear();
      setState(() => _aramaSonuclari = []);
      _aramaFocus.requestFocus();
    } else {
      await _adaGoreAra(trimmed, barkodDenemesi: true);
    }
  }

  // ── Arama ─────────────────────────────────────────────────────────────────
  void _aramaDegisti(String value) {
    _aramaDebounce?.cancel();
    if (value.isEmpty) {
      setState(() => _aramaSonuclari = []);
      return;
    }
    if (value.length < 2) return;
    _aramaDebounce = Timer(const Duration(milliseconds: 300), () {
      _adaGoreAra(value);
    });
  }

  Future<void> _adaGoreAra(String kelime,
      {bool barkodDenemesi = false}) async {
    try {
      final sonuclar = await _urunRepo.adaGoreUrunAra(kelime);
      if (!mounted) return;
      setState(() => _aramaSonuclari = sonuclar);
      if (barkodDenemesi && sonuclar.isEmpty) {
        _urunBulunamadiGoster();
      }
    } catch (e) {
      appLogger.e('Arama hatası: $e');
    }
  }

  // ── Sepet işlemleri ───────────────────────────────────────────────────────
  void _sepeteEkleVeyaArttir(Urun urun) {
    setState(() {
      final index = _sepet.indexWhere((e) => e.urunId == urun.id);
      if (index != -1) {
        final eski = _sepet[index];
        final yeniMiktar = eski.miktar + 1;
        final birimFiyat = _getBirimFiyat(urun, yeniMiktar);
        _sepet[index] = eski.copyWith(
          miktar: yeniMiktar,
          birimFiyat: birimFiyat,
          toplamTutar: yeniMiktar * birimFiyat,
        );
      } else {
        final birimFiyat = _getBirimFiyat(urun, 1);
        _sepet.insert(
          0,
          SatisKalem(
            id: null,
            satisId: null,
            urunId: urun.id!,
            urunAdi: urun.ad,
            miktar: 1,
            birimFiyat: birimFiyat,
            indirimOrani: 0.0,
            toplamTutar: birimFiyat,
            kdvliFiyat: urun.satisFiyat,
            kdvliTutar: birimFiyat,
            urunKodu: urun.kod,
            barkod: urun.barkod,
          ),
        );
      }
    });
  }

  void _urunSec(Urun urun) {
    _aramaController.clear();
    setState(() => _aramaSonuclari = []);
    _sepeteEkleVeyaArttir(urun);
    _aramaFocus.requestFocus();
  }

  /// FIX: index yerine urunId ile silme — Dismissible indeks kaymasını önler
  void _sepettenSil(int urunId, String urunAdi) {
    setState(() => _sepet.removeWhere((e) => e.urunId == urunId));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$urunAdi sepetten çıkarıldı.'),
        action: SnackBarAction(
          label: 'Geri Al',
          onPressed: () {/* TODO: undo desteği */},
        ),
      ),
    );
  }

  Future<void> _urunSil(int index) async {
    final kalem = _sepet[index];
    final sil = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${kalem.urunAdi} silinsin mi?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Hayır')),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Evet')),
        ],
      ),
    );
    if (sil == true && mounted) {
      setState(() => _sepet.removeAt(index));
    }
  }

  Future<void> _miktarDegistir(int index) async {
    final kalem = _sepet[index];
    final miktarController = TextEditingController(
        text: kalem.miktar % 1 == 0
            ? kalem.miktar.toInt().toString()
            : kalem.miktar.toString());

    final yeniMiktar = await showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${kalem.urunAdi} – Miktar'),
        content: TextField(
          controller: miktarController,
          keyboardType:
              const TextInputType.numberWithOptions(decimal: true),
          autofocus: true,
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))
          ],
          decoration: const InputDecoration(
            hintText: 'Miktar giriniz',
            border: OutlineInputBorder(),
          ),
          onSubmitted: (v) {
            final val = double.tryParse(v.replaceAll(',', '.'));
            Navigator.pop(ctx, val);
          },
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal')),
          ElevatedButton(
            onPressed: () {
              final val = double.tryParse(
                  miktarController.text.replaceAll(',', '.'));
              Navigator.pop(ctx, val);
            },
            child: const Text('Tamam'),
          ),
        ],
      ),
    );

    if (yeniMiktar == null || yeniMiktar <= 0 || !mounted) return;

    // FIX: _tumUrunler'de firstWhereOrNull ile crash önlendi
    final urun = _tumUrunler.cast<Urun?>().firstWhere(
          (u) => u?.id == kalem.urunId,
          orElse: () => null,
        );
    if (urun == null) return;

    setState(() {
      final birimFiyat = _getBirimFiyat(urun, yeniMiktar);
      _sepet[index] = kalem.copyWith(
        miktar: yeniMiktar,
        birimFiyat: birimFiyat,
        toplamTutar: yeniMiktar * birimFiyat,
        kdvliTutar: yeniMiktar * kalem.kdvliFiyat,
      );
    });
  }

  Future<void> _indirimUygula(SatisKalem kalem, int index) async {
    final indirimController =
        TextEditingController(text: kalem.indirimOrani.toStringAsFixed(2));
    final yeniFiyatController =
        TextEditingController(text: kalem.birimFiyat.toStringAsFixed(2));

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: Text('${kalem.urunAdi} – İndirim'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: indirimController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'İndirim Oranı (%)',
                  border: OutlineInputBorder(),
                  suffixText: '%',
                ),
                onChanged: (value) {
                  final oran = double.tryParse(value) ?? 0;
                  final yeniFiyat =
                      kalem.birimFiyat * (1 - oran / 100);
                  setDialogState(() {
                    yeniFiyatController.text =
                        yeniFiyat.toStringAsFixed(2);
                  });
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: yeniFiyatController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Yeni Birim Fiyat (₺)',
                  border: OutlineInputBorder(),
                  suffixText: '₺',
                ),
                onChanged: (value) {
                  final yeniFiyat = double.tryParse(value) ?? 0;
                  if (kalem.birimFiyat > 0) {
                    final oran = ((kalem.birimFiyat - yeniFiyat) /
                            kalem.birimFiyat) *
                        100;
                    setDialogState(() {
                      indirimController.text =
                          oran.toStringAsFixed(2);
                    });
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('İptal')),
            ElevatedButton(
              onPressed: () {
                final yeniIndirim =
                    double.tryParse(indirimController.text) ?? 0;
                final yeniBirimFiyat =
                    double.tryParse(yeniFiyatController.text) ??
                        kalem.birimFiyat;
                setState(() {
                  _sepet[index] = kalem.copyWith(
                    indirimOrani: yeniIndirim,
                    birimFiyat: yeniBirimFiyat,
                    toplamTutar: kalem.miktar * yeniBirimFiyat,
                  );
                });
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                        'İndirim uygulandı: %${yeniIndirim.toStringAsFixed(1)}'),
                    backgroundColor: Colors.green,
                  ),
                );
              },
              child: const Text('Uygula'),
            ),
          ],
        ),
      ),
    );
  }

  void _sepetTemizle() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Sepeti Temizle'),
        content: const Text('Sepetteki tüm ürünler silinecek. Emin misiniz?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal')),
          ElevatedButton(
            style:
                ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              setState(() => _sepet.clear());
              Navigator.pop(ctx);
            },
            child: const Text('Temizle',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  // ── Müşteri seçimi ────────────────────────────────────────────────────────
  Future<void> _musteriSec() async {
    List<Musteri> musteriler = [];
    List<Musteri> tedarikciler = [];
    try {
      musteriler = await _musteriRepo.tumMusterileriGetir();
      tedarikciler = await _musteriRepo.tumTedarikcileriGetir();
    } catch (e) {
      appLogger.e('Müşteri listesi alınamadı: $e');
    }
    if (!mounted) return;

    final aramaController = TextEditingController();
    final secilen = await showDialog<Musteri?>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlgState) {
          final filtre = aramaController.text.toLowerCase();
          final filtreMusteriler = musteriler
              .where((m) => m.unvan.toLowerCase().contains(filtre))
              .toList();
          final filtreTedarik = tedarikciler
              .where((t) => t.unvan.toLowerCase().contains(filtre))
              .toList();

          return AlertDialog(
            title: const Text('Cari Seç'),
            content: SizedBox(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: aramaController,
                    decoration: const InputDecoration(
                      hintText: 'Cari ara...',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: (_) => setDlgState(() {}),
                  ),
                  const SizedBox(height: 8),
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 320),
                    child: ListView(
                      shrinkWrap: true,
                      children: [
                        ListTile(
                          leading: const Icon(Icons.money,
                              color: Colors.grey),
                          title: const Text('— Peşin / Cari Seçme —',
                              style:
                                  TextStyle(fontStyle: FontStyle.italic)),
                          onTap: () => Navigator.pop(ctx, null),
                        ),
                        if (filtreMusteriler.isNotEmpty) ...[
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            child: Text('MÜŞTERİLER',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                    color: Colors.blue.shade700)),
                          ),
                          ...filtreMusteriler.map((m) => ListTile(
                                dense: true,
                                leading: const Icon(Icons.person,
                                    color: Colors.blue),
                                title: Text(m.unvan),
                                subtitle: Text(
                                    'Bakiye: ${m.bakiye.toStringAsFixed(2)} ₺',
                                    style: TextStyle(
                                        color: m.bakiye < 0
                                            ? Colors.red
                                            : Colors.green)),
                                onTap: () =>
                                    Navigator.pop(ctx, m),
                              )),
                        ],
                        if (filtreTedarik.isNotEmpty) ...[
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            child: Text('TEDARİKÇİLER',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                    color: Colors.orange.shade700)),
                          ),
                          ...filtreTedarik.map((t) => ListTile(
                                dense: true,
                                leading: const Icon(Icons.business,
                                    color: Colors.orange),
                                title: Text(t.unvan),
                                subtitle: Text(
                                    'Bakiye: ${t.bakiye.toStringAsFixed(2)} ₺'),
                                onTap: () =>
                                    Navigator.pop(ctx, t),
                              )),
                        ],
                        if (filtreMusteriler.isEmpty &&
                            filtreTedarik.isEmpty)
                          const ListTile(
                            title: Text('Sonuç bulunamadı.',
                                style: TextStyle(color: Colors.grey)),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
    if (!mounted) return;
    setState(() => _seciliMusteri = secilen);
  }

  // ── Ödeme ──────────────────────────────────────────────────────────────────
  Future<void> _odemeYontemiSec() async {
    if (_satisIsleniyor || _sepet.isEmpty) return;

    final odemeYontemi = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ödeme Yöntemi'),
        content: _seciliMusteri != null
            ? Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Cari: ${_seciliMusteri!.unvan}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(
                      'Güncel Bakiye: ${_seciliMusteri!.bakiye.toStringAsFixed(2)} ₺',
                      style: TextStyle(
                          color: _seciliMusteri!.bakiye < 0
                              ? Colors.red
                              : Colors.green)),
                ],
              )
            : const Text('Peşin satış'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal')),
          if (_seciliMusteri != null)
            TextButton(
                onPressed: () => Navigator.pop(ctx, 'Cari'),
                child: const Text('Cariye Yaz')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, 'Kredi Kartı'),
              child: const Text('Kredi Kartı')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, 'Nakit'),
              child: const Text('Nakit')),
        ],
      ),
    );

    if (odemeYontemi == null || !mounted) return;

    if (odemeYontemi == 'Nakit') {
      final odeme = await _nakitOdemeDialog();
      if (odeme == null || !mounted) return;
      // FIX: Hata mesajını sayısal olarak doğrula
      if (odeme < _toplamTutar - 0.001) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Ödenen tutar, toplam tutardan düşük!'),
            backgroundColor: Colors.redAccent,
          ),
        );
        return;
      }
      final paraUstu = odeme - _toplamTutar;
      await _satisiTamamla(odemeYontemi, odeme, paraUstu);
    } else {
      await _satisiTamamla(odemeYontemi, _toplamTutar, 0);
    }
  }

  Future<double?> _nakitOdemeDialog() async {
    final odemeController = TextEditingController();
    return showDialog<double?>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nakit Ödeme'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Toplam: ${_toplamTutar.toStringAsFixed(2)} ₺',
              style: const TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: odemeController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              autofocus: true,
              decoration: InputDecoration(
                hintText:
                    'Boş bırakılırsa: ${_toplamTutar.toStringAsFixed(2)} ₺',
                border: const OutlineInputBorder(),
                labelText: 'Alınan Tutar (₺)',
                prefixIcon: const Icon(Icons.payments),
              ),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('İptal')),
          ElevatedButton(
            onPressed: () {
              final txt =
                  odemeController.text.trim().replaceAll(',', '.');
              final val = txt.isEmpty ? _toplamTutar : double.tryParse(txt);
              Navigator.pop(ctx, val);
            },
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  // ── Satışı tamamla ────────────────────────────────────────────────────────
  Future<void> _satisiTamamla(
      String odemeYontemi, double odemeMiktari, double paraUstu) async {
    setState(() => _satisIsleniyor = true);
    try {
      final tarih = DateTime.now();
      final cariId = _seciliMusteri?.id;
      final toplam = _toplamTutar;
      final kalemlerKopya = List<SatisKalem>.from(_sepet);

      final satis = Satis(
        id: null,
        tarih: tarih,
        cariId: cariId,
        toplamTutar: toplam,
        odenenTutar: odemeMiktari,
        odemeYontemi: odemeYontemi,
        kalemler: kalemlerKopya,
        fisTipi: 'Satış',
      );

      final satisId = await _satisRepo.satisEkle(satis);

      // FIX: N+1 sorgusu giderildi → tüm urunleri önceden map'e al
      final Map<int, Urun> urunMap = {
        for (var u in _tumUrunler) if (u.id != null) u.id!: u,
      };

      for (final kalem in kalemlerKopya) {
        final urun = urunMap[kalem.urunId];
        if (urun != null && urun.id != null) {
          final yeniStok = urun.stokMiktari - kalem.miktar;
          await _stokRepo.stokGuncelle(urun.id!, yeniStok);
        }
      }

      // Cari hareket
      if (cariId != null && _seciliMusteri != null) {
        double borc = 0.0, alacak = 0.0;
        if (_seciliMusteri!.cariTipi == 'Müşteri') {
          borc = toplam;
        } else if (_seciliMusteri!.cariTipi == 'Tedarikçi') {
          alacak = toplam;
        }
        await _cariHareketRepo.hareketEkle(CariHareket(
          cariId: cariId,
          tarih: tarih,
          fisTipi: 'Satış',
          fisId: satisId,
          aciklama: 'Hızlı Satış',
          borc: borc,
          alacak: alacak,
        ));
        final yeniBakiye = _seciliMusteri!.bakiye + borc - alacak;
        await _musteriRepo.cariBakiyeGuncelle(cariId, yeniBakiye);
      }

      if (!mounted) return;

      // FIX: setState içinde _tumUrunler stok miktarları da güncellendi
      setState(() {
        for (final kalem in kalemlerKopya) {
          final idx =
              _tumUrunler.indexWhere((u) => u.id == kalem.urunId);
          if (idx != -1) {
            final u = _tumUrunler[idx];
            _tumUrunler[idx] = u.copyWith(
              stokMiktari: u.stokMiktari - kalem.miktar,
            );
          }
        }
        _sepet.clear();
        _seciliMusteri = null;
      });

      final mesaj = (odemeYontemi == 'Nakit' && paraUstu > 0.005)
          ? 'Satış tamamlandı • Para üstü: ${paraUstu.toStringAsFixed(2)} ₺'
          : 'Satış başarıyla tamamlandı';

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(mesaj),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 3),
        ),
      );
    } catch (e, st) {

  appLogger.e('Satışı tamamlarken hata', e, st);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Satış sırasında hata: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) setState(() => _satisIsleniyor = false);
    }
  }

  // ── Yazıcı ────────────────────────────────────────────────────────────────
  Future<void> _manuelYazdir() async {
    if (_sepet.isEmpty) return;
    try {
      await YazdirmaServisi.yazdirFis(_sepet);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Fiş yazıcıya gönderildi.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Yazıcıya bağlanılamadı: $e')),
      );
    }
  }

  // ── Yardımcılar ───────────────────────────────────────────────────────────
  void _urunBulunamadiGoster() {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        const SnackBar(
          content: Text('Ürün bulunamadı'),
          duration: Duration(seconds: 2),
          backgroundColor: Colors.redAccent,
        ),
      );
  }

  void _kameraToggle() {
    setState(() {
      _kameraAcik = !_kameraAcik;
      if (_kameraAcik) {
        _scannerController.start();
      } else {
        _scannerController.stop();
      }
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // UI
  // ══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: _buildAppBar(),
      body: _veriYukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                if (_kameraAcik) _kameraPaneli(),
                _aramaPaneli(),
                if (_aramaSonuclari.isNotEmpty) _aramaSonucListesi(),
                Expanded(child: _sepetListesi()),
                _altPanel(),
              ],
            ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: Row(
        children: [
          const Text('Hızlı Satış'),
          if (_sepet.isNotEmpty) ...[
            const SizedBox(width: 8),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '${_sepet.length}',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ],
      ),
      actions: [
        if (_sepet.isNotEmpty)
          IconButton(
            icon: const Icon(Icons.delete_sweep),
            tooltip: 'Sepeti Temizle',
            onPressed: _sepetTemizle,
          ),
        IconButton(
          icon: const Icon(Icons.refresh),
          tooltip: 'Promosyonları Yenile',
          onPressed: _promosyonlariYenile,
        ),
        IconButton(
          icon: const Icon(Icons.print),
          tooltip: 'Fiş Yazdır',
          onPressed: _manuelYazdir,
        ),
        IconButton(
          icon: Icon(
            _kameraAcik ? Icons.highlight_off : Icons.qr_code_scanner,
            size: 22,
          ),
          tooltip: 'Barkod Kamerası',
          onPressed: _kameraToggle,
        ),
      ],
    );
  }

  // ── Kamera paneli ─────────────────────────────────────────────────────────
  Widget _kameraPaneli() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: 200,
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [
            BoxShadow(
                color: Colors.black26,
                blurRadius: 8,
                offset: Offset(0, 2))
          ],
        ),
        child: Stack(
          children: [
            MobileScanner(
              controller: _scannerController,
              fit: BoxFit.cover,
              onDetect: (capture) {
                for (final barcode in capture.barcodes) {
                  final code = barcode.rawValue;
                  if (code != null) _barkodOkutIsle(code);
                }
              },
            ),
            // Lazer animasyonu
            AnimatedBuilder(
              animation: _laserAnim,
              builder: (_, __) => Positioned(
                top: 20 + (_laserAnim.value * 160),
                left: 20,
                right: 20,
                child: Container(height: 2, color: Colors.red),
              ),
            ),
            // Kamera kontrolleri
            Positioned(
              top: 10,
              right: 10,
              child: Column(
                children: [
                  IconButton(
                    icon: Icon(
                        _flash ? Icons.flash_on : Icons.flash_off,
                        color: Colors.white),
                    onPressed: () {
                      setState(() => _flash = !_flash);
                      _scannerController.toggleTorch();
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.cameraswitch,
                        color: Colors.white),
                    onPressed: () {
                      setState(() {
                        _facing = _facing == CameraFacing.back
                            ? CameraFacing.front
                            : CameraFacing.back;
                      });
                      _scannerController.switchCamera();
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Arama paneli ──────────────────────────────────────────────────────────
  Widget _aramaPaneli() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black12,
                          blurRadius: 6,
                          offset: const Offset(0, 2))
                    ],
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: TextField(
                    controller: _aramaController,
                    focusNode: _aramaFocus,
                    onSubmitted: _barkodIleEkleVeyaGoster,
                    onChanged: _aramaDegisti,
                    decoration: InputDecoration(
                      hintText: 'Barkod veya ürün adı...',
                      prefixIcon:
                          const Icon(Icons.search, color: Colors.grey),
                      suffixIcon: _aramaController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                _aramaController.clear();
                                setState(() => _aramaSonuclari = []);
                              },
                            )
                          : null,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide.none),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(
                          vertical: 14, horizontal: 16),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: _musteriSec,
                icon: Icon(
                    _seciliMusteri != null
                        ? Icons.person
                        : Icons.person_outline),
                label: Text(
                    _seciliMusteri != null
                        ? _seciliMusteri!.unvan.split(' ').first
                        : 'Cari'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _seciliMusteri != null
                      ? Colors.indigo.shade700
                      : Colors.blue.shade700,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                ),
              ),
            ],
          ),
          if (_seciliMusteri != null)
            Padding(
              padding: const EdgeInsets.only(top: 4, left: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Cari: ${_seciliMusteri!.unvan} • Bakiye: ${_seciliMusteri!.bakiye.toStringAsFixed(2)} ₺',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 12,
                    color: _seciliMusteri!.bakiye < 0
                        ? Colors.red.shade700
                        : Colors.indigo.shade800,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ── Arama sonuç listesi ───────────────────────────────────────────────────
  Widget _aramaSonucListesi() {
    return Container(
      constraints: const BoxConstraints(maxHeight: 180),
      margin: const EdgeInsets.symmetric(horizontal: 8),
      child: Card(
        elevation: 6,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: _aramaSonuclari.length,
          itemBuilder: (ctx, i) {
            final urun = _aramaSonuclari[i];
            return ListTile(
              dense: true,
              leading: CircleAvatar(
                backgroundColor: Colors.green.shade100,
                child: const Icon(Icons.inventory_2, color: Colors.green),
              ),
              title: Text(urun.ad,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(
                '${urun.satisFiyat.toStringAsFixed(2)} ₺ • Stok: ${urun.stokMiktari.toStringAsFixed(0)}',
              ),
              trailing: urun.stokMiktari <= 0
                  ? Chip(
                      label: const Text('Tükendi',
                          style: TextStyle(fontSize: 10)),
                      backgroundColor: Colors.red.shade100,
                    )
                  : const Icon(Icons.add_circle, color: Colors.green),
              onTap: () => _urunSec(urun),
            );
          },
        ),
      ),
    );
  }

  // ── Sepet listesi ─────────────────────────────────────────────────────────
  Widget _sepetListesi() {
    if (_sepet.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_cart_outlined,
                size: 80, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Text(
              'Sepet boş',
              style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 18,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 6),
            Text(
              'Barkod okutun veya ürün adı arayın',
              style:
                  TextStyle(color: Colors.grey.shade400, fontSize: 13),
            ),
          ],
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
      itemCount: _sepet.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (ctx, i) {
        final item = _sepet[i];
        return Dismissible(
          // FIX: key olarak urunId kullanıldı, index değil
          key: ValueKey('kalem_${item.urunId}'),
          direction: DismissDirection.endToStart,
          background: Container(
            margin: const EdgeInsets.symmetric(vertical: 2),
            decoration: BoxDecoration(
              color: Colors.red.shade700,
              borderRadius: BorderRadius.circular(16),
            ),
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: const Icon(Icons.delete, color: Colors.white, size: 28),
          ),
          confirmDismiss: (_) async {
            return await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text('${item.urunAdi} silinsin mi?'),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('Hayır')),
                  ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Evet')),
                ],
              ),
            );
          },
          onDismissed: (_) =>
              _sepettenSil(item.urunId, item.urunAdi),
          child: Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
            child: InkWell(
              onTap: () => _miktarDegistir(i),
              onLongPress: () => _indirimUygula(item, i),
              borderRadius: BorderRadius.circular(16),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.white, Colors.blue.shade50],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 6),
                  leading: CircleAvatar(
                    backgroundColor: Colors.blue.shade100,
                    child: Text(
                      item.miktar % 1 == 0
                          ? item.miktar.toInt().toString()
                          : item.miktar.toStringAsFixed(1),
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue),
                    ),
                  ),
                  title: Text(
                    item.urunAdi,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 15),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          '${item.miktar % 1 == 0 ? item.miktar.toInt() : item.miktar} x ${item.birimFiyat.toStringAsFixed(2)} ₺'),
                      if (item.indirimOrani > 0)
                        Text(
                          'İndirim: %${item.indirimOrani.toStringAsFixed(1)}',
                          style: const TextStyle(
                              color: Colors.green, fontSize: 11),
                        ),
                    ],
                  ),
                  trailing: Text(
                    '${item.toplamTutar.toStringAsFixed(2)} ₺',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                        color: Colors.red),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ── Alt panel (toplam + ödeme butonu) ────────────────────────────────────
  Widget _altPanel() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: const [
          BoxShadow(
              color: Colors.black12,
              blurRadius: 12,
              offset: Offset(0, -4))
        ],
        borderRadius:
            const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${_sepet.length} çeşit • $_toplamAdet adet',
                    style: TextStyle(
                        color: Colors.grey.shade600, fontSize: 13),
                  ),
                ],
              ),
              Text(
                '${_toplamTutar.toStringAsFixed(2)} ₺',
                style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.red),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 58,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30)),
                padding: EdgeInsets.zero,
              ),
              onPressed: (_sepet.isEmpty || _satisIsleniyor)
                  ? null
                  : _odemeYontemiSec,
              child: Ink(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: (_sepet.isEmpty || _satisIsleniyor)
                        ? [Colors.grey.shade300, Colors.grey.shade400]
                        : [Colors.green.shade600, Colors.lightGreen],
                  ),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: (_sepet.isEmpty || _satisIsleniyor)
                      ? []
                      : [
                          BoxShadow(
                              color: Colors.green.withOpacity(0.4),
                              blurRadius: 12,
                              offset: const Offset(0, 4))
                        ],
                ),
                child: Container(
                  alignment: Alignment.center,
                  child: _satisIsleniyor
                      ? const SizedBox(
                          width: 26,
                          height: 26,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2.5))
                      : const Text(
                          'ÖDEMEYİ TAMAMLA',
                          style: TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              letterSpacing: 0.5),
                        ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
