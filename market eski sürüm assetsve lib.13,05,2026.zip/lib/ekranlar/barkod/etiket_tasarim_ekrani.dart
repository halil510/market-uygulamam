import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:barcode/barcode.dart';

import 'package:market_uygulamasi/servisler/yazdirma_servisi.dart';
import 'package:market_uygulamasi/servisler/etiket_motoru_zpl.dart';
import 'package:market_uygulamasi/servisler/etiket_motoru_tspl.dart';

class EtiketTasarimEkrani extends StatefulWidget {
  const EtiketTasarimEkrani({Key? key}) : super(key: key);

  @override
  State<EtiketTasarimEkrani> createState() => _EtiketTasarimEkraniState();
}

class _EtiketTasarimEkraniState extends State<EtiketTasarimEkrani> {
  final _form = GlobalKey<FormState>();
  final _adCtrl = TextEditingController();
  final _fiyatCtrl = TextEditingController();
  final _barkodCtrl = TextEditingController(text: '8690000000000');
  final _genislikCtrl = TextEditingController(text: '50');
  final _yukseklikCtrl = TextEditingController(text: '30');

  String _dil = 'ZPL'; // ZPL / TSPL

  @override
  void initState() {
    super.initState();
    _yukle();
  }

  Future<void> _yukle() async {
    final sp = await SharedPreferences.getInstance();
    _adCtrl.text = sp.getString('etiket_ad') ?? '';
    _fiyatCtrl.text = sp.getString('etiket_fiyat') ?? '';
    _barkodCtrl.text = sp.getString('etiket_barkod') ?? '8690000000000';
    _genislikCtrl.text = sp.getString('etiket_w') ?? '50';
    _yukseklikCtrl.text = sp.getString('etiket_h') ?? '30';
    _dil = sp.getString('etiket_dil') ?? 'ZPL';
    setState(() {});
  }

  Future<void> _kaydet() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('etiket_ad', _adCtrl.text);
    await sp.setString('etiket_fiyat', _fiyatCtrl.text);
    await sp.setString('etiket_barkod', _barkodCtrl.text);
    await sp.setString('etiket_w', _genislikCtrl.text);
    await sp.setString('etiket_h', _yukseklikCtrl.text);
    await sp.setString('etiket_dil', _dil);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Şablon kaydedildi')),
    );
  }

  String _olusturKomut() {
    final w = double.tryParse(_genislikCtrl.text.replaceAll(',', '.')) ?? 50;
    final h = double.tryParse(_yukseklikCtrl.text.replaceAll(',', '.')) ?? 30;
    final barkod = _barkodCtrl.text.trim();
    final ad = _adCtrl.text.trim().isEmpty ? null : _adCtrl.text.trim();
    final fiyat = _fiyatCtrl.text.trim().isEmpty ? null : _fiyatCtrl.text.trim();

    if (_dil == 'ZPL') {
      return ZplEtiketMotoru.olustur(
        genislikMm: w,
        yukseklikMm: h,
        barkod: barkod,
        ad: ad,
        fiyat: fiyat,
      );
    } else {
      return TsplEtiketMotoru.olustur(
        genislikMm: w,
        yukseklikMm: h,
        barkod: barkod,
        ad: ad,
        fiyat: fiyat,
      );
    }
  }

  Future<void> _yazdir() async {
    final komut = _olusturKomut();
    await YazdirmaServisi.hamKomutYazdir(komut, YaziciKategori.etiket);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Etiket komutu gönderildi')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    final formFields = Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.all(12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: _tf('Ürün Adı', _adCtrl)),
                const SizedBox(width: 12),
                Expanded(child: _tf('Fiyat (örn: 49.90 ₺)', _fiyatCtrl)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _tf('Barkod', _barkodCtrl, required: true)),
                const SizedBox(width: 12),
                Expanded(child: _tf('Genişlik (mm)', _genislikCtrl, required: true)),
                const SizedBox(width: 12),
                Expanded(child: _tf('Yükseklik (mm)', _yukseklikCtrl, required: true)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Çıktı Dili:'),
                const SizedBox(width: 12),
                DropdownButton<String>(
                  value: _dil,
                  items: const [
                    DropdownMenuItem(value: 'ZPL', child: Text('ZPL (Zebra)')),
                    DropdownMenuItem(value: 'TSPL', child: Text('TSPL (TSC)')),
                  ],
                  onChanged: (v) => setState(() => _dil = v ?? 'ZPL'),
                ),
                const Spacer(),
                TextButton.icon(
                  onPressed: _kaydet,
                  icon: const Icon(Icons.save, color: Colors.blue),
                  label: const Text('Şablonu Kaydet', style: TextStyle(color: Colors.blue)),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: _yazdir,
                  icon: const Icon(Icons.print),
                  label: const Text('YAZDIR'),
                ),
              ],
            ),
          ],
        ),
      ),
    );

    final preview = Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.all(12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Önizleme', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text(_adCtrl.text, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 8),
            Container(
              height: 100,
              width: double.infinity,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('BARKOD ÖNİZLEME (Code128)'),
            ),
            const SizedBox(height: 8),
            Text(
              _fiyatCtrl.text,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text('Boyut: ${_genislikCtrl.text}×${_yukseklikCtrl.text} mm'),
          ],
        ),
      ),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Etiket Tasarım & Yazdırma')),
      body: isWide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 2, child: formFields),
                Expanded(flex: 1, child: preview),
              ],
            )
          : ListView(
              children: [
                formFields,
                preview,
              ],
            ),
    );
  }

  Widget _tf(String label, TextEditingController c, {bool required = false}) {
    return TextFormField(
      controller: c,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      ),
      validator: required ? (v) => (v == null || v.trim().isEmpty) ? 'Zorunlu' : null : null,
    );
  }
}
