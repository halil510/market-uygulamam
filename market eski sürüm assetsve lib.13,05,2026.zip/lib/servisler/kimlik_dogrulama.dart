import 'package:market_uygulamasi/repozitory/kullanici_repo.dart';

class KimlikDogrulama {
  final KullaniciRepository _kullaniciRepo = KullaniciRepository();

  Future<bool> girisYap(String kullaniciAdi, String sifre) async {
    final kullanici = await _kullaniciRepo.girisYap(kullaniciAdi, sifre);
    return kullanici != null;
  }

  Future<bool> sifreDegistir(String kullaniciAdi, String eskiSifre, String yeniSifre) async {
    return await _kullaniciRepo.sifreDegistir(kullaniciAdi, eskiSifre, yeniSifre);
  }
}