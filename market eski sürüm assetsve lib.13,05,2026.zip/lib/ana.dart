import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:market_uygulamasi/modern_ui/theme/app_theme.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/rotalar.dart';
import 'package:market_uygulamasi/ekranlar/giris_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/ana_ekran.dart';
import 'package:market_uygulamasi/ekranlar/urun/urun_liste_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/urun/urun_detay_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/stok/stok_liste_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/satis/hizli_satis_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/satis/sepet_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/iade/barkod_yazdirma_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/ayarlar/fiyat_guncelle_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/ayarlar/veri_yedekleme_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/sifre_degistir_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/ayarlar/ayarlar_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/yazici_ayar_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/raporlar/gun_sonu_rapor_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/ayarlar/veritabani_yonetimi_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/musteri/cari_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/iade/barkodlu_iade_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/barkod/etiket_tasarim_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/iade/stok_sayim_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/dashboard_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/promosyon/promosyon.dart';
import 'package:market_uygulamasi/servisler/auth_servisi.dart';
import 'package:market_uygulamasi/servisler/bildirim_servisi.dart';

// ★ Tema değişimini tüm uygulamaya yayacak değer
final ValueNotifier<String> temaNotifier = ValueNotifier<String>('light');

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
await BildirimServisi.init();
  final prefs = await SharedPreferences.getInstance();
  final kayitliTema = prefs.getString('tema_adi') ?? 'light';
  temaNotifier.value = kayitliTema; // başlangıç değeri

     // 🔥 EKLE BUNU
  await AuthServisi().oturumKontrol();

  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    temaNotifier.addListener(_temaDegisti);
  }

  void _temaDegisti() {
    setState(() {}); // temaNotifier.value değişince MaterialApp yeniden build olur
  }

  @override
  void dispose() {
    temaNotifier.removeListener(_temaDegisti);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Market Uygulaması',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.getTema(temaNotifier.value),   // ← her değişimde güncellenir
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('tr', 'TR')],
      locale: const Locale('tr', 'TR'),
      initialRoute: Rotalar.giris,
      routes: {
        Rotalar.giris: (context) => GirisEkrani(),
        Rotalar.anaEkran: (context) => AnaEkran(),
        Rotalar.urunListe: (context) => UrunListeEkrani(),
        Rotalar.stokListe: (context) => StokListeEkrani(),
        Rotalar.hizliSatis: (context) => HizliSatisEkrani(),
        Rotalar.sepet: (context) => SepetEkrani(),
        Rotalar.BarkodYazdirmaEkrani: (context) => BarkodYazdirmaEkrani(),
        Rotalar.fiyatGuncelle: (context) => FiyatGuncelleEkrani(),
        Rotalar.veriYedekle: (context) => VeriYedeklemeEkrani(),
        Rotalar.sifreDegistir: (context) => SifreDegistirEkrani(),
        Rotalar.ayarlar: (context) => AyarlarEkrani(),
        Rotalar.yaziciAyar: (context) => YaziciAyarEkrani(),
        Rotalar.gunSonuRapor: (context) => GunSonuRaporEkrani(),
        Rotalar.veritabaniYonetimi: (context) => VeritabaniYonetimiEkrani(),
        Rotalar.cariler: (context) => CariEkrani(),
        Rotalar.barkodluIade: (context) => const BarkodluIadeEkrani(),
        Rotalar.etiketTasarim: (context) => const EtiketTasarimEkrani(),
        Rotalar.stokSayim: (context) => StokSayimEkrani(),
        Rotalar.dashboard: (context) => DashboardEkrani(),
        Rotalar.promosyon: (context) => const PromosyonEkrani(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == Rotalar.urunDetay) {
          final args = settings.arguments;
          if (args is Urun) {
            return MaterialPageRoute(
              builder: (context) => UrunDetayEkrani(duzenlenecekUrun: args),
            );
          }
          return MaterialPageRoute(
            builder: (context) => const UrunDetayEkrani(duzenlenecekUrun: null),
          );
        }
        return null;
      },
    );
  }
}