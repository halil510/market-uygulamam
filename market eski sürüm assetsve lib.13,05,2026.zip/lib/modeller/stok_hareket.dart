class StokHareket {
  String id;
  String urunId;
  String urunAdi;
  DateTime tarih;
  String hareketTipi; // Giriş, Çıkış, Düzeltme
  double miktar;
  double birimFiyat;

  StokHareket({
    required this.id,
    required this.urunId,
    required this.urunAdi,
    required this.tarih,
    required this.hareketTipi,
    required this.miktar,
    required this.birimFiyat,
  });

  factory StokHareket.fromMap(Map<String, dynamic> map) {
    return StokHareket(
      id: map['id'],
      urunId: map['urunId'],
      urunAdi: map['urunAdi'],
      tarih: DateTime.parse(map['tarih']),
      hareketTipi: map['hareketTipi'],
      miktar: map['miktar']?.toDouble() ?? 0.0,
      birimFiyat: map['birimFiyat']?.toDouble() ?? 0.0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'urunId': urunId,
      'urunAdi': urunAdi,
      'tarih': tarih.toIso8601String(),
      'hareketTipi': hareketTipi,
      'miktar': miktar,
      'birimFiyat': birimFiyat,
    };
  }
}