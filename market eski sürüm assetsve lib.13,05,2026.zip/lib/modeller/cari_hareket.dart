import '../../modeller/cari_hareket.dart';
class CariHareket {
  int? id;
  int cariId;
  DateTime tarih;
  String fisTipi;
  int? fisId;
  String? fisNo; // Eklendi
  String aciklama;
  double borc;
  double alacak;
  double? bakiye;

  CariHareket({
    this.id,
    required this.cariId,
    required this.tarih,
    required this.fisTipi,
    this.fisId,
    this.fisNo, // Eklendi
    required this.aciklama,
    this.borc = 0,
    this.alacak = 0,
    this.bakiye,
  });

  factory CariHareket.fromMap(Map<String, dynamic> map) {
    return CariHareket(
      id: map['id'] as int?,
      cariId: map['cari_id'] as int,
      tarih: DateTime.tryParse(map['tarih'] ?? '') ?? DateTime.now(),
      fisTipi: map['fis_tipi'] ?? '',
      fisId: map['fis_id'] as int?,
      fisNo: map['fis_no'] as String?, // Eklendi
      aciklama: map['aciklama'] ?? '',
      borc: _doubleFromAny(map['borc']),
      alacak: _doubleFromAny(map['alacak']),
      bakiye: map['bakiye'] != null ? _doubleFromAny(map['bakiye']) : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'cari_id': cariId,
      'tarih': tarih.toIso8601String(),
      'fis_tipi': fisTipi,
      'fis_id': fisId,
      'fis_no': fisNo, // Eklendi
      'aciklama': aciklama,
      'borc': borc,
      'alacak': alacak,
      'bakiye': bakiye,
    };
  }

  static double _doubleFromAny(dynamic value) {
    if (value is int) return value.toDouble();
    if (value is double) return value;
    if (value is String) return double.tryParse(value) ?? 0;
    return 0;
  }
}