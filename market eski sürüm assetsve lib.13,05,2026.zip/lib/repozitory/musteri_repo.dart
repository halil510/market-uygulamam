import 'package:sqflite/sqflite.dart';
import '../modeller/musteri.dart';
import '../servisler/veritabani_yardimcisi.dart';

class MusteriRepo {
  static final MusteriRepo _instance = MusteriRepo._internal();
  factory MusteriRepo() => _instance;
  MusteriRepo._internal();

  Future<Database> get _database async {
    return await VeritabaniYardimcisi.getDatabase();
  }

Future<List<Musteri>> tumMusterileriGetir() async {
  final db = await _database;
  final List<Map<String, dynamic>> maps = await db.query(
    'Cari',
    where: 'cari_tipi = ?',
    whereArgs: ['Müşteri'],
    orderBy: 'unvan ASC',
  );
  return maps.map((e) => Musteri.fromMap(e)).toList();
}


  Future<List<Musteri>> tumTedarikcileriGetir() async {
    final db = await _database;
    final maps = await db.query(
      'Cari',
      where: 'cari_tipi = ?',
      whereArgs: ['Tedarikçi'],
      orderBy: 'unvan ASC',
    );
    return maps.map((map) => Musteri.fromMap(map)).toList();
  }

Future<int> cariEkle(Musteri musteri) async {
  final db = await _database;

  final id = await db.insert(
    'Cari',
    musteri.toMap(),
    conflictAlgorithm: ConflictAlgorithm.replace,
  );

  return id;
}

  Future<void> cariGuncelle(Musteri musteri) async {
    final db = await _database;
    await db.update(
      'Cari',
      musteri.toMap(),
      where: 'id = ?',
      whereArgs: [musteri.id],
    );
  }

  Future<void> cariSil(int id) async {
    final db = await _database;
    await db.delete('Cari', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Musteri>> musteriAra(String arama) async {
    final db = await _database;
    final maps = await db.query(
      'Cari',
      where: 'unvan LIKE ?',
      whereArgs: ['%$arama%'],
      orderBy: 'unvan ASC',
    );
    return maps.map((map) => Musteri.fromMap(map)).toList();
  }

  Future<Musteri?> musteriGetirById(int id) async {
    final db = await _database;
    final maps = await db.query('Cari', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) {
      return Musteri.fromMap(maps.first);
    }
    return null;
  }

  Future<void> cariBakiyeGuncelle(int cariId, double yeniBakiye) async {
    final db = await _database;
    await db.update(
      'Cari',
      {'bakiye': yeniBakiye},
      where: 'id = ?',
      whereArgs: [cariId],
    );
  }
  
  // Tüm carileri getirmek için yeni metod (gerekirse)
  Future<List<Musteri>> tumCarileriGetir() async {
    final db = await _database;
    final maps = await db.query('Cari', orderBy: 'unvan ASC');
    return maps.map((map) => Musteri.fromMap(map)).toList();
  }
}