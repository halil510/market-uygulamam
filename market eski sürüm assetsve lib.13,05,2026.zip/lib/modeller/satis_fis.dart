class SatisFis {
  final int id;
  final String fisNo;
  final DateTime tarih;
  final int cariId;
  final double toplamTutar;
  final double iskontoTutar;
  final double kdvTutar;
  final double genelToplam;
  final String odemeTipi;
  final String? aciklama;

  SatisFis({
    required this.id,
    required this.fisNo,
    required this.tarih,
    required this.cariId,
    required this.toplamTutar,
    required this.iskontoTutar,
    required this.kdvTutar,
    required this.genelToplam,
    required this.odemeTipi,
    this.aciklama,
  });
}