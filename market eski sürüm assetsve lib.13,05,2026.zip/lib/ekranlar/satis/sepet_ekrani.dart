import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/urun.dart';

class SepetEkrani extends StatelessWidget {
  final List<Urun> sepetUrunleri = []; // Sepet verileri

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sepet')),
      body: ListView.builder(
        itemCount: sepetUrunleri.length,
        itemBuilder: (context, index) {
          final urun = sepetUrunleri[index];
          return ListTile(
            title: Text(urun.ad),
            subtitle: Text('${urun.satisFiyat} ₺ x ${1}'),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {}, // Ürünü sepetten çıkar
            ),
          );
        },
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(16),
        child: ElevatedButton(
          onPressed: () {}, // Ödemeye geç
          child: Text('Ödemeye Geç - Toplam: 0 ₺'),
        ),
      ),
    );
  }
}