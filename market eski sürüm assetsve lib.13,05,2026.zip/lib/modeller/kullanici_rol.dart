enum KullaniciRol { admin, personel }

extension KullaniciRolExtension on KullaniciRol {
  String get displayName {
    switch (this) {
      case KullaniciRol.admin: return 'Yönetici';
      case KullaniciRol.personel: return 'Personel';
    }
  }
  
  bool get yetkiliStokSilme => this == KullaniciRol.admin;
  bool get yetkiliFiyatDegistirme => this == KullaniciRol.admin;
  bool get yetkiliRaporGoruntuleme => this == KullaniciRol.admin;
  bool get yetkiliCariSilme => this == KullaniciRol.admin;
  bool get yetkiliVeriYedekleme => this == KullaniciRol.admin;
  bool get yetkiliAyarlaraErisim => this == KullaniciRol.admin;
}