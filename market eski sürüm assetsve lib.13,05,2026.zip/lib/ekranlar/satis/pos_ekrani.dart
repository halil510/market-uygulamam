import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/modeller/satis_kalem.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/satis_repo.dart';
import 'package:market_uygulamasi/servisler/satis_servisi.dart';
import 'package:market_uygulamasi/yardimci/yardimci_fonksiyonlar.dart';

class PosEkrani extends StatefulWidget {
  @override
  _PosEkraniState createState() => _PosEkraniState();
}

class _PosEkraniState extends State<PosEkrani> {
  final SatisServisi _satisServisi = SatisServisi();
  List<SatisKalem> _sepet = [];
  double _toplamTutar = 0.0;
  String _odemeYontemi = 'Nakit';
  String _musteriAdi = '';
  bool _fisYazdir = true;

  void _urunEkle(Urun urun) {
    setState(() {
      final index = _sepet.indexWhere((kalem) => kalem.urunId == urun.id.toString());
      
      if (index != -1) {
        _sepet[index] = SatisKalem(
          id: _sepet[index].id,
          satisId: _sepet[index].satisId,
          urunId: urun.id ?? 0,
          urunAdi: urun.ad,
          miktar: _sepet[index].miktar + 1,
          birimFiyat: urun.satisFiyat,
          indirimOrani: 0.0,
          toplamTutar: (_sepet[index].miktar + 1) * urun.satisFiyat,
          kdvliFiyat: urun.satisFiyat, // Varsayılan değer
          kdvliTutar: (_sepet[index].miktar + 1) * urun.satisFiyat, // Varsayılan değer
        );
      } else {
        _sepet.add(SatisKalem(
          id: DateTime.now().millisecondsSinceEpoch,
          satisId: -1,
          urunId: urun.id ?? 0,
          urunAdi: urun.ad,
          miktar: 1,
          birimFiyat: urun.satisFiyat,
          indirimOrani: 0.0,
          toplamTutar: urun.satisFiyat,
          kdvliFiyat: urun.satisFiyat, // Varsayılan değer
          kdvliTutar: urun.satisFiyat, // Varsayılan değer
        ));
      }
      
      _toplamTutarHesapla();
    });
  }

  void _toplamTutarHesapla() {
    _toplamTutar = 0.0;
    for (var kalem in _sepet) {
      _toplamTutar += kalem.toplamTutar;
    }
  }

  Future<void> _satisiTamamla() async {
    if (_sepet.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sepetiniz boş')),
      );
      return;
    }
    
    final satis = Satis(
  id: DateTime.now().millisecondsSinceEpoch,
  tarih: DateTime.now(),
  cariId: null, // ya da uygun cariId, eğer müşteri seçiliyorsa int tipinde
  toplamTutar: _toplamTutar,
  odenenTutar: _toplamTutar,
  odemeYontemi: _odemeYontemi,
  kalemler: _sepet,
 fisTipi: 'Satış', // Burada 'Satış' gibi bir değer verebilirsiniz.
);

    
    try {
      await _satisServisi.satisYap(satis, _sepet);
      
      if (_fisYazdir) {
        // Yazdırma işlemi
      }
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Satış tamamlandı: ${YardimciFonksiyonlar.paraFormatla(_toplamTutar)}')
        ),
      );
      
      setState(() {
        _sepet.clear();
        _toplamTutar = 0.0;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Satış hatası: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('POS Ekranı')),
      body: Column(
        children: [
          // Müşteri ve ödeme bilgileri
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(
                      labelText: 'Müşteri Adı',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (value) => _musteriAdi = value,
                  ),
                ),
                const SizedBox(width: 10),
                DropdownButton<String>(
                  value: _odemeYontemi,
                  items: ['Nakit', 'Kredi Kartı', 'Havale'].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) => setState(() => _odemeYontemi = value!),
                ),
              ],
            ),
          ),
          
          // Sepet listesi
          Expanded(
            child: ListView.builder(
              itemCount: _sepet.length,
              itemBuilder: (context, index) {
                final kalem = _sepet[index];
                return ListTile(
                  title: Text(kalem.urunAdi),
                  subtitle: Text('${kalem.miktar} x ${YardimciFonksiyonlar.paraFormatla(kalem.birimFiyat)}'),
                  trailing: Text(
                    YardimciFonksiyonlar.paraFormatla(kalem.toplamTutar),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                );
              },
            ),
          ),
          
          // Toplam ve butonlar
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.grey[200],
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('TOPLAM:', style: TextStyle(fontSize: 20)),
                    Text(
                      YardimciFonksiyonlar.paraFormatla(_toplamTutar),
                      style: const TextStyle(
                        fontSize: 20, 
                        fontWeight: FontWeight.bold
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Checkbox(
                      value: _fisYazdir,
                      onChanged: (value) => setState(() => _fisYazdir = value!),
                    ),
                    const Text('Fiş Yazdır'),
                    const Spacer(),
                    ElevatedButton(
                      onPressed: _satisiTamamla,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 30, 
                          vertical: 15
                        ),
                      ),
                      child: const Text('SATIŞI TAMAMLA'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}