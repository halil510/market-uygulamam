import 'package:flutter/material.dart';
import 'package:market_uygulamasi/servisler/auth_servisi.dart';

class RolKorumaliWidget extends StatelessWidget {
  final Widget child;
  final bool Function()? yetkiKontrol;
  final Widget? yetkisizWidget;

  const RolKorumaliWidget({
    Key? key,
    required this.child,
    this.yetkiKontrol,
    this.yetkisizWidget,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final yetkili = yetkiKontrol?.call() ?? AuthServisi().isAdmin;
    if (yetkili) return child;
    return yetkisizWidget ?? const SizedBox.shrink();
  }
}