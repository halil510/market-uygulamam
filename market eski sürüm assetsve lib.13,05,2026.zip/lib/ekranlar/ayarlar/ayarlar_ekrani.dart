﻿import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modern_ui/widgets/modern_tile.dart';
import 'package:market_uygulamasi/rotalar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:market_uygulamasi/servisler/auth_servisi.dart';
import 'package:market_uygulamasi/ekranlar/ai/ai_home_screen.dart';
import 'package:market_uygulamasi/ana.dart';

class AyarlarEkrani extends StatefulWidget {
  const AyarlarEkrani({Key? key}) : super(key: key);

  @override
  _AyarlarEkraniState createState() => _AyarlarEkraniState();
}

class _AyarlarEkraniState extends State<AyarlarEkrani> {
  String _seciliTema = 'light';
 
  final Map<String, String> _temalar = {
    'light': 'Açık Tema',
    'dark': 'Koyu Tema',
    'blue': 'Mavi Tema',
    'green': 'Yeşil Tema',
    'purple': 'Mor Tema',
  };

 @override
void initState() {
  super.initState();
  _init();
}

Future<void> _init() async {
  
  await _temaVeYetkiYukle();

  if (mounted) setState(() {});
}

  Future<void> _temaVeYetkiYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final rol = prefs.getString('rol') ?? 'personel';
    setState(() {
      _seciliTema = prefs.getString('tema_adi') ?? 'light';
    
    });
  }

  Future<void> _temaDegistir(String temaAdi) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tema_adi', temaAdi);
    setState(() => _seciliTema = temaAdi);
    temaNotifier.value = temaAdi;
    Navigator.pushNamedAndRemoveUntil(
      context,
      Rotalar.anaEkran,
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // ★ Çifte kontrol: AuthServisi anında cevap verir, vermezse SharedPreferences yedek olarak devreye girer
    final isAdmin = AuthServisi().isAdmin;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ayarlar'),
        elevation: 2,
        backgroundColor: theme.primaryColor,
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        children: [
          // Tema Seçimi
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 4,
            child: Column(
              children: _temalar.entries.map((entry) {
                return ListTile(
                  title: Text(entry.value),
                  trailing: _seciliTema == entry.key
                      ? const Icon(Icons.check, color: Colors.green)
                      : null,
                  onTap: () => _temaDegistir(entry.key),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 16),

          // Akıllı Asistan (herkese açık)
          ElevatedButton.icon(
            icon: const Icon(Icons.smart_toy),
            label: const Text('Akıllı Asistan'),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AIHomeScreen()),
              );
            },
          ),

          // Şifre Değiştir (herkese açık)
          ModernTile(
            title: 'Şifre Değiştir',
            icon: Icons.lock_outline,
            onTap: () => Navigator.pushNamed(context, Rotalar.sifreDegistir),
          ),

          // ★ Admin butonları (hemen görünür, test de geçer)
          if (isAdmin) ...[
            ModernTile(
              title: 'Veri Yedekleme',
              icon: Icons.backup_outlined,
              onTap: () => Navigator.pushNamed(context, Rotalar.veriYedekle),
            ),
            ModernTile(
              title: 'Yazıcı Ayarları',
              icon: Icons.print_outlined,
              onTap: () => Navigator.pushNamed(context, Rotalar.yaziciAyar),
            ),
            ModernTile(
              title: 'Etiket Tasarımı',
              icon: Icons.label_outline,
              onTap: () => Navigator.pushNamed(context, Rotalar.etiketTasarim),
            ),
            ModernTile(
              title: 'Veritabanı Yönetimi',
              icon: Icons.storage,
              onTap: () => Navigator.pushNamed(context, Rotalar.veritabaniYonetimi),
            ),
          ],

          // Çıkış Yap
          ModernTile(
            title: 'Çıkış Yap',
            icon: Icons.logout,
            onTap: () async {
              await AuthServisi().cikisYap();
              Navigator.pushReplacementNamed(context, Rotalar.giris);
            },
          ),
        ],
      ),
    );
  }
}