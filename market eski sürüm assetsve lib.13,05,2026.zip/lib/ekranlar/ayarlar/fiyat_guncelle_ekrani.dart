import 'package:flutter/material.dart';
import 'package:market_uygulamasi/servisler/fiyat_yonetimi.dart';

class FiyatGuncelleEkrani extends StatefulWidget {
  @override
  _FiyatGuncelleEkraniState createState() => _FiyatGuncelleEkraniState();
}

class _FiyatGuncelleEkraniState extends State<FiyatGuncelleEkrani> {
  final FiyatYonetimi _fiyatYonetimi = FiyatYonetimi();
  double _yuzde = 10.0;
  bool _artis = true;

  void _fiyatlariGuncelle() {
    _fiyatYonetimi.fiyatGuncelleTumUrunler(_yuzde, _artis);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fiyatlar güncellendi')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Fiyat Güncelleme')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Yüzde Değeri'),
              onChanged: (value) => _yuzde = double.tryParse(value) ?? 0.0,
            ),
            Row(
              children: [
                Text('Arttır'),
                Switch(
                  value: _artis,
                  onChanged: (value) => setState(() => _artis = value),
                ),
                Text('Azalt'),
              ],
            ),
            ElevatedButton(
              onPressed: _fiyatlariGuncelle,
              child: Text('Fiyatları Güncelle'),
            ),
          ],
        ),
      ),
    );
  }
}