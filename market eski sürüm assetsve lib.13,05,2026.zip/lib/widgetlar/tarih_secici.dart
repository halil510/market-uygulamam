import 'package:flutter/material.dart';

class TarihSecici extends StatefulWidget {
  const TarihSecici({Key? key, required this.onTarihSecildi}) : super(key: key);

  final Function(DateTime, DateTime) onTarihSecildi;

  @override
  _TarihSeciciState createState() => _TarihSeciciState();
}

class _TarihSeciciState extends State<TarihSecici> {
  DateTime _baslangicTarihi = DateTime.now();
  DateTime _bitisTarihi = DateTime.now();

  Future<void> _tarihSec(BuildContext context, bool isStart) async {
    final initial = isStart ? _baslangicTarihi : _bitisTarihi;
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          _baslangicTarihi = picked;
          if (_baslangicTarihi.isAfter(_bitisTarihi)) {
            _bitisTarihi = _baslangicTarihi;
          }
        } else {
          _bitisTarihi = picked;
          if (_bitisTarihi.isBefore(_baslangicTarihi)) {
            _baslangicTarihi = _bitisTarihi;
          }
        }
      });
      widget.onTarihSecildi(_baslangicTarihi, _bitisTarihi);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextButton(
            onPressed: () => _tarihSec(context, true),
            child: Text('Başlangıç: ${_baslangicTarihi.day}/${_baslangicTarihi.month}/${_baslangicTarihi.year}'),
          ),
        ),
        Text('-'),
        Expanded(
          child: TextButton(
            onPressed: () => _tarihSec(context, false),
            child: Text('Bitiş: ${_bitisTarihi.day}/${_bitisTarihi.month}/${_bitisTarihi.year}'),
          ),
        ),
      ],
    );
  }
}
