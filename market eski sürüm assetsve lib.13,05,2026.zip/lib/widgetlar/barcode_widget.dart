import 'package:flutter/material.dart';
import 'package:barcode_widget/barcode_widget.dart' as bw;

class BarcodeWidget extends StatelessWidget {
  const BarcodeWidget({
    Key? key,
    required this.barkod,
    this.width = 200,
    this.height = 100,
    this.fontSize = 16,
    this.drawNumber = true,
  }) : super(key: key);

  final String barkod;
  final double width;
  final double height;
  final double fontSize;
  final bool drawNumber;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height + (drawNumber ? fontSize + 8 : 0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: width,
            height: height,
            child: bw.BarcodeWidget(
              data: barkod,
              barcode: bw.Barcode.code128(),
              drawText: false,
            ),
          ),
          if (drawNumber) SizedBox(height: 4),
          if (drawNumber)
            Text(
              barkod,
              style: TextStyle(
                fontSize: fontSize,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
        ],
      ),
    );
  }
}
