import 'dart:math';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/modeller/musteri.dart';
import 'package:market_uygulamasi/modeller/satis_kalem.dart';
import 'package:market_uygulamasi/repozitory/satis_repo.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/servisler/log_servisi.dart';
import 'package:intl/intl.dart';

// ================= AI CONTEXT =================
class AIContext {
  String? sonUrun;
  String? sonMusteri;
  String? sonKategori;
  Intent? sonIntent;
}

final AIContext _context = AIContext();

enum Intent {
  stokDurumu,
  stokSorgula,
  satisRaporu,
  enCokSatan,
  karMarji,
  musteriAnalizi,
  musteriBorc,
  tahmin,
  oneri,
  genelOzet,
  urunAra,
  urunListele,
  grafikIstegi,
  sohbet,
  cariListele,
  cariHareketleri,
  stokHareketleri,
  iadeKayitlari,
  yaziciDurumu,
  raporListele,
  enKarliUrun,
  stokGirisCikis,
  favoriMusteri,
  gunlukOzet,
  kategoriAnaliz,
  markaAnaliz,
  fiyatGecmisi,
  stokDeger,
  kasaDurumu,
  odemeYontemiDagilim,
  kazancim, // YENİ
  tanimama,
}

class ExtractedEntities {
  DateTime? tarih;
  DateTime? tarihBitis;
  String? urunAdi;
  String? musteriAdi;
  double? sayi;
  String? zamanPeriyodu;
  String? kategori;
  String? marka;
  String? karsilastirma;
  double? fiyatMin;
  double? fiyatMax;
  bool grafikIsteniyor = false;

  String? cariTipi;
  String? hareketTipi;
  String? bakiyeDurumu;
  int? limit;
  String? yaziciTipi;
  String? yaziciKategori;
  
  String? odemeYontemi;
  String? siralamaYonu;
  String? karsilastirmaOp;
  bool detayliIsteniyor = false;

  List<String> urunler = []; // Çoklu ürün desteği

  bool get hasTarih => tarih != null || zamanPeriyodu != null;
}

class AdvancedAI {
  final VeritabaniYardimcisi _dbHelper = VeritabaniYardimcisi();
  final SatisRepository _satisRepo = SatisRepository();
  final UrunRepoSitory _urunRepo = UrunRepoSitory();

  List<Map<String, dynamic>> _urunlerCache = [];
  List<Map<String, dynamic>> _musterilerCache = [];
  List<Map<String, dynamic>> _tedarikcilerCache = [];
  bool _cacheLoaded = false;
  DateTime _cacheTime = DateTime.now();
  static const Duration _cacheDuration = Duration(minutes: 5);

  Future<void> _loadCache({bool force = false}) async {
    if (_cacheLoaded && !force && DateTime.now().difference(_cacheTime) < _cacheDuration) return;
    try {
      final db = await _dbHelper.db;
      _urunlerCache = await db.query('urunler');
      _musterilerCache = await db.query('Cari', where: 'cari_tipi = ?', whereArgs: ['Müşteri']);
      _tedarikcilerCache = await db.query('Cari', where: 'cari_tipi = ?', whereArgs: ['Tedarikçi']);
      _cacheLoaded = true;
      _cacheTime = DateTime.now();
    } catch (e, s) {
      Log.e('Önbellek yüklenemedi', tag: 'AdvancedAI', error: e, stackTrace: s);
    }
  }

  static double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  static int? _toInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }

  static String _toString(dynamic value) => value?.toString() ?? '';

  Future<Map<String, dynamic>> analizEt() async {
    try {
      final db = await _dbHelper.db;
      final urunlerMap = await db.query('urunler');
      final urunler = urunlerMap.map((m) => Urun.fromMap(m)).toList();
      final satislar = await _tumSatislariGetir(db);
      final musteriler = await _tumMusterileriGetir(db);
      final enCokSatanlar = _enCokSatanUrunler(satislar, urunler);
      final stokAnalizi = _stokAnalizi(urunler);
      final karMarjAnalizi = _karMarjAnalizi(urunler);
      final musteriAnalizi = await _musteriAnalizi(satislar, musteriler, db);
      final zamanSerisi = _zamanSerisiAnalizi(satislar);
      final kategoriSatis = await _kategoriSatisAnalizi(satislar);
      final markaSatis = await _markaSatisAnalizi(satislar);
      final odemeYontemiDagilim = _odemeYontemiDagilim(satislar);
      final toplamStokDeger = _toplamStokDeger(urunler);
      return {
        'enCokSatanlar': enCokSatanlar,
        'stokAnalizi': stokAnalizi,
        'karMarjAnalizi': karMarjAnalizi,
        'musteriAnalizi': musteriAnalizi,
        'zamanSerisi': zamanSerisi,
        'toplamUrun': urunler.length,
        'toplamMusteri': musteriler.length,
        'toplamSatisAdedi': satislar.length,
        'urunler': urunler.map((u) => u.toMap()).toList(),
        'kategoriSatis': kategoriSatis,
        'markaSatis': markaSatis,
        'odemeYontemiDagilim': odemeYontemiDagilim,
        'toplamStokDeger': toplamStokDeger,
      };
    } catch (e, s) {
      Log.e('AI analiz hatası', tag: 'AdvancedAI', error: e, stackTrace: s);
      return {'hata': e.toString()};
    }
  }

  Future<Map<String, double>> _kategoriSatisAnalizi(List<Satis> satislar) async {
    final Map<String, double> kategoriToplam = {};
    for (var satis in satislar) {
      for (var kalem in satis.kalemler) {
        final urun = await _urunRepo.idyeGoreUrunGetir(kalem.urunId);
        final kategori = urun?.anagrup ?? 'Diğer';
        kategoriToplam[kategori] = (kategoriToplam[kategori] ?? 0) + kalem.toplamTutar;
      }
    }
    return kategoriToplam;
  }

  Future<Map<String, double>> _markaSatisAnalizi(List<Satis> satislar) async {
    final Map<String, double> markaToplam = {};
    for (var satis in satislar) {
      for (var kalem in satis.kalemler) {
        final urun = await _urunRepo.idyeGoreUrunGetir(kalem.urunId);
        final marka = urun?.marka ?? 'Diğer';
        markaToplam[marka] = (markaToplam[marka] ?? 0) + kalem.toplamTutar;
      }
    }
    return markaToplam;
  }

  Map<String, double> _odemeYontemiDagilim(List<Satis> satislar) {
    final Map<String, double> odemeMap = {};
    for (var satis in satislar) {
      odemeMap[satis.odemeYontemi] = (odemeMap[satis.odemeYontemi] ?? 0) + satis.toplamTutar;
    }
    return odemeMap;
  }

  double _toplamStokDeger(List<Urun> urunler) {
    double toplam = 0;
    for (var urun in urunler) {
      toplam += (urun.stokMiktari ?? 0) * (urun.alisFiyat ?? 0);
    }
    return toplam;
  }

  Future<String> soruyuCoz(String soru) async {
    await _loadCache();
    final analiz = await analizEt();
    if (analiz.containsKey('hata')) {
      return 'Üzgünüm, bir hata oluştu: ${analiz['hata']}';
    }
    final (intent, entities) = _anlas(soru);
    if (entities.grafikIsteniyor) return 'CHART:gunluk';
    switch (intent) {
      case Intent.stokDurumu: return _cevaplaStokDurumu(analiz, entities);
      case Intent.stokSorgula: return await _cevaplaStokSorgula(entities);
      case Intent.satisRaporu: return await _cevaplaSatisRaporu(analiz, entities);
      case Intent.enCokSatan: return _cevaplaEnCokSatan(analiz, entities);
      case Intent.karMarji: return _cevaplaKarMarji(analiz, entities);
      case Intent.musteriAnalizi: return await _cevaplaMusteriAnalizi(analiz, entities);
      case Intent.musteriBorc: return await _cevaplaMusteriBorc(entities);
      case Intent.tahmin: return await _cevaplaTahmin(entities);
      case Intent.oneri: return await _cevaplaOneri(analiz);
      case Intent.genelOzet: return _genelOzet(analiz);
      case Intent.urunAra: return await _cevaplaUrunAra(entities);
      case Intent.urunListele: return await _cevaplaUrunListele(entities, analiz);
      case Intent.grafikIstegi: return 'CHART:gunluk';
      case Intent.sohbet: return _sohbetCevap(soru);
      case Intent.cariListele: return await _cevaplaCariListele(entities);
      case Intent.cariHareketleri: return await _cevaplaCariHareketleri(entities);
      case Intent.stokHareketleri: return await _cevaplaStokHareketleri(entities);
      case Intent.iadeKayitlari: return await _cevaplaIadeKayitlari(entities);
      case Intent.yaziciDurumu: return await _cevaplaYaziciDurumu(entities);
      case Intent.raporListele: return await _cevaplaRaporListele(entities);
      case Intent.enKarliUrun: return _cevaplaEnKarliUrun(analiz);
      case Intent.stokGirisCikis: return await _cevaplaStokGirisCikis(entities);
      case Intent.favoriMusteri: return _cevaplaFavoriMusteri(analiz, entities);
      case Intent.gunlukOzet: return await _cevaplaGunlukOzet(entities);
      case Intent.kategoriAnaliz: return await _cevaplaKategoriAnaliz(entities, analiz);
      case Intent.markaAnaliz: return await _cevaplaMarkaAnaliz(entities, analiz);
      case Intent.fiyatGecmisi: return await _cevaplaFiyatGecmisi(entities);
      case Intent.stokDeger: return _cevaplaStokDeger(analiz);
      case Intent.kasaDurumu: return await _cevaplaKasaDurumu(entities);
      case Intent.odemeYontemiDagilim: return _cevaplaOdemeYontemiDagilim(analiz, entities);
      case Intent.kazancim: return await _cevaplaKazancim(entities); // YENİ
      default: return _varsayilanCevap();
    }
  }

  Future<Map<String, dynamic>> tahminEt({int gunSayisi = 7, String? urunAdi}) async {
    try {
      final db = await _dbHelper.db;
      final satislar = await _tumSatislariGetir(db);
      List<Satis> filtrelenmisSatislar = satislar;
      if (urunAdi != null && urunAdi.isNotEmpty) {
        final urun = await _urunRepo.barkodlaUrunGetir(urunAdi);
        if (urun != null) {
          filtrelenmisSatislar = satislar.where((s) => s.kalemler.any((k) => k.urunId == urun.id)).toList();
        }
      }
      final bugun = DateTime.now();
      final otuzGunOnce = bugun.subtract(const Duration(days: 30));
      final son30Gun = filtrelenmisSatislar.where((s) => s.tarih.isAfter(otuzGunOnce)).toList();
      final Map<String, double> gunlukToplam = {};
      for (var satis in son30Gun) {
        final gun = DateFormat('yyyy-MM-dd').format(satis.tarih);
        gunlukToplam[gun] = (gunlukToplam[gun] ?? 0) + satis.toplamTutar;
      }
      if (gunlukToplam.isEmpty) return {};
      final degerler = gunlukToplam.values.toList();
      final ortalama = degerler.reduce((a, b) => a + b) / degerler.length;
      final trend = _trendHesapla(degerler);
      final tahminler = <double>[];
      for (int i = 0; i < gunSayisi; i++) {
        tahminler.add(ortalama + trend * (i + 1));
      }
      return {
        'ortalama': ortalama,
        'trend': trend,
        'tahminler': tahminler,
        'gunSayisi': gunSayisi,
      };
    } catch (e, s) {
      Log.e('Tahmin hatası', tag: 'AdvancedAI', error: e, stackTrace: s);
      return {};
    }
  }

  Future<List<Map<String, dynamic>>> siparisOnerileri() async {
    try {
      final db = await _dbHelper.db;
      final urunlerMap = await db.query('urunler');
      final urunler = urunlerMap.map((m) => Urun.fromMap(m)).toList();

      final yediGunOnce = DateTime.now().subtract(const Duration(days: 7));
      final satislar = await _tumSatislariGetir(db);
      final Map<int, double> sonHaftaSatisMiktar = {};
      for (var satis in satislar) {
        if (satis.tarih.isAfter(yediGunOnce)) {
          for (var kalem in satis.kalemler) {
            sonHaftaSatisMiktar[kalem.urunId] =
                (sonHaftaSatisMiktar[kalem.urunId] ?? 0) + kalem.miktar;
          }
        }
      }

      final oneriler = <Map<String, dynamic>>[];
      for (var urun in urunler) {
        final stok = urun.stokMiktari ?? 0;
        final satisHizi = sonHaftaSatisMiktar[urun.id] ?? 0.0;
        final karMarji = ((urun.satisFiyat - (urun.alisFiyat ?? 0)) / (urun.alisFiyat ?? 1)) * 100;

        if (stok < 5 && satisHizi > 10) {
          oneriler.add({
            'urunAdi': urun.ad,
            'mevcutStok': stok,
            'onerilenSiparis': (satisHizi * 2).ceil(),
            'neden': '🔥 Acil sipariş (yüksek satış hızı)',
            'oncelik': 1,
          });
        } else if (stok < 5) {
          oneriler.add({
            'urunAdi': urun.ad,
            'mevcutStok': stok,
            'onerilenSiparis': 10 - stok,
            'neden': 'Kritik stok',
            'oncelik': 2,
          });
        } else if (karMarji < 5 && karMarji > 0) {
          oneriler.add({
            'urunAdi': urun.ad,
            'mevcutStok': stok,
            'onerilenSiparis': 0,
            'neden': '⚠️ Kâr marjı çok düşük (%${karMarji.toStringAsFixed(1)})',
            'oncelik': 3,
          });
        }
      }

      oneriler.sort((a, b) => (a['oncelik'] as int).compareTo(b['oncelik'] as int));
      return oneriler;
    } catch (e, s) {
      Log.e('Sipariş önerileri hatası', tag: 'AdvancedAI', error: e, stackTrace: s);
      return [];
    }
  }

  Future<List<Satis>> _tumSatislariGetir(database) async {
    try {
      final satislarMap = await database.query('satislar', orderBy: 'tarih DESC');
      final satislar = <Satis>[];
      for (var s in satislarMap) {
        final kalemlerMap = await database.query('satis_detay', where: 'satisId = ?', whereArgs: [s['id']]);
        final kalemler = kalemlerMap.map<SatisKalem>((k) {
          return SatisKalem(
            id: _toInt(k['id']),
            satisId: _toInt(k['satisId']),
            urunId: _toInt(k['urunId']) ?? 0,
            urunAdi: k['urunAdi']?.toString() ?? '',
            miktar: _toDouble(k['miktar']) ?? 0.0,
            birimFiyat: _toDouble(k['birimFiyat']) ?? 0.0,
            indirimOrani: _toDouble(k['indirimOrani']) ?? 0.0,
            toplamTutar: _toDouble(k['toplamTutar']) ?? 0.0,
            kdvliFiyat: _toDouble(k['kdvliFiyat']) ?? 0.0,
            kdvliTutar: _toDouble(k['kdvliTutar']) ?? 0.0,
            urunKodu: k['urunKodu']?.toString(),
            barkod: k['barkod']?.toString(),
          );
        }).toList();
        final satis = Satis(
          id: _toInt(s['id']),
          tarih: DateTime.tryParse(s['tarih']?.toString() ?? '') ?? DateTime.now(),
          cariId: _toInt(s['cariId']),
          toplamTutar: _toDouble(s['toplamTutar']) ?? 0.0,
          odenenTutar: _toDouble(s['odenenTutar']) ?? 0.0,
          odemeYontemi: s['odemeYontemi']?.toString() ?? '',
          kalemler: kalemler,
          fisTipi: s['fisTipi']?.toString() ?? 'Satış',
        );
        satislar.add(satis);
      }
      return satislar;
    } catch (e, s) {
      Log.e('_tumSatislariGetir hatası', tag: 'AdvancedAI', error: e, stackTrace: s);
      return [];
    }
  }

  Future<List<Musteri>> _tumMusterileriGetir(database) async {
    try {
      final maps = await database.query('Cari');
      return maps.map((m) => Musteri.fromMap(m)).toList();
    } catch (e, s) {
      Log.e('_tumMusterileriGetir hatası', tag: 'AdvancedAI', error: e, stackTrace: s);
      return [];
    }
  }

  List<Map<String, dynamic>> _enCokSatanUrunler(List<Satis> satislar, List<Urun> urunler) {
    final Map<int, double> toplamSatis = {};
    for (var s in satislar) {
      for (var k in s.kalemler) {
        toplamSatis[k.urunId] = (toplamSatis[k.urunId] ?? 0) + k.miktar;
      }
    }
    final List<Map<String, dynamic>> liste = [];
    toplamSatis.forEach((urunId, toplam) {
      final urun = urunler.firstWhere(
        (u) => u.id == urunId,
        orElse: () => Urun(ad: 'Bilinmeyen', barkod: '', satisFiyat: 0),
      );
      liste.add({'ad': urun.ad, 'toplam': toplam});
    });
    liste.sort((a, b) => b['toplam'].compareTo(a['toplam']));
    return liste;
  }

  Map<String, dynamic> _stokAnalizi(List<Urun> urunler) {
    final kritik = <Map<String, dynamic>>[];
    final normal = <Map<String, dynamic>>[];
    for (var u in urunler) {
      final stok = u.stokMiktari ?? 0;
      final item = {'ad': u.ad, 'stok': stok};
      if (stok < 5) kritik.add(item);
      else normal.add(item);
    }
    return {'kritik': kritik, 'normal': normal};
  }

  Map<String, dynamic> _karMarjAnalizi(List<Urun> urunler) {
    double toplamKar = 0;
    int sayac = 0;
    Map<String, dynamic> enYuksek = {'ad': '', 'kar': 0.0};
    Map<String, dynamic> enDusuk = {'ad': '', 'kar': double.infinity};
    for (var u in urunler) {
      final alis = u.alisFiyat ?? 0;
      final satis = u.satisFiyat ?? 0;
      if (alis > 0 && satis > 0) {
        final kar = ((satis - alis) / alis) * 100;
        toplamKar += kar;
        sayac++;
        if (kar > enYuksek['kar']) enYuksek = {'ad': u.ad, 'kar': kar};
        if (kar < enDusuk['kar']) enDusuk = {'ad': u.ad, 'kar': kar};
      }
    }
    return {
      'ortalamaKar': sayac > 0 ? toplamKar / sayac : 0,
      'enYuksekKar': enYuksek,
      'enDusukKar': enDusuk,
    };
  }

  Future<Map<String, dynamic>> _musteriAnalizi(List<Satis> satislar, List<Musteri> musteriler, database) async {
    final Map<int, double> musteriHarcama = {};
    for (var s in satislar) {
      if (s.cariId != null) {
        musteriHarcama[s.cariId!] = (musteriHarcama[s.cariId!] ?? 0) + s.toplamTutar;
      }
    }
    final enCokHarcayan = <Map<String, dynamic>>[];
    musteriHarcama.forEach((id, toplam) {
      final musteri = musteriler.firstWhere(
        (m) => m.id == id,
        orElse: () => Musteri(cariKodu: '', unvan: 'Bilinmeyen', bakiye: 0),
      );
      enCokHarcayan.add({'unvan': musteri.unvan, 'toplam': toplam});
    });
    enCokHarcayan.sort((a, b) => b['toplam'].compareTo(a['toplam']));
    return {'enCokHarcayan': enCokHarcayan, 'toplamMusteri': musteriler.length};
  }

  Map<String, dynamic> _zamanSerisiAnalizi(List<Satis> satislar) {
    final bugun = DateTime.now();
    final son30Gun = List.generate(30, (i) => bugun.subtract(Duration(days: i)));
    final gunluk = <Map<String, dynamic>>[];
    for (var gun in son30Gun) {
      final gunStr = DateFormat('yyyy-MM-dd').format(gun);
      final gunSatislari = satislar.where((s) => DateFormat('yyyy-MM-dd').format(s.tarih) == gunStr).toList();
      final toplam = gunSatislari.fold(0.0, (sum, s) => sum + s.toplamTutar);
      gunluk.add({'tarih': gunStr, 'toplam': toplam});
    }
    gunluk.sort((a, b) => a['tarih'].compareTo(b['tarih']));
    return {'gunluk': gunluk};
  }

  double _trendHesapla(List<double> veriler) {
    if (veriler.length < 2) return 0;
    double xOrt = (veriler.length - 1) / 2;
    double yOrt = veriler.reduce((a, b) => a + b) / veriler.length;
    double pay = 0, payda = 0;
    for (int i = 0; i < veriler.length; i++) {
      pay += (i - xOrt) * (veriler[i] - yOrt);
      payda += pow(i - xOrt, 2).toDouble();
    }
    if (payda == 0) return 0;
    return pay / payda;
  }

  String _genelOzet(Map<String, dynamic> analiz) {
    final enCok = analiz['enCokSatanlar'] as List;
    final stok = analiz['stokAnalizi'] as Map;
    final kar = analiz['karMarjAnalizi'] as Map;
    final musteri = analiz['musteriAnalizi'] as Map;
    return '''
📊 **GENEL ÖZET**
• Toplam ürün: ${analiz['toplamUrun']}
• Toplam müşteri: ${analiz['toplamMusteri']}
• Toplam satış adedi: ${analiz['toplamSatisAdedi']}
• Kritik stok: ${(stok['kritik'] as List).length} ürün
• Ortalama kâr marjı: %${kar['ortalamaKar'].toStringAsFixed(1)}
• En çok satan: ${enCok.isNotEmpty ? enCok.first['ad'] : 'veri yok'}
• En çok harcayan müşteri: ${musteri['enCokHarcayan'].isNotEmpty ? musteri['enCokHarcayan'].first['unvan'] : 'veri yok'}
''';
  }
  // ==================== NLP VE ENTITY ÇIKARIM ====================
  (Intent, ExtractedEntities) _anlas(String soru) {
    final s = soru.toLowerCase().trim();
    final entities = ExtractedEntities();
    _extractZaman(s, entities);
    _extractSayi(s, entities);
    _extractUrunAdi(s, entities);
    _extractMusteriAdi(s, entities);
    _extractKategoriMarka(s, entities);
    _extractFiyatAraligi(s, entities);
    _extractKarsilastirma(s, entities);
    _extractGrafik(s, entities);
    _extractCariTipi(s, entities);
    _extractHareketTipi(s, entities);
    _extractBakiyeDurumu(s, entities);
    _extractLimit(s, entities);
    _extractYaziciTipi(s, entities);
    _extractOdemeYontemi(s, entities);
    _extractSiralamaYonu(s, entities);
    _extractDetaySeviyesi(s, entities);
    final intent = _siniflandirIntent(s, entities);

    // ===== CONTEXT TAMAMLAMA =====
    _context.sonIntent = intent;
    if (entities.urunAdi != null) {
      _context.sonUrun = entities.urunAdi;
    } else if (_context.sonUrun != null && intent != Intent.tanimama) {
      entities.urunAdi = _context.sonUrun;
      if (!entities.urunler.contains(_context.sonUrun)) {
        entities.urunler.add(_context.sonUrun!);
      }
    }
    if (entities.musteriAdi != null) {
      _context.sonMusteri = entities.musteriAdi;
    } else if (_context.sonMusteri != null && intent != Intent.tanimama) {
      entities.musteriAdi = _context.sonMusteri;
    }

    return (intent, entities);
  }

  void _extractZaman(String s, ExtractedEntities entities) {
    // YENİ: "aylık", "haftalık", "yıllık" gibi kelimeleri yakala (önce bunlar kontrol edilsin)
    if (s.contains('aylık') || s.contains('aylik')) {
      final now = DateTime.now();
      entities.zamanPeriyodu = 'bu ay';
      entities.tarih = DateTime(now.year, now.month, 1);
      return;
    }
    if (s.contains('haftalık') || s.contains('haftalik')) {
      final now = DateTime.now();
      final pazartesi = now.subtract(Duration(days: now.weekday - 1));
      entities.zamanPeriyodu = 'bu hafta';
      entities.tarih = pazartesi;
      return;
    }
    if (s.contains('yıllık') || s.contains('yillik')) {
      final now = DateTime.now();
      entities.zamanPeriyodu = 'bu yıl';
      entities.tarih = DateTime(now.year, 1, 1);
      return;
    }
    // MEVCUT KOD
    final now = DateTime.now();
    final bugun = DateTime(now.year, now.month, now.day);
    if (s.contains('bugün') || s.contains('bugun')) {
      entities.zamanPeriyodu = 'bugün';
      entities.tarih = bugun;
    } else if (s.contains('dün') || s.contains('dun')) {
      entities.zamanPeriyodu = 'dün';
      entities.tarih = bugun.subtract(const Duration(days: 1));
    } else if (s.contains('bu hafta')) {
      entities.zamanPeriyodu = 'bu hafta';
      final pazartesi = bugun.subtract(Duration(days: bugun.weekday - 1));
      entities.tarih = pazartesi;
    } else if (s.contains('bu ay')) {
      entities.zamanPeriyodu = 'bu ay';
      entities.tarih = DateTime(bugun.year, bugun.month, 1);
    } else if (s.contains('bu yıl') || s.contains('bu yil')) {
      entities.zamanPeriyodu = 'bu yıl';
      entities.tarih = DateTime(bugun.year, 1, 1);
    } else if (s.contains('geçen ay') || s.contains('gecen ay')) {
      entities.zamanPeriyodu = 'geçen ay';
      entities.tarih = DateTime(bugun.year, bugun.month - 1, 1);
    } else if (s.contains('geçen hafta') || s.contains('gecen hafta')) {
      entities.zamanPeriyodu = 'geçen hafta';
      entities.tarih = bugun.subtract(Duration(days: 7));
    } else {
      final regexGun = RegExp(r'(\d+)\s*g[üi]n\s*önce');
      final matchGun = regexGun.firstMatch(s);
      if (matchGun != null) {
        final sayi = int.parse(matchGun.group(1)!);
        entities.tarih = bugun.subtract(Duration(days: sayi));
        entities.zamanPeriyodu = '$sayi gün önce';
      } else {
        final regexHafta = RegExp(r'(\d+)\s*hafta\s*önce');
        final matchHafta = regexHafta.firstMatch(s);
        if (matchHafta != null) {
          final sayi = int.parse(matchHafta.group(1)!);
          entities.tarih = bugun.subtract(Duration(days: sayi * 7));
          entities.zamanPeriyodu = '$sayi hafta önce';
        }
      }
    }
  }

  void _extractSayi(String s, ExtractedEntities entities) {
    final regex = RegExp(r'(\d+)(?:\.\d+)?');
    final matches = regex.allMatches(s);
    if (matches.isNotEmpty) {
      entities.sayi = double.parse(matches.first.group(0)!);
    }
  }

  void _extractUrunAdi(String s, ExtractedEntities entities) {
    final tumUrunNesneleri = _urunlerCache.map((map) => Urun.fromMap(map)).toList();
    final tumAdlar = tumUrunNesneleri.map((u) => u.ad).toList();

    for (var ad in tumAdlar) {
      if (ad.isNotEmpty && s.contains(ad.toLowerCase())) {
        if (!entities.urunler.contains(ad)) {
          entities.urunler.add(ad);
        }
      }
    }

    if (entities.urunler.isEmpty) {
      final fuzzyAd = _fuzzyUrunBul(s, tumUrunNesneleri);
      if (fuzzyAd != null) {
        entities.urunler.add(fuzzyAd);
      }
    }

    if (entities.urunler.isNotEmpty) {
      entities.urunAdi = entities.urunler.first;
    }
  }

  String? _fuzzyUrunBul(String input, List<Urun> urunler) {
    int maxSkor = 0;
    String? enIyi;
    final girilen = input.toLowerCase();
    for (var u in urunler) {
      final ad = u.ad.toLowerCase();
      int skor = 0;
      for (var ch in girilen.split('')) {
        if (ad.contains(ch)) skor++;
      }
      skor -= (ad.length - girilen.length).abs() ~/ 2;
      if (skor > maxSkor) {
        maxSkor = skor;
        enIyi = u.ad;
      }
    }
    return maxSkor > 3 ? enIyi : null;
  }

  void _extractMusteriAdi(String s, ExtractedEntities entities) {
    for (var musteri in _musterilerCache) {
      final unvan = musteri['unvan']?.toString() ?? '';
      if (unvan.isNotEmpty && s.contains(unvan.toLowerCase())) {
        entities.musteriAdi = unvan;
        break;
      }
    }
    if (entities.musteriAdi == null) {
      for (var tedarikci in _tedarikcilerCache) {
        final unvan = tedarikci['unvan']?.toString() ?? '';
        if (unvan.isNotEmpty && s.contains(unvan.toLowerCase())) {
          entities.musteriAdi = unvan;
          break;
        }
      }
    }
  }

  void _extractKategoriMarka(String s, ExtractedEntities entities) {
    final kategoriler = <String>{};
    for (var urun in _urunlerCache) {
      if (urun['anagrup'] != null) kategoriler.add(urun['anagrup'].toString());
      if (urun['altGrup'] != null) kategoriler.add(urun['altGrup'].toString());
      if (urun['marka'] != null) kategoriler.add(urun['marka'].toString());
    }
    for (var kat in kategoriler) {
      if (kat.isNotEmpty && s.contains(kat.toLowerCase())) {
        entities.kategori = kat;
        break;
      }
    }
    for (var urun in _urunlerCache) {
      final marka = urun['marka']?.toString() ?? '';
      if (marka.isNotEmpty && s.contains(marka.toLowerCase())) {
        entities.marka = marka;
        break;
      }
    }
  }

  void _extractFiyatAraligi(String s, ExtractedEntities entities) {
    final regexAlt = RegExp(r'(\d+)\s*(?:tl|lira)?\s*(?:alt[ıi]|az|düşük)');
    final regexUst = RegExp(r'(\d+)\s*(?:tl|lira)?\s*(?:üst[üu]|çok|yüksek|pahalı)');
    final matchAlt = regexAlt.firstMatch(s);
    final matchUst = regexUst.firstMatch(s);
    if (matchAlt != null) {
      entities.fiyatMax = double.parse(matchAlt.group(1)!);
    }
    if (matchUst != null) {
      entities.fiyatMin = double.parse(matchUst.group(1)!);
    }
    final regexArasi = RegExp(r'(\d+)\s*(?:ile|-)\s*(\d+)\s*(?:tl|lira)?\s*aras[ıi]');
    final matchArasi = regexArasi.firstMatch(s);
    if (matchArasi != null) {
      entities.fiyatMin = double.parse(matchArasi.group(1)!);
      entities.fiyatMax = double.parse(matchArasi.group(2)!);
    }
  }

  void _extractKarsilastirma(String s, ExtractedEntities entities) {
    if (s.contains('en ucuz') || s.contains('en düşük')) {
      entities.karsilastirma = 'en_ucuz';
    } else if (s.contains('en pahalı') || s.contains('en yüksek')) {
      entities.karsilastirma = 'en_pahali';
    } else if (s.contains('kritik') || s.contains('azalan')) {
      entities.karsilastirma = 'kritik';
    }
  }

  void _extractGrafik(String s, ExtractedEntities entities) {
    if (s.contains('grafik') || (s.contains('göster') && s.contains('satış')) ||
        s.contains('chart') || s.contains('trend')) {
      entities.grafikIsteniyor = true;
    }
  }

  void _extractCariTipi(String s, ExtractedEntities entities) {
    if (s.contains('müşteri') || s.contains('musteri')) {
      entities.cariTipi = 'Müşteri';
    } else if (s.contains('tedarikçi') || s.contains('tedarikci') || s.contains('sağlayıcı')) {
      entities.cariTipi = 'Tedarikçi';
    }
  }

  void _extractHareketTipi(String s, ExtractedEntities entities) {
    if (s.contains('tahsilat') || s.contains('ödeme al')) {
      entities.hareketTipi = 'Tahsilat';
    } else if (s.contains('ödeme') || s.contains('ödeme yap')) {
      entities.hareketTipi = 'Ödeme';
    } else if (s.contains('satış') && s.contains('hareket')) {
      entities.hareketTipi = 'Satış';
    } else if (s.contains('stok giriş') || s.contains('giren')) {
      entities.hareketTipi = 'Giriş';
    } else if (s.contains('stok çıkış') || s.contains('çıkan')) {
      entities.hareketTipi = 'Çıkış';
    } else if (s.contains('sayım')) {
      entities.hareketTipi = 'Sayım';
    }
  }

  void _extractBakiyeDurumu(String s, ExtractedEntities entities) {
    if (s.contains('borçlu') || s.contains('borcu olan')) {
      entities.bakiyeDurumu = 'borçlu';
    } else if (s.contains('alacaklı') || s.contains('alacağı olan')) {
      entities.bakiyeDurumu = 'alacaklı';
    } else if (s.contains('sıfır bakiye') || s.contains('borcu olmayan')) {
      entities.bakiyeDurumu = 'sıfır';
    }
  }

  void _extractLimit(String s, ExtractedEntities entities) {
    final regex = RegExp(r'son (\d+)');
    final match = regex.firstMatch(s);
    if (match != null) {
      entities.limit = int.parse(match.group(1)!);
    } else if (entities.sayi != null) {
      entities.limit = entities.sayi!.toInt();
    }
  }

  void _extractYaziciTipi(String s, ExtractedEntities entities) {
    if (s.contains('bluetooth')) {
      entities.yaziciTipi = 'bluetooth';
    } else if (s.contains('ağ') || s.contains('ethernet') || s.contains('wifi')) {
      entities.yaziciTipi = 'ag';
    }
    if (s.contains('fiş') || s.contains('fis')) {
      entities.yaziciKategori = 'fis';
    } else if (s.contains('etiket')) {
      entities.yaziciKategori = 'etiket';
    }
  }

  void _extractOdemeYontemi(String s, ExtractedEntities entities) {
    if (s.contains('nakit')) entities.odemeYontemi = 'Nakit';
    else if (s.contains('kredi kartı') || s.contains('kredi karti')) entities.odemeYontemi = 'Kredi Kartı';
    else if (s.contains('cari')) entities.odemeYontemi = 'Cari';
  }

  void _extractSiralamaYonu(String s, ExtractedEntities entities) {
    if (s.contains('artan') || s.contains('küçükten büyüğe')) entities.siralamaYonu = 'artan';
    else if (s.contains('azalan') || s.contains('büyükten küçüğe')) entities.siralamaYonu = 'azalan';
  }

  void _extractDetaySeviyesi(String s, ExtractedEntities entities) {
    if (s.contains('detaylı') || s.contains('ayrıntılı')) entities.detayliIsteniyor = true;
  }

  Intent _siniflandirIntent(String s, ExtractedEntities entities) {
    if (s.contains('merhaba') || s.contains('selam') || s.contains('günaydın') ||
        s.contains('iyi günler') || s.contains('nasılsın') || s.contains('naber') ||
        s.contains('teşekkür') || s.contains('sağ ol') || s.contains('görüşürüz')) {
      return Intent.sohbet;
    }
    if (entities.grafikIsteniyor) return Intent.grafikIstegi;

    Map<Intent, int> puanlar = {};

    void puanEkle(Intent intent, int puan) {
      puanlar[intent] = (puanlar[intent] ?? 0) + puan;
    }

    const Map<Intent, List<String>> keywordMap = {
      Intent.stokDurumu: ['kritik stok', 'azalan', 'bitmek', 'kalmamış', 'stok uyarısı'],
      Intent.stokSorgula: ['stok', 'kaç adet', 'stoğu', 'kaldı'],
      Intent.satisRaporu: ['satış', 'satis', 'ciro', 'hasılat', 'gelir', 'toplam', 'rapor'],
      Intent.enCokSatan: ['en çok', 'popüler', 'favori', 'çok satan', 'en çok satan'],
      Intent.karMarji: ['kâr', 'kar', 'marj', 'kazanç', 'kar marjı'],
      Intent.musteriAnalizi: ['müşteri analizi', 'musteri analizi', 'en çok harcayan'],
      Intent.musteriBorc: ['borç', 'alacak', 'bakiye', 'ne kadar borcu', 'hesap durumu'],
      Intent.tahmin: ['tahmin', 'öngörü', 'gelecek', 'olacak', 'tahmini satış'],
      Intent.oneri: ['öneri', 'tavsiye', 'sipariş', 'almalı', 'önerme'],
      Intent.urunAra: ['ara', 'bul', 'ürün ara', 'barkod', 'kodu'],
      Intent.urunListele: ['listele', 'göster', 'liste', 'hepsi', 'tümü', 'kategorisi', 'marka'],
      Intent.cariListele: ['cari', 'cariler', 'müşteri listesi', 'musteri listesi', 'tedarikçi listesi'],
      Intent.cariHareketleri: ['hareket', 'cari hareket', 'tahsilat', 'ödeme', 'cari ekstre'],
      Intent.stokHareketleri: ['stok hareket', 'stok giriş', 'stok çıkış', 'sayım'],
      Intent.iadeKayitlari: ['iade', 'geri gelen', 'iptal'],
      Intent.yaziciDurumu: ['yazıcı', 'yazici', 'printer', 'bluetooth yazıcı'],
      Intent.raporListele: ['rapor', 'kayıtlı rapor', 'gün sonu raporu', 'geçmiş rapor'],
      Intent.enKarliUrun: ['en karlı', 'en yüksek kar', 'karlı ürün', 'hangi ürün daha karlı'],
      Intent.stokGirisCikis: ['stok giriş çıkış', 'stok hareket özeti', 'giren çıkan', 'stok akışı'],
      Intent.favoriMusteri: ['favori müşteri', 'en çok alışveriş', 'en çok harcayan', 'vip müşteri'],
      Intent.gunlukOzet: ['günlük özet', 'bugünkü durum', 'gün sonu', 'rapor ver'],
      Intent.kategoriAnaliz: ['kategori satış', 'kategorilere göre', 'hangi kategoride', 'kategori bazında'],
      Intent.markaAnaliz: ['marka satış', 'markalara göre', 'hangi markada', 'marka bazında'],
      Intent.fiyatGecmisi: ['fiyat geçmişi', 'fiyat değişimi', 'ne kadardı', 'fiyatı neydi'],
      Intent.stokDeger: ['stok değeri', 'toplam stok tutarı', 'stok kaç tl'],
      Intent.kasaDurumu: ['kasa durumu', 'nakit durumu', 'kasa', 'kasada ne kadar'],
      Intent.odemeYontemiDagilim: ['ödeme dağılımı', 'nasıl ödendi', 'ödeme şekli', 'ödeme türü'],
      Intent.kazancim: ['karım', 'kazancım', 'net kar', 'aylık kar', 'haftalık kar', 'yıllık kar', 'kar ne kadar', 'kazanç', 'kâr'],
    };

    for (var entry in keywordMap.entries) {
      for (var kelime in entry.value) {
        if (s.contains(kelime)) {
          puanEkle(entry.key, 3);
        }
      }
    }

    // Ek puanlamalar
    if (s.contains('kar') || s.contains('kazanç') || s.contains('net kar')) {
      puanEkle(Intent.kazancim, 4);
    }
    if ((s.contains('aylık') || s.contains('aylik')) && (s.contains('kar') || s.contains('kazanç'))) {
      puanEkle(Intent.kazancim, 6);
    }
    if ((s.contains('haftalık') || s.contains('haftalik')) && (s.contains('kar') || s.contains('kazanç'))) {
      puanEkle(Intent.kazancim, 6);
    }
    if ((s.contains('yıllık') || s.contains('yillik')) && (s.contains('kar') || s.contains('kazanç'))) {
      puanEkle(Intent.kazancim, 6);
    }

    if (entities.urunAdi != null) {
      if (s.contains('stok') || s.contains('kaç')) puanEkle(Intent.stokSorgula, 5);
      if (s.contains('fiyat') || s.contains('ne kadar')) puanEkle(Intent.urunAra, 5);
    }
    if (entities.musteriAdi != null) {
      if (s.contains('borç') || s.contains('bakiye')) puanEkle(Intent.musteriBorc, 6);
      if (s.contains('hareket')) puanEkle(Intent.cariHareketleri, 6);
    }
    if (entities.kategori != null || entities.marka != null) puanEkle(Intent.urunListele, 4);
    if (entities.fiyatMin != null || entities.fiyatMax != null) puanEkle(Intent.urunListele, 4);
    if (entities.karsilastirma == 'kritik') puanEkle(Intent.stokDurumu, 5);
    if (entities.zamanPeriyodu != null) puanEkle(Intent.satisRaporu, 3);
    if (entities.cariTipi != null) puanEkle(Intent.cariListele, 5);
    if (entities.hareketTipi != null) {
      if (entities.hareketTipi == 'Tahsilat' || entities.hareketTipi == 'Ödeme')
        puanEkle(Intent.cariHareketleri, 6);
      else
        puanEkle(Intent.stokHareketleri, 5);
    }

    if (puanlar.isEmpty) return Intent.genelOzet;
    return puanlar.entries.reduce((a, b) => a.value > b.value ? a : b).key;
  }

  // ==================== CEVAPLAMA METOTLARI ====================
  String _cevaplaStokDurumu(Map<String, dynamic> analiz, ExtractedEntities entities) {
    final stok = analiz['stokAnalizi'] as Map;
    final kritik = stok['kritik'] as List;
    if (kritik.isEmpty) return 'Kritik stokta ürün yok.';
    if (entities.urunAdi != null) {
      final urun = kritik.firstWhere(
        (u) => u['ad'].toString().toLowerCase().contains(entities.urunAdi!.toLowerCase()),
        orElse: () => null,
      );
      if (urun != null) return '${urun['ad']} stokta ${urun['stok']} adet kalmış.';
      else return '${entities.urunAdi} kritik stokta değil veya bulunamadı.';
    }
    if (entities.sayi != null) {
      final esik = entities.sayi!;
      final esikAltindakiler = kritik.where((u) => u['stok'] < esik).toList();
      if (esikAltindakiler.isEmpty) return '$esik adet altında stok yok.';
      return '$esik adet altındaki ürünler:\n${esikAltindakiler.map((u) => '• ${u['ad']} (${u['stok']} adet)').join('\n')}';
    }
    return 'Kritik stok (5 adet altı):\n${kritik.take(5).map((u) => '• ${u['ad']} (${u['stok']} adet)').join('\n')}';
  }

  Future<String> _cevaplaStokSorgula(ExtractedEntities entities) async {
    if (entities.urunAdi == null) return 'Hangi ürünün stoğunu öğrenmek istersiniz?';
    try {
      final db = await _dbHelper.db;
      final result = await db.query('urunler', where: 'ad LIKE ?', whereArgs: ['%${entities.urunAdi}%']);
      if (result.isEmpty) return '${entities.urunAdi} adlı ürün bulunamadı.';
      final urun = Urun.fromMap(result.first);
      return '${urun.ad} stoğu: ${urun.stokMiktari ?? 0} adet.';
    } catch (e, s) {
      Log.e('Stok sorgulama hatası', error: e, stackTrace: s);
      return 'Stok bilgisi alınırken hata oluştu.';
    }
  }

  Future<String> _cevaplaSatisRaporu(Map<String, dynamic> analiz, ExtractedEntities entities) async {
    DateTime baslangic, bitis;
    if (entities.tarih != null) {
      if (entities.zamanPeriyodu == 'bugün' || entities.zamanPeriyodu == 'dün') {
        baslangic = DateTime(entities.tarih!.year, entities.tarih!.month, entities.tarih!.day);
        bitis = baslangic.add(const Duration(days: 1)).subtract(const Duration(seconds: 1));
      } else if (entities.zamanPeriyodu == 'bu hafta') {
        baslangic = entities.tarih!;
        bitis = baslangic.add(const Duration(days: 6, hours: 23, minutes: 59, seconds: 59));
      } else if (entities.zamanPeriyodu == 'bu ay') {
        baslangic = entities.tarih!;
        bitis = DateTime(baslangic.year, baslangic.month + 1, 0, 23, 59, 59);
      } else if (entities.zamanPeriyodu == 'bu yıl') {
        baslangic = entities.tarih!;
        bitis = DateTime(baslangic.year, 12, 31, 23, 59, 59);
      } else if (entities.zamanPeriyodu == 'geçen ay') {
        baslangic = entities.tarih!;
        bitis = DateTime(baslangic.year, baslangic.month + 1, 0, 23, 59, 59);
      } else if (entities.zamanPeriyodu == 'geçen hafta') {
        baslangic = entities.tarih!;
        bitis = baslangic.add(const Duration(days: 6, hours: 23, minutes: 59, seconds: 59));
      } else {
        baslangic = entities.tarih!;
        bitis = baslangic.add(const Duration(days: 1)).subtract(const Duration(seconds: 1));
      }
    } else {
      final bugun = DateTime.now();
      baslangic = DateTime(bugun.year, bugun.month, bugun.day);
      bitis = baslangic.add(const Duration(days: 1)).subtract(const Duration(seconds: 1));
    }
    final satislar = await _satisRepo.tariheGoreSatislariGetir(baslangic, bitis);
    final toplam = satislar.fold(0.0, (sum, s) => sum + s.toplamTutar);
    final adet = satislar.length;
    return '${entities.zamanPeriyodu ?? 'Bugün'} satışları:\nToplam: ${toplam.toStringAsFixed(2)} ₺\nToplam işlem: $adet';
  }

  String _cevaplaEnCokSatan(Map<String, dynamic> analiz, ExtractedEntities entities) {
    final enCok = analiz['enCokSatanlar'] as List;
    if (enCok.isEmpty) return 'Henüz satış verisi yok.';
    int limit = entities.sayi?.toInt() ?? 5;
    if (limit > enCok.length) limit = enCok.length;
    return 'En çok satan $limit ürün:\n${enCok.take(limit).map((u) => '• ${u['ad']} (${u['toplam']} adet)').join('\n')}';
  }

  String _cevaplaKarMarji(Map<String, dynamic> analiz, ExtractedEntities entities) {
    final kar = analiz['karMarjAnalizi'] as Map;
    if (entities.urunAdi != null) {
      final enCok = analiz['enCokSatanlar'] as List;
      final urun = enCok.firstWhere(
        (u) => u['ad'].toString().toLowerCase().contains(entities.urunAdi!.toLowerCase()),
        orElse: () => null,
      );
      if (urun != null) return '${urun['ad']} için ortalama kâr marjı %${kar['ortalamaKar'].toStringAsFixed(1)}';
      else return '${entities.urunAdi} için kâr marjı verisi yok.';
    }
    return '''
Ortalama kâr marjı: %${kar['ortalamaKar'].toStringAsFixed(1)}
En yüksek: ${kar['enYuksekKar']['ad']} (%${kar['enYuksekKar']['kar'].toStringAsFixed(1)})
En düşük: ${kar['enDusukKar']['ad']} (%${kar['enDusukKar']['kar'].toStringAsFixed(1)})
''';
  }

  Future<String> _cevaplaMusteriAnalizi(Map<String, dynamic> analiz, ExtractedEntities entities) async {
    final musteriAnaliz = analiz['musteriAnalizi'] as Map;
    final enCok = musteriAnaliz['enCokHarcayan'] as List;
    if (entities.musteriAdi != null) {
      final musteriler = await _tumMusterileriGetir(await _dbHelper.db);
      final musteri = musteriler.firstWhere(
        (m) => m.unvan.toLowerCase().contains(entities.musteriAdi!.toLowerCase()),
        orElse: () => Musteri(cariKodu: '', unvan: '', bakiye: 0),
      );
      if (musteri.id != null) return '${musteri.unvan} bakiyesi: ${musteri.bakiye.toStringAsFixed(2)} ₺';
      else return 'Müşteri bulunamadı.';
    }
    if (enCok.isEmpty) return 'Müşteri verisi yok.';
    int limit = entities.sayi?.toInt() ?? 3;
    if (limit > enCok.length) limit = enCok.length;
    return 'En çok harcayan $limit müşteri:\n${enCok.take(limit).map((m) => '• ${m['unvan']} (${m['toplam'].toStringAsFixed(2)} ₺)').join('\n')}';
  }

  Future<String> _cevaplaMusteriBorc(ExtractedEntities entities) async {
    if (entities.musteriAdi == null) return 'Hangi müşterinin borcunu öğrenmek istersiniz?';
    try {
      final db = await _dbHelper.db;
      final result = await db.query('Cari', where: 'unvan LIKE ?', whereArgs: ['%${entities.musteriAdi}%']);
      if (result.isEmpty) return '${entities.musteriAdi} adlı müşteri bulunamadı.';
      final musteri = Musteri.fromMap(result.first);
      final bakiye = musteri.bakiye ?? 0;
      final durum = bakiye >= 0 ? 'alacak' : 'borç';
      return '${musteri.unvan} güncel bakiye: ${bakiye.abs().toStringAsFixed(2)} ₺ ($durum)';
    } catch (e, s) {
      Log.e('Müşteri borç sorgulama hatası', error: e, stackTrace: s);
      return 'Bakiye bilgisi alınırken hata oluştu.';
    }
  }

  Future<String> _cevaplaTahmin(ExtractedEntities entities) async {
    final tahmin = await tahminEt(gunSayisi: entities.sayi?.toInt() ?? 7);
    if (tahmin.isEmpty) return 'Tahmin için yeterli veri yok.';
    final ortalama = tahmin['ortalama'];
    final trend = tahmin['trend'];
    final tahminler = tahmin['tahminler'] as List;
    String trendYon = trend > 0 ? 'yükseliş' : (trend < 0 ? 'düşüş' : 'sabit');
    return '''
Önümüzdeki ${tahminler.length} gün için tahmin:
Ortalama satış: ${ortalama.toStringAsFixed(2)} ₺
Trend: $trendYon (${trend.toStringAsFixed(2)} ₺/gün)
Tahmini toplam: ${tahminler.reduce((a, b) => a + b).toStringAsFixed(2)} ₺
''';
  }

  Future<String> _cevaplaOneri(Map<String, dynamic> analiz) async {
    final oneriler = await siparisOnerileri();
    if (oneriler.isEmpty) return 'Şu anda sipariş önerisi yok.';
    return 'Sipariş önerileri:\n${oneriler.map((o) => '• ${o['urunAdi']}: ${o['mevcutStok']} stok (önerilen: ${o['onerilenSiparis']} adet)').join('\n')}';
  }

  Future<String> _cevaplaUrunAra(ExtractedEntities entities) async {
    if (entities.urunAdi == null && entities.sayi == null) return 'Aramak istediğiniz ürün adını veya barkodunu yazın.';
    try {
      final db = await _dbHelper.db;
      final arama = entities.urunAdi ?? entities.sayi?.toString() ?? '';
      final results = await db.query('urunler', where: 'ad LIKE ? OR barkod LIKE ? OR kod LIKE ?', whereArgs: ['%$arama%', '%$arama%', '%$arama%'], limit: 10);
      if (results.isEmpty) return 'Eşleşen ürün bulunamadı.';
      final urunler = results.map((m) => Urun.fromMap(m)).toList();
      return 'Bulunan ürünler:\n${urunler.map((u) => '• ${u.ad} (Stok: ${u.stokMiktari ?? 0})').join('\n')}';
    } catch (e, s) {
      Log.e('Ürün arama hatası', error: e, stackTrace: s);
      return 'Arama sırasında hata oluştu.';
    }
  }

  Future<String> _cevaplaUrunListele(ExtractedEntities entities, Map<String, dynamic> analiz) async {
    List<Urun> tumUrunler = (analiz['urunler'] as List).map((m) => Urun.fromMap(m as Map<String, dynamic>)).toList();
    Iterable<Urun> filtrelenmis = tumUrunler;
    if (entities.kategori != null) {
      filtrelenmis = filtrelenmis.where((u) => u.anagrup?.toLowerCase() == entities.kategori!.toLowerCase() || u.altGrup?.toLowerCase() == entities.kategori!.toLowerCase());
    }
    if (entities.marka != null) {
      filtrelenmis = filtrelenmis.where((u) => u.marka?.toLowerCase() == entities.marka!.toLowerCase());
    }
    if (entities.fiyatMin != null) filtrelenmis = filtrelenmis.where((u) => u.satisFiyat >= entities.fiyatMin!);
    if (entities.fiyatMax != null) filtrelenmis = filtrelenmis.where((u) => u.satisFiyat <= entities.fiyatMax!);
    if (entities.karsilastirma == 'en_ucuz') filtrelenmis = [tumUrunler.reduce((a, b) => a.satisFiyat < b.satisFiyat ? a : b)];
    else if (entities.karsilastirma == 'en_pahali') filtrelenmis = [tumUrunler.reduce((a, b) => a.satisFiyat > b.satisFiyat ? a : b)];
    else if (entities.karsilastirma == 'kritik') filtrelenmis = tumUrunler.where((u) => (u.stokMiktari ?? 0) < 5);
    if (filtrelenmis.isEmpty) return 'Kriterlere uygun ürün bulunamadı.';
    final limit = entities.limit ?? 10;
    final liste = filtrelenmis.take(limit).toList();
    String baslik = '';
    if (entities.kategori != null) baslik = '$entities.kategori kategorisindeki';
    else if (entities.marka != null) baslik = '$entities.marka markalı';
    else baslik = 'Tüm';
    return '$baslik ürünler (ilk ${liste.length}):\n${liste.map((u) => '• ${u.ad} - Stok: ${u.stokMiktari ?? 0} - Fiyat: ${u.satisFiyat.toStringAsFixed(2)} ₺').join('\n')}';
  }

  Future<String> _cevaplaCariListele(ExtractedEntities entities) async {
    try {
      final db = await _dbHelper.db;
      String sql = 'SELECT * FROM Cari';
      List<String> where = [];
      List<dynamic> args = [];
      if (entities.cariTipi != null) {
        where.add('cari_tipi = ?');
        args.add(entities.cariTipi);
      }
      if (entities.bakiyeDurumu != null) {
        if (entities.bakiyeDurumu == 'borçlu') where.add('bakiye < 0');
        else if (entities.bakiyeDurumu == 'alacaklı') where.add('bakiye > 0');
        else if (entities.bakiyeDurumu == 'sıfır') where.add('bakiye = 0');
      }
      if (entities.musteriAdi != null) {
        where.add('unvan LIKE ?');
        args.add('%${entities.musteriAdi}%');
      }
      if (where.isNotEmpty) sql += ' WHERE ' + where.join(' AND ');
      sql += ' ORDER BY unvan ASC LIMIT 50';
      final result = await db.rawQuery(sql, args);
      if (result.isEmpty) return 'Kriterlere uygun cari bulunamadı.';
      final limit = entities.limit ?? 10;
      final liste = result.take(limit).toList();
      String baslik = entities.cariTipi != null ? '${entities.cariTipi} listesi' : 'Cari listesi';
      if (entities.bakiyeDurumu != null) baslik += ' (${entities.bakiyeDurumu})';
      return '$baslik:\n${liste.map((c) {
        final bakiye = (c['bakiye'] as num?)?.toDouble() ?? 0;
        final durum = bakiye >= 0 ? 'alacaklı' : 'borçlu';
        return '• ${c['unvan']} - Bakiye: ${bakiye.abs().toStringAsFixed(2)} ₺ ($durum)';
      }).join('\n')}';
    } catch (e, s) {
      Log.e('Cari listeleme hatası', error: e, stackTrace: s);
      return 'Cari listesi alınırken hata oluştu.';
    }
  }

  Future<String> _cevaplaCariHareketleri(ExtractedEntities entities) async {
    try {
      final db = await _dbHelper.db;
      List<String> where = [];
      List<dynamic> args = [];
      if (entities.musteriAdi != null) {
        final cariResult = await db.query('Cari', where: 'unvan LIKE ?', whereArgs: ['%${entities.musteriAdi}%']);
        if (cariResult.isEmpty) return '${entities.musteriAdi} adlı cari bulunamadı.';
        final cariId = cariResult.first['id'];
        where.add('cariId = ?');
        args.add(cariId);
      }
      if (entities.hareketTipi != null) {
        where.add('fisTipi = ?');
        args.add(entities.hareketTipi);
      }
      if (entities.tarih != null) {
        final bas = DateFormat('yyyy-MM-dd 00:00:00').format(entities.tarih!);
        final bit = DateFormat('yyyy-MM-dd 23:59:59').format(entities.tarih!);
        where.add('tarih BETWEEN ? AND ?');
        args.add(bas);
        args.add(bit);
      }
      String sql = 'SELECT * FROM CariHareketleri';
      if (where.isNotEmpty) sql += ' WHERE ' + where.join(' AND ');
      sql += ' ORDER BY tarih DESC';
      if (entities.limit != null) sql += ' LIMIT ?';
      if (entities.limit != null) args.add(entities.limit);
      final result = await db.rawQuery(sql, args);
      if (result.isEmpty) return 'Hareket bulunamadı.';
      return 'Cari hareketleri:\n${result.map((h) {
        final tip = h['fisTipi'];
        final borc = (h['borc'] as num?)?.toDouble() ?? 0;
        final alacak = (h['alacak'] as num?)?.toDouble() ?? 0;
        final tutar = borc > 0 ? borc : alacak;
        final aciklama = h['aciklama'] ?? '';
        return '• ${h['tarih']} - $tip: $tutar ₺ ($aciklama)';
      }).join('\n')}';
    } catch (e, s) {
      Log.e('Cari hareketleri hatası', error: e, stackTrace: s);
      return 'Hareketler alınırken hata oluştu.';
    }
  }

  Future<String> _cevaplaStokHareketleri(ExtractedEntities entities) async {
    try {
      final db = await _dbHelper.db;
      List<String> where = [];
      List<dynamic> args = [];
      if (entities.urunAdi != null) {
        final urunResult = await db.query('urunler', where: 'ad LIKE ?', whereArgs: ['%${entities.urunAdi}%']);
        if (urunResult.isEmpty) return '${entities.urunAdi} adlı ürün bulunamadı.';
        final urunId = urunResult.first['id'];
        where.add('urunId = ?');
        args.add(urunId);
      }
      if (entities.hareketTipi != null) {
        where.add('hareketTuru = ?');
        args.add(entities.hareketTipi);
      }
      if (entities.tarih != null) {
        final bas = DateFormat('yyyy-MM-dd 00:00:00').format(entities.tarih!);
        final bit = DateFormat('yyyy-MM-dd 23:59:59').format(entities.tarih!);
        where.add('tarih BETWEEN ? AND ?');
        args.add(bas);
        args.add(bit);
      }
      String sql = 'SELECT sh.*, u.ad as urun_adi FROM StokHareketleri sh LEFT JOIN urunler u ON sh.urunId = u.id';
      if (where.isNotEmpty) sql += ' WHERE ' + where.join(' AND ');
      sql += ' ORDER BY tarih DESC';
      if (entities.limit != null) sql += ' LIMIT ?';
      if (entities.limit != null) args.add(entities.limit);
      final result = await db.rawQuery(sql, args);
      if (result.isEmpty) return 'Stok hareketi bulunamadı.';
      return 'Stok hareketleri:\n${result.map((h) {
        final urunAd = h['urun_adi'] ?? 'Bilinmeyen';
        final tur = h['hareketTuru'];
        final miktar = (h['miktar'] as num?)?.toDouble() ?? 0;
        final tarih = h['tarih'];
        return '• $tarih - $urunAd: $tur $miktar adet';
      }).join('\n')}';
    } catch (e, s) {
      Log.e('Stok hareketleri hatası', error: e, stackTrace: s);
      return 'Stok hareketleri alınırken hata oluştu.';
    }
  }

  Future<String> _cevaplaIadeKayitlari(ExtractedEntities entities) async {
    try {
      final db = await _dbHelper.db;
      String sql = 'SELECT * FROM iade_kayitlari';
      List<String> where = [];
      List<dynamic> args = [];
      if (entities.urunAdi != null) {
        where.add('urun_adi LIKE ?');
        args.add('%${entities.urunAdi}%');
      }
      if (entities.tarih != null) {
        final bas = DateFormat('yyyy-MM-dd').format(entities.tarih!);
        where.add('tarih LIKE ?');
        args.add('$bas%');
      }
      if (where.isNotEmpty) sql += ' WHERE ' + where.join(' AND ');
      sql += ' ORDER BY tarih DESC';
      if (entities.limit != null) sql += ' LIMIT ?';
      if (entities.limit != null) args.add(entities.limit);
      final result = await db.rawQuery(sql, args);
      if (result.isEmpty) return 'İade kaydı bulunamadı.';
      return 'İade kayıtları:\n${result.map((i) {
        final urun = i['urun_adi'];
        final miktar = i['miktar'];
        final neden = i['iade_nedeni'] ?? 'Belirtilmemiş';
        final tarih = i['tarih'];
        return '• $tarih - $urun: $miktar adet ($neden)';
      }).join('\n')}';
    } catch (e, s) {
      Log.e('İade kayıtları hatası', error: e, stackTrace: s);
      return 'İade kayıtları alınırken hata oluştu.';
    }
  }

  Future<String> _cevaplaYaziciDurumu(ExtractedEntities entities) async {
    try {
      final db = await _dbHelper.db;
      List<String> where = [];
      List<dynamic> args = [];
      if (entities.yaziciTipi != null) {
        where.add('tur = ?');
        args.add(entities.yaziciTipi);
      }
      if (entities.yaziciKategori != null) {
        where.add('kategori = ?');
        args.add(entities.yaziciKategori);
      }
      String sql = 'SELECT * FROM Yazicilar';
      if (where.isNotEmpty) sql += ' WHERE ' + where.join(' AND ');
      sql += ' ORDER BY varsayilan DESC, ad ASC';
      final result = await db.rawQuery(sql, args);
      if (result.isEmpty) return 'Tanımlı yazıcı bulunamadı.';
      return 'Yazıcılar:\n${result.map((y) {
        final varsayilan = y['varsayilan'] == 1 ? ' (varsayılan)' : '';
        return '• ${y['adi']} - ${y['tur']} (${y['kategori']})$varsayilan';
      }).join('\n')}';
    } catch (e, s) {
      Log.e('Yazıcı sorgulama hatası', error: e, stackTrace: s);
      return 'Yazıcı bilgileri alınırken hata oluştu.';
    }
  }

  Future<String> _cevaplaRaporListele(ExtractedEntities entities) async {
    try {
      final db = await _dbHelper.db;
      String sql = 'SELECT * FROM gun_sonu_raporlari ORDER BY tarih DESC';
      if (entities.limit != null) sql += ' LIMIT ?';
      final result = await db.rawQuery(sql, entities.limit != null ? [entities.limit] : []);
      if (result.isEmpty) return 'Kayıtlı rapor bulunamadı.';
      return 'Kayıtlı gün sonu raporları:\n${result.map((r) {
        final tarih = r['tarih'];
        return '• $tarih';
      }).join('\n')}\nDetay için "tarih ile rapor göster" şeklinde sorabilirsiniz.';
    } catch (e, s) {
      Log.e('Rapor listeleme hatası', error: e, stackTrace: s);
      return 'Raporlar alınırken hata oluştu.';
    }
  }

  String _cevaplaEnKarliUrun(Map<String, dynamic> analiz) {
    final kar = analiz['karMarjAnalizi'] as Map;
    return '📈 En yüksek kâr marjlı ürün: **${kar['enYuksekKar']['ad']}** (%${kar['enYuksekKar']['kar'].toStringAsFixed(1)})';
  }

  Future<String> _cevaplaStokGirisCikis(ExtractedEntities entities) async {
    try {
      final db = await _dbHelper.db;
      DateTime baslangic, bitis;
      if (entities.tarih != null) {
        baslangic = entities.tarih!;
        bitis = entities.tarihBitis ?? baslangic;
      } else {
        final bugun = DateTime.now();
        baslangic = DateTime(bugun.year, bugun.month, bugun.day);
        bitis = baslangic;
      }
      final basStr = DateFormat('yyyy-MM-dd 00:00:00').format(baslangic);
      final bitStr = DateFormat('yyyy-MM-dd 23:59:59').format(bitis);
      final result = await db.rawQuery('''
        SELECT hareketTuru, SUM(miktar) as toplamMiktar
        FROM StokHareketleri
        WHERE tarih BETWEEN ? AND ?
        GROUP BY hareketTuru
      ''', [basStr, bitStr]);
      if (result.isEmpty) return 'Belirtilen tarihte stok hareketi yok.';
      String giris = '0', cikis = '0', sayim = '0';
      for (var row in result) {
        final tur = row['hareketTuru'];
        final miktar = (row['toplamMiktar'] as num).toDouble().toStringAsFixed(2);
        if (tur == 'Giriş') giris = miktar;
        else if (tur == 'Çıkış') cikis = miktar;
        else if (tur == 'Sayım') sayim = miktar;
      }
      return '📦 Stok Hareket Özeti:\n• Giriş: $giris adet\n• Çıkış: $cikis adet\n• Sayım: $sayim adet';
    } catch (e) {
      return 'Stok hareketleri alınırken hata oluştu.';
    }
  }

  String _cevaplaFavoriMusteri(Map<String, dynamic> analiz, ExtractedEntities entities) {
    final musteriAnaliz = analiz['musteriAnalizi'] as Map;
    final enCok = musteriAnaliz['enCokHarcayan'] as List;
    if (enCok.isEmpty) return 'Müşteri verisi yok.';
    int limit = entities.limit ?? 1;
    if (limit > enCok.length) limit = enCok.length;
    if (limit == 1) return '👑 En çok harcayan müşteri: **${enCok.first['unvan']}** (${enCok.first['toplam'].toStringAsFixed(2)} ₺)';
    else return '👥 En çok harcayan $limit müşteri:\n${enCok.take(limit).map((m) => '• ${m['unvan']} (${m['toplam'].toStringAsFixed(2)} ₺)').join('\n')}';
  }

  Future<String> _cevaplaGunlukOzet(ExtractedEntities entities) async {
    DateTime tarih = entities.tarih ?? DateTime.now();
    final baslangic = DateTime(tarih.year, tarih.month, tarih.day);
    final bitis = DateTime(tarih.year, tarih.month, tarih.day, 23, 59, 59);
    final satislar = await _satisRepo.tariheGoreSatislariGetir(baslangic, bitis);
    double toplamSatis = 0, nakit = 0, kredi = 0, cari = 0;
    double toplamMaliyet = 0;
    for (var satis in satislar) {
      toplamSatis += satis.toplamTutar;
      if (satis.odemeYontemi == 'Nakit') nakit += satis.toplamTutar;
      else if (satis.odemeYontemi == 'Kredi Kartı') kredi += satis.toplamTutar;
      else if (satis.odemeYontemi == 'Cari') cari += satis.toplamTutar;
      
      for (var kalem in satis.kalemler) {
        final urun = await _urunRepo.idyeGoreUrunGetir(kalem.urunId);
        toplamMaliyet += (urun?.alisFiyat ?? 0) * kalem.miktar;
      }
    }
    final db = await _dbHelper.db;
    final tahsilatResult = await db.rawQuery('SELECT SUM(alacak) as toplam FROM CariHareketleri WHERE fis_tipi = "Tahsilat" AND date(tarih) = date(?)', [tarih.toIso8601String()]);
    final odemeResult = await db.rawQuery('SELECT SUM(borc) as toplam FROM CariHareketleri WHERE fis_tipi = "Ödeme" AND date(tarih) = date(?)', [tarih.toIso8601String()]);
    double tahsilat = (tahsilatResult.first['toplam'] as num?)?.toDouble() ?? 0;
    double odeme = (odemeResult.first['toplam'] as num?)?.toDouble() ?? 0;
    double kar = toplamSatis - toplamMaliyet; // DÜZELTİLDİ
    return '''
📅 **${DateFormat('dd.MM.yyyy').format(tarih)} Günlük Özet**
• Toplam Satış: ${toplamSatis.toStringAsFixed(2)} ₺
• Nakit: ${nakit.toStringAsFixed(2)} ₺
• Kredi Kartı: ${kredi.toStringAsFixed(2)} ₺
• Cari: ${cari.toStringAsFixed(2)} ₺
• Tahsilat: ${tahsilat.toStringAsFixed(2)} ₺
• Ödeme: ${odeme.toStringAsFixed(2)} ₺
• Tahmini Net Kar: ${kar.toStringAsFixed(2)} ₺
''';
  }

  Future<String> _cevaplaKategoriAnaliz(ExtractedEntities entities, Map<String, dynamic> analiz) async {
    final kategoriSatis = analiz['kategoriSatis'] as Map<String, double>;
    if (kategoriSatis.isEmpty) return 'Kategori bazında satış verisi yok.';
    List<MapEntry<String, double>> list = kategoriSatis.entries.toList();
    list.sort((a,b) => b.value.compareTo(a.value));
    int limit = entities.limit ?? 5;
    if (limit > list.length) limit = list.length;
    StringBuffer sb = StringBuffer('📂 Kategorilere göre satışlar:\n');
    for (int i=0; i<limit; i++) sb.writeln('• ${list[i].key}: ${list[i].value.toStringAsFixed(2)} ₺');
    return sb.toString();
  }

  Future<String> _cevaplaMarkaAnaliz(ExtractedEntities entities, Map<String, dynamic> analiz) async {
    final markaSatis = analiz['markaSatis'] as Map<String, double>;
    if (markaSatis.isEmpty) return 'Marka bazında satış verisi yok.';
    List<MapEntry<String, double>> list = markaSatis.entries.toList();
    list.sort((a,b) => b.value.compareTo(a.value));
    int limit = entities.limit ?? 5;
    if (limit > list.length) limit = list.length;
    StringBuffer sb = StringBuffer('🏷️ Markalara göre satışlar:\n');
    for (int i=0; i<limit; i++) sb.writeln('• ${list[i].key}: ${list[i].value.toStringAsFixed(2)} ₺');
    return sb.toString();
  }

  Future<String> _cevaplaFiyatGecmisi(ExtractedEntities entities) async {
    if (entities.urunAdi == null) return 'Hangi ürünün fiyat geçmişini görmek istersiniz?';
    try {
      final db = await _dbHelper.db;
      final urun = await _urunRepo.barkodlaUrunGetir(entities.urunAdi!);
      if (urun == null) return 'Ürün bulunamadı.';
      final maps = await db.query('fiyat_gecmis', where: 'urunId = ?', whereArgs: [urun.id], orderBy: 'tarih DESC', limit: 5);
      if (maps.isEmpty) return 'Bu ürün için fiyat geçmişi bulunamadı.';
      StringBuffer sb = StringBuffer('📉 **${urun.ad}** fiyat geçmişi:\n');
      for (var m in maps) {
        final tarih = DateTime.parse(m['tarih'].toString());
        final eski = m['eskiFiyat'];
        final yeni = m['yeniFiyat'];
        sb.writeln('• ${DateFormat('dd.MM.yyyy').format(tarih)}: $eski ₺ → $yeni ₺');
      }
      return sb.toString();
    } catch (e) {
      return 'Fiyat geçmişi alınırken hata oluştu: $e';
    }
  }

  String _cevaplaStokDeger(Map<String, dynamic> analiz) {
    final deger = analiz['toplamStokDeger'] as double;
    return '💰 Toplam stok değeri (alış fiyatlarına göre): **${deger.toStringAsFixed(2)} ₺**';
  }

  Future<String> _cevaplaKasaDurumu(ExtractedEntities entities) async {
    try {
      final db = await _dbHelper.db;
      final bugun = DateTime.now();
      final otuzGunOnce = bugun.subtract(const Duration(days: 30));
      final result = await db.rawQuery('''
        SELECT 
          SUM(CASE WHEN fis_tipi = 'Tahsilat' THEN alacak ELSE 0 END) as toplamTahsilat,
          SUM(CASE WHEN fis_tipi = 'Ödeme' THEN borc ELSE 0 END) as toplamOdeme
        FROM CariHareketleri
        WHERE date(tarih) >= date(?)
      ''', [otuzGunOnce.toIso8601String()]);
      double tahsilat = (result.first['toplamTahsilat'] as num?)?.toDouble() ?? 0;
      double odeme = (result.first['toplamOdeme'] as num?)?.toDouble() ?? 0;
      double bakiye = tahsilat - odeme;
      return '''
💵 **Son 30 günlük nakit durumu:**
• Toplam Tahsilat: ${tahsilat.toStringAsFixed(2)} ₺
• Toplam Ödeme: ${odeme.toStringAsFixed(2)} ₺
• Net Nakit Akışı: ${bakiye.toStringAsFixed(2)} ₺
''';
    } catch (e) {
      return 'Kasa durumu alınırken hata oluştu.';
    }
  }

  String _cevaplaOdemeYontemiDagilim(Map<String, dynamic> analiz, ExtractedEntities entities) {
    final dagilim = analiz['odemeYontemiDagilim'] as Map<String, double>;
    if (dagilim.isEmpty) return 'Ödeme yöntemi verisi yok.';
    StringBuffer sb = StringBuffer('💳 Ödeme yöntemlerine göre dağılım:\n');
    dagilim.forEach((yontem, tutar) { sb.writeln('• $yontem: ${tutar.toStringAsFixed(2)} ₺'); });
    return sb.toString();
  }

  // ================= YENİ: KAZANÇ METODU =================
  Future<String> _cevaplaKazancim(ExtractedEntities entities) async {
    DateTime baslangic, bitis;
    final now = DateTime.now();
    final periyot = entities.zamanPeriyodu;
    
    if (periyot == 'bugün') {
      baslangic = DateTime(now.year, now.month, now.day);
      bitis = baslangic.add(const Duration(days: 1)).subtract(const Duration(seconds: 1));
    } else if (periyot == 'dün') {
      final dun = now.subtract(const Duration(days: 1));
      baslangic = DateTime(dun.year, dun.month, dun.day);
      bitis = baslangic.add(const Duration(days: 1)).subtract(const Duration(seconds: 1));
    } else if (periyot == 'bu hafta') {
      final pazartesi = now.subtract(Duration(days: now.weekday - 1));
      baslangic = DateTime(pazartesi.year, pazartesi.month, pazartesi.day);
      bitis = baslangic.add(const Duration(days: 6, hours: 23, minutes: 59, seconds: 59));
    } else if (periyot == 'bu ay') {
      baslangic = DateTime(now.year, now.month, 1);
      bitis = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
    } else if (periyot == 'bu yıl') {
      baslangic = DateTime(now.year, 1, 1);
      bitis = DateTime(now.year, 12, 31, 23, 59, 59);
    } else if (periyot == 'geçen ay') {
      final gecenAy = now.month == 1 ? DateTime(now.year - 1, 12, 1) : DateTime(now.year, now.month - 1, 1);
      baslangic = gecenAy;
      bitis = DateTime(gecenAy.year, gecenAy.month + 1, 0, 23, 59, 59);
    } else if (periyot == 'geçen hafta') {
      final gecenHaftaPazartesi = now.subtract(Duration(days: now.weekday - 1 + 7));
      baslangic = DateTime(gecenHaftaPazartesi.year, gecenHaftaPazartesi.month, gecenHaftaPazartesi.day);
      bitis = baslangic.add(const Duration(days: 6, hours: 23, minutes: 59, seconds: 59));
    } else if (entities.tarih != null) {
      baslangic = entities.tarih!;
      bitis = entities.tarihBitis ?? baslangic.add(const Duration(days: 1)).subtract(const Duration(seconds: 1));
    } else {
      baslangic = DateTime(now.year, now.month, now.day);
      bitis = baslangic.add(const Duration(days: 1)).subtract(const Duration(seconds: 1));
    }

    final satislar = await _satisRepo.tariheGoreSatislariGetir(baslangic, bitis);
    double toplamSatis = 0;
    double toplamMaliyet = 0;

    for (var satis in satislar) {
      if (satis.fisTipi == 'Satış') {
        toplamSatis += satis.toplamTutar;
        for (var kalem in satis.kalemler) {
          final urun = await _urunRepo.idyeGoreUrunGetir(kalem.urunId);
          final maliyet = (urun?.alisFiyat ?? 0) * kalem.miktar;
          toplamMaliyet += maliyet;
        }
      }
    }

    final netKar = toplamSatis - toplamMaliyet;
    final periyotAdi = periyot ?? 'Bugün';
    
    return '''
💰 **${periyotAdi.toUpperCase()} NET KAR RAPORU**
📅 Tarih aralığı: ${DateFormat('dd.MM.yyyy').format(baslangic)} - ${DateFormat('dd.MM.yyyy').format(bitis)}
• Toplam Satış: ${toplamSatis.toStringAsFixed(2)} ₺
• Toplam Maliyet: ${toplamMaliyet.toStringAsFixed(2)} ₺
• **Net Kar: ${netKar.toStringAsFixed(2)} ₺**
''';
  }

  String _sohbetCevap(String soru) {
    final s = soru.toLowerCase();
    if (s.contains('merhaba') || s.contains('selam') || s.contains('günaydın')) {
      return 'Merhaba! Size nasıl yardımcı olabilirim? Stok, satış, müşteri veya ürünler hakkında sorular sorabilirsiniz.';
    } else if (s.contains('nasılsın')) {
      return 'Ben bir yapay zekayım, her zaman iyiyim! Size nasıl yardım edebilirim?';
    } else if (s.contains('teşekkür') || s.contains('sağ ol')) {
      return 'Rica ederim, ne zaman ihtiyacınız olsa buradayım.';
    } else if (s.contains('görüşürüz') || s.contains('hoşça kal')) {
      return 'Görüşmek üzere, iyi günler!';
    } else if (s.contains('ne yapabilirsin') || s.contains('yeteneklerin')) {
      return _varsayilanCevap();
    }
    return 'Anlamadım, lütfen biraz daha açıklayıcı olur musunuz?';
  }

  String _varsayilanCevap() {
    return '''
Merhaba! Size pek çok konuda yardımcı olabilirim:

📦 **Stok & Ürünler**
- "Kritik stoklar", "süt stoğu kaç?", "ürün ara X", "süt ürünlerini listele", "en ucuz ürün"

💰 **Satış & Finans**
- "Dünkü satışlar", "bu ay ciro", "en çok satan 5 ürün", "ortalama kâr marjı", "önümüzdeki 7 gün tahmini"

👥 **Cariler (Müşteri/Tedarikçi)**
- "Müşteri listesi", "borçlu müşteriler", "tedarikçiler", "ahmet'in bakiyesi", "ahmet'in hareketleri", "tahsilatlar"

📊 **Hareketler & Raporlar**
- "Stok hareketleri", "son 10 iade", "yazıcılar", "kayıtlı raporlar"

📈 **Grafik**
- "Grafik göster", "satış grafiği"

Sohbet de edebiliriz. Ne sormak istersiniz?
''';
  }
}