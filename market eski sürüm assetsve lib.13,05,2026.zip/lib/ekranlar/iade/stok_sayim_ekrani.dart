// lib/ekranlar/iade/stok_sayim_ekrani.dart
// İyileştirilmiş ve performansı artırılmış tam kod

import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/widgetlar/barkod_tarayici.dart';
import 'package:excel/excel.dart' hide Border, BorderStyle;
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:market_uygulamasi/core/logger.dart';
import 'package:barcode_widget/barcode_widget.dart' as bw;
import 'package:market_uygulamasi/ekranlar/urun/urun_detay_ekrani.dart';
import 'dart:async';

class StokSayimEkrani extends StatefulWidget {
  @override
  _StokSayimEkraniState createState() => _StokSayimEkraniState();
}

class _StokSayimEkraniState extends State<StokSayimEkrani> {
  final UrunRepoSitory _repo = UrunRepoSitory();
  List<Urun> _tumUrunler = [];
  List<StokSayimItem> _sayimListesi = [];

  final TextEditingController _aramaController = TextEditingController();
  final FocusNode _aramaFocusNode = FocusNode();
  List<Urun> _aramaSonuclari = [];
  Timer? _aramaDebounce;

  bool _excelYukleniyor = false;
  bool _yukleniyor = true;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _verileriYukle();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      FocusScope.of(context).requestFocus(_aramaFocusNode);
    });
    _aramaController.addListener(_onAramaChanged);
  }

  @override
  void dispose() {
    _aramaDebounce?.cancel();
    _aramaController.removeListener(_onAramaChanged);
    _aramaController.dispose();
    _aramaFocusNode.dispose();
    _scrollController.dispose();
    for (var item in _sayimListesi) {
      item.controller.dispose();
      item.focusNode.dispose();
    }
    super.dispose();
  }

  void _onAramaChanged() {
    _aramaDebounce?.cancel();
    final value = _aramaController.text;
    if (value.isEmpty) {
      setState(() => _aramaSonuclari = []);
      return;
    }
    if (value.length < 2) return;
    _aramaDebounce = Timer(const Duration(milliseconds: 300), () {
      _adaGoreAra(value);
    });
  }

  Future<void> _verileriYukle() async {
    setState(() => _yukleniyor = true);
    await _urunleriYukle();
    await _geciciListeyiYukle();
    setState(() => _yukleniyor = false);
  }

  Future<void> _urunleriYukle() async {
    final urunler = await _repo.tumUrunleriGetir();
    if (mounted) {
      setState(() => _tumUrunler = urunler);
    }
  }

  Future<void> _geciciListeyiYukle() async {
    try {
      final geciciListe = await _repo.geciciSayimListesiGetir();
      final Map<int, Urun> urunMap = {for (var u in _tumUrunler) u.id!: u};

      for (var item in _sayimListesi) {
        item.controller.dispose();
        item.focusNode.dispose();
      }

      setState(() {
        _sayimListesi.clear();
        for (var kayit in geciciListe) {
          final urunId = kayit['urun_id'] as int;
          final urun = urunMap[urunId];
          if (urun != null) {
            _sayimListesi.add(StokSayimItem(
              urun: urun,
              mevcutStok: (kayit['mevcutStok'] as num).toDouble(),
              yeniStok: (kayit['yeniStok'] as num).toDouble(),
            ));
          }
        }
      });
    } catch (e) {
      appLogger.e('Geçici liste yüklenemedi: $e');
      _showMessage('Geçici liste yüklenemedi: $e', isError: true);
    }
  }

  Future<void> _adaGoreAra(String kelime) async {
    final sonuclar = await _repo.adaGoreUrunAra(kelime);
    if (!mounted) return;
    setState(() => _aramaSonuclari = sonuclar);
  }

  Future<void> _barkodOku() async {
    final barkod = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => BarkodTarayici()),
    );
    if (barkod != null && barkod.isNotEmpty) {
      _aramaController.text = barkod;
      final urun = await _repo.barkodlaUrunGetir(barkod);
      if (urun != null) {
        _sayimListesineEkle(urun);
        _aramaController.clear();
        setState(() => _aramaSonuclari = []);
      } else {
        await _adaGoreAra(barkod);
        if (_aramaSonuclari.isEmpty) {
          _urunBulunamadiDialog(barkod);
        }
      }
    }
  }

  void _scrollToAndFocusItem(int index) {
    if (index < 0 || index >= _sayimListesi.length) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          index * 120.0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      }
      FocusScope.of(context).requestFocus(_sayimListesi[index].focusNode);
    });
  }

  void _sayimListesineEkle(Urun urun) {
    final existingIndex = _sayimListesi.indexWhere((item) => item.urun.id == urun.id);
    if (existingIndex != -1) {
      _showMessage('${urun.ad} zaten listede, miktarını güncelleyebilirsiniz.', isError: false);
      _scrollToAndFocusItem(existingIndex);
      return;
    }

    setState(() {
      _sayimListesi.insert(0, StokSayimItem(
        urun: urun,
        mevcutStok: urun.stokMiktari,
        yeniStok: 0,
      ));
      _aramaSonuclari = [];
      _aramaController.clear();
    });
    _repo.geciciSayimEkleveyaGuncelle(urun.id!, urun.stokMiktari, 0);
    _aramaFocusNode.requestFocus();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_sayimListesi.isNotEmpty) {
        _scrollToAndFocusItem(0);
      }
    });
  }

  void _urunSec(Urun urun) {
    _sayimListesineEkle(urun);
  }

  Future<void> _urunBulunamadiDialog(String aranan) async {
    final ekle = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ürün Bulunamadı'),
        content: Text('"$aranan" ile eşleşen ürün bulunamadı.\nYeni ürün eklemek ister misiniz?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hayır')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Evet')),
        ],
      ),
    );
    if (ekle == true) {
      await _yeniUrunEkle(aranan);
    }
  }

  Future<void> _yeniUrunEkle(String barkod) async {
    final sonuc = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => UrunDetayEkrani(baslangicBarkod: barkod)),
    );
    if (sonuc == true) {
      await _urunleriYukle();
      await _geciciListeyiYukle();
      final yeniUrun = _tumUrunler.firstWhere(
        (u) => u.barkod == barkod,
        orElse: () => throw Exception('Yeni ürün bulunamadı'),
      );
      _sayimListesineEkle(yeniUrun);
    }
  }

  void _stokGuncelle(StokSayimItem item, String yeniDegerStr) {
    final yeniDeger = double.tryParse(yeniDegerStr) ?? 0;
    if (item.yeniStok != yeniDeger) {
      item.yeniStok = yeniDeger;
      _repo.geciciSayimEkleveyaGuncelle(
        item.urun.id!,
        item.mevcutStok,
        item.yeniStok,
      );
      setState(() {});
    }
  }

  void _ilaveStokGir(StokSayimItem item) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Stok İlave Et'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'İlave Miktar',
            border: OutlineInputBorder(),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
          ElevatedButton(
            onPressed: () {
              final ilaveMiktar = double.tryParse(controller.text) ?? 0;
              if (ilaveMiktar > 0) {
                setState(() {
                  item.mevcutStok += ilaveMiktar;
                  item.yeniStok = item.mevcutStok;
                  item.controller.text = item.yeniStok.toStringAsFixed(2);
                });
                _repo.geciciSayimEkleveyaGuncelle(
                  item.urun.id!,
                  item.mevcutStok,
                  item.yeniStok,
                );
              }
              Navigator.pop(context);
            },
            child: const Text('İlave Et'),
          ),
        ],
      ),
    );
  }

  Future<void> _stoklariKaydet() async {
    setState(() => _yukleniyor = true);
    try {
      for (final item in _sayimListesi) {
        final kaydedilecekStok = (item.yeniStok == 0) ? item.mevcutStok : item.yeniStok;
        final guncellenenUrun = item.urun.copyWith(stokMiktari: kaydedilecekStok);
        await _repo.urunGuncelle(guncellenenUrun);
        item.mevcutStok = kaydedilecekStok;
        item.yeniStok = 0;
        item.controller.clear();
        await _repo.geciciSayimEkleveyaGuncelle(item.urun.id!, item.mevcutStok, 0);
      }
      _showMessage('Stoklar güncellendi, liste kaydedildi');
      setState(() {});
      await _urunleriYukle();
    } catch (e) {
      _showMessage('Kaydetme hatası: $e', isError: true);
    } finally {
      setState(() => _yukleniyor = false);
    }
  }

  void _listeyiTemizle() async {
    final onay = await _onayAl('Tüm sayım listesini temizlemek istediğinize emin misiniz?');
    if (!onay) return;

    await _repo.geciciSayimTemizle();
    for (var item in _sayimListesi) {
      item.controller.dispose();
      item.focusNode.dispose();
    }
    setState(() => _sayimListesi.clear());
    _showMessage('Liste tamamen temizlendi');
  }

  Future<bool> _onayAl(String mesaj) async {
    return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Onay'),
            content: Text(mesaj),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hayır')),
              ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Evet')),
            ],
          ),
        ) ??
        false;
  }

  void _showMessage(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _excelDisariAktar() async {
    if (_sayimListesi.isEmpty) {
      _showMessage('Aktarılacak veri yok', isError: true);
      return;
    }
    final excel = Excel.createExcel();
    final sheet = excel['Stok Sayım'];
    sheet.appendRow(['Kod', 'UrunAdi', 'Mevcut Stok', 'Yeni Stok', 'Fark', 'DepoAdi']);
    for (final item in _sayimListesi) {
      final yeni = item.yeniStok == 0 ? item.mevcutStok : item.yeniStok;
      sheet.appendRow([
        item.urun.kod ?? '',
        item.urun.ad ?? '',
        item.mevcutStok,
        yeni,
        yeni - item.mevcutStok,
        'Merkez Depo'
      ]);
    }
    final bytes = excel.encode();
    if (bytes == null) {
      _showMessage('Excel dosyası oluşturulamadı', isError: true);
      return;
    }
    final file = File('${(await getApplicationDocumentsDirectory()).path}/stok_sayim_${DateTime.now().millisecondsSinceEpoch}.xlsx');
    await file.writeAsBytes(bytes, flush: true);
    await Share.shareFiles([file.path], text: 'Stok Sayım Excel');
    _showMessage('Excel başarıyla oluşturuldu');
  }

  Future<void> _excelIceriAktar() async {
    setState(() => _excelYukleniyor = true);
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx'],
      );
      if (result == null) return;
      final file = File(result.files.single.path!);
      final bytes = await file.readAsBytes();
      final excel = Excel.decodeBytes(bytes);

      for (var item in _sayimListesi) {
        item.controller.dispose();
        item.focusNode.dispose();
      }
      setState(() => _sayimListesi.clear());

      int eklenen = 0;
      for (final table in excel.tables.keys) {
        final sheet = excel.tables[table]!;
        for (int i = 1; i < sheet.rows.length && i < 1000; i++) {
          final row = sheet.rows[i];
          if (row.length >= 1) {
            final barkod = row[0]?.value?.toString() ?? '';
            if (barkod.isNotEmpty) {
              Urun? bulunanUrun;
              for (var u in _tumUrunler) {
                if (u.barkod == barkod || (u.barkodlar?.split(',').contains(barkod) ?? false)) {
                  bulunanUrun = u;
                  break;
                }
              }
              if (bulunanUrun != null) {
                _sayimListesi.add(StokSayimItem(
                  urun: bulunanUrun,
                  mevcutStok: bulunanUrun.stokMiktari,
                  yeniStok: 0,
                ));
                await _repo.geciciSayimEkleveyaGuncelle(bulunanUrun.id!, bulunanUrun.stokMiktari, 0);
                eklenen++;
              }
            }
          }
        }
      }
      setState(() {});
      _showMessage('Excel aktarıldı ($eklenen ürün)');
    } catch (e) {
      _showMessage('Excel hatası: $e', isError: true);
    } finally {
      setState(() => _excelYukleniyor = false);
    }
  }

  void _barkodDialogAc(Urun urun) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(urun.ad, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              SizedBox(
                width: 250,
                height: 150,
                child: bw.BarcodeWidget(
                  barcode: bw.Barcode.code128(),
                  data: urun.barkod,
                  width: 250,
                  height: 150,
                  drawText: false,
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text("Kapat")),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Stok Sayım'),
        actions: [
          if (_excelYukleniyor)
            const Padding(padding: EdgeInsets.all(8.0), child: CircularProgressIndicator(color: Colors.white))
          else
            IconButton(icon: const Icon(Icons.file_download), onPressed: _excelDisariAktar, tooltip: 'Dışa Aktar'),
          IconButton(icon: const Icon(Icons.file_upload), onPressed: _excelYukleniyor ? null : _excelIceriAktar, tooltip: 'İçe Aktar'),
        ],
      ),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _aramaController,
                          focusNode: _aramaFocusNode,
                          decoration: InputDecoration(
                            labelText: 'Barkod veya Ürün Ara',
                            border: const OutlineInputBorder(),
                            prefixIcon: const Icon(Icons.search),
                            suffixIcon: _aramaController.text.isNotEmpty
                                ? IconButton(
                                    icon: const Icon(Icons.clear),
                                    onPressed: () {
                                      _aramaController.clear();
                                      setState(() => _aramaSonuclari = []);
                                      _aramaFocusNode.requestFocus();
                                    },
                                  )
                                : null,
                          ),
                          onSubmitted: (value) async {
                            final urun = await _repo.barkodlaUrunGetir(value);
                            if (urun != null) {
                              _sayimListesineEkle(urun);
                              _aramaController.clear();
                              setState(() => _aramaSonuclari = []);
                            } else {
                              await _adaGoreAra(value);
                              if (_aramaSonuclari.isEmpty) _urunBulunamadiDialog(value);
                            }
                          },
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.qr_code_scanner),
                        onPressed: _barkodOku,
                        tooltip: 'Barkod Oku',
                      ),
                    ],
                  ),
                ),
                if (_aramaSonuclari.isNotEmpty)
                  Container(
                    height: 180,
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    child: Card(
                      child: ListView.builder(
                        itemCount: _aramaSonuclari.length,
                        itemBuilder: (ctx, i) {
                          final urun = _aramaSonuclari[i];
                          return ListTile(
                            leading: const Icon(Icons.inventory),
                            title: Text(urun.ad),
                            subtitle: Text('Stok: ${urun.stokMiktari.toStringAsFixed(2)} • Fiyat: ${urun.satisFiyat.toStringAsFixed(2)} ₺'),
                            trailing: const Icon(Icons.add_circle, color: Colors.green),
                            onTap: () => _urunSec(urun),
                          );
                        },
                      ),
                    ),
                  ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Sayım Listesi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  ),
                ),
                Expanded(
                  child: _excelYukleniyor
                      ? const Center(child: CircularProgressIndicator())
                      : _sayimListesi.isEmpty
                          ? const Center(child: Text('Sayım listesi boş'))
                          : ListView.builder(
                              controller: _scrollController,
                              itemCount: _sayimListesi.length,
                              itemBuilder: (context, index) {
                                final item = _sayimListesi[index];
                                return Dismissible(
                                  key: ValueKey(item.urun.id),
                                  direction: DismissDirection.endToStart,
                                  confirmDismiss: (_) async => await _onayAl('${item.urun.ad} silinsin mi?'),
                                  onDismissed: (_) {
                                    final silinenId = item.urun.id;
                                    setState(() {
                                      item.controller.dispose();
                                      item.focusNode.dispose();
                                      _sayimListesi.remove(item);
                                    });
                                    _repo.geciciSayimSil(silinenId!);
                                  },
                                  background: Container(
                                    color: Colors.red,
                                    alignment: Alignment.centerRight,
                                    padding: const EdgeInsets.symmetric(horizontal: 20),
                                    child: const Icon(Icons.delete, color: Colors.white),
                                  ),
                                  child: _stokItemCard(item, index),
                                );
                              },
                            ),
                ),
                Container(
                  padding: const EdgeInsets.all(16),
                  color: Colors.grey[200],
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: _stoklariKaydet,
                        child: const Text('Stokları Kaydet'),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                      ),
                      ElevatedButton(
                        onPressed: _listeyiTemizle,
                        child: const Text('Listeyi Temizle'),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _stokItemCard(StokSayimItem item, int index) {
    return InkWell(
      onTap: () => _barkodDialogAc(item.urun),
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item.urun.ad, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              Row(
                children: [
                  Text('Mevcut Stok: ${item.mevcutStok.toStringAsFixed(2)}'),
                  const Spacer(),
                  Text(
                    'Fark: ${(item.yeniStok - item.mevcutStok).toStringAsFixed(2)}',
                    style: TextStyle(
                      color: (item.yeniStok - item.mevcutStok) > 0
                          ? Colors.green
                          : (item.yeniStok - item.mevcutStok) < 0
                              ? Colors.red
                              : Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text('Satış Fiyatı: ${item.urun.satisFiyat.toStringAsFixed(2)} ${item.urun.paraBirimi}',
                  style: TextStyle(color: Colors.blue[800], fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: item.controller,
                      focusNode: item.focusNode,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Yeni Stok',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (value) => _stokGuncelle(item, value),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => _ilaveStokGir(item),
                    tooltip: 'Stok İlave Et',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class StokSayimItem {
  final Urun urun;
  double mevcutStok;
  double yeniStok;
  final TextEditingController controller;
  final FocusNode focusNode;

  StokSayimItem({
    required this.urun,
    required this.mevcutStok,
    required this.yeniStok,
  }) : controller = TextEditingController(text: yeniStok == 0 ? '' : yeniStok.toStringAsFixed(2)),
        focusNode = FocusNode();
}