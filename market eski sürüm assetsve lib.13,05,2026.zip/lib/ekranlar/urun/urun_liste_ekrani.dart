// lib/ekranlar/urun/urun_liste_ekrani.dart

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/rotalar.dart';
import 'package:market_uygulamasi/widgetlar/barkod_tarayici.dart';
import 'package:market_uygulamasi/ekranlar/urun/toplu_islem_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/promosyon/promosyon.dart';
import 'package:market_uygulamasi/ekranlar/urun/urun_detay_ekrani.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:excel/excel.dart' as excel_pkg;
import 'package:intl/intl.dart';

// ─── Renk Paleti ────────────────────────────
class _R {
  static const bg       = Color(0xFFF5F6FA);
  static const primary  = Color(0xFF1A237E);
  static const accent   = Color(0xFF3949AB);
  static const success  = Color(0xFF2E7D32);
  static const danger   = Color(0xFFC62828);
  static const warning  = Color(0xFFE65100);
  static const card     = Colors.white;
  static const textHead = Color(0xFF1A1A2E);
  static const textSub  = Color(0xFF6B7280);
}

// ─── Sıralama Seçenekleri ───────────────────
enum SiralamaSecenegi { adAZ, adZA, fiyatArtan, fiyatAzalan, stokArtan, stokAzalan, karOrani }

extension SiralamaAdi on SiralamaSecenegi {
  String get label {
    switch (this) {
      case SiralamaSecenegi.adAZ:       return 'Ad (A→Z)';
      case SiralamaSecenegi.adZA:       return 'Ad (Z→A)';
      case SiralamaSecenegi.fiyatArtan: return 'Fiyat Artan';
      case SiralamaSecenegi.fiyatAzalan:return 'Fiyat Azalan';
      case SiralamaSecenegi.stokArtan:  return 'Stok Artan';
      case SiralamaSecenegi.stokAzalan: return 'Stok Azalan';
      case SiralamaSecenegi.karOrani:   return 'Kâr Oranı';
    }
  }
}

// ─── Görünüm Modu ───────────────────────────
enum GoruntumModu { liste, izgara }

// ═══════════════════════════════════════════
class UrunListeEkrani extends StatefulWidget {
  @override
  State<UrunListeEkrani> createState() => _UrunListeEkraniState();
}

class _UrunListeEkraniState extends State<UrunListeEkrani>
    with SingleTickerProviderStateMixin {
  final _repo = UrunRepoSitory();
  final _aramaCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  List<Urun> _tumUrunler = [];
  List<Urun> _gosterilenUrunler = [];
  Set<int> _seciliIds = {};

  bool _yukleniyor = false;
  GoruntumModu _goruntum = GoruntumModu.liste;
  SiralamaSecenegi _siralama = SiralamaSecenegi.adAZ;
  Timer? _debounce;

  // Filtreler
  String? _filtreGrup;
  String? _filtreMarka;
  bool? _filtreStokDurumu; // true=stokta, false=tükendi, null=tümü
  bool? _filtrePromosyon;

  final _para = NumberFormat('#,##0.00', 'tr_TR');

  // Gruplar & Markalar dinamik
  List<String> get _gruplar => _tumUrunler.map((u) => u.anagrup ?? '').where((g) => g.isNotEmpty).toSet().toList()..sort();
  List<String> get _markalar => _tumUrunler.map((u) => u.marka ?? '').where((m) => m.isNotEmpty).toSet().toList()..sort();

  bool get _filtreAktif => _filtreGrup != null || _filtreMarka != null || _filtreStokDurumu != null || _filtrePromosyon != null;

  @override
  void initState() {
    super.initState();
    _urunleriYukle();
    _aramaCtrl.addListener(_aramaChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _aramaCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  // ── Veri ────────────────────────────────────
  Future<void> _urunleriYukle() async {
    setState(() => _yukleniyor = true);
    try {
      final list = await _repo.tumUrunleriGetir();
      _tumUrunler = list;
      _uygula();
    } catch (e) {
      _snack('Yükleme hatası: $e', hata: true);
    } finally {
      setState(() => _yukleniyor = false);
    }
  }

  void _aramaChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 280), _uygula);
  }

  void _uygula() {
    final q = _aramaCtrl.text.toLowerCase();
    List<Urun> sonuc = _tumUrunler.where((u) {
      // Arama
      final adOk = q.isEmpty || (u.ad.toLowerCase().contains(q)) ||
          (u.barkod.toLowerCase().contains(q)) ||
          (u.kod.toLowerCase().contains(q)) ||
          (u.marka?.toLowerCase().contains(q) ?? false) ||
          (u.anagrup?.toLowerCase().contains(q) ?? false);
      // Grup filtresi
      final grupOk = _filtreGrup == null || u.anagrup == _filtreGrup;
      // Marka filtresi
      final markaOk = _filtreMarka == null || u.marka == _filtreMarka;
      // Stok durumu
      final stokOk = _filtreStokDurumu == null ||
          (_filtreStokDurumu! ? u.stokMiktari > 0 : u.stokMiktari <= 0);
      // Promosyon
      final promOk = _filtrePromosyon == null || u.promosyonAktif == _filtrePromosyon;
      return adOk && grupOk && markaOk && stokOk && promOk;
    }).toList();

    // Sıralama
    switch (_siralama) {
      case SiralamaSecenegi.adAZ:        sonuc.sort((a, b) => a.ad.compareTo(b.ad)); break;
      case SiralamaSecenegi.adZA:        sonuc.sort((a, b) => b.ad.compareTo(a.ad)); break;
      case SiralamaSecenegi.fiyatArtan:  sonuc.sort((a, b) => a.satisFiyat.compareTo(b.satisFiyat)); break;
      case SiralamaSecenegi.fiyatAzalan: sonuc.sort((a, b) => b.satisFiyat.compareTo(a.satisFiyat)); break;
      case SiralamaSecenegi.stokArtan:   sonuc.sort((a, b) => a.stokMiktari.compareTo(b.stokMiktari)); break;
      case SiralamaSecenegi.stokAzalan:  sonuc.sort((a, b) => b.stokMiktari.compareTo(a.stokMiktari)); break;
      case SiralamaSecenegi.karOrani:
        sonuc.sort((a, b) => _karOrani(b).compareTo(_karOrani(a))); break;
    }

    setState(() => _gosterilenUrunler = sonuc);
  }

  double _karOrani(Urun u) {
    final alis = u.alisFiyat ?? 0;
    if (alis <= 0) return 0;
    return ((u.satisFiyat - alis) / alis) * 100;
  }

  // ── Seçim işlemleri ─────────────────────────
  void _secimToggle(int id) => setState(() {
    _seciliIds.contains(id) ? _seciliIds.remove(id) : _seciliIds.add(id);
  });

  void _tumunuSec() => setState(() {
    if (_seciliIds.length == _gosterilenUrunler.length) {
      _seciliIds.clear();
    } else {
      _seciliIds = _gosterilenUrunler.map((u) => u.id!).toSet();
    }
  });

  List<Urun> get _seciliUrunler =>
      _tumUrunler.where((u) => _seciliIds.contains(u.id)).toList();

  // ── Silme ────────────────────────────────────
  Future<void> _seciliUrunleriSil() async {
    final onay = await _dialog(
      'Ürünleri Sil',
      '${_seciliIds.length} ürün kalıcı olarak silinecek. Emin misiniz?',
    );
    if (onay != true) return;
    for (final id in _seciliIds) await _repo.urunSil(id);
    setState(() => _seciliIds.clear());
    _snack('${_seciliIds.length} ürün silindi', hata: false);
    await _urunleriYukle();
  }

  // ── Barkod okuma ─────────────────────────────
  Future<void> _barkodOku() async {
    final barkod = await Navigator.push<String>(
        context, MaterialPageRoute(builder: (_) => BarkodTarayici()));
    if (barkod == null || barkod.isEmpty) return;
    _aramaCtrl.text = barkod;
    _uygula();
    if (_gosterilenUrunler.isEmpty) {
      final ekle = await _dialog(
        'Ürün Bulunamadı',
        '"$barkod" barkodlu ürün yok.\nYeni ürün eklemek ister misiniz?',
        onayLabel: 'Ekle',
      );
      if (ekle == true) {
        final sonuc = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => UrunDetayEkrani(baslangicBarkod: barkod)));
        if (sonuc == true) await _urunleriYukle();
      }
    }
  }

  // ── Export ────────────────────────────────────
  List<Urun> get _aktarilacak =>
      _seciliIds.isNotEmpty ? _seciliUrunler : _gosterilenUrunler;

  Future<void> _excelAktar() async {
    if (_aktarilacak.isEmpty) { _snack('Aktarılacak ürün yok', hata: true); return; }
    try {
      final ex = excel_pkg.Excel.createExcel();
      final sh = ex['Ürünler'];
      sh.appendRow(['Kod','Barkod','Ürün Adı','Birim','Alış','Alış KDV\'li','Satış',
        'KDV%','Stok','Ana Grup','Alt Grup','Marka','İndirim%','İndirimli Fiyat',
        'Kâr Oranı%','Promosyon']);
      for (final u in _aktarilacak) {
        final kdvliAlis = u.alisFiyatKdvDahil ?? (u.alisFiyat ?? 0) * (1 + (u.kdvOrani ?? 0) / 100);
        final kar = _karOrani(u);
        sh.appendRow([
          u.kod, u.barkod, u.ad, u.birim ?? '',
          (u.alisFiyat ?? 0).toStringAsFixed(3),
          kdvliAlis.toStringAsFixed(3),
          u.satisFiyat.toStringAsFixed(3),
          (u.kdvOrani ?? 0).toStringAsFixed(0),
          u.stokMiktari.toStringAsFixed(2),
          u.anagrup ?? '', u.altGrup ?? '', u.marka ?? '',
          (u.indirimOrani ?? 0).toStringAsFixed(2),
          (u.indirimliFiyat ?? u.satisFiyat).toStringAsFixed(2),
          kar.toStringAsFixed(2),
          u.promosyonAktif ? 'Evet' : 'Hayır',
        ]);
      }
      final bytes = ex.encode();
      if (bytes == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/urunler_${DateTime.now().millisecondsSinceEpoch}.xlsx');
      await file.writeAsBytes(bytes, flush: true);
      await Share.shareXFiles([XFile(file.path)], text: 'Ürün Listesi');
    } catch (e) { _snack('Excel hatası: $e', hata: true); }
  }

  Future<void> _csvAktar() async {
    if (_aktarilacak.isEmpty) { _snack('Aktarılacak ürün yok', hata: true); return; }
    try {
      final buf = StringBuffer()..write('\uFEFF');
      buf.writeln('Kod,Barkod,Ürün Adı,Birim,Alış,Alış KDV\'li,Satış,KDV%,Stok,Ana Grup,Marka,Kâr%');
      for (final u in _aktarilacak) {
        final kdv = u.alisFiyatKdvDahil ?? (u.alisFiyat ?? 0) * (1 + (u.kdvOrani ?? 0) / 100);
        final row = [u.kod, u.barkod, u.ad, u.birim ?? '',
          (u.alisFiyat ?? 0).toStringAsFixed(3), kdv.toStringAsFixed(3),
          u.satisFiyat.toStringAsFixed(3), (u.kdvOrani ?? 0).toStringAsFixed(0),
          u.stokMiktari.toStringAsFixed(2), u.anagrup ?? '', u.marka ?? '',
          _karOrani(u).toStringAsFixed(2)]
            .map((v) => v.contains(',') ? '"$v"' : v).join(',');
        buf.writeln(row);
      }
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/urunler_${DateTime.now().millisecondsSinceEpoch}.csv');
      await file.writeAsString(buf.toString(), encoding: utf8);
      await Share.shareXFiles([XFile(file.path)], text: 'Ürün Listesi CSV');
      _snack('CSV hazır', hata: false);
    } catch (e) { _snack('CSV hatası: $e', hata: true); }
  }

  // ── Filtre sheet ─────────────────────────────
  void _filtreSheet() {
    String? gGrup = _filtreGrup;
    String? gMarka = _filtreMarka;
    bool? gStok = _filtreStokDurumu;
    bool? gProm = _filtrePromosyon;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(builder: (ctx, ss) {
      Widget chip<T>(String label, T? value, T? myValue, VoidCallback fn) {
  final secili = value == myValue;
  return FilterChip(
    label: Text(
      label,
      style: TextStyle(
        fontSize: 12,
        color: secili ? Colors.white : _R.textSub,
      ),
    ),
    selected: secili,
    onSelected: (_) => ss(fn),
    selectedColor: _R.accent,
    backgroundColor: Colors.white,
    side: BorderSide(color: secili ? _R.accent : Colors.grey.shade300),
    showCheckmark: false,
    padding: const EdgeInsets.symmetric(horizontal: 6),
  );
}

        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 40, height: 4,
                decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 16),
            Row(children: [
              const Text('Filtrele', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const Spacer(),
              TextButton(
                onPressed: () => ss(() { gGrup = null; gMarka = null; gStok = null; gProm = null; }),
                child: const Text('Sıfırla'),
              ),
            ]),
            const Divider(),

            // Stok Durumu
            _filtreBolum('Stok Durumu'),
            Wrap(spacing: 8, children: [
              chip('Tümü',   gStok, null,  () => gStok = null),
              chip('Stokta', gStok, true,  () => gStok = true),
              chip('Tükendi',gStok, false, () => gStok = false),
            ]),
            const SizedBox(height: 12),

            // Promosyon
            _filtreBolum('Promosyon'),
            Wrap(spacing: 8, children: [
              chip('Tümü',   gProm, null,  () => gProm = null),
              chip('Aktif',  gProm, true,  () => gProm = true),
              chip('Pasif',  gProm, false, () => gProm = false),
            ]),
            const SizedBox(height: 12),

            // Ana Grup
            if (_gruplar.isNotEmpty) ...[
              _filtreBolum('Ana Grup'),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: chip('Tümü', gGrup, gGrup == null, () => gGrup = null),
                    ),
                    ..._gruplar.map((g) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: chip(g, gGrup, g == gGrup, () => gGrup = g == gGrup ? null : g),
                    )),
                  ],
                ),
              ),
              const SizedBox(height: 12),
            ],

            // Marka
            if (_markalar.isNotEmpty) ...[
              _filtreBolum('Marka'),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: chip('Tümü', gMarka, gMarka == null, () => gMarka = null),
                    ),
                    ..._markalar.map((m) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: chip(m, gMarka, m == gMarka, () => gMarka = m == gMarka ? null : m),
                    )),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],

            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: _R.primary,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () {
                  setState(() {
                    _filtreGrup = gGrup; _filtreMarka = gMarka;
                    _filtreStokDurumu = gStok; _filtrePromosyon = gProm;
                  });
                  _uygula();
                  Navigator.pop(ctx);
                },
                child: const Text('Uygula', style: TextStyle(fontSize: 15)),
              ),
            ),
          ]),
        );
      }),
    );
  }

  Widget _filtreBolum(String baslik) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Align(
      alignment: Alignment.centerLeft,
      child: Text(baslik,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: _R.textSub)),
    ),
  );

  // ── Sıralama ──────────────────────────────────
  void _siralamaSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 16),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('Sırala', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          const Divider(),
          ...SiralamaSecenegi.values.map((s) => RadioListTile<SiralamaSecenegi>(
            dense: true,
            value: s,
            groupValue: _siralama,
            title: Text(s.label, style: const TextStyle(fontSize: 14)),
            activeColor: _R.primary,
            onChanged: (v) {
              setState(() => _siralama = v!);
              _uygula();
              Navigator.pop(context);
            },
          )),
        ]),
      ),
    );
  }

  // ── Yardımcı ──────────────────────────────────
  void _snack(String msg, {required bool hata}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: hata ? _R.danger : _R.success,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  Future<bool?> _dialog(String baslik, String icerik, {String onayLabel = 'Evet'}) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(baslik),
        content: Text(icerik),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: _R.primary),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(onayLabel),
          ),
        ],
      ),
    );
  }

  // ══ BUILD ══════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final secimVarMi = _seciliIds.isNotEmpty;
    return Scaffold(
      backgroundColor: _R.bg,
      body: NestedScrollView(
        controller: _scrollCtrl,
        headerSliverBuilder: (_, innerScrolled) => [
          _buildAppBar(secimVarMi),
        ],
        body: Column(children: [
          _buildAramaSatiri(),
          _buildOzetSatiri(),
          Expanded(
            child: _yukleniyor
                ? const Center(child: CircularProgressIndicator())
                : _gosterilenUrunler.isEmpty
                    ? _bostState()
                    : _goruntum == GoruntumModu.liste
                        ? _listeView()
                        : _izgaraView(),
          ),
          _secimActionBar(secimVarMi),
        ]),
      ),
      floatingActionButton: secimVarMi
          ? null
          : FloatingActionButton.extended(
              onPressed: () async {
                final sonuc = await Navigator.pushNamed(context, Rotalar.urunDetay);
                if (sonuc == true) await _urunleriYukle();
              },
              icon: const Icon(Icons.add),
              label: const Text('Yeni Ürün'),
              backgroundColor: _R.primary,
            ),
    );
  }

  // ── AppBar ────────────────────────────────────
  SliverAppBar _buildAppBar(bool secimVarMi) {
    return SliverAppBar(
      pinned: true,
      floating: true,
      snap: true,
      backgroundColor: secimVarMi ? _R.accent : _R.primary,
      foregroundColor: Colors.white,
      title: secimVarMi
          ? Text('${_seciliIds.length} ürün seçildi',
              style: const TextStyle(fontWeight: FontWeight.w600))
          : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Ürün Listesi',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              Text('${_tumUrunler.length} ürün',
                  style: const TextStyle(fontSize: 11, color: Colors.white70)),
            ]),
      leading: secimVarMi
          ? IconButton(
              icon: const Icon(Icons.close),
              onPressed: () => setState(() => _seciliIds.clear()),
            )
          : null,
      actions: secimVarMi
          ? [
              IconButton(
                icon: const Icon(Icons.select_all),
                tooltip: 'Tümünü Seç',
                onPressed: _tumunuSec,
              ),
              IconButton(
                icon: const Icon(Icons.local_offer_outlined),
                tooltip: 'Promosyon Ekle',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PromosyonEkrani(baslangicUrunleri: _seciliUrunler),
                    ),
                  ).then((_) => _urunleriYukle());
                },
              ),
              IconButton(
                icon: const Icon(Icons.settings_input_component_outlined),
                tooltip: 'Toplu İşlem',
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => TopluIslemEkrani(seciliUrunler: _seciliUrunler))),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                tooltip: 'Sil',
                onPressed: _seciliUrunleriSil,
              ),
            ]
          : [
              IconButton(
                icon: const Icon(Icons.qr_code_scanner_rounded),
                tooltip: 'Barkod Tara',
                onPressed: _barkodOku,
              ),
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                itemBuilder: (_) => [
                  _menuItem('excel', Icons.table_chart_outlined, 'Excel Olarak Dışa Aktar'),
                  _menuItem('csv',   Icons.text_snippet_outlined,  'CSV Olarak Dışa Aktar'),
                  const PopupMenuDivider(),
                  _menuItem('toplu', Icons.tune_rounded, 'Toplu İşlem'),
                  _menuItem('refresh', Icons.refresh_rounded, 'Yenile'),
                ],
                onSelected: (v) async {
                  if (v == 'excel') _excelAktar();
                  else if (v == 'csv') _csvAktar();
                  else if (v == 'refresh') _urunleriYukle();
                  else if (v == 'toplu') Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => TopluIslemEkrani(seciliUrunler: _gosterilenUrunler)),
                  );
                },
              ),
            ],
    );
  }

  PopupMenuItem<String> _menuItem(String v, IconData ikon, String label) {
    return PopupMenuItem(
      value: v,
      child: Row(children: [
        Icon(ikon, size: 18, color: _R.textSub),
        const SizedBox(width: 10),
        Text(label, style: const TextStyle(fontSize: 14)),
      ]),
    );
  }

  // ── Arama Satırı ──────────────────────────────
  Widget _buildAramaSatiri() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 6),
      child: Row(children: [
        // Arama kutusu
        Expanded(
          child: Container(
            height: 46,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6, offset: const Offset(0, 2))],
            ),
            child: Row(children: [
              const SizedBox(width: 12),
              const Icon(Icons.search_rounded, color: _R.textSub, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _aramaCtrl,
                  style: const TextStyle(fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: 'Ad, barkod, kod, marka...',
                    hintStyle: TextStyle(color: _R.textSub, fontSize: 13),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
              ),
              if (_aramaCtrl.text.isNotEmpty)
                IconButton(
                  icon: const Icon(Icons.close, size: 18, color: _R.textSub),
                  onPressed: () { _aramaCtrl.clear(); _uygula(); },
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                )
              else
                const SizedBox(width: 36),
            ]),
          ),
        ),
        const SizedBox(width: 8),
        // Filtre
        _ToolBtn(
          ikon: Icons.tune_rounded,
          aktif: _filtreAktif,
          onTap: _filtreSheet,
        ),
        const SizedBox(width: 6),
        // Sıralama
        _ToolBtn(
          ikon: Icons.sort_rounded,
          onTap: _siralamaSheet,
        ),
        const SizedBox(width: 6),
        // Görünüm
        _ToolBtn(
          ikon: _goruntum == GoruntumModu.liste
              ? Icons.grid_view_rounded
              : Icons.view_list_rounded,
          onTap: () => setState(() {
            _goruntum = _goruntum == GoruntumModu.liste
                ? GoruntumModu.izgara
                : GoruntumModu.liste;
          }),
        ),
      ]),
    );
  }

  // ── Özet İstatistik Satırı ────────────────────
  Widget _buildOzetSatiri() {
    final toplam = _gosterilenUrunler.length;
    final tukendi = _gosterilenUrunler.where((u) => u.stokMiktari <= 0).length;
    final kritik  = _gosterilenUrunler.where((u) => u.stokMiktari > 0 && u.stokMiktari < 5).length;
    final prom    = _gosterilenUrunler.where((u) => u.promosyonAktif).length;

    return SizedBox(
      height: 60,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        children: [
          _istatKart('Toplam', toplam.toString(), Colors.indigo, Icons.inventory_2_outlined),
          _istatKart('Tükendi', tukendi.toString(), _R.danger, Icons.remove_circle_outline),
          _istatKart('Kritik', kritik.toString(), _R.warning, Icons.warning_amber_outlined),
          _istatKart('Promosyon', prom.toString(), Colors.purple, Icons.local_offer_outlined),
          if (_filtreAktif)
            _istatKart('Filtreli', toplam.toString(), _R.accent, Icons.filter_alt_outlined),
        ],
      ),
    );
  }

  Widget _istatKart(String baslik, String deger, Color renk, IconData ikon) {
    return Container(
      margin: const EdgeInsets.only(right: 8, bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: renk.withOpacity(0.09),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: renk.withOpacity(0.2)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(ikon, size: 16, color: renk),
        const SizedBox(width: 6),
        Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(deger, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: renk)),
          Text(baslik, style: TextStyle(fontSize: 10, color: renk.withOpacity(0.7))),
        ]),
      ]),
    );
  }

  // ── Liste Görünüm ─────────────────────────────
  Widget _listeView() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 100),
      itemCount: _gosterilenUrunler.length,
      itemBuilder: (_, i) => _listeKarti(_gosterilenUrunler[i]),
    );
  }

  Widget _listeKarti(Urun u) {
    final secili = _seciliIds.contains(u.id);
    final stokAz = u.stokMiktari > 0 && u.stokMiktari < 5;
    final stokYok = u.stokMiktari <= 0;
    final kdvliAlis = u.alisFiyatKdvDahil ??
        (u.alisFiyat ?? 0) * (1 + (u.kdvOrani ?? 0) / 100);
    final kar = _karOrani(u);

    return GestureDetector(
      onLongPress: () => _secimToggle(u.id!),
      onTap: () async {
        if (_seciliIds.isNotEmpty) {
          _secimToggle(u.id!);
        } else {
          final sonuc = await Navigator.pushNamed(context, Rotalar.urunDetay, arguments: u);
          if (sonuc == true) await _urunleriYukle();
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: secili ? _R.accent.withOpacity(0.08) : _R.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: secili
                ? _R.accent
                : stokYok
                    ? _R.danger.withOpacity(0.25)
                    : stokAz
                        ? _R.warning.withOpacity(0.35)
                        : Colors.transparent,
            width: secili ? 1.5 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(secili ? 0.06 : 0.04),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(children: [
            // ── Resim / Harf avatar ───────────────
            _UrunAvatar(urun: u, secili: secili),
            const SizedBox(width: 12),

            // ── Orta bilgi ────────────────────────
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Ad + Promosyon badge
                Row(children: [
                  Expanded(
                    child: Text(u.ad,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                          color: secili ? _R.accent : _R.textHead,
                        )),
                  ),
                  if (u.promosyonAktif)
                    _Badge('PROMO', Colors.purple),
                ]),
                const SizedBox(height: 3),

                // Kod & Barkod
                Row(children: [
                  if (u.kod.isNotEmpty) ...[
                    Icon(Icons.tag, size: 11, color: _R.textSub),
                    const SizedBox(width: 2),
                    Text(u.kod, style: const TextStyle(fontSize: 11, color: _R.textSub)),
                    const SizedBox(width: 8),
                  ],
                  Icon(Icons.qr_code, size: 11, color: _R.textSub),
                  const SizedBox(width: 2),
                  Expanded(
                    child: Text(u.barkod,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, color: _R.textSub)),
                  ),
                ]),

                // Grup & Marka
                if ((u.anagrup?.isNotEmpty ?? false) || (u.marka?.isNotEmpty ?? false)) ...[
                  const SizedBox(height: 2),
                  Row(children: [
                    if (u.anagrup?.isNotEmpty ?? false) ...[
                      Icon(Icons.folder_outlined, size: 11, color: _R.textSub),
                      const SizedBox(width: 2),
                      Text(u.anagrup!, style: const TextStyle(fontSize: 11, color: _R.textSub)),
                      const SizedBox(width: 8),
                    ],
                    if (u.marka?.isNotEmpty ?? false) ...[
                      Icon(Icons.label_outline, size: 11, color: _R.textSub),
                      const SizedBox(width: 2),
                      Expanded(
                        child: Text(u.marka!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 11, color: _R.textSub)),
                      ),
                    ],
                  ]),
                ],

                const SizedBox(height: 6),

                // Fiyat satırı
                Row(children: [
                  // KDV'li alış
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Alış (KDV\'li)', style: TextStyle(fontSize: 9, color: _R.textSub)),
                    Text('${_para.format(kdvliAlis)} ₺',
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: _R.warning)),
                  ]),
                  const SizedBox(width: 14),
                  // Kâr oranı
                  if (u.alisFiyat != null && u.alisFiyat! > 0)
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Kâr', style: TextStyle(fontSize: 9, color: _R.textSub)),
                      Text('%${kar.toStringAsFixed(1)}',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: kar >= 0 ? _R.success : _R.danger,
                          )),
                    ]),
                ]),
              ]),
            ),
            const SizedBox(width: 10),

            // ── Sağ: Satış fiyatı + Stok ─────────
            Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('${_para.format(u.satisFiyat)} ₺',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold, color: _R.primary)),
              const SizedBox(height: 4),
              _StokBadge(stok: u.stokMiktari, birim: u.birim ?? 'Adet'),
              if (secili) ...[
                const SizedBox(height: 4),
                const Icon(Icons.check_circle_rounded, color: _R.accent, size: 18),
              ],
            ]),
          ]),
        ),
      ),
    );
  }

  // ── Izgara Görünüm ────────────────────────────
  Widget _izgaraView() {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 100),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.75,
      ),
      itemCount: _gosterilenUrunler.length,
      itemBuilder: (_, i) => _izgaraKarti(_gosterilenUrunler[i]),
    );
  }

  Widget _izgaraKarti(Urun u) {
    final secili = _seciliIds.contains(u.id);
    final stokYok = u.stokMiktari <= 0;
    final stokAz  = u.stokMiktari > 0 && u.stokMiktari < 5;

    return GestureDetector(
      onLongPress: () => _secimToggle(u.id!),
      onTap: () async {
        if (_seciliIds.isNotEmpty) {
          _secimToggle(u.id!);
        } else {
          final sonuc = await Navigator.pushNamed(context, Rotalar.urunDetay, arguments: u);
          if (sonuc == true) await _urunleriYukle();
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          color: secili ? _R.accent.withOpacity(0.07) : _R.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: secili ? _R.accent : Colors.transparent,
            width: 1.5,
          ),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Üst: Avatar / Resim alanı
          Expanded(
            child: Stack(children: [
              Center(child: _UrunAvatar(urun: u, secili: secili, boyut: 60, fontBoyut: 22)),
              // Stok tükenmiş overlay
              if (stokYok)
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.12),
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                    ),
                    child: const Center(
                      child: RotationTransition(
                        turns: AlwaysStoppedAnimation(-0.08),
                        child: _Badge('TÜKENDİ', _R.danger),
                      ),
                    ),
                  ),
                ),
              if (u.promosyonAktif)
                const Positioned(top: 8, right: 8, child: _Badge('PROMO', Colors.purple)),
              if (secili)
                const Positioned(
                  top: 8, left: 8,
                  child: CircleAvatar(
                    radius: 10,
                    backgroundColor: _R.accent,
                    child: Icon(Icons.check, size: 12, color: Colors.white),
                  ),
                ),
            ]),
          ),

          // Alt: bilgi
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(u.ad,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, height: 1.2)),
              if (u.marka?.isNotEmpty ?? false) ...[
                const SizedBox(height: 2),
                Text(u.marka!, style: const TextStyle(fontSize: 10, color: _R.textSub),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
              const SizedBox(height: 6),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('${_para.format(u.satisFiyat)} ₺',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: _R.primary)),
                _StokBadge(stok: u.stokMiktari, birim: u.birim ?? 'Adet', kucuk: true),
              ]),
              if (stokAz)
                Text('Kritik Stok!',
                    style: TextStyle(fontSize: 10, color: _R.warning, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── Seçim Action Bar ─────────────────────────
  Widget _secimActionBar(bool goruntule) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeInOut,
      height: goruntule ? 72 : 0,
      child: goruntule
          ? Container(
              decoration: BoxDecoration(
                color: _R.primary,
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 12, offset: const Offset(0, -3))
                ],
              ),
              child: SafeArea(
                top: false,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _barBtn(Icons.local_offer_outlined, 'Promosyon', () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => PromosyonEkrani(baslangicUrunleri: _seciliUrunler)),
                      ).then((_) => _urunleriYukle());
                    }),
                    _barBtn(Icons.tune_rounded, 'Toplu İşlem', () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => TopluIslemEkrani(seciliUrunler: _seciliUrunler)),
                      );
                    }),
                    _barBtn(Icons.upload_file_outlined, 'Dışa Aktar', _excelAktar),
                    _barBtn(Icons.delete_outline, 'Sil', _seciliUrunleriSil, renk: _R.danger),
                  ],
                ),
              ),
            )
          : const SizedBox(),
    );
  }

  Widget _barBtn(IconData ikon, String label, VoidCallback onTap, {Color? renk}) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(ikon, color: renk ?? Colors.white, size: 22),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 10, color: renk ?? Colors.white70)),
        ]),
      ),
    );
  }

  // ── Boş state ────────────────────────────────
  Widget _bostState() {
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.inventory_2_outlined, size: 80, color: Colors.grey[300]),
        const SizedBox(height: 16),
        Text(
          _aramaCtrl.text.isNotEmpty || _filtreAktif
              ? 'Ürün bulunamadı'
              : 'Henüz ürün yok',
          style: TextStyle(fontSize: 17, color: Colors.grey[400], fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        if (_aramaCtrl.text.isNotEmpty || _filtreAktif)
          TextButton(
            onPressed: () {
              _aramaCtrl.clear();
              setState(() { _filtreGrup = null; _filtreMarka = null; _filtreStokDurumu = null; _filtrePromosyon = null; });
              _uygula();
            },
            child: const Text('Filtreyi Temizle'),
          )
        else
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: _R.primary),
            onPressed: () async {
              final sonuc = await Navigator.pushNamed(context, Rotalar.urunDetay);
              if (sonuc == true) await _urunleriYukle();
            },
            icon: const Icon(Icons.add),
            label: const Text('İlk Ürünü Ekle'),
          ),
      ]),
    );
  }
}

// ═══════════════════════════════════════════
//  Alt Widget'lar
// ═══════════════════════════════════════════

class _UrunAvatar extends StatelessWidget {
  final Urun urun;
  final bool secili;
  final double boyut;
  final double fontBoyut;
  const _UrunAvatar({required this.urun, required this.secili, this.boyut = 50, this.fontBoyut = 17});

  Color _renkUret(String s) {
    final renkler = [
      const Color(0xFF3949AB), const Color(0xFF0277BD), const Color(0xFF00695C),
      const Color(0xFF558B2F), const Color(0xFF6A1B9A), const Color(0xFFAD1457),
      const Color(0xFF4E342E), const Color(0xFF37474F),
    ];
    if (s.isEmpty) return renkler[0];
    return renkler[s.codeUnitAt(0) % renkler.length];
  }

  @override
  Widget build(BuildContext context) {
    final harf = urun.ad.isNotEmpty ? urun.ad[0].toUpperCase() : '?';
    final renk = _renkUret(urun.ad);

    if (urun.resimYolu != null && urun.resimYolu!.isNotEmpty && File(urun.resimYolu!).existsSync()) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Image.file(File(urun.resimYolu!),
            width: boyut, height: boyut, fit: BoxFit.cover),
      );
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: boyut,
      height: boyut,
      decoration: BoxDecoration(
        color: secili ? _R.accent : renk.withOpacity(0.15),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Text(
          secili ? '✓' : harf,
          style: TextStyle(
            fontSize: fontBoyut,
            fontWeight: FontWeight.bold,
            color: secili ? Colors.white : renk,
          ),
        ),
      ),
    );
  }
}

class _StokBadge extends StatelessWidget {
  final double stok;
  final String birim;
  final bool kucuk;
  const _StokBadge({required this.stok, required this.birim, this.kucuk = false});

  @override
  Widget build(BuildContext context) {
    final Color renk;
    final String label;
    if (stok <= 0) {
      renk = _R.danger; label = 'Tükendi';
    } else if (stok < 5) {
      renk = _R.warning; label = '${stok.toStringAsFixed(stok == stok.roundToDouble() ? 0 : 1)} $birim';
    } else {
      renk = _R.success; label = '${stok.toStringAsFixed(stok == stok.roundToDouble() ? 0 : 1)} $birim';
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: kucuk ? 6 : 8, vertical: kucuk ? 2 : 3),
      decoration: BoxDecoration(
        color: renk.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: renk.withOpacity(0.3)),
      ),
      child: Text(label,
          style: TextStyle(
              fontSize: kucuk ? 10 : 11,
              fontWeight: FontWeight.w700,
              color: renk)),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color renk;
  const _Badge(this.label, this.renk);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: renk,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(label,
          style: const TextStyle(fontSize: 9, color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
    );
  }
}

class _ToolBtn extends StatelessWidget {
  final IconData ikon;
  final VoidCallback onTap;
  final bool aktif;
  const _ToolBtn({required this.ikon, required this.onTap, this.aktif = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(
          color: aktif ? _R.accent.withOpacity(0.12) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: aktif ? _R.accent : Colors.grey.shade200),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 1))],
        ),
        child: Stack(children: [
          Center(child: Icon(ikon, size: 20, color: aktif ? _R.accent : _R.textSub)),
          if (aktif)
            Positioned(
              right: 7, top: 7,
              child: Container(
                width: 7, height: 7,
                decoration: BoxDecoration(color: _R.accent, borderRadius: BorderRadius.circular(4)),
              ),
            ),
        ]),
      ),
    );
  }
}