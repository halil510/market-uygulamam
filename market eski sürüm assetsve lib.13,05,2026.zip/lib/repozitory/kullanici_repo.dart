import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:sqflite/sqflite.dart';
import 'package:market_uygulamasi/modeller/kullanici.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';

class KullaniciRepository {
  final VeritabaniYardimcisi _dbHelper = VeritabaniYardimcisi();

  Future<Database> get _db async => _dbHelper.db;

  String _hash(String s) {
    final bytes = utf8.encode(s);
    return sha256.convert(bytes).toString();
  }

  Future<Kullanici?> girisYap(String kullaniciAdi, String sifre) async {
    final db = await _db;

    // 1. Hash'li kontol
    final hashedSifre = _hash(sifre);
    var maps = await db.query(
      'kullanicilar',
      where: 'kullaniciAdi = ? AND sifre = ?',
      whereArgs: [kullaniciAdi, hashedSifre],
      limit: 1,
    );
    if (maps.isNotEmpty) {
      return Kullanici.fromMap(maps.first);
    }

    // 2. Düz metin kontrol (eski veri)
    maps = await db.query(
      'kullanicilar',
      where: 'kullaniciAdi = ? AND sifre = ?',
      whereArgs: [kullaniciAdi, sifre],
      limit: 1,
    );
    if (maps.isNotEmpty) {
      // Eski düz metin şifreyi hash'leyip güncelle
      final user = Kullanici.fromMap(maps.first);
      await db.update(
        'kullanicilar',
        {'sifre': hashedSifre},
        where: 'id = ?',
        whereArgs: [user.id],
      );
      return user;
    }

    return null;
  }

  Future<bool> sifreDegistir(String kullaniciAdi, String eskiSifre, String yeniSifre) async {
    final db = await _db;
    // Önce hash'li dene
    var sonuc = await db.query(
      'kullanicilar',
      where: 'kullaniciAdi = ? AND sifre = ?',
      whereArgs: [kullaniciAdi, _hash(eskiSifre)],
    );
    if (sonuc.isEmpty) {
      // Düz metin dene (eski şifre henüz dönüştürülmemiş olabilir)
      sonuc = await db.query(
        'kullanicilar',
        where: 'kullaniciAdi = ? AND sifre = ?',
        whereArgs: [kullaniciAdi, eskiSifre],
      );
    }
    if (sonuc.isEmpty) return false;

    await db.update(
      'kullanicilar',
      {'sifre': _hash(yeniSifre)},
      where: 'kullaniciAdi = ?',
      whereArgs: [kullaniciAdi],
    );
    return true;
  }

  Future<void> kullaniciEkle(Kullanici kullanici) async {
  final db = await _db;

  final varMi = await db.query(
    'kullanicilar',
    where: 'kullaniciAdi = ?',
    whereArgs: [kullanici.kullaniciAdi],
  );

  if (varMi.isNotEmpty) {
    throw Exception("Bu kullanıcı zaten var");
  }

  final map = kullanici.toMap();
  map['sifre'] = _hash(map['sifre']);

  await db.insert('kullanicilar', map);
}
  Future<void> kullaniciGuncelle(Kullanici kullanici) async {
    final db = await _db;
    if (kullanici.id == null) {
      throw Exception('Güncellenecek kullanıcının ID\'si boş olamaz.');
    }
    await db.update(
      'kullanicilar',
      kullanici.toMap(),
      where: 'id = ?',
      whereArgs: [kullanici.id],
    );
  }

  Future<void> kullaniciSil(int id) async {
    final db = await _db;
    await db.delete('kullanicilar', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Kullanici>> kullaniciListesiGetir() async {
    final db = await _db;
    final List<Map<String, dynamic>> maps = await db.query('kullanicilar');
    return maps.map((m) => Kullanici.fromMap(m)).toList();
  }
}