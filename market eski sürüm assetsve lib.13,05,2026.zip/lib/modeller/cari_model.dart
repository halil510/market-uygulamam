
class Cari {
  final int? id;
  final String ad;
  final double borc;
  final double alacak;

  Cari({
    this.id,
    required this.ad,
    this.borc = 0,
    this.alacak = 0,
  });

  double get bakiye => alacak - borc;

  factory Cari.fromMap(Map<String, dynamic> map) {
    return Cari(
      id: map['id'],
      ad: map['ad'],
      borc: map['borc']?.toDouble() ?? 0,
      alacak: map['alacak']?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'ad': ad,
      'borc': borc,
      'alacak': alacak,
    };
  }
}
