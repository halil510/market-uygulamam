// lib/modern_ui/theme/app_colors.dart
import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF4361EE); // Mavi - Ana vurgu rengi
  static const Color primaryGradientStart = Color(0xFF4361EE); // Mavi (gradyan başlangıç)
  static const Color primaryGradientEnd = Color(0xFF3F37C9); // Koyu mavi (gradyan bitiş)
  
  static const Color secondary = Color(0xFF3F37C9); // Koyu mavi - İkincil vurgu
  static const Color accent = Color(0xFF4895EF); // Açık mavi - Dikkat çekici vurgu
  
  static const Color background = Color(0xFFF8F9FA); // Çok açık gri - Açık tema arka plan
  static const Color backgroundLight = Color(0xFFFFFFFF); // Beyaz - Açık yüzey
  static const Color backgroundVariant = Color(0xFFE9ECEF); // Açık gri - Alternatif arka plan
  
  static const Color surface = Colors.white; // Beyaz - Kartlar ve yüzeyler
  
  static const Color darkBackground = Color(0xFF121212); // Siyah - Koyu tema arka plan
  static const Color darkSurface = Color(0xFF1E1E1E); // Koyu gri - Koyu tema yüzey
  
  static const Color error = Color(0xFFE63946); // Kırmızı - Hata ve uyarılar
  static const Color success = Color(0xFF2ECC71); // Yeşil - Başarı durumu
  static const Color warning = Color(0xFFF39C12); // Turuncu - Uyarı veya dikkat
  
  static const Color textPrimary = Color(0xFF212529); // Siyah/koyu gri - Ana metin
  static const Color textSecondary = Color(0xFF6C757D); // Orta gri - İkincil metin
  static const Color textDisabled = Color(0xFFADB5BD); // Açık gri - Pasif metin
  static const Color textHint = Color(0xFF868E96); // Gri - İpucu metin
  
  static const Color buttonHover = Color(0xFF365FCB); // Koyu mavi - Buton hover efekti
  static const Color buttonPressed = Color(0xFF2F50AA); // Çok koyu mavi - Buton basılı
  static const Color buttonDisabled = Color(0xFFB0B8C1); // Açık gri - Pasif buton
  
  static const Color border = Color(0xFFE0E0E0); // Açık gri - Kenarlık rengi
  static const Color borderDark = Color(0xFF2C2C2C); // Koyu gri - Koyu tema kenarlık
}
