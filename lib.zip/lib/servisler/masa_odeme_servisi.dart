// lib/servisler/masa_odeme_servisi.dart
// Tek sorumluluk: Açık bir masa siparişini SATIŞ kaydına çevirmek.
//   - satislar / satis_kalem oluşturur (fis_tipi: 'Masa Satış')
//   - stok düşer
//   - kasa hareketi (nakit/kart/havale kısmı) ekler
//   - varsa cari hareketi (veresiye kısmı) ekler
//   - masa_siparisleri kaydını 'odendi' yapar, masayı boşaltır
//
// Hızlı Satış ekranındaki _satisiTamamla ile aynı muhasebe mantığını
// masa/restoran akışına taşır — kod tekrarını önlemek için ortak bir
// "SatisYazimi" yardımcı tipi kullanılabilir, ancak farklı context
// (masa adı, sipariş id) nedeniyle burada bağımsız tutuldu.
import '../depolar/masa_deposu.dart';
import '../depolar/satis_deposu.dart';
import '../depolar/stok_deposu.dart';
import '../depolar/kasa_deposu.dart';
import '../depolar/cari_deposu.dart';
import '../veri/database/veritabani.dart';
import '../modeller/satis_model.dart';
import '../modeller/satis_kalem_model.dart';
import '../modeller/kasa_hareket_model.dart';
import '../modeller/cari_hareket_model.dart';
import '../modeller/masa_siparis_model.dart';
import '../servisler/auth_servisi.dart';
import '../cekirdek/utils/para_utils.dart';
import '../servisler/aktif_sube_servisi.dart';

class MasaOdemeSonuc {
  final int satisId;
  final String fisNo;
  final List<SatisKalemModel> kalemler;
  final double genelToplam;
  final double odenenTutar;
  final double paraUstu;
  final String odemeYontemi;
  MasaOdemeSonuc({
    required this.satisId, required this.fisNo, required this.kalemler,
    required this.genelToplam, required this.odenenTutar,
    required this.paraUstu, required this.odemeYontemi,
  });
}

class MasaOdemeServisi {
  final _satisDepo = SatisDeposu();
  final _stokDepo  = StokDeposu();
  final _kasaDepo  = KasaDeposu();
  final _cariDepo  = CariDeposu();
  final _masaDepo  = MasaDeposu();

  /// [odemeKalemleri]: [{'yontem': 'Nakit'|'Kredi Kartı'|'Havale/EFT'|'Cari', 'tutar': double}, ...]
  /// Çoklu Ödeme (karma) ekranından gelen formatla aynı.
  Future<MasaOdemeSonuc> odemeYap({
    required MasaSiparisModel siparis,
    required String masaAdi,
    required List<Map<String, dynamic>> odemeKalemleri,
    required double paraUstu,
    int? cariId,
    String? cariAdi,
  }) async {
    if (siparis.id == null) throw Exception('Sipariş bulunamadı');
    if (siparis.kalemler.isEmpty) throw Exception('Masada ürün yok');

    final tarih = DateTime.now();
    final kullanici = await AuthServisi().mevcutKullanici();
    // ÖNCEDEN masa satışları da normal satışlarla AYNI "satis" (MKP)
    // sayacını kullanıyordu — kullanıcı isteği: masa satışlarının kendi
    // ayrı, farklı ön ekli (MSA) fiş numarası serisi olsun.
    final fisNo = await Veritabani().fisNoUret('masa', subeId: AktifSubeServisi().subeId ?? 1);
    final genelTop = siparis.hesaplananToplam;

    final satisKalemler = siparis.kalemler.map((k) => SatisKalemModel(
      satisId: 0,
      urunId: k.urunId,
      urunAdi: k.urunAdi,
      barkod: null,
      miktar: k.miktar,
      birimFiyat: k.birimFiyat,
      toplamTutar: k.toplam,
      iskontoOran: 0, iskontoTutar: 0,
      kdvOran: k.kdvOran,
      kdvTutar: k.toplam - (k.toplam / (1 + k.kdvOran / 100)),
      netFiyat: k.toplam / (1 + k.kdvOran / 100),
      alisFiyat: 0, alisFiyatKdv: 0,
    )).toList();

    final toplamOdenen = odemeKalemleri.fold(0.0,
        (s, k) => s + (k['tutar'] as num).toDouble());
    final odemeYontemi = odemeKalemleri.length == 1
        ? odemeKalemleri.first['yontem'] as String
        : 'Karma';

    final satis = SatisModel(
      fisNo: fisNo,
      tarih: tarih,
      cariId: cariId ?? siparis.cariId,
      cariAdi: cariAdi ?? siparis.cariAdi,
      toplamTutar: genelTop,
      genelToplam: genelTop,
      odenenTutar: toplamOdenen,
      odemeYontemi: odemeYontemi,
      fisTipi: 'Masa Satış',
      aciklama: 'Masa: $masaAdi',
      kasiyerId: kullanici?.id,
      kullaniciId: kullanici?.id,
    );

    final satisId = await _satisDepo.satisEkle(satis, satisKalemler);

    // Stok düş
    for (final k in siparis.kalemler) {
      await _stokDepo.stokDus(
        urunId: k.urunId,
        miktar: k.miktar,
        kullaniciId: kullanici?.id,
        referansId: satisId,
        referansTuru: 'satis',
        aciklama: 'Masa Satış: $masaAdi ($fisNo)',
      );
    }

    // Kasa hareketi — Cari hariç tüm kalemler
    final nakitToplam = odemeKalemleri
        .where((k) => k['yontem'] != 'Cari')
        .fold(0.0, (s, k) => s + (k['tutar'] as num).toDouble());
    if (nakitToplam > 0.005) {
      final detay = odemeKalemleri.where((k) => k['yontem'] != 'Cari')
          .map((k) => '${k['yontem']}: ${ParaUtils.formatla((k['tutar'] as num).toDouble())}')
          .join(', ');
      await _kasaDepo.hareketEkle(KasaHareketModel(
        hareketTipi: 'Satış',
        tutar: nakitToplam,
        referansId: satisId,
        referansTuru: 'satis',
        tarih: tarih,
        aciklama: 'Masa Satış: $masaAdi — $fisNo ($detay)',
        kullaniciId: kullanici?.id,
      ));
    }

    // Cari hareketi — veresiye kısmı
    final cariTutar = odemeKalemleri
        .where((k) => k['yontem'] == 'Cari')
        .fold(0.0, (s, k) => s + (k['tutar'] as num).toDouble());
    final efektifCariId = cariId ?? siparis.cariId;
    if (efektifCariId != null && cariTutar > 0.005) {
      await _cariDepo.hareketEkle(CariHareketModel(
        cariId: efektifCariId,
        tarih: tarih,
        fisTipi: 'Satış',
        fisId: satisId,
        fisNo: fisNo,
        aciklama: 'Masa Veresiye: $masaAdi ($fisNo)',
        borc: cariTutar,
        alacak: 0,
        odemeTuru: 'Cari',
        kullanici: kullanici?.adSoyad,
      ));
    }

    // Masayı kapat
    await _masaDepo.siparisKapat(siparis.id!, siparis.masaId, satisId: satisId);

    return MasaOdemeSonuc(
      satisId: satisId, fisNo: fisNo, kalemler: satisKalemler,
      genelToplam: genelTop, odenenTutar: toplamOdenen,
      paraUstu: paraUstu, odemeYontemi: odemeYontemi,
    );
  }
}
