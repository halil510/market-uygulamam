class IadeKaydi {
  int? id;
  int urunId;
  String urunAdi;
  String barkod;
  double alisFiyati;
  double orijinalAlisFiyati; // Yeni eklenen alan (field olarak tanımlandı)
  double satisFiyati;
  double iadeMiktari;
  double kdvOrani;
  String nedeni;
  DateTime tarih;
  String? indirimNotu;
  String tedarikci; // Yeni eklenen alan

  /// Toplam iade tutarı (KDV dahil), dinamik hesaplanır
  double get toplamIadeTutari =>
      (alisFiyati * (1 + (kdvOrani / 100))) * iadeMiktari;

  IadeKaydi({
    this.id,
    required this.urunId,
    required this.urunAdi,
    required this.barkod,
    required this.alisFiyati,
    required this.orijinalAlisFiyati, // Constructor’da da var
    required this.satisFiyati,
    required this.iadeMiktari,
    required this.kdvOrani,
    required this.nedeni,
    required this.tarih,
    this.indirimNotu,
    required this.tedarikci,
  });

  factory IadeKaydi.fromMap(Map<String, dynamic> map) {
    return IadeKaydi(
      id: map['id'],
      urunId: map['urunId'],
      urunAdi: map['urunAdi'] ?? '',
      barkod: map['barkod'] ?? '',
      alisFiyati: (map['alisFiyati'] as num?)?.toDouble() ?? 0.0,
      orijinalAlisFiyati:
          (map['orijinalAlisFiyati'] as num?)?.toDouble() ?? 0.0, // Eklendi
      satisFiyati: (map['satisFiyati'] as num?)?.toDouble() ?? 0.0,
      iadeMiktari: (map['iadeMiktari'] as num?)?.toDouble() ?? 0.0,
      kdvOrani: (map['kdvOrani'] as num?)?.toDouble() ?? 0.0,
      nedeni: map['nedeni'] ?? '',
      tarih: DateTime.tryParse(map['tarih'] ?? '') ?? DateTime.now(),
      indirimNotu: map['indirimNotu'],
      tedarikci: map['tedarikci'] ?? 'Bilinmiyor',
    );
  }
// copyWith metodu
IadeKaydi copyWith({
  int? id,
  int? urunId,
  String? urunAdi,
  String? barkod,
  double? alisFiyati,
  double? orijinalAlisFiyati,
  double? satisFiyati,
  double? iadeMiktari,
  double? kdvOrani,
  String? nedeni,
  DateTime? tarih,
  String? indirimNotu,
  String? tedarikci,
}) {
  return IadeKaydi(
    id: id ?? this.id,
    urunId: urunId ?? this.urunId,
    urunAdi: urunAdi ?? this.urunAdi,
    barkod: barkod ?? this.barkod,
    alisFiyati: alisFiyati ?? this.alisFiyati,
    orijinalAlisFiyati: orijinalAlisFiyati ?? this.orijinalAlisFiyati,
    satisFiyati: satisFiyati ?? this.satisFiyati,
    iadeMiktari: iadeMiktari ?? this.iadeMiktari,
    kdvOrani: kdvOrani ?? this.kdvOrani,
    nedeni: nedeni ?? this.nedeni,
    tarih: tarih ?? this.tarih,
    indirimNotu: indirimNotu ?? this.indirimNotu,
    tedarikci: tedarikci ?? this.tedarikci,
  );
}


  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'urunId': urunId,
      'urunAdi': urunAdi,
      'barkod': barkod,
      'alisFiyati': alisFiyati,
      'orijinalAlisFiyati': orijinalAlisFiyati, // Eklendi
      'satisFiyati': satisFiyati,
      'iadeMiktari': iadeMiktari,
      'kdvOrani': kdvOrani,
      'nedeni': nedeni,
      'tarih': tarih.toIso8601String(),
      'indirimNotu': indirimNotu,
      'tedarikci': tedarikci,
    };
  }
}
