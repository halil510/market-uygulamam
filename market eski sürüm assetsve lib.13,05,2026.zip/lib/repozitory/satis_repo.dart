import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:intl/intl.dart';
import '../modeller/satis.dart';
import '../modeller/satis_kalem.dart';
import 'package:market_uygulamasi/core/logger.dart';

class SatisRepository {
  static final SatisRepository _instance = SatisRepository._internal();
  factory SatisRepository() => _instance;
  SatisRepository._internal();

  static Database? _db;

  Future<Database> get _database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'market.db');
    _db = await openDatabase(path);
    return _db!;
  }

  // ========== GÜVENLİ PARSE YARDIMCILARI ==========
  double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  int? _toInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }

  String _toString(dynamic value) => value?.toString() ?? '';

  // ========== METOTLAR ==========

  Future<List<Satis>> tariheGoreSatislariGetir(DateTime baslangic, DateTime bitis) async {
    final db = await _database;

    final basStr = DateFormat('yyyy-MM-dd HH:mm:ss').format(baslangic);
    final bitStr = DateFormat('yyyy-MM-dd HH:mm:ss').format(bitis);

    appLogger.i("📅 Tarih aralığı sorgusu: $basStr → $bitStr");

    try {
      final satisMaps = await db.rawQuery('''
        SELECT sd.*, s.tarih, s.odemeYontemi, s.toplamTutar AS satisToplam, s.fisTipi,
               u.kod AS urunKodu, u.barkod AS barkod
        FROM satis_detay sd
        INNER JOIN satislar s ON sd.satisId = s.id
        LEFT JOIN urunler u ON sd.urunId = u.id
        WHERE datetime(s.tarih) >= datetime(?) AND datetime(s.tarih) <= datetime(?)
        ORDER BY datetime(s.tarih) ASC
      ''', [basStr, bitStr]);

      final Map<int, Satis> satisMapById = {};

      for (final row in satisMaps) {
        final satisId = row['satisId'] as int;
        
        // Güvenli parse ile SatisKalem oluştur
        final kalem = SatisKalem(
          id: _toInt(row['id']),
          satisId: satisId,
          urunId: _toInt(row['urunId']) ?? 0,
          urunAdi: _toString(row['urunAdi']),
          miktar: _toDouble(row['miktar']) ?? 0.0,
          birimFiyat: _toDouble(row['birimFiyat']) ?? 0.0,
          indirimOrani: _toDouble(row['indirimOrani']) ?? 0.0,
          toplamTutar: _toDouble(row['toplamTutar']) ?? 0.0,
          kdvliFiyat: _toDouble(row['kdvliFiyat']) ?? 0.0,
          kdvliTutar: _toDouble(row['kdvliTutar']) ?? 0.0,
          urunKodu: _toString(row['urunKodu']),
          barkod: _toString(row['barkod']),
        );

        if (!satisMapById.containsKey(satisId)) {
          DateTime tarih;
          try {
            tarih = DateTime.parse(row['tarih'].toString());
          } catch (_) {
            tarih = DateTime.now();
          }

          satisMapById[satisId] = Satis(
            id: satisId,
            tarih: tarih,
            toplamTutar: _toDouble(row['satisToplam']) ?? 0.0,
            odenenTutar: 0.0,
            odemeYontemi: _toString(row['odemeYontemi']),
            fisTipi: _toString(row['fisTipi']),
            kalemler: [kalem],
          );
        } else {
          satisMapById[satisId]!.kalemler.add(kalem);
        }
      }

      final satislar = satisMapById.values.toList();
      appLogger.i("✅ Filtreli satış sayısı: ${satislar.length}");
      return satislar;
    } catch (e, s) {
      appLogger.i("❌ Sorgu hatası: $e\n$s");
      return [];
    }
  }

  Future<Map<String, double>> gunSonuOzetGetir(DateTime baslangic, DateTime bitis) async {
    final db = await _database;

    try {
      final satislar = await tariheGoreSatislariGetir(baslangic, bitis);
      double toplamSatis = 0.0;
      double toplamMaliyet = 0.0;

      for (var satis in satislar) {
        if (satis.fisTipi == 'Satış') {
          toplamSatis += satis.toplamTutar;

          for (var kalem in satis.kalemler) {
            final urun = await db.rawQuery(
                'SELECT alisFiyat FROM urunler WHERE id = ?', [kalem.urunId]);
            final alisFiyat = urun.isNotEmpty
                ? _toDouble(urun.first['alisFiyat']) ?? 0.0
                : 0.0;
            toplamMaliyet += alisFiyat * kalem.miktar;
          }
        }
      }

      final netKar = toplamSatis - toplamMaliyet;
      appLogger.i("📊 Gün Sonu Özeti: Satış=$toplamSatis ₺ | Maliyet=$toplamMaliyet ₺ | Kar=$netKar ₺");

      return {'toplamSatis': toplamSatis, 'netKar': netKar};
    } catch (e, s) {
      appLogger.i("❌ Gün sonu hesaplama hatası: $e\n$s");
      return {'toplamSatis': 0.0, 'netKar': 0.0};
    }
  }

  Future<int> satisEkle(Satis satis) async {
    final db = await _database;
    final satisMap = satis.toMap();
    satisMap.remove('id');
    satisMap['tarih'] = DateFormat('yyyy-MM-dd HH:mm:ss').format(satis.tarih);
    satisMap['fisTipi'] = satis.fisTipi.isNotEmpty ? satis.fisTipi : 'Satış';

    final satisId = await db.insert('satislar', satisMap);

    for (var kalem in satis.kalemler) {
      final kalemMap = {
        'satisId': satisId,
        'urunId': kalem.urunId,
        'urunAdi': kalem.urunAdi,
        'miktar': kalem.miktar,
        'birimFiyat': kalem.birimFiyat,
        'indirimOrani': kalem.indirimOrani,
        'toplamTutar': kalem.toplamTutar,
        'kdvliFiyat': kalem.kdvliFiyat,
        'kdvliTutar': kalem.kdvliTutar,
      };
      await db.insert('satis_detay', kalemMap);
    }

    appLogger.i("✅ Yeni satış eklendi (ID: $satisId)");
    return satisId;
  }

  Future<Satis?> satisGetir(int id) async {
    try {
      final db = await _database;

      final kalemMaps = await db.rawQuery('''
        SELECT sd.*, s.tarih, s.odemeYontemi, s.toplamTutar AS satisToplam, s.fisTipi,
               u.kod AS urunKodu, u.barkod AS barkod
        FROM satis_detay sd
        INNER JOIN satislar s ON sd.satisId = s.id
        LEFT JOIN urunler u ON sd.urunId = u.id
        WHERE sd.satisId = ?
      ''', [id]);

      if (kalemMaps.isEmpty) return null;

      Satis? satis;
      for (final row in kalemMaps) {
        final kalem = SatisKalem(
          id: _toInt(row['id']),
          satisId: row['satisId'] as int,
          urunId: _toInt(row['urunId']) ?? 0,
          urunAdi: _toString(row['urunAdi']),
          miktar: _toDouble(row['miktar']) ?? 0.0,
          birimFiyat: _toDouble(row['birimFiyat']) ?? 0.0,
          indirimOrani: _toDouble(row['indirimOrani']) ?? 0.0,
          toplamTutar: _toDouble(row['toplamTutar']) ?? 0.0,
          kdvliFiyat: _toDouble(row['kdvliFiyat']) ?? 0.0,
          kdvliTutar: _toDouble(row['kdvliTutar']) ?? 0.0,
          urunKodu: _toString(row['urunKodu']),
          barkod: _toString(row['barkod']),
        );

        if (satis == null) {
          DateTime tarih;
          try {
            tarih = DateTime.parse(row['tarih'].toString());
          } catch (_) {
            tarih = DateTime.now();
          }

          satis = Satis(
            id: id,
            tarih: tarih,
            toplamTutar: _toDouble(row['satisToplam']) ?? 0.0,
            odenenTutar: 0.0,
            odemeYontemi: _toString(row['odemeYontemi']),
            fisTipi: _toString(row['fisTipi']),
            kalemler: [kalem],
          );
        } else {
          satis.kalemler.add(kalem);
        }
      }

      return satis;
    } catch (e) {
      appLogger.i("Satış getirme hatası: $e");
      return null;
    }
  }

  Future<List<Satis>> tumSatislariGetir() async {
    final db = await _database;
    final satisMaps = await db.rawQuery('''
      SELECT sd.*, s.tarih, s.odemeYontemi, s.toplamTutar AS satisToplam, s.fisTipi,
             u.kod AS urunKodu, u.barkod AS barkod
      FROM satis_detay sd
      INNER JOIN satislar s ON sd.satisId = s.id
      LEFT JOIN urunler u ON sd.urunId = u.id
      ORDER BY datetime(s.tarih) ASC
    ''');

    final Map<int, Satis> satisMapById = {};

    for (final row in satisMaps) {
      final satisId = row['satisId'] as int;
      final kalem = SatisKalem(
        id: _toInt(row['id']),
        satisId: satisId,
        urunId: _toInt(row['urunId']) ?? 0,
        urunAdi: _toString(row['urunAdi']),
        miktar: _toDouble(row['miktar']) ?? 0.0,
        birimFiyat: _toDouble(row['birimFiyat']) ?? 0.0,
        indirimOrani: _toDouble(row['indirimOrani']) ?? 0.0,
        toplamTutar: _toDouble(row['toplamTutar']) ?? 0.0,
        kdvliFiyat: _toDouble(row['kdvliFiyat']) ?? 0.0,
        kdvliTutar: _toDouble(row['kdvliTutar']) ?? 0.0,
        urunKodu: _toString(row['urunKodu']),
        barkod: _toString(row['barkod']),
      );

      if (!satisMapById.containsKey(satisId)) {
        DateTime tarih;
        try {
          tarih = DateTime.parse(row['tarih'].toString());
        } catch (_) {
          tarih = DateTime.now();
        }

        satisMapById[satisId] = Satis(
          id: satisId,
          tarih: tarih,
          toplamTutar: _toDouble(row['satisToplam']) ?? 0.0,
          odenenTutar: 0.0,
          odemeYontemi: _toString(row['odemeYontemi']),
          fisTipi: _toString(row['fisTipi']),
          kalemler: [kalem],
        );
      } else {
        satisMapById[satisId]!.kalemler.add(kalem);
      }
    }

    return satisMapById.values.toList();
  }

  Future<void> satisSil(int id) async {
    final db = await _database;
    await db.delete('satis_detay', where: 'satisId = ?', whereArgs: [id]);
    await db.delete('satislar', where: 'id = ?', whereArgs: [id]);
    appLogger.i("🗑️ Satış silindi (ID: $id)");
  }

  Future<void> tumSatislariSil() async {
    final db = await _database;
    await db.delete('satis_detay');
    await db.delete('satislar');
    appLogger.i("🧹 Tüm satışlar silindi");
  }
}