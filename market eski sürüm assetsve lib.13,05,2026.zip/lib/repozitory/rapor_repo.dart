import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:sqflite/sqflite.dart';

class RaporRepository {
  final VeritabaniYardimcisi _dbHelper = VeritabaniYardimcisi();

  Future<Database> get db async => _dbHelper.db;

  Future<Map<String, dynamic>> karMarjiRaporu() async {
    final database = await db;
    
    // Örnek rapor verisi - gerçek uygulamanızda SQL sorgularıyla doldurulmalı
    return {
      'toplamKar': 15000.0,
      'enKarlıUrun': 'Lahmacun',
      'enCokSatan': 'Su',
      'aylikCiro': 50000.0
    };
  }
}