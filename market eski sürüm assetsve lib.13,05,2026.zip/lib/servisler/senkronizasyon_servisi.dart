import 'package:market_uygulamasi/servisler/urun_servisi.dart';

class SenkronizasyonServisi {
  final UrunServisi _urunServisi = UrunServisi();

  Future<void> verileriSenkronizeEt() async {
    // Firebase veya diğer sunucu ile senkronizasyon
    final urunler = await _urunServisi.tumUrunleriGetir();
    // Senkronizasyon işlemleri...
  }
}