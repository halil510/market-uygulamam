class PaginationHelper {
  final int pageSize;
  int _currentPage = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  PaginationHelper({this.pageSize = 50});

  int get currentPage => _currentPage;
  bool get hasMore => _hasMore;
  bool get isLoading => _isLoading;

  int get offset => _currentPage * pageSize;
  int get limit => pageSize;

  void reset() {
    _currentPage = 0;
    _hasMore = true;
    _isLoading = false;
  }

  void onPageLoaded(int itemCount) {
    _hasMore = itemCount >= pageSize;
    if (_hasMore) _currentPage++;
    _isLoading = false;
  }

  void onError() {
    _isLoading = false;
  }

  void setLoading() {
    _isLoading = true;
  }
}