import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:sqflite/sqflite.dart';

class TedarikciRepository {
  final VeritabaniYardimcisi _database = VeritabaniYardimcisi();

  /// Tüm tedarikçileri getir
  Future<List<String>> tumTedarikcileriGetir() async {
    final db = await _database.db;
    final sonuclar = await db.query('tedarikciler');
    return sonuclar.map((row) => row['ad'] as String).toList();
  }

  /// Yeni tedarikçi ekle (varsa günceller)
  Future<void> tedarikciEkle(String tedarikciAdi) async {
    final db = await _database.db;
    await db.insert(
      'tedarikciler',
      {'ad': tedarikciAdi},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
