import 'package:flutter/material.dart';

class StokUyari extends StatelessWidget {
  final double stok;

  const StokUyari({Key? key, required this.stok}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color renk = stok > 10
        ? Colors.green
        : stok > 0
            ? Colors.orange
            : Colors.red;

    String uyari = stok > 10
        ? 'Stok: $stok'
        : stok > 0
            ? 'Düşük Stok!'
            : 'Stok Yok!';

    return Chip(
      label: Text(uyari),
      backgroundColor: renk.withOpacity(0.1),
      labelStyle: TextStyle(color: renk),
    );
  }
}