import 'package:equatable/equatable.dart';

class SatisKalem {
  final int? id;
  final int? satisId;
  final int urunId;
  final String urunAdi;
  final double miktar;
  final double birimFiyat;
  final double indirimOrani;
  final double toplamTutar;
  final double kdvliFiyat;
  final double kdvliTutar;

  final String? urunKodu;
  final String? barkod;

  const SatisKalem({
    this.id,
    this.satisId,
    required this.urunId,
    required this.urunAdi,
    required this.miktar,
    required this.birimFiyat,
    required this.indirimOrani,
    required this.toplamTutar,
    required this.kdvliFiyat,
    required this.kdvliTutar,
    this.urunKodu,
    this.barkod,
  });

  // ========== ORİJİNAL COPYWITH (AYNEN KALDI) ==========
  SatisKalem copyWith({
    int? id,
    int? satisId,
    int? urunId,
    String? urunAdi,
    double? miktar,
    double? birimFiyat,
    double? indirimOrani,
    double? toplamTutar,
    double? kdvliFiyat,
    double? kdvliTutar,
    String? urunKodu,
    String? barkod,
  }) {
    return SatisKalem(
      id: id ?? this.id,
      satisId: satisId ?? this.satisId,
      urunId: urunId ?? this.urunId,
      urunAdi: urunAdi ?? this.urunAdi,
      miktar: miktar ?? this.miktar,
      birimFiyat: birimFiyat ?? this.birimFiyat,
      indirimOrani: indirimOrani ?? this.indirimOrani,
      toplamTutar: toplamTutar ?? this.toplamTutar,
      kdvliFiyat: kdvliFiyat ?? this.kdvliFiyat,
      kdvliTutar: kdvliTutar ?? this.kdvliTutar,
      urunKodu: urunKodu ?? this.urunKodu,
      barkod: barkod ?? this.barkod,
    );
  }

  // ========== GÜVENLİ PARSE FONKSİYONLARI ==========
  static double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  static int? _toInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }

  // ========== GÜNCELLENMİŞ FROMMAP (SADECE PARSE DEĞİŞTİ) ==========
  factory SatisKalem.fromMap(Map<String, dynamic> map) {
    return SatisKalem(
      id: _toInt(map['id']),
      satisId: _toInt(map['satisId']),
      urunId: _toInt(map['urunId']) ?? 0,
      urunAdi: map['urunAdi']?.toString() ?? '',
      miktar: _toDouble(map['miktar']) ?? 0.0,
      birimFiyat: _toDouble(map['birimFiyat']) ?? 0.0,
      indirimOrani: _toDouble(map['indirimOrani']) ?? 0.0,
      toplamTutar: _toDouble(map['toplamTutar']) ?? 0.0,
      kdvliFiyat: _toDouble(map['kdvliFiyat']) ?? 0.0,
      kdvliTutar: _toDouble(map['kdvliTutar']) ?? 0.0,
      urunKodu: map['urunKodu']?.toString(),
      barkod: map['barkod']?.toString(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'satisId': satisId,
      'urunId': urunId,
      'urunAdi': urunAdi,
      'miktar': miktar,
      'birimFiyat': birimFiyat,
      'indirimOrani': indirimOrani,
      'toplamTutar': toplamTutar,
      'kdvliFiyat': kdvliFiyat,
      'kdvliTutar': kdvliTutar,
      'urunKodu': urunKodu,
      'barkod': barkod,
    };
  }
}

extension SatisKalemExcel on SatisKalem {
  double get excelKdvliFiyat => birimFiyat;
  double get excelKdvliTutar => miktar * birimFiyat;
  Map<String, dynamic> toMapForExcel() {
    return {
      'Kod': urunKodu ?? '',
      'Barkod': barkod ?? '',
      'Ürün Adı': urunAdi,
      'Miktar': miktar,
      'Birim': 'ADET',
      'KDV li fiyat': excelKdvliFiyat,
      'KDV li tutar': excelKdvliTutar,
      'İndirim': indirimOrani,
    };
  }
}