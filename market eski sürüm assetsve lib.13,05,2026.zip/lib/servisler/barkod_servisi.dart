import 'package:flutter/material.dart';

class BarkodServisi {
  static const List<String> GECERLI_ON_EKLER = [
    '869', '888', '890', '899', 
    '690', '691', '692', '693', '694'
  ];

  bool gecerliBarkod(String barkod) {
    if (barkod.length < 8 || barkod.length > 13) return false;
    if (!RegExp(r'^[0-9]+$').hasMatch(barkod)) return false;
    return GECERLI_ON_EKLER.any((prefix) => barkod.startsWith(prefix));
  }

  String duzeltBarkod(String barkod) {
    barkod = barkod.replaceAll(RegExp(r'[^0-9]'), '');
    if (barkod.length > 13) barkod = barkod.substring(0, 13);
    if (barkod.length < 8) barkod = barkod.padLeft(8, '0');
    return barkod;
  }

  static Widget barkodEtiketOlustur(String barkod, {double? width, double? height}) {
    return Container(
      width: width ?? 150,
      height: height ?? 50,
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black),
      ),
      child: Text(barkod, style: TextStyle(fontSize: 16)),
    );
  }

  static Widget barkodGorselOlustur(String barkod, {double? width, double? height}) {
    return Image.asset(
      'assets/placeholder_barcode.png',
      width: width ?? 150,
      height: height ?? 50,
    );
  }
}
