// lib/servisler/yazdirma_servisi.dart
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:blue_thermal_printer/blue_thermal_printer.dart';

import 'package:market_uygulamasi/modeller/yazici.dart';
import 'package:market_uygulamasi/modeller/satis_kalem.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:market_uygulamasi/servisler/etiket_motoru_zpl.dart';
import 'package:market_uygulamasi/servisler/etiket_motoru_tspl.dart';

enum YaziciKategori { fis, etiket }

class YazdirmaServisi {
  YazdirmaServisi._();

  /// Metin temizleme: Türkçe karakterleri ASCII'ye çevir, özel karakterleri kaldır
  static String _temizleMetin(String text) {
    if (text.isEmpty) return '';
    final replacements = {
      'ğ': 'g', 'Ğ': 'G',
      'ü': 'u', 'Ü': 'U',
      'ş': 's', 'Ş': 'S',
      'ı': 'i', 'İ': 'I',
      'ö': 'o', 'Ö': 'O',
      'ç': 'c', 'Ç': 'C',
    };
    String result = text;
    for (var entry in replacements.entries) {
      result = result.replaceAll(entry.key, entry.value);
    }
    // Alfanümerik ve boşluk dışındaki karakterleri kaldır (noktalama işaretleri sorun çıkarabilir)
    result = result.replaceAll(RegExp(r'[^\w\s]'), '');
    // Fazla boşlukları temizle
    result = result.replaceAll(RegExp(r'\s+'), ' ').trim();
    return result;
  }

  static Future<void> yazdirFis(List<SatisKalem> kalemler,
      {String baslik = 'MARKET FİŞİ'}) async {
    final yazici = await _varsayilanYaziciyiGetir(YaziciKategori.fis);
    if (yazici == null) throw Exception('Varsayılan fiş yazıcı tanımlı değil');

    final profile = await CapabilityProfile.load();
    final gen = Generator(PaperSize.mm80, profile);
    final List<int> bytes = [];

    // Başlık temizlenmiş
    final temizBaslik = _temizleMetin(baslik);
    bytes.addAll(gen.text(
      temizBaslik,
      styles: PosStyles(
        align: PosAlign.center,
        height: PosTextSize.size2,
        width: PosTextSize.size2,
      ),
      linesAfter: 1,
    ));

    for (final k in kalemler) {
      final urunAdiRaw = k.urunAdi ?? '';
      final urunAdi = _temizleMetin(urunAdiRaw);
      // Güvenli substring: 14 karakterden fazla ise kısalt, değilse olduğu gibi bırak
      String urunAdiFormatted = urunAdi.length > 14 ? urunAdi.substring(0, 14) : urunAdi;
      // Sağa yaslamak için padRight yap, toplam 14 karakter olacak
      urunAdiFormatted = urunAdiFormatted.padRight(14);
      
      final miktar = k.miktar.toStringAsFixed(0).padLeft(3);
      final fiyat = k.birimFiyat.toStringAsFixed(2).padLeft(8);

      bytes.addAll(gen.row([
        PosColumn(text: urunAdiFormatted, width: 8),
        PosColumn(
          text: miktar,
          width: 2,
          styles: PosStyles(align: PosAlign.right),
        ),
        PosColumn(
          text: fiyat,
          width: 2,
          styles: PosStyles(align: PosAlign.right),
        ),
      ]));
    }

    final toplam = kalemler.fold<double>(0.0, (s, k) => s + k.toplamTutar);
    final toplamStr = _temizleMetin('${toplam.toStringAsFixed(2)} TL');

    bytes.addAll(gen.hr());
    bytes.addAll(gen.row([
      PosColumn(text: 'TOPLAM', width: 6, styles: PosStyles(bold: true)),
      PosColumn(
        text: toplamStr,
        width: 6,
        styles: PosStyles(align: PosAlign.right, bold: true),
      ),
    ]));
    bytes.addAll(gen.hr(ch: '='));

    final tesekkur = _temizleMetin('Teşekkür ederiz');
    bytes.addAll(gen.text(
      tesekkur,
      styles: PosStyles(align: PosAlign.center),
    ));

    bytes.addAll(gen.feed(3));
    bytes.addAll(gen.cut());

    await _gonder(yazici, Uint8List.fromList(bytes));
  }

  static Future<void> yazdirEtiket({
    required String barkod,
    String? ad,
    String? fiyat,
    double genislik = 50,
    double yukseklik = 30,
    String dil = 'TSPL',
  }) async {
    final yazici = await _varsayilanYaziciyiGetir(YaziciKategori.etiket);
    if (yazici == null) throw Exception('Varsayılan etiket yazıcı tanımlı değil');

    final temizAd = ad != null ? _temizleMetin(ad) : null;
    final temizFiyat = fiyat != null ? _temizleMetin(fiyat) : null;
    final temizBarkod = barkod.replaceAll(RegExp(r'[^0-9]'), ''); // Sadece rakamlar

    String komut;
    if (dil == 'ZPL') {
      komut = ZplEtiketMotoru.olustur(
        genislikMm: genislik,
        yukseklikMm: yukseklik,
        barkod: temizBarkod,
        ad: temizAd,
        fiyat: temizFiyat,
      );
    } else {
      komut = TsplEtiketMotoru.olustur(
        genislikMm: genislik,
        yukseklikMm: yukseklik,
        barkod: temizBarkod,
        ad: temizAd,
        fiyat: temizFiyat,
      );
    }

    await _gonder(yazici, Uint8List.fromList(komut.codeUnits));
  }

  static Future<void> hamKomutYazdir(
      String data, YaziciKategori kategori) async {
    final yazici = await _varsayilanYaziciyiGetir(kategori);
    if (yazici == null) throw Exception('Varsayılan yazıcı tanımlı değil');
    await _gonder(yazici, Uint8List.fromList(data.codeUnits));
  }

  static Future<void> bartenderIleYazdir(dynamic data, String printerIp,
      {int port = 9100}) async {
    final soket = await Socket.connect(printerIp, port);
    List<int> veri;

    if (data is String) {
      final dosya = File(data);
      if (await dosya.exists()) {
        veri = await dosya.readAsBytes();
      } else {
        veri = data.codeUnits;
      }
    } else if (data is List<int>) {
      veri = data;
    } else {
      throw Exception('Bartender yazdırma için geçersiz veri tipi: ${data.runtimeType}');
    }

    soket.add(veri);
    await soket.flush();
    await soket.close();
  }

  static Future<Yazici?> _varsayilanYaziciyiGetir(YaziciKategori kategori) async {
    final db = await VeritabaniYardimcisi().db;
    final rows = await db.query(
      'Yazicilar',
      where: 'varsayilan = 1 AND kategori = ?',
      whereArgs: [kategori.name],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Yazici.fromMap(rows.first);
  }

  static Future<void> _gonder(Yazici y, Uint8List bytes) async {
    if (y.tur == 'bluetooth') {
      final bt = BlueThermalPrinter.instance;
      final isConnected = (await bt.isConnected) ?? false;
      if (!isConnected) {
        if (y.cihazId == null) throw Exception('Bluetooth cihazId yok');
        final devices = await bt.getBondedDevices();
        final target = devices.firstWhere(
          (d) => d.address == y.cihazId,
          orElse: () => throw Exception('BT cihaz eşlenmemiş: ${y.cihazId}'),
        );
        await bt.connect(target);
      }
      await bt.writeBytes(bytes);
      await Future.delayed(const Duration(milliseconds: 300));
      await bt.disconnect();
    } else if (y.tur == 'ag') {
      if (y.ip == null || y.port == null) throw Exception('Ağ yazıcı IP/Port eksik');
      final socket = await Socket.connect(y.ip, y.port!, timeout: const Duration(seconds: 5));
      socket.add(bytes);
      await socket.flush();
      await Future.delayed(const Duration(milliseconds: 200));
      await socket.close();
    } else {
      throw Exception('Desteklenmeyen yazıcı türü: ${y.tur}');
    }
  }
}