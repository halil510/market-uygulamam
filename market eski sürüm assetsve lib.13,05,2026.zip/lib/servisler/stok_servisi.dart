// lib/servisler/stok_servisi.dart
import 'package:market_uygulamasi/repozitory/urun_repo.dart';

enum StokIslemTuru { alis, satis, iade }

class StokServisi {
  final UrunRepoSitory _urunRepository = UrunRepoSitory();

  Future<void> stokGuncelle(int urunId, double miktar, {required StokIslemTuru islemTuru}) async {
    final urun = await _urunRepository.idyeGoreUrunGetir(urunId);
    if (urun == null) throw Exception('Ürün bulunamadı');
    
    double yeniStok = urun.stokMiktari;
    switch (islemTuru) {
      case StokIslemTuru.alis:
        yeniStok += miktar;
        break;
      case StokIslemTuru.satis:
        yeniStok -= miktar;
        break;
      case StokIslemTuru.iade:
        yeniStok += miktar;
        break;
    }
    if (yeniStok < 0) throw Exception('Stok negatif olamaz');
    await _urunRepository.stokGuncelle(urunId, yeniStok);
  }
}