import 'dart:developer' as developer;
import 'package:market_uygulamasi/servisler/log_servisi.dart';

class PerformansServisi {
  static final _instance = PerformansServisi._internal();
  factory PerformansServisi() => _instance;
  PerformansServisi._internal();

  final Map<String, List<int>> _metrikler = {};

  void metrikKaydet(String isim, int milisaniye) {
    _metrikler.putIfAbsent(isim, () => []);
    _metrikler[isim]!.add(milisaniye);
    
    if (_metrikler[isim]!.length > 100) {
      _metrikler[isim]!.removeAt(0);
    }
  }

  double ortalamaMs(String isim) {
    final degerler = _metrikler[isim];
    if (degerler == null || degerler.isEmpty) return 0;
    return degerler.reduce((a, b) => a + b) / degerler.length;
  }

  Map<String, double> tumMetrikler() {
    return _metrikler.map((key, value) => MapEntry(key, ortalamaMs(key)));
  }

  Future<T> olcVeCalistir<T>(String isim, Future<T> Function() islem) async {
    final baslangic = DateTime.now();
    try {
      return await islem();
    } finally {
      final sure = DateTime.now().difference(baslangic).inMilliseconds;
      metrikKaydet(isim, sure);
      if (sure > 1000) {
        Log.w('Yavaş işlem: $isim ${sure}ms', tag: 'PERF');
      }
    }
  }
}