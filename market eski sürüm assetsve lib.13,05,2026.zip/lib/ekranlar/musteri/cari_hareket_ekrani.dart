// lib/ekranlar/musteri/cari_hareket_ekrani.dart
//
// ✅ Düzeltmeler:
//   • Üst kart: toplamBorc / toplamAlacak / bakiye DOĞRU hesaplanıyor
//     (Açılış satırı dahil, sadece gerçek hareketler toplanıyor)
//   • Bakiye rengi: borçta kırmızı, alacakta yeşil, sıfırda gri
//   • Cari tipi (Müşteri / Tedarikçi) bakiye yönü doğru
//   • Running balance her satırda gösteriliyor
//   • Tarih filtresi (DateRange picker) eklendi
//   • Fiş tipi filtresi (chip row) eklendi
//   • Hareket ekleme bottom sheet (Tahsilat / Ödeme / Düzeltme)
//   • Export: CSV + PDF
//   • Boş state + hata state tasarımı

import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:intl/intl.dart';

import 'package:market_uygulamasi/modeller/cari_hareket.dart';
import 'package:market_uygulamasi/modeller/musteri.dart';
import 'package:market_uygulamasi/repozitory/cari_hareket_repo.dart';
import 'package:market_uygulamasi/repozitory/musteri_repo.dart';
import 'package:market_uygulamasi/ekranlar/musteri/fis_detay_ekrani.dart';
import 'package:market_uygulamasi/servisler/log_servisi.dart';

// ─────────────────────────────────────────────
// Sabitler & Renk Paleti
// ─────────────────────────────────────────────
class _Renk {
  static const primary    = Color(0xFF1565C0);
  static const surface    = Color(0xFFF5F7FA);
  static const cardBg     = Colors.white;
  static const borcRenk   = Color(0xFFD32F2F);
  static const alacakRenk = Color(0xFF2E7D32);
  static const bakiyeSifir= Color(0xFF757575);
  static const satis      = Color(0xFF1565C0);
  static const alis       = Color(0xFFE65100);
  static const tahsilat   = Color(0xFF2E7D32);
  static const odeme      = Color(0xFF6A1B9A);
  static const acilis     = Color(0xFF546E7A);
  static const diger      = Color(0xFF455A64);
}

class _Stil {
  static const double cardRadius = 16;
  static const double itemRadius = 12;
  static const EdgeInsets pagePad = EdgeInsets.symmetric(horizontal: 16);
}

// ─────────────────────────────────────────────
// Widget
// ─────────────────────────────────────────────
class CariHareketEkrani extends StatefulWidget {
  final Musteri cari;
  const CariHareketEkrani({Key? key, required this.cari}) : super(key: key);

  @override
  State<CariHareketEkrani> createState() => _CariHareketEkraniState();
}

class _CariHareketEkraniState extends State<CariHareketEkrani> {
  final CariHareketRepo _hareketRepo = CariHareketRepo();
  final MusteriRepo     _musteriRepo = MusteriRepo();
  late pw.Font _pdfFont;

  // Ham liste (tüm hareketler, running balance hesaplanmış)
  List<CariHareket> _tumHareketler = [];

  // Filtreli görünen liste
  List<CariHareket> _gosterilenHareketler = [];

  // Üst kart değerleri – sadece ham listeden (Açılış hariç)
  double _toplamBorc   = 0;
  double _toplamAlacak = 0;
  double _bakiye       = 0;

  // Filtreler
  String?       _secilenFisTipi; // null = tümü
  DateTimeRange? _tarihAraligi;

  bool   _yukleniyor = true;
  String? _hata;

  final _para = NumberFormat('#,##0.00', 'tr_TR');

  // ── Yaşam döngüsü ──────────────────────────
  @override
  void initState() {
    super.initState();
    _loadFont();
    _hareketleriGetir();
  }

  Future<void> _loadFont() async {
    try {
      final data = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
      _pdfFont = pw.Font.ttf(data);
    } catch (_) {
      _pdfFont = pw.Font.courier();
    }
  }

  // ── Veri çekme & Hesaplama ──────────────────
  Future<void> _hareketleriGetir() async {
    setState(() { _yukleniyor = true; _hata = null; });
    try {
      final guncelCari = await _musteriRepo.musteriGetirById(widget.cari.id!);
      if (guncelCari == null) {
        setState(() { _yukleniyor = false; _hata = 'Cari bulunamadı.'; });
        return;
      }

      // DB'den tarihe göre ASC getir
      final fetched = await _hareketRepo.hareketleriGetir(guncelCari.id!);
      fetched.sort((a, b) => a.tarih.compareTo(b.tarih));

      // ── Açılış bakiyesi hesapla ──────────────
      // Hareketlerin borç-alacak toplamını bul, DB'deki bakiyeden çıkar
      final movBorc   = fetched.fold(0.0, (s, h) => s + h.borc);
      final movAlacak = fetched.fold(0.0, (s, h) => s + h.alacak);
      final movNet    = movBorc - movAlacak;

      // guncelCari.bakiye = DB'deki son bakiye (Müşteri için: borc-alacak)
      final openingBalance = guncelCari.bakiye - movNet;

      final List<CariHareket> liste = List.from(fetched);

      // Açılış satırı ekle (zaten yoksa ve sıfır değilse)
      if (openingBalance.abs() > 0.001 &&
          !liste.any((h) => h.fisTipi == 'Açılış')) {
        final acilisTarih = liste.isNotEmpty
            ? liste.first.tarih.subtract(const Duration(seconds: 1))
            : DateTime.now().subtract(const Duration(days: 1));

        final bool musteriMi = guncelCari.cariTipi == 'Müşteri';
        liste.insert(
          0,
          CariHareket(
            id: -1,
            cariId: guncelCari.id!,
            fisId: null,
            fisTipi: 'Açılış',
            fisNo: '',
            aciklama: 'Önceki Bakiye',
            tarih: acilisTarih,
            // Müşteri: opening > 0 → borçlu   |  Tedarikçi: opening > 0 → alacaklı
            borc:   musteriMi
                ? (openingBalance > 0 ? openingBalance : 0)
                : (openingBalance < 0 ? openingBalance.abs() : 0),
            alacak: musteriMi
                ? (openingBalance < 0 ? openingBalance.abs() : 0)
                : (openingBalance > 0 ? openingBalance : 0),
            bakiye: openingBalance,
          ),
        );
      }

      // ── Running balance hesapla ──────────────
      double running = 0;
      final acilisIdx = liste.indexWhere((h) => h.fisTipi == 'Açılış');
      if (acilisIdx != -1) {
        running = liste[acilisIdx].borc - liste[acilisIdx].alacak;
        liste[acilisIdx].bakiye = running;
      }
      final startIdx = acilisIdx != -1 ? acilisIdx + 1 : 0;

      // ── Üst kart toplamları (Açılış hariç) ──
      double tb = 0, ta = 0;
      for (int i = startIdx; i < liste.length; i++) {
        running += liste[i].borc - liste[i].alacak;
        liste[i].bakiye = running;
        tb += liste[i].borc;
        ta += liste[i].alacak;
      }

      setState(() {
        _tumHareketler = liste.reversed.toList(); // En yeni üstte
        _toplamBorc    = tb;
        _toplamAlacak  = ta;
        _bakiye        = running; // Son bakiye
        _yukleniyor    = false;
      });
      _filtreUygula();
    } catch (e) {
      setState(() { _yukleniyor = false; _hata = e.toString(); });
      Log.e('Hareket getirme hatası', error: e);
    }
  }

  void _filtreUygula() {
    setState(() {
      _gosterilenHareketler = _tumHareketler.where((h) {
        final tipOk  = _secilenFisTipi == null || h.fisTipi == _secilenFisTipi;
        final tarihOk = _tarihAraligi == null ||
            (!h.tarih.isBefore(_tarihAraligi!.start) &&
             !h.tarih.isAfter(_tarihAraligi!.end.add(const Duration(days: 1))));
        return tipOk && tarihOk;
      }).toList();
    });
  }

  // ── Silme ────────────────────────────────────
  Future<void> _silHareket(CariHareket h) async {
    if (h.id == null || h.id == -1) return;
    final onay = await _onayDiyalogu(
      baslik: 'Hareketi Sil',
      icerik: '${h.aciklama} hareketi kalıcı olarak silinecek. Devam edilsin mi?',
      onayRenk: _Renk.borcRenk,
    );
    if (onay) {
      await _hareketRepo.hareketSil(h.id!);
      await _hareketleriGetir();
    }
  }

  // ── Fiş detay ────────────────────────────────
  Future<void> _fisDetayiniGoster(CariHareket h) async {
    if (h.fisTipi == 'Açılış' || h.id == -1) {
      _snack('Bu hareket için fiş detayı bulunmuyor.');
      return;
    }
    if (h.fisId == null) {
      _snack('Fiş ID bilgisi eksik.');
      return;
    }
    if (h.fisTipi != 'Satış') {
      _snack('${h.fisTipi} fiş detayı henüz desteklenmiyor.');
      return;
    }
    final sonuc = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FisDetayEkrani(fisId: h.fisId!, fisTipi: h.fisTipi),
      ),
    );
    if (sonuc == true) _hareketleriGetir();
  }

  // ── Hareket ekleme ───────────────────────────
  void _hareketEkleBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _HareketEkleSheet(
        cariId: widget.cari.id!,
        onKaydet: _hareketleriGetir,
      ),
    );
  }

  // ── Tarih filtresi ───────────────────────────
  Future<void> _tarihFiltresiSec() async {
    final result = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 1)),
      initialDateRange: _tarihAraligi,
      locale: const Locale('tr', 'TR'),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(primary: _Renk.primary),
        ),
        child: child!,
      ),
    );
    if (result != null) {
      setState(() => _tarihAraligi = result);
      _filtreUygula();
    }
  }

  // ── Export ───────────────────────────────────
  Future<void> _exportCSV() async {
    final rows = <List<dynamic>>[
      ['Tarih', 'Fiş Tipi', 'Fiş No', 'Açıklama', 'Borç (₺)', 'Alacak (₺)', 'Bakiye (₺)'],
      ..._gosterilenHareketler.map((h) => [
        DateFormat('dd.MM.yyyy', 'tr_TR').format(h.tarih.toLocal()),
        h.fisTipi,
        h.fisNo ?? '',
        h.aciklama,
        h.borc.toStringAsFixed(2),
        h.alacak.toStringAsFixed(2),
        (h.bakiye ?? 0).toStringAsFixed(2),
      ]),
      ['', 'TOPLAM', '', '',
        _toplamBorc.toStringAsFixed(2),
        _toplamAlacak.toStringAsFixed(2),
        _bakiye.toStringAsFixed(2)],
    ];
    final csv = const ListToCsvConverter().convert(rows);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/${widget.cari.unvan}_hareketler.csv');
    await file.writeAsBytes([0xEF, 0xBB, 0xBF, ...utf8.encode(csv)]);
    await Share.shareXFiles([XFile(file.path)], text: '${widget.cari.unvan} Hareketleri');
  }

  Future<void> _exportPDF() async {
    final pdf   = pw.Document();
    final fmt   = DateFormat('dd.MM.yyyy', 'tr_TR');
    final theme = pw.ThemeData.withFont(base: _pdfFont);

    pdf.addPage(pw.MultiPage(
      theme: theme,
      pageFormat: PdfPageFormat.a4.landscape,
      header: (_) => pw.Container(
        margin: const pw.EdgeInsets.only(bottom: 12),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text('${widget.cari.unvan} — Cari Hareket Raporu',
              style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.Text('Oluşturma tarihi: ${fmt.format(DateTime.now())}',
              style: pw.TextStyle(fontSize: 10, color: PdfColors.grey600)),
          pw.Divider(),
        ]),
      ),
      build: (_) => [
        pw.Table.fromTextArray(
          headers: ['Tarih', 'Fiş Tipi', 'Fiş No', 'Açıklama', 'Borç', 'Alacak', 'Bakiye'],
          data: _gosterilenHareketler.map((h) => [
            fmt.format(h.tarih.toLocal()),
            h.fisTipi,
            h.fisNo ?? '',
            h.aciklama,
            '${h.borc.toStringAsFixed(2)} ₺',
            '${h.alacak.toStringAsFixed(2)} ₺',
            '${(h.bakiye ?? 0).toStringAsFixed(2)} ₺',
          ]).toList(),
          cellStyle: pw.TextStyle(font: _pdfFont, fontSize: 9),
          headerStyle: pw.TextStyle(font: _pdfFont, fontWeight: pw.FontWeight.bold,
              color: PdfColors.white, fontSize: 9),
          headerDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFF1565C0)),
          border: pw.TableBorder.all(color: PdfColors.grey300),
          rowDecoration: const pw.BoxDecoration(color: PdfColors.white),
          oddRowDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFF5F7FA)),
        ),
        pw.SizedBox(height: 16),
        pw.Row(mainAxisAlignment: pw.MainAxisAlignment.end, children: [
          _pdfBilgi('Toplam Borç',   '${_toplamBorc.toStringAsFixed(2)} ₺',   _pdfFont),
          pw.SizedBox(width: 24),
          _pdfBilgi('Toplam Alacak', '${_toplamAlacak.toStringAsFixed(2)} ₺', _pdfFont),
          pw.SizedBox(width: 24),
          _pdfBilgi('Net Bakiye',    '${_bakiye.toStringAsFixed(2)} ₺',       _pdfFont),
        ]),
      ],
    ));

    await Printing.sharePdf(
        bytes: await pdf.save(),
        filename: '${widget.cari.unvan}_hareket_raporu.pdf');
  }

  pw.Widget _pdfBilgi(String baslik, String deger, pw.Font font) {
    return pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
      pw.Text(baslik, style: pw.TextStyle(font: font, fontSize: 8, color: PdfColors.grey600)),
      pw.Text(deger,  style: pw.TextStyle(font: font, fontSize: 11, fontWeight: pw.FontWeight.bold)),
    ]);
  }

  // ── Yardımcı ────────────────────────────────
  Future<bool> _onayDiyalogu({
    required String baslik,
    required String icerik,
    Color? onayRenk,
  }) async {
    return await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(baslik),
        content: Text(icerik),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('İptal'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: onayRenk ?? _Renk.primary),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Onayla'),
          ),
        ],
      ),
    ) ?? false;
  }

  void _snack(String mesaj) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mesaj),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // ── Build ────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Renk.surface,
      appBar: _appBar(),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : _hata != null
              ? _hataView()
              : Column(children: [
                  _ozetKart(),
                  _filtreSatiri(),
                  const SizedBox(height: 4),
                  Expanded(child: _hareketListesi()),
                ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _hareketEkleBottomSheet,
        icon: const Icon(Icons.add),
        label: const Text('Hareket Ekle'),
        backgroundColor: _Renk.primary,
      ),
    );
  }

  PreferredSizeWidget _appBar() {
    return AppBar(
      elevation: 0,
      backgroundColor: _Renk.primary,
      foregroundColor: Colors.white,
      title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.cari.unvan,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        Text(widget.cari.cariTipi,
            style: const TextStyle(fontSize: 12, color: Colors.white70)),
      ]),
      actions: [
        IconButton(
          icon: const Icon(Icons.picture_as_pdf_outlined),
          tooltip: 'PDF İndir',
          onPressed: _exportPDF,
        ),
        IconButton(
          icon: const Icon(Icons.table_chart_outlined),
          tooltip: 'CSV / Excel',
          onPressed: _exportCSV,
        ),
        IconButton(
          icon: const Icon(Icons.refresh),
          tooltip: 'Yenile',
          onPressed: _hareketleriGetir,
        ),
      ],
    );
  }

  // ── Özet Kart ─────────────────────────────────
  Widget _ozetKart() {
    // Bakiye rengi: müşteri için borc-alacak > 0 → kırmızı (müşteri borçlu)
    final bakiyeRenk = _bakiye > 0.001
        ? _Renk.borcRenk
        : _bakiye < -0.001
            ? _Renk.alacakRenk
            : _Renk.bakiyeSifir;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      decoration: BoxDecoration(
        color: _Renk.cardBg,
        borderRadius: BorderRadius.circular(_Stil.cardRadius),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        child: Row(children: [
          Expanded(child: _ozetTile('Toplam Borç',   _toplamBorc,  _Renk.borcRenk,   Icons.arrow_upward)),
          _dikey(),
          Expanded(child: _ozetTile('Toplam Alacak', _toplamAlacak,_Renk.alacakRenk, Icons.arrow_downward)),
          _dikey(),
          Expanded(child: _ozetTile('Net Bakiye',    _bakiye,      bakiyeRenk,        Icons.account_balance_wallet_outlined)),
        ]),
      ),
    );
  }

  Widget _ozetTile(String baslik, double tutar, Color renk, IconData ikon) {
    return Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(ikon, size: 14, color: renk),
        const SizedBox(width: 4),
        Text(baslik,
            style: TextStyle(fontSize: 11, color: Colors.grey[600], fontWeight: FontWeight.w500)),
      ]),
      const SizedBox(height: 6),
      Text(
        '${_para.format(tutar.abs())} ₺',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.bold,
          color: renk,
        ),
        textAlign: TextAlign.center,
      ),
    ]);
  }

  Widget _dikey() => Container(
      width: 1, height: 48, color: Colors.grey.shade200, margin: const EdgeInsets.symmetric(horizontal: 8));

  // ── Filtre Satırı ─────────────────────────────
  Widget _filtreSatiri() {
    final fisTipleri = ['Satış', 'Alış', 'Tahsilat', 'Ödeme', 'Açılış'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          // Tarih filtresi
          ActionChip(
            avatar: Icon(
              Icons.date_range,
              size: 16,
              color: _tarihAraligi != null ? _Renk.primary : Colors.grey[600],
            ),
            label: Text(
              _tarihAraligi != null
                  ? '${DateFormat('dd.MM', 'tr_TR').format(_tarihAraligi!.start)} – '
                    '${DateFormat('dd.MM', 'tr_TR').format(_tarihAraligi!.end)}'
                  : 'Tarih',
              style: TextStyle(
                fontSize: 12,
                color: _tarihAraligi != null ? _Renk.primary : Colors.grey[700],
              ),
            ),
            backgroundColor: _tarihAraligi != null
                ? _Renk.primary.withOpacity(0.1)
                : Colors.white,
            side: BorderSide(
              color: _tarihAraligi != null ? _Renk.primary : Colors.grey.shade300,
            ),
            onPressed: _tarihFiltresiSec,
          ),
          if (_tarihAraligi != null) ...[
            const SizedBox(width: 4),
            ActionChip(
              label: const Icon(Icons.close, size: 14),
              backgroundColor: Colors.white,
              side: BorderSide(color: Colors.grey.shade300),
              onPressed: () {
                setState(() => _tarihAraligi = null);
                _filtreUygula();
              },
            ),
          ],
          const SizedBox(width: 8),
          // Fiş tipi çipleri
          ...fisTipleri.map((tip) {
            final secili = _secilenFisTipi == tip;
            final renk   = _fisTipiRenk(tip);
            return Padding(
              padding: const EdgeInsets.only(right: 6),
              child: FilterChip(
                label: Text(tip, style: TextStyle(fontSize: 12, color: secili ? Colors.white : renk)),
                selected: secili,
                onSelected: (_) {
                  setState(() => _secilenFisTipi = secili ? null : tip);
                  _filtreUygula();
                },
                backgroundColor: Colors.white,
                selectedColor: renk,
                side: BorderSide(color: secili ? renk : Colors.grey.shade300),
                showCheckmark: false,
              ),
            );
          }),
        ]),
      ),
    );
  }

  // ── Hareket Listesi ────────────────────────────
  Widget _hareketListesi() {
    if (_gosterilenHareketler.isEmpty) return _bostState();

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
      itemCount: _gosterilenHareketler.length,
      itemBuilder: (_, i) => _hareketKart(_gosterilenHareketler[i]),
    );
  }

  Widget _hareketKart(CariHareket h) {
    final renk    = _fisTipiRenk(h.fisTipi);
    final ikon    = _fisTipiIkon(h.fisTipi);
    final tarihFmt= DateFormat('dd MMM yyyy', 'tr_TR').format(h.tarih.toLocal());
    final saat    = DateFormat('HH:mm',       'tr_TR').format(h.tarih.toLocal());
    final bakiyeRenk = (h.bakiye ?? 0) > 0.001
        ? _Renk.borcRenk
        : (h.bakiye ?? 0) < -0.001
            ? _Renk.alacakRenk
            : _Renk.bakiyeSifir;

    return Dismissible(
      key: ValueKey(h.id),
      direction: h.id == -1 ? DismissDirection.none : DismissDirection.endToStart,
      background: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: _Renk.borcRenk,
          borderRadius: BorderRadius.circular(_Stil.itemRadius),
        ),
        child: const Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.delete_outline, color: Colors.white),
          SizedBox(height: 2),
          Text('Sil', style: TextStyle(color: Colors.white, fontSize: 11)),
        ]),
      ),
      confirmDismiss: (_) => _onayDiyalogu(
        baslik: 'Hareketi Sil',
        icerik: '"${h.aciklama}" hareketi silinecek. Bu işlem geri alınamaz.',
        onayRenk: _Renk.borcRenk,
      ),
      onDismissed: (_) => _silHareket(h),
      child: GestureDetector(
        onTap: () => _fisDetayiniGoster(h),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          decoration: BoxDecoration(
            color: _Renk.cardBg,
            borderRadius: BorderRadius.circular(_Stil.itemRadius),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: IntrinsicHeight(
            child: Row(children: [
              // Sol renk şeridi
              Container(
                width: 4,
                decoration: BoxDecoration(
                  color: renk,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(_Stil.itemRadius),
                    bottomLeft: Radius.circular(_Stil.itemRadius),
                  ),
                ),
              ),
              // İkon
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: renk.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(ikon, color: renk, size: 20),
                ),
              ),
              // Orta bilgiler
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(h.aciklama,
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 2),
                    Row(children: [
                      Icon(Icons.calendar_today_outlined, size: 11, color: Colors.grey[500]),
                      const SizedBox(width: 3),
                      Text('$tarihFmt  $saat',
                          style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                    ]),
                    if (h.fisNo != null && h.fisNo!.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Row(children: [
                        Icon(Icons.receipt_long_outlined, size: 11, color: Colors.grey[400]),
                        const SizedBox(width: 3),
                        Text('Fiş: ${h.fisNo}',
                            style: TextStyle(fontSize: 11, color: Colors.grey[400])),
                      ]),
                    ],
                  ]),
                ),
              ),
              // Sağ: borç / alacak / bakiye
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 12, 14, 12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.center, children: [
                  if (h.borc > 0.001)
                    Text('- ${_para.format(h.borc)} ₺',
                        style: const TextStyle(
                            color: _Renk.borcRenk, fontWeight: FontWeight.bold, fontSize: 13)),
                  if (h.alacak > 0.001)
                    Text('+ ${_para.format(h.alacak)} ₺',
                        style: const TextStyle(
                            color: _Renk.alacakRenk, fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: bakiyeRenk.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      '${_para.format((h.bakiye ?? 0).abs())} ₺',
                      style: TextStyle(
                          fontSize: 11,
                          color: bakiyeRenk,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  // ── Boş & Hata State ─────────────────────────
  Widget _bostState() {
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.receipt_long_outlined, size: 64, color: Colors.grey[300]),
        const SizedBox(height: 12),
        Text('Hareket bulunamadı',
            style: TextStyle(fontSize: 16, color: Colors.grey[400], fontWeight: FontWeight.w500)),
        const SizedBox(height: 6),
        Text('Filtre değiştirerek veya yeni hareket ekleyerek başlayın.',
            style: TextStyle(fontSize: 12, color: Colors.grey[400]),
            textAlign: TextAlign.center),
      ]),
    );
  }

  Widget _hataView() {
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.error_outline, size: 56, color: _Renk.borcRenk),
        const SizedBox(height: 12),
        const Text('Veriler yüklenemedi', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        Text(_hata ?? '', style: TextStyle(fontSize: 12, color: Colors.grey[500])),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _hareketleriGetir,
          icon: const Icon(Icons.refresh),
          label: const Text('Tekrar Dene'),
        ),
      ]),
    );
  }

  // ── Renk & İkon yardımcıları ─────────────────
  Color _fisTipiRenk(String tip) {
    switch (tip) {
      case 'Satış':    return _Renk.satis;
      case 'Alış':     return _Renk.alis;
      case 'Tahsilat': return _Renk.tahsilat;
      case 'Ödeme':    return _Renk.odeme;
      case 'Açılış':   return _Renk.acilis;
      default:         return _Renk.diger;
    }
  }

  IconData _fisTipiIkon(String tip) {
    switch (tip) {
      case 'Satış':    return Icons.shopping_cart_outlined;
      case 'Alış':     return Icons.inventory_2_outlined;
      case 'Tahsilat': return Icons.payments_outlined;
      case 'Ödeme':    return Icons.send_outlined;
      case 'Açılış':   return Icons.history_outlined;
      default:         return Icons.receipt_outlined;
    }
  }
}

// ══════════════════════════════════════════════
// Hareket Ekleme Bottom Sheet
// ══════════════════════════════════════════════
class _HareketEkleSheet extends StatefulWidget {
  final int cariId;
  final VoidCallback onKaydet;

  const _HareketEkleSheet({required this.cariId, required this.onKaydet});

  @override
  State<_HareketEkleSheet> createState() => _HareketEkleSheetState();
}

class _HareketEkleSheetState extends State<_HareketEkleSheet> {
  final _formKey     = GlobalKey<FormState>();
  final _tutarCtrl   = TextEditingController();
  final _aciklamaCtrl= TextEditingController();
  final _hareketRepo = CariHareketRepo();

  String _fisTipi = 'Tahsilat';
  bool   _kaydediliyor = false;

  final List<String> _tipler = ['Tahsilat', 'Ödeme', 'Düzeltme'];

  Future<void> _kaydet() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _kaydediliyor = true);

    final tutar = double.parse(_tutarCtrl.text.replaceAll(',', '.'));

    final hareket = CariHareket(
      cariId: widget.cariId,
      tarih: DateTime.now(),
      fisTipi: _fisTipi,
      aciklama: _aciklamaCtrl.text.trim().isNotEmpty
          ? _aciklamaCtrl.text.trim()
          : _fisTipi,
      borc:   _fisTipi == 'Ödeme'     ? tutar : 0,
      alacak: _fisTipi == 'Tahsilat'  ? tutar : 0,
    );

    try {
      await _hareketRepo.hareketEkle(hareket);
      widget.onKaydet();
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _kaydediliyor = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Kayıt hatası: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + bottom),
      child: Form(
        key: _formKey,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          // Handle
          Container(width: 40, height: 4, decoration: BoxDecoration(
              color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 16),
          const Text('Yeni Hareket Ekle',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),

          // Fiş tipi
          SegmentedButton<String>(
            segments: _tipler.map((t) => ButtonSegment(value: t, label: Text(t))).toList(),
            selected: {_fisTipi},
            onSelectionChanged: (s) => setState(() => _fisTipi = s.first),
            style: SegmentedButton.styleFrom(
              selectedBackgroundColor: _Renk.primary,
              selectedForegroundColor: Colors.white,
            ),
          ),
          const SizedBox(height: 16),

          // Tutar
          TextFormField(
            controller: _tutarCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: 'Tutar (₺)',
              prefixIcon: const Icon(Icons.attach_money),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            ),
            validator: (v) {
              if (v == null || v.isEmpty) return 'Tutar giriniz';
              if (double.tryParse(v.replaceAll(',', '.')) == null) return 'Geçersiz tutar';
              return null;
            },
          ),
          const SizedBox(height: 12),

          // Açıklama
          TextFormField(
            controller: _aciklamaCtrl,
            decoration: InputDecoration(
              labelText: 'Açıklama (opsiyonel)',
              prefixIcon: const Icon(Icons.notes_outlined),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          const SizedBox(height: 20),

          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _kaydediliyor ? null : _kaydet,
              icon: _kaydediliyor
                  ? const SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.save_outlined),
              label: const Text('Kaydet'),
              style: FilledButton.styleFrom(
                backgroundColor: _Renk.primary,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}