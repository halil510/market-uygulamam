// lib/repozitory/urun_repo.dart
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:sqflite/sqflite.dart';
import 'package:market_uygulamasi/servisler/log_servisi.dart';
import 'package:market_uygulamasi/servisler/cache_servisi.dart';
import 'package:market_uygulamasi/yardimci/performans_servisi.dart';
import 'package:market_uygulamasi/yardimci/convert_helper.dart';

class UrunRepoSitory {
  final VeritabaniYardimcisi _dbHelper = VeritabaniYardimcisi();
  final CacheServisi _cache = CacheServisi();
  final PerformansServisi _perf = PerformansServisi();

  Future<Database> get db async => _dbHelper.db;

  void _clearUrunCaches() {
    _cache.remove('tum_urunler');
    _cache.remove('ana_gruplar');
    _cache.remove('alt_gruplar');
    for (int i = 0; i < 100; i++) {
      _cache.remove('tum_urunler_page_$i');
    }
  }

  // ======================== ÜRÜN CRUD ========================
  Future<void> urunEkle(Urun urun) async {
    try {
      Log.i('Ürün ekleniyor: ${urun.ad}', tag: 'UrunRepo');
      if (urun.ad.isEmpty) {
        Log.w('Ürün adı boş olamaz', tag: 'UrunRepo');
        throw Exception('Ürün adı boş olamaz');
      }
      final database = await db;
      await _perf.olcVeCalistir('urunEkle', () async {
        await database.insert(
          'urunler',
          urun.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      });
      _clearUrunCaches();
      Log.i('Ürün başarıyla eklendi: ${urun.ad} (ID: ${urun.id})', tag: 'UrunRepo');
    } catch (e, stackTrace) {
      Log.e('Ürün ekleme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  Future<void> urunGuncelle(Urun urun) async {
    try {
      Log.i('Ürün güncelleniyor: ${urun.ad} (ID: ${urun.id})', tag: 'UrunRepo');
      if (urun.id == null) {
        Log.e('Ürün IDsi boş olamaz', tag: 'UrunRepo');
        throw Exception('Ürün IDsi boş olamaz');
      }
      final database = await db;
      await _perf.olcVeCalistir('urunGuncelle', () async {
        final result = await database.update(
          'urunler',
          urun.toMap(),
          where: 'id = ?',
          whereArgs: [urun.id],
        );
        if (result == 0) {
          Log.w('Güncellenecek ürün bulunamadı: ID ${urun.id}', tag: 'UrunRepo');
          throw Exception('Ürün bulunamadı');
        }
      });
      _clearUrunCaches();
      Log.i('Ürün başarıyla güncellendi: ${urun.ad} (ID: ${urun.id})', tag: 'UrunRepo');
    } catch (e, stackTrace) {
      Log.e('Ürün güncelleme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  Future<void> urunSil(int id) async {
    try {
      Log.i('Ürün siliniyor: ID $id', tag: 'UrunRepo');
      final database = await db;
      await _perf.olcVeCalistir('urunSil', () async {
        final result = await database.delete(
          'urunler',
          where: 'id = ?',
          whereArgs: [id],
        );
        if (result == 0) {
          Log.w('Silinecek ürün bulunamadı: ID $id', tag: 'UrunRepo');
          throw Exception('Ürün bulunamadı');
        }
      });
      _clearUrunCaches();
      Log.i('Ürün başarıyla silindi: ID $id', tag: 'UrunRepo');
    } catch (e, stackTrace) {
      Log.e('Ürün silme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  Future<void> stokGuncelle(int id, double yeniStok) async {
    try {
      Log.i('Stok güncelleniyor: ID $id, Yeni stok: $yeniStok', tag: 'UrunRepo');
      final database = await db;
      await _perf.olcVeCalistir('stokGuncelle', () async {
        final result = await database.update(
          'urunler',
          {'stokMiktari': yeniStok},
          where: 'id = ?',
          whereArgs: [id],
        );
        if (result == 0) {
          Log.w('Stok güncellenecek ürün bulunamadı: ID $id', tag: 'UrunRepo');
          throw Exception('Ürün bulunamadı');
        }
      });
      _clearUrunCaches();
      Log.i('Stok başarıyla güncellendi: ID $id, Yeni stok: $yeniStok', tag: 'UrunRepo');
    } catch (e, stackTrace) {
      Log.e('Stok güncelleme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  // ======================== BARKOD İLE GETİR ========================
  Future<Urun?> barkodlaUrunGetir(String barkod) async {
    try {
      Log.d('Barkod ile ürün aranıyor: $barkod', tag: 'UrunRepo');
      final trimmedBarkod = barkod.trim();
      if (trimmedBarkod.isEmpty) {
        Log.w('Barkod boş olamaz', tag: 'UrunRepo');
        return null;
      }
      return _cache.getOrFetch('urun_barkod_$trimmedBarkod', () async {
        final database = await db;
        final anaBarkodSonuc = await database.query(
          'urunler',
          where: 'TRIM(barkod) = ?',
          whereArgs: [trimmedBarkod],
          limit: 1,
        );
        if (anaBarkodSonuc.isNotEmpty) {
          return Urun.fromMap(anaBarkodSonuc.first);
        }
        final alternatifSonuclar = await database.query(
          'urunler',
          where: "barkodlar LIKE ?",
          whereArgs: ['%$trimmedBarkod%'],
        );
        for (final map in alternatifSonuclar) {
          final urun = Urun.fromMap(map);
          final barkodlar = (urun.barkodlar ?? '').split(',').map((e) => e.trim()).toList();
          if (barkodlar.any((b) => b.toLowerCase() == trimmedBarkod.toLowerCase())) {
            return urun;
          }
        }
        return null;
      });
    } catch (e, stackTrace) {
      Log.e('Barkod ile ürün getirme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  // ======================== TOPLU GETİRME ========================
  Future<List<Urun>> tumUrunleriGetir({String? barkod}) async {
    final cacheKey = barkod != null ? 'urunler_ara_$barkod' : 'tum_urunler';
    return _cache.getOrFetch(cacheKey, () async {
      Log.i('Tüm ürünler getiriliyor. Barkod filtresi: $barkod', tag: 'UrunRepo');
      final database = await db;
      List<Map<String, dynamic>> maps;
      if (barkod != null && barkod.isNotEmpty) {
        final trimmedBarkod = barkod.trim();
        maps = await database.query(
          'urunler',
          where: 'TRIM(barkod) = ?',
          whereArgs: [trimmedBarkod],
        );
        if (maps.isEmpty) {
          maps = await database.query(
            'urunler',
            where: "barkodlar LIKE ?",
            whereArgs: ['%$trimmedBarkod%'],
          );
        }
      } else {
        maps = await database.query('urunler');
      }
      Log.d('${maps.length} ürün bulundu', tag: 'UrunRepo');
      return maps.map((m) => Urun.fromMap(m)).toList();
    }, expiry: const Duration(minutes: 5));
  }

  Future<List<Urun>> urunleriSayfaliGetir(int offset, int limit) async {
    final cacheKey = 'tum_urunler_page_$offset';
    return _cache.getOrFetch(cacheKey, () async {
      final database = await db;
      final maps = await database.query(
        'urunler',
        offset: offset,
        limit: limit,
        orderBy: 'ad ASC',
      );
      return maps.map((m) => Urun.fromMap(m)).toList();
    }, expiry: const Duration(minutes: 5));
  }

  // ======================== TEKİL GETİRME ========================
  Future<Urun?> urunGetir(int id) async {
    return _cache.getOrFetch('urun_$id', () async {
      Log.d('Ürün getiriliyor: ID $id', tag: 'UrunRepo');
      final database = await db;
      final maps = await database.query(
        'urunler',
        where: 'id = ?',
        whereArgs: [id],
        limit: 1,
      );
      final urun = maps.isNotEmpty ? Urun.fromMap(maps.first) : null;
      if (urun == null) Log.w('Ürün bulunamadı: ID $id', tag: 'UrunRepo');
      return urun;
    });
  }

  Future<Urun?> idyeGoreUrunGetir(int id) async => urunGetir(id);



// ======================== SAYFALI ARAMA (AD + BARKOD + ALTERNATİF) ========================
Future<List<Urun>> urunAraSayfali(String kelime, int limit, int offset) async {
  if (kelime.isEmpty) return [];
  final cacheKey = 'urun_ara_sayfali_${kelime}_${offset}_$limit';
  return _cache.getOrFetch(cacheKey, () async {
    Log.d('Sayfalı arama: "$kelime", limit=$limit, offset=$offset', tag: 'UrunRepo');
    final database = await db;
    final maps = await database.rawQuery('''
      SELECT * FROM urunler 
      WHERE ad LIKE ? 
         OR barkod LIKE ? 
         OR barkodlar LIKE ?
      ORDER BY ad ASC
      LIMIT ? OFFSET ?
    ''', ['%$kelime%', '%$kelime%', '%$kelime%', limit, offset]);
    return maps.map((m) => Urun.fromMap(m)).toList();
  }, expiry: const Duration(minutes: 3));
}
// ======================== ARAMA (AD + BARKOD + ALTERNATİF BARKODLAR) ========================
Future<List<Urun>> adaGoreUrunAra(String kelime) async {
  if (kelime.isEmpty) return [];
  final cacheKey = 'urun_ara_$kelime';
  return _cache.getOrFetch(cacheKey, () async {
    Log.d('Ad / barkod ile ürün aranıyor: $kelime', tag: 'UrunRepo');
    final database = await db;
    final maps = await database.rawQuery('''
      SELECT * FROM urunler 
      WHERE ad LIKE ? 
         OR barkod LIKE ? 
         OR barkodlar LIKE ?
    ''', ['%$kelime%', '%$kelime%', '%$kelime%']);
    Log.d('${maps.length} ürün bulundu: "$kelime"', tag: 'UrunRepo');
    return maps.map((m) => Urun.fromMap(m)).toList();
  }, expiry: const Duration(minutes: 3));
}

  // ======================== GRUPLAR (DÜZELTİLDİ – anagrup, altGrup) ========================
  Future<List<String>> anaGruplariGetir() async {
    return _cache.getOrFetch('ana_gruplar', () async {
      Log.d('Ana gruplar getiriliyor', tag: 'UrunRepo');
      final database = await db;
      final result = await database.rawQuery(
        "SELECT DISTINCT anagrup FROM urunler WHERE anagrup IS NOT NULL AND anagrup != ''"
      );
      return result.map((e) => e['anagrup'] as String).toList();
    }, expiry: const Duration(hours: 1));
  }

  Future<List<String>> tumAnaGruplariGetir() async => anaGruplariGetir();

  Future<List<String>> altGruplariGetir() async {
    return _cache.getOrFetch('alt_gruplar', () async {
      Log.d('Alt gruplar getiriliyor', tag: 'UrunRepo');
      final database = await db;
      final result = await database.rawQuery(
        "SELECT DISTINCT altGrup FROM urunler WHERE altGrup IS NOT NULL AND altGrup != ''"
      );
      return result.map((e) => e['altGrup'] as String).toList();
    }, expiry: const Duration(hours: 1));
  }
      Future<List<String>> tumAltGruplariGetir() async => altGruplariGetir();

    // ======================== alan1 getir ========================

  
Future<List<String>> tumAlan1DegerleriniGetir() async {
  final Database db = await this.db; // veya await _dbHelper.db
  final result = await db.query(
    'urunler',
    columns: ['alan1'],
    where: 'alan1 IS NOT NULL AND alan1 != ""',
  );
  final List<String> list = result.map((row) => row['alan1'] as String).toList();
  return list.toSet().toList();
}
  // --------------------- Geçici Sayım ---------------------
  Future<List<Map<String, dynamic>>> geciciSayimListesiGetir() async {
    try {
      Log.d('Geçici sayım listesi getiriliyor', tag: 'UrunRepo');
      return await _dbHelper.geciciSayimListesiGetir();
    } catch (e, stackTrace) {
      Log.e('Geçici sayım listesi getirme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  Future<void> geciciSayimEkleveyaGuncelle(int urunId, double mevcutStok, double yeniStok) async {
    try {
      Log.d('Geçici sayım kaydı ekleniyor/güncelleniyor: ürünId=$urunId', tag: 'UrunRepo');
      await _dbHelper.geciciSayimEkleveyaGuncelle(urunId, mevcutStok, yeniStok);
    } catch (e, stackTrace) {
      Log.e('Geçici sayım ekleme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  Future<void> geciciSayimSil(int urunId) async {
    try {
      Log.d('Geçici sayım siliniyor: ürünId=$urunId', tag: 'UrunRepo');
      await _dbHelper.geciciSayimSil(urunId);
    } catch (e, stackTrace) {
      Log.e('Geçici sayım silme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  Future<void> geciciSayimTemizle() async {
    try {
      Log.d('Geçici sayım tablosu temizleniyor', tag: 'UrunRepo');
      await _dbHelper.geciciSayimTemizle();
    } catch (e, stackTrace) {
      Log.e('Geçici sayım temizleme hatası', tag: 'UrunRepo', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }
}