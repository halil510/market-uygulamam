import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:market_uygulamasi/modeller/iade_kaydi.dart';
import 'package:market_uygulamasi/servisler/barkod_servisi.dart';

class ExcelIadeServisi {
  static String _temizleIndirim(String? deger) {
    if (deger == null || deger.isEmpty) return '';
    // Sadece sayı, nokta ve virgülü al
    final regex = RegExp(r'(\d+[.,]?\d*)');
    final match = regex.firstMatch(deger);
    if (match != null) {
      String sayi = match.group(0)!;
      sayi = sayi.replaceAll(',', '.'); // virgülü noktaya çevir
      return sayi;
    }
    return '';
  }

  static Future<File> iadeKayitlariniExceleAktar(List<IadeKaydi> iadeler) async {
    final excel = Excel.createExcel();
    final sheet = excel['Iade Kayıtları'];

    sheet.appendRow([
      'ID', 'Ürün Adı', 'Barkod', 'Kod', 'Fiyat', 'Kart Satış Fiyatı',
      'Miktar', 'İade Nedeni', 'Tarih', 'Indirim(%)', 'Kdv(%)'
    ]);

    for (final iade in iadeler) {
      final duzeltilmisBarkod = BarkodServisi().duzeltBarkod(iade.barkod);
      final temizIndirim = _temizleIndirim(iade.indirimNotu);
      
      sheet.appendRow([
        iade.id,
        iade.urunAdi,
        iade.barkod,
        duzeltilmisBarkod,
        iade.alisFiyati,
        iade.satisFiyati,
        iade.iadeMiktari,
        iade.nedeni,
        iade.tarih.toString(),
        temizIndirim,
        iade.kdvOrani,
      ]);
    }

    final dir = await getTemporaryDirectory();
    final filePath = '${dir.path}/iade_kayitlari_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    final file = File(filePath);
    await file.writeAsBytes(excel.encode()!);
    return file;
  }

  static Future<void> dosyayiPaylas(File file) async {
    await Share.shareFiles([file.path], text: 'İade Kayıtları');
  }
}