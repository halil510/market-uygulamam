// lib/ekranlar/cari/cari_liste_ekrani.dart — Modern v2
import 'cari_secim_baglami.dart';
import 'package:market_plus/cekirdek/utils/metin_arama.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'masaustu/cari_masaustu_gorunum.dart';
import '../../widgetlar/ortak/bulut_durum_widget.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../saglayicilar/riverpod/cari_provider.dart';
import '../../saglayicilar/riverpod/auth_provider.dart';
import '../../modeller/cari_model.dart';
import '../../servisler/bildirim_servisi.dart';
import '../../cekirdek/utils/para_utils.dart';
import '../../uygulama/tema/uygulama_temasi.dart';
import '../../widgetlar/ortak/yukleniyor_widget.dart';
import '../../tasarim_sistemi/tasarim_sistemi.dart';
import '../../depolar/cari_deposu.dart';
import '../../depolar/bekleyen_siparis_deposu.dart';
import '../../servisler/excel_servisi.dart';
import '../../cekirdek/utils/hata_utils.dart';
import '../../widgetlar/cari/cari_excel_ice_aktar_yardimcisi.dart';
import '../../widgetlar/masaustu/tekrar_gorununce_yenile.dart';

class CariListeEkrani extends ConsumerStatefulWidget {
  /// AI Chat'ten "cari X'e git" gibi bir komutla gelindiğinde, ekran
  /// açılır açılmaz bu terimle otomatik arama yapılması için.
  final String? baslangicArama;
  const CariListeEkrani({super.key, this.baslangicArama});
  @override
  ConsumerState<CariListeEkrani> createState() => _CariListeEkraniState();
}

class _CariListeEkraniState extends ConsumerState<CariListeEkrani>
    with SingleTickerProviderStateMixin, TekrarGorununceYenile {
  // Başka ekranda yapılan satış/tahsilat/iade bakiyeleri değiştirmiş olabilir.
  @override
  void tekrarGorununce() => ref.read(carilerProvider.notifier).yukle();

  late TabController _tab;
  final _araCtrl = TextEditingController();
  Timer? _debounce;
  String _bakiyeFiltre = 'Tümü';
  static const _filtreler = ['Tümü', 'Alacaklı', 'Borçlu', 'Dengede'];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
    _araCtrl.addListener(_aramaChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(carilerProvider.notifier).yukle();
      if (widget.baslangicArama != null && widget.baslangicArama!.trim().isNotEmpty) {
        _araCtrl.text = widget.baslangicArama!.trim();
      }
    });
  }

  @override
  void dispose() {
    _tab.dispose();
    _debounce?.cancel();
    _araCtrl.dispose();
    super.dispose();
  }

  void _aramaChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      ref.read(cariFiltresiProvider.notifier).aramaGuncelle(_araCtrl.text);
    });
  }

  Future<void> _sil(CariModel c) async {
    // 🔴 DÜZELTME (Madde 19 — Silme Mantığı denetimi, 2026-09-16): bu
    // diyalog carinin AÇIK (durum='bekliyor') bekleyen siparişi olup
    // olmadığını hiç kontrol etmiyordu — cari silindiğinde (soft-delete)
    // fiziksel kayıt bozulmuyor ama cari artık dropdown/arama
    // sonuçlarında görünmediğinden, o siparişi kapatmak için cari
    // tekrar seçilemiyordu. Bakiye uyarısıyla aynı desende, doluysa
    // net bir uyarı ekleniyor.
    var bekleyenSiparisSayisi = 0;
    if (c.id != null) {
      try {
        final bekleyenler = await BekleyenSiparisDeposu()
            .bekleyenSiparisleriGetir(cariId: c.id, durum: 'bekliyor');
        bekleyenSiparisSayisi = bekleyenler.length;
      } catch (_) {
        // Sayım başarısız olursa sessizce geç — silme akışını bloklamasın.
      }
    }
    if (!mounted) return;
    final onay = await showDialog<bool>(context: context,
      builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        
        title: Row(children: [
          Container(padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: TsRenk.zemin(TsRenk.hata), shape: BoxShape.circle),
            child: const Icon(Icons.delete_outline, color: TsRenk.hata, size: 20)),
          const SizedBox(width: 10),
          const Text('Cari Sil', style: TextStyle(fontSize: 16)),
        ]),
        // 🔴 Derin denetimde bulundu (P2): bu diyalog carinin bakiyesini
        // hiç göstermiyordu — borçlu/alacaklı bir cari (soft-delete
        // olduğu için veri kaybolmasa da) is_deleted=0 filtresi
        // kullanan TÜM ekran/rapordan kaybolur, işletme o parayı
        // unutabilir. Bakiye sıfır değilse net bir uyarı ekleniyor.
        content: RichText(text: TextSpan(
          style: TextStyle(color: TsRenk.metinBirincil(ctx), fontSize: 14),
          children: [
            TextSpan(text: c.unvan, style: const TextStyle(fontWeight: FontWeight.w700)),
            const TextSpan(text: ' adlı cari silinecek.\nBu işlem geri alınamaz.'),
            if (c.bakiye.abs() > 0.005)
              TextSpan(
                text: c.bakiye > 0
                    ? '\n\n⚠️ Bu carinin ${ParaUtils.formatla(c.bakiye)} alacağı var — '
                      'silindikten sonra raporlarda görünmeyecek.'
                    : '\n\n⚠️ Bu carinin ${ParaUtils.formatla(c.bakiye.abs())} borcu var — '
                      'silindikten sonra raporlarda görünmeyecek.',
                style: const TextStyle(color: TsRenk.hata, fontWeight: FontWeight.w600),
              ),
            if (bekleyenSiparisSayisi > 0)
              TextSpan(
                text: '\n\n⚠️ Bu carinin $bekleyenSiparisSayisi bekleyen siparişi var — '
                    'cari silindikten sonra arama/seçim listelerinde görünmeyeceği için '
                    'bu siparişleri kapatmak zorlaşacak.',
                style: const TextStyle(color: TsRenk.hata, fontWeight: FontWeight.w600),
              ),
          ],
        )),
        actions: [
              const BulutDurumIkonu(),
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(
            style: FilledButton.styleFrom(foregroundColor: Colors.white,
          backgroundColor: TsRenk.hata),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sil')),
        ],
      ));
    if (onay != true || !mounted) return;
    try {
      await ref.read(carilerProvider.notifier).sil(c.id!);
      if (mounted) BildirimServisi.basari(context, '${c.unvan} silindi');
    } catch (e) {
      if (mounted) BildirimServisi.hata(context, 'Hata: $e');
    }
  }

  /// Masaüstü çoklu seçimden toplu silme. Tekli silmedeki uyarılar (bakiye,
  /// bekleyen sipariş) TEK özet onayda toplanır; silme carilerProvider.sil ile
  /// tek tek yapılır, biri hata verse de diğerleri devam eder.
  Future<bool> _topluSil(List<CariModel> cariler) async {
    if (cariler.isEmpty) return false;
    final bakiyeli = cariler.where((c) => c.bakiye.abs() > 0.005).toList();
    var siparisli = 0;
    for (final c in cariler) {
      if (c.id == null) continue;
      try {
        final b = await BekleyenSiparisDeposu()
            .bekleyenSiparisleriGetir(cariId: c.id, durum: 'bekliyor');
        if (b.isNotEmpty) siparisli++;
      } catch (_) {/* sayım başarısızsa uyarısız devam */}
    }
    if (!mounted) return false;
    final onay = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('${cariler.length} Cari Silinsin mi?', style: const TextStyle(fontSize: 16)),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(cariler.take(8).map((c) => '• ${c.unvan}').join('\n') +
              (cariler.length > 8 ? '\n… ve ${cariler.length - 8} cari daha' : '')),
          const SizedBox(height: 8),
          const Text('Bu işlem geri alınamaz.'),
          if (bakiyeli.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(
                  '⚠️ ${bakiyeli.length} carinin bakiyesi var (toplam '
                  '${ParaUtils.formatla(bakiyeli.fold<double>(0, (t, c) => t + c.bakiye.abs()))}) — '
                  'silindikten sonra raporlarda görünmeyecek.',
                  style: const TextStyle(color: TsRenk.hata, fontWeight: FontWeight.w600)),
            ),
          if (siparisli > 0)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(
                  '⚠️ $siparisli carinin bekleyen siparişi var — silindikten sonra bu '
                  'siparişleri kapatmak zorlaşacak.',
                  style: const TextStyle(color: TsRenk.hata, fontWeight: FontWeight.w600)),
            ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(
            style: FilledButton.styleFrom(foregroundColor: Colors.white, backgroundColor: TsRenk.hata),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('${cariler.length} Cariyi Sil'),
          ),
        ],
      ),
    );
    if (onay != true || !mounted) return false;
    var silinen = 0;
    final hatalar = <String>[];
    for (final c in cariler) {
      try {
        await ref.read(carilerProvider.notifier).sil(c.id!);
        silinen++;
      } catch (e) {
        hatalar.add('${c.unvan}: ${kullaniciyaHataMetni(e)}');
      }
    }
    if (!mounted) return true;
    if (hatalar.isEmpty) {
      BildirimServisi.basari(context, '$silinen cari silindi');
    } else {
      BildirimServisi.hata(context,
          '$silinen cari silindi, ${hatalar.length} silinemedi: ${hatalar.first}');
    }
    return true;
  }

  // ── Excel dışa aktar ────────────────────────────────────────────────────
  // Kullanıcı isteği (2026-09-21): "cari listede excel içe alma dışa
  // verme olsun... tüm carileri dışa verme mümkün mü". TÜM cariler
  // (pasif dahil) tek dosyada — CariDeposu.tumunuBorcAlacakAdresIle()
  // her cari için gerçek toplam borç/alacağı (cari_hareket'ten) ve
  // varsayılan adresini de getirir.
  Future<void> _excelDisaAktar({Set<int>? sadece}) async {
    try {
      var satirlar = await CariDeposu().tumunuBorcAlacakAdresIle();
      if (sadece != null) {
        satirlar = satirlar.where((r) => sadece.contains(r['id'])).toList();
      }
      if (satirlar.isEmpty) {
        if (mounted) BildirimServisi.uyari(context, 'Dışa aktarılacak cari bulunamadı');
        return;
      }
      final yol = await ExcelServisi().carileriExcelEAktar(satirlar);
      await ExcelServisi().paylasExcel(yol);
    } catch (e) {
      if (mounted) BildirimServisi.hata(context, 'Excel hatası: $e');
    }
  }

  List<CariModel> _filtrele(List<CariModel> liste) {
    if (_bakiyeFiltre == 'Tümü') return liste;
    return liste.where((c) {
      switch (_bakiyeFiltre) {
        case 'Alacaklı': return c.bakiye > 0;
        case 'Borçlu':   return c.bakiye < 0;
        case 'Dengede':  return c.bakiye == 0;
        default:         return true;
      }
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final durum  = ref.watch(carilerProvider);
    final filtre = ref.watch(cariFiltresiProvider);

    // Filtreleme - memoize için durum değişmeden hesaplamayı atla
    final aramaMetni = aramaNormalize(filtre.aramaMetni);
    // 🔴 DÜZELTME (cari ekranları derin analizi, 2026-09-14): "Tümü"
    // sekmesi ünvan/telefon/cari kodu ÜÇÜNÜ de kontrol ederken, "Müşteri"
    // ve "Tedarikçi" sekmeleri SADECE ünvanı kontrol ediyordu — AYNI arama
    // terimini yazan kullanıcı "Tümü"de sonuç görüp sekme değiştirince
    // (ör. bir telefon numarası aratılınca) boş liste görüyordu. Artık her
    // üç sekme de AYNI eşleşme kuralını kullanıyor.
    bool aramaEslesiyor(CariModel c) =>
        aramaMetni.isEmpty ||
        aramaNormalize(c.unvan).contains(aramaMetni) ||
        (c.telefon?.contains(aramaMetni) ?? false) ||
        aramaNormalize(c.cariKodu ?? '').contains(aramaMetni);
    final hepsi = [...durum.musteriler,
      ...durum.tedarikciler.where((t) => !durum.musteriler.any((m) => m.id == t.id))];
    final tum = _filtrele(hepsi.where(aramaEslesiyor).toList());
    final musteriler   = _filtrele(durum.musteriler.where(aramaEslesiyor).toList());
    final tedarikciler = _filtrele(durum.tedarikciler.where(aramaEslesiyor).toList());
    // Bayi sekmesi: Toptan Satış ekranıyla aynı kural (müşteri olabilen +
    // müşteri tipi Bayi/Toptan). "Tümü" yine herkesi içerir.
    final bayiler = _filtrele(hepsi.where((c) =>
        aramaEslesiyor(c) &&
        c.cariTipi.contains('Müşteri') &&
        (c.musteriTipi == 'Bayi' || c.musteriTipi == 'Toptan')).toList());
    final toplamAlacak = durum.toplamAlacak;
    final toplamBorc   = durum.toplamBorc;

    return Scaffold(
      backgroundColor: context.scaffoldBg,
      appBar: TsAppBar(
        baslikWidget: const Text('Cariler',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 18)),
        aksiyonlar: [
          IconButton(icon: const Icon(Icons.refresh, color: Colors.white),
              onPressed: () => ref.read(carilerProvider.notifier).yukle()),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            onSelected: (v) {
              if (v == 'excel') _excelDisaAktar();
              if (v == 'excel_ice') {
                CariExcelIceAktarYardimcisi.iceAktar(context,
                    onTamamlandi: () => ref.read(carilerProvider.notifier).yukle());
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                  value: 'excel_ice',
                  child: ListTile(
                      dense: true,
                      leading: Icon(Icons.upload_file, size: 18, color: TsRenk.basarili),
                      title: Text('Excel\'den İçe Aktar', style: TextStyle(fontSize: 13)))),
              PopupMenuItem(
                  value: 'excel',
                  child: ListTile(
                      dense: true,
                      leading: Icon(Icons.download, size: 18, color: AppRenkler.primary),
                      title: Text('Tüm Carileri Excel\'e Aktar', style: TextStyle(fontSize: 13)))),
            ],
          ),
        ],
        alt: PreferredSize(
          preferredSize: const Size.fromHeight(96),
          child: Column(children: [
            // Arama
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Container(
                height: 40,
                decoration: BoxDecoration(
                    color: const Color(0x26FFFFFF),
                    borderRadius: BorderRadius.circular(20)),
                child: TextField(
                  controller: _araCtrl,
                  cursorColor: Colors.white,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Ad, kod, telefon ara...',
                    hintStyle: const TextStyle(color: Color(0xB2FFFFFF), fontSize: 13),
                    prefixIcon: const Icon(Icons.search, color: Colors.white70, size: 18),
                    suffixIcon: _araCtrl.text.isNotEmpty
                        ? IconButton(icon: const Icon(Icons.clear, color: Colors.white70, size: 16),
                            onPressed: () { _araCtrl.clear(); ref.read(cariFiltresiProvider.notifier).aramaGuncelle(''); })
                        : null,
                    // 🔴🔴 KRİTİK DÜZELTME (kullanıcı bulgusu, 2026-09-22):
                    // uygulama genelinde ThemeData.inputDecorationTheme
                    // TÜM TextField'lara VARSAYILAN olarak `filled: true,
                    // fillColor: AppRenkler.background` (açık temada
                    // neredeyse beyaz, #F8F9FE) uyguluyor — bu alan bunu
                    // hiç EZMEDİĞİ için, dıştaki Container'ın (gradyan
                    // üstünde görünmesi için tasarlanmış) yarı saydam beyaz
                    // arkaplanının ÜSTÜNE, TextField'ın KENDİ neredeyse-
                    // beyaz dolgusu biniyordu — beyaz yazı, neredeyse beyaz
                    // dolgunun üstünde YAZARKEN görünmüyordu (arama
                    // ÇALIŞIYORDU, sadece yazı görünmüyordu — kullanıcı
                    // bulgusuyla birebir eşleşiyor). Diğer tüm liste
                    // ekranları (satis_liste_ekrani.dart, personel_liste_
                    // ekrani.dart vb.) bu global varsayılanı BİLİNÇLİ
                    // OLARAK ezip kendi fillColor'unu veriyordu — burada
                    // unutulmuştu.
                    filled: false,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 11),
                  ),
                ),
              ),
            ),
            // Tab bar
            TabBar(
              controller: _tab,
              indicatorColor: Colors.white,
              indicatorWeight: 3,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white60,
              labelStyle: TsMetin.kucukVurgu,
              tabs: [
                Tab(text: 'Tümü (${tum.length})'),
                Tab(text: 'Müşteri (${musteriler.length})'),
                Tab(text: 'Tedarikçi (${tedarikciler.length})'),
                Tab(text: 'Bayi (${bayiler.length})'),
              ],
            ),
          ]),
        ),
        geriTusu: false,
      ),
      body: Column(children: [
        // Özet + Filtre şeridi
        Container(
          color: context.cardBg,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(children: [
            // Alacak chip
            if (toplamAlacak > 0) _OzetChip(
              ikon: Icons.arrow_downward_rounded,
              renk: TsRenk.basarili,
              etiket: 'Alacak',
              tutar: toplamAlacak),
            if (toplamAlacak > 0) const SizedBox(width: 8),
            // Borç chip
            if (toplamBorc > 0) _OzetChip(
              ikon: Icons.arrow_upward_rounded,
              renk: TsRenk.hata,
              etiket: 'Borç',
              tutar: toplamBorc),
            const Spacer(),
            // Bakiye filtre
            PopupMenuButton<String>(
              initialValue: _bakiyeFiltre,
              onSelected: (v) => setState(() => _bakiyeFiltre = v),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                    color: _bakiyeFiltre != 'Tümü'
                        ? AppRenkler.primary.withAlpha(26) : context.borderColor,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _bakiyeFiltre != 'Tümü'
                        ? AppRenkler.primary : context.borderColor)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.filter_list, size: 14),
                  const SizedBox(width: 4),
                  Text(_bakiyeFiltre, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                ]),
              ),
              itemBuilder: (_) => _filtreler.map((f) => PopupMenuItem(
                value: f, child: Text(f))).toList(),
            ),
          ]),
        ),

        Expanded(
          child: durum.yukleniyor
              ? const SatirYukleniyorWidget(satirSayisi: 7)
              : TabBarView(controller: _tab, children: [
                  _CariTab(cariler: tum, onSil: _sil, onTopluSil: _topluSil,
                      onTopluExcel: (ids) => _excelDisaAktar(sadece: ids),
                      onRefresh: () => ref.read(carilerProvider.notifier).yukle()),
                  _CariTab(cariler: musteriler, onSil: _sil, onTopluSil: _topluSil,
                      onTopluExcel: (ids) => _excelDisaAktar(sadece: ids),
                      onRefresh: () => ref.read(carilerProvider.notifier).yukle()),
                  _CariTab(cariler: tedarikciler, onSil: _sil, onTopluSil: _topluSil,
                      onTopluExcel: (ids) => _excelDisaAktar(sadece: ids),
                      onRefresh: () => ref.read(carilerProvider.notifier).yukle()),
                  _CariTab(cariler: bayiler, onSil: _sil, onTopluSil: _topluSil,
                      onTopluExcel: (ids) => _excelDisaAktar(sadece: ids),
                      onRefresh: () => ref.read(carilerProvider.notifier).yukle()),
                ]),
        ),
      ]),
      floatingActionButton: MediaQuery.sizeOf(context).width > 1100 ? null : TsYetkili(child: FloatingActionButton.extended(
        elevation: 6,
        backgroundColor: AppRenkler.primary,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.person_add),
        label: const Text('Cari Ekle'),
        onPressed: () => context.push('/cari/ekle').then((_) =>
            ref.read(carilerProvider.notifier).yukle()),
      )),
    );
  }
}

class _OzetChip extends StatelessWidget {
  final IconData ikon; final Color renk; final String etiket; final double tutar;
  const _OzetChip({required this.ikon, required this.renk, required this.etiket, required this.tutar});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: renk.withAlpha(20), borderRadius: BorderRadius.circular(12)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(ikon, size: 12, color: renk),
      const SizedBox(width: 4),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(etiket, style: TextStyle(fontSize: 9, color: renk, fontWeight: FontWeight.w600)),
        Text(ParaUtils.formatla(tutar),
            style: TextStyle(fontSize: 11, color: renk, fontWeight: FontWeight.w800)),
      ]),
    ]),
  );
}

class _CariTab extends StatelessWidget {
  final List<CariModel> cariler;
  final Future<void> Function(CariModel) onSil;
  final Future<void> Function() onRefresh;
  final Future<bool> Function(List<CariModel>) onTopluSil;
  final Future<void> Function(Set<int>) onTopluExcel;
  const _CariTab({required this.cariler, required this.onSil, required this.onRefresh,
      required this.onTopluSil, required this.onTopluExcel});

  @override
  Widget build(BuildContext context) {
    // Geniş pencerede (masaüstü) tablo görünümü — liste BOŞKEN de gösterilir ki
    // alt şerit (F1 Cari Ekle) ve kısayollar kaybolmasın.
    if (MediaQuery.sizeOf(context).width > 1100) {
      return CariMasaustuGorunum(
          cariler: cariler, onSil: onSil, onYenile: onRefresh,
          onTopluSil: onTopluSil, onTopluExcel: onTopluExcel);
    }
    if (cariler.isEmpty) {
      return const TsBosDurum(
      ikon: Icons.people_outline,
      baslik: 'Kayıt bulunamadı',
    );
    }
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
        itemCount: cariler.length,
        itemBuilder: (_, i) => _CariKart(cari: cariler[i], onSil: () => onSil(cariler[i])),
      ),
    );
  }
}

class _CariKart extends ConsumerWidget {
  final CariModel cari; final VoidCallback onSil;
  const _CariKart({required this.cari, required this.onSil});

  // NOT: getter'dan metoda çevrildi — gövdesi context.textSecondary
  // kullanıyor, ama _CariKart bir ConsumerWidget (State değil), bu yüzden
  // getter'ın context'e erişimi yok. Çağrı yerlerinin hepsi build() içinde.
  Color _renk(BuildContext context) {
    if (cari.bakiye == 0) return context.textSecondary;
    final mst = cari.cariTipi.contains('Müşteri');
    if (mst) return cari.bakiye > 0 ? TsRenk.basarili : TsRenk.bilgi;
    return cari.bakiye < 0 ? TsRenk.hata : TsRenk.bilgi;
  }

  String get _etiket {
    if (cari.bakiye == 0) return 'Dengede';
    final mst = cari.cariTipi.contains('Müşteri');
    if (mst) return cari.bakiye > 0 ? 'Alacak' : 'Fazla Ödedi';
    return cari.bakiye < 0 ? 'Borç' : 'Fazla Ödedik';
  }

  Color get _avatarRenk {
    final tip = cari.cariTipi;
    if (tip.contains('Müşteri') && !tip.contains('Tedarikçi')) return TsRenk.bilgi;
    if (tip.contains('Tedarikçi') && !tip.contains('Müşteri')) return TsRenk.vurguMor;
    return TsRenk.vurguTurkuaz;
  }

  /// Kullanıcının anlaşılır bulacağı tip rozeti: Müşteri / Tedarikçi /
  /// Bayi / Toptan Müşteri / Müşteri+Tedarikçi — ham cari kodu yerine.
  Widget _tipEtiketi(CariModel cari) {
    final tip = cari.cariTipi;
    final musteriMi = tip.contains('Müşteri');
    final tedarikciMi = tip.contains('Tedarik');
    String etiket;
    Color renk;
    if (musteriMi && tedarikciMi) {
      etiket = 'Müşteri + Tedarikçi'; renk = TsRenk.vurguTurkuaz;
    } else if (tedarikciMi) {
      etiket = 'Tedarikçi'; renk = TsRenk.vurguMor;
    } else if (cari.musteriTipi == 'Bayi') {
      etiket = 'Bayi'; renk = TsRenk.uyari;
    } else if (cari.musteriTipi == 'Toptan') {
      etiket = 'Toptan Müşteri'; renk = TsRenk.bilgi;
    } else {
      etiket = 'Müşteri'; renk = TsRenk.bilgi;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
        color: renk.withAlpha(28),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(etiket,
          style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: renk)),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final silYetkisiVar = ref.watch(authProvider.select((s) => s.isMudur));
    return Dismissible(
    key: ValueKey('cari_${cari.id}'),
    direction: silYetkisiVar ? DismissDirection.endToStart : DismissDirection.none,
    background: Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
          color: TsRenk.hata, borderRadius: BorderRadius.circular(16)),
      alignment: Alignment.centerRight,
      padding: const EdgeInsets.only(right: 20),
      child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.delete_outline, color: Colors.white),
        Text('Sil', style: TextStyle(color: Colors.white, fontSize: 11)),
      ])),
    confirmDismiss: (_) async { onSil(); return false; },
    child: Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TsKart(
        onTap: () {
          final secim = CariSecimBaglami.maybeOf(context);
          if (secim != null) { secim.onSec(cari); return; }
          context.push('/cari/detay/${cari.id}');
        },
        padding: EdgeInsets.zero,
        child: Row(children: [
          // Renkli sol çizgi
          Container(width: 4, height: 68,
              decoration: BoxDecoration(
                  color: _renk(context), borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16), bottomLeft: Radius.circular(16)))),
          const SizedBox(width: 12),
          // Avatar (+ e-Fatura/e-Arşiv durum noktası)
          Stack(clipBehavior: Clip.none, children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(color: _avatarRenk.withAlpha(31), shape: BoxShape.circle),
              child: Center(child: Text(
                cari.unvan.isNotEmpty ? cari.unvan[0].toUpperCase() : '?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: _avatarRenk))),
            ),
          ]),
          const SizedBox(width: 10),
          // İsim + bilgiler
          Expanded(child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(child: Text(cari.unvan,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                    maxLines: 1, overflow: TextOverflow.ellipsis)),
                // Yalnız GİB'de DOĞRULANMIŞ e-Fatura mükellefine küçük
                // rozet (profesyonel ERP'lerdeki gibi). Müşterilerin çoğu
                // e-Arşiv olduğundan her kartta etiket kalabalık yaratıyordu;
                // "Sorgula" çipi de kartın ortasında amblem gibi duruyordu —
                // sorgulama artık Cari Detay'da (kullanıcı bulgusu 2026-09-28).
                if (cari.mukellefDurumu == 'efatura') ...[
                  const SizedBox(width: 5),
                  const Tooltip(
                    message: 'e-Fatura mükellefi (GİB\'de kayıtlı)',
                    child: Icon(Icons.verified, size: 15, color: TsRenk.basarili),
                  ),
                ],
              ]),
              const SizedBox(height: 2),
              Row(children: [
                // 🔴 DÜZELTME (kullanıcı bulgusu): Burada ham cari kodu
                // (ör. "M001") gösteriliyordu — bu bilgi çoğu kullanıcı
                // için anlamsız/teknikti. Artık kullanıcının daha
                // anlamlı bulacağı bir TİP ETİKETİ gösteriliyor:
                // Müşteri / Tedarikçi / Bayi / Toptan Müşteri.
                _tipEtiketi(cari),
                const SizedBox(width: 8),
                if (cari.telefon != null) ...[
                  Icon(Icons.phone_outlined, size: 11, color: context.textSecondary),
                  const SizedBox(width: 2),
                  Text(cari.telefon!, style: TextStyle(fontSize: 11, color: context.textSecondary)),
                ],
              ]),
            ]),
          )),
          // Bakiye sağ taraf
          Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(ParaUtils.formatla(cari.bakiye.abs()),
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: _renk(context))),
              Container(
                margin: const EdgeInsets.only(top: 2),
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                    color: _renk(context).withAlpha(26), borderRadius: BorderRadius.circular(12)),
                child: Text(_etiket,
                    style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: _renk(context)))),
            ]),
          ),
        ]),
      ),
    ),
  );
  }
}
