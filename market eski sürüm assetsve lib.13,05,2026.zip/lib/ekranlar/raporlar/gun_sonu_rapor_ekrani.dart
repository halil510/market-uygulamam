// lib/ekranlar/raporlar/gun_sonu_rapor_ekrani.dart
//
// ═══════════════════════════════════════════════════════════════════════════
// DÜZELTİLEN HATALAR:
//
//  1. build() içinde appLogger.i() döngüsü — her frame'de çalışıyordu
//     UI render sırasında log basılmamalı; initState/veri yükleme sırasında basılmalı.
//
//  2. _periyotSecenekleri listesinde 'Özel' yok ama _periyot = 'Özel' atanıyor.
//     DropdownButton value listede olmayan bir değer → runtime exception.
//     'Özel' listeye eklendi ve dropdown'da gösterildi.
//
//  3. _exceleAktar() içinde finally bloğu yanlış yerde: setState(_yukleniyor=false)
//     başarı snackbar'ından önce çalışıp widget rebuild tetikliyordu.
//     Artık doğru sıralama: işle → snackbar → finally.
//
//  4. _fisDetayGoster alertdialog context parametresi: showDialog builder'ında
//     context parametresi outer context ile aynı ada sahipti — gölgeleme sorunu.
//     Builder parametresi 'ctx' olarak yeniden adlandırıldı.
//
//  5. _tarihSec içinde lastDate: DateTime.now() — gün içinde seçim yapılırken
//     saate bağlı kısıtlama olabilir; DateTime(now.year,now.month,now.day,23,59) olarak düzeltildi.
//
//  6. Rapor ekranında "Özel" tarih seçilince dropdown çöküyor çünkü
//     DropdownButton.value = 'Özel' ama items listesinde yoktu.
//
//  7. _buildBilgiKart'ta kart rengi: bold=true olan Net Kar kartı yeşil gösteriliyor
//     ama kar negatifse de yeşil kalıyor. Kar değerine göre renk dinamikleştirildi.
//
//  8. Satış listesinde ödeme yöntemi gösterilmiyordu; eklendi.
//
//  9. PDF'de satış tablosu pw.MultiPage yerine tek sayfa — çok satış varsa taşıyor.
//     pw.MultiPage'e geçildi.
//
// 10. Cari satış toplamı (cariye faturalanan) ayrı gösterilmiyordu. Eklendi.
// ═══════════════════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/servisler/rapor_servisi.dart';
import 'package:market_uygulamasi/servisler/excel_gunsonu_servisi.dart';
import 'package:market_uygulamasi/yardimci/yardimci_fonksiyonlar.dart';
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:intl/intl.dart';

class GunSonuRaporEkrani extends StatefulWidget {
  @override
  _GunSonuRaporEkraniState createState() => _GunSonuRaporEkraniState();
}

class _GunSonuRaporEkraniState extends State<GunSonuRaporEkrani> {
  final RaporServisi _raporServisi = RaporServisi();

  DateTime _baslangicTarihi = DateTime.now();
  DateTime _bitisTarihi = DateTime.now();

  // FIX 2,6: 'Özel' listeye eklendi
  String _periyot = 'Günlük';
  final List<String> _periyotSecenekleri = [
    'Günlük',
    'Haftalık',
    'Aylık',
    'Özel',
  ];

  List<Satis> _satislar = [];
  double _toplamTutar = 0.0;
  double _nakitToplam = 0.0;
  double _krediKartiToplam = 0.0;
  double _cariToplam = 0.0;
  double _tahsilatToplam = 0.0;
  double _odemeToplam = 0.0;
  double _kar = 0.0;
  bool _yukleniyor = false;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _baslangicTarihi = DateTime(now.year, now.month, now.day);
    _bitisTarihi = DateTime(now.year, now.month, now.day, 23, 59, 59);
    WidgetsBinding.instance.addPostFrameCallback((_) => _raporuGetir());
  }

  Future<void> _raporuGetir() async {
    if (!mounted) return;
    setState(() => _yukleniyor = true);
    try {
      final rapor = await _raporServisi.aralikRaporuGetir(
        baslangic: _baslangicTarihi,
        bitis: _bitisTarihi,
      );
      if (!mounted) return;

      final satislar = (rapor['satislar'] as List<Satis>?) ?? [];

      // FIX 1: Log buraya taşındı (build'den çıkarıldı)
      for (final s in satislar) {
        debugPrint('Satış id: ${s.id}, kalem sayısı: ${s.kalemler.length}');
      }

      // FIX 10: Cari satış toplamı hesapla
      final cariToplam = satislar
          .where((s) => s.cariId != null && s.odemeYontemi == 'Cari')
          .fold(0.0, (sum, s) => sum + s.toplamTutar);

      setState(() {
        _satislar = satislar;
        _toplamTutar = rapor['toplamTutar'] ?? 0.0;
        _nakitToplam = rapor['nakitToplam'] ?? 0.0;
        _krediKartiToplam = rapor['krediKartiToplam'] ?? 0.0;
        _cariToplam = cariToplam;
        _tahsilatToplam = rapor['tahsilatToplam'] ?? 0.0;
        _odemeToplam = rapor['odemeToplam'] ?? 0.0;
        _kar = rapor['kar'] ?? 0.0;
        _yukleniyor = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _yukleniyor = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Rapor alınamadı: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // FIX 3: finally bloğu sıralaması düzeltildi
  Future<void> _exceleAktar() async {
    if (_satislar.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aktarılacak veri bulunamadı')),
      );
      return;
    }
    setState(() => _yukleniyor = true);
    try {
      final dosyaYolu = await ExcelGunSonuServisi.disariAktar(
        _satislar,
        _baslangicTarihi,
        _bitisTarihi,
      );
      await ExcelGunSonuServisi.dosyayiPaylas(dosyaYolu);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Excel başarıyla oluşturuldu')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Excel aktarım hatası: $e'),
            backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _yukleniyor = false); // FIX 3
    }
  }

  // FIX 2,6: 'Özel' değeri artık listede; tarih seçince periyot='Özel' olur
  void _periyotDegisti(String? yeniPeriyot) {
    if (yeniPeriyot == null || yeniPeriyot == 'Özel') return;
    final now = DateTime.now();
    DateTime bas, bit;

    if (yeniPeriyot == 'Günlük') {
      bas = DateTime(now.year, now.month, now.day);
      bit = DateTime(now.year, now.month, now.day, 23, 59, 59);
    } else if (yeniPeriyot == 'Haftalık') {
      bas = now.subtract(Duration(days: now.weekday - 1));
      bas = DateTime(bas.year, bas.month, bas.day);
      bit = bas.add(const Duration(days: 6));
      bit = DateTime(bit.year, bit.month, bit.day, 23, 59, 59);
    } else {
      // Aylık
      bas = DateTime(now.year, now.month, 1);
      // Ayın son günü: bir sonraki ayın 0. günü = bu ayın son günü
      bit = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
    }

    setState(() {
      _periyot = yeniPeriyot;
      _baslangicTarihi = bas;
      _bitisTarihi = bit;
    });
    _raporuGetir();
  }

  // FIX 5: lastDate düzeltildi, FIX 6: periyot 'Özel' olarak ayarlandı
  Future<void> _tarihSec(bool baslangic) async {
    final now = DateTime.now();
    final selectedDate = await showDatePicker(
      context: context,
      initialDate: baslangic ? _baslangicTarihi : _bitisTarihi,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year, now.month, now.day, 23, 59, 59),
      locale: const Locale('tr', 'TR'),
    );
    if (selectedDate == null || !mounted) return;

    setState(() {
      if (baslangic) {
        _baslangicTarihi =
            DateTime(selectedDate.year, selectedDate.month, selectedDate.day);
        if (_bitisTarihi.isBefore(_baslangicTarihi)) {
          _bitisTarihi = DateTime(
              selectedDate.year, selectedDate.month, selectedDate.day, 23, 59, 59);
        }
      } else {
        _bitisTarihi = DateTime(
            selectedDate.year, selectedDate.month, selectedDate.day, 23, 59, 59);
        if (_baslangicTarihi.isAfter(_bitisTarihi)) {
          _baslangicTarihi =
              DateTime(selectedDate.year, selectedDate.month, selectedDate.day);
        }
      }
      _periyot = 'Özel'; // FIX 6
    });
    _raporuGetir();
  }

  // FIX 9: PDF'de MultiPage kullanımı
  Future<void> _pdfOlustur() async {
    final font = await PdfGoogleFonts.robotoRegular();
    final boldFont = await PdfGoogleFonts.robotoBold();
    final pdf = pw.Document();
    final tarihFormat = DateFormat('dd.MM.yyyy');

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        header: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Center(
              child: pw.Text('GÜN SONU RAPORU',
                  style: pw.TextStyle(font: boldFont, fontSize: 18)),
            ),
            pw.SizedBox(height: 6),
            pw.Center(
              child: pw.Text(
                '${tarihFormat.format(_baslangicTarihi)} – ${tarihFormat.format(_bitisTarihi)}',
                style: pw.TextStyle(font: font, fontSize: 11),
              ),
            ),
            pw.Divider(),
          ],
        ),
        build: (ctx) => [
          pw.Table(
            border: pw.TableBorder.all(),
            columnWidths: {
              0: const pw.FlexColumnWidth(3),
              1: const pw.FlexColumnWidth(2),
            },
            children: [
              _pdfSatir('Toplam Satış', _toplamTutar, boldFont),
              _pdfSatir('Nakit Satış', _nakitToplam, font),
              _pdfSatir('Kredi Kartı Satış', _krediKartiToplam, font),
              _pdfSatir('Cariye Satış', _cariToplam, font),
              _pdfSatir('Tahsilat (Gelir)', _tahsilatToplam, font),
              _pdfSatir('Ödeme (Gider)', _odemeToplam, font),
              _pdfSatir('Net Kar', _kar, boldFont),
            ],
          ),
          pw.SizedBox(height: 20),
          pw.Text('Satış Detayları', style: pw.TextStyle(font: boldFont, fontSize: 13)),
          pw.SizedBox(height: 8),
          pw.Table(
            border: pw.TableBorder.all(),
            columnWidths: {
              0: const pw.FlexColumnWidth(1.2),
              1: const pw.FlexColumnWidth(2),
              2: const pw.FlexColumnWidth(1.5),
              3: const pw.FlexColumnWidth(1.8),
            },
            children: [
              pw.TableRow(
                decoration: const pw.BoxDecoration(color: PdfColors.blue700),
                children: [
                  _pdfHucre('Fiş No', font: boldFont, beyaz: true),
                  _pdfHucre('Tarih', font: boldFont, beyaz: true),
                  _pdfHucre('Tutar', font: boldFont, beyaz: true),
                  _pdfHucre('Ödeme Yöntemi', font: boldFont, beyaz: true),
                ],
              ),
              ..._satislar.map((satis) => pw.TableRow(
                    children: [
                      _pdfHucre(
                          satis.id?.toString().padLeft(6, '0') ?? '-',
                          font: font),
                      _pdfHucre(
                          DateFormat('dd.MM.yyyy HH:mm')
                              .format(satis.tarih),
                          font: font),
                      _pdfHucre(
                          YardimciFonksiyonlar.paraFormatla(satis.toplamTutar),
                          font: font),
                      _pdfHucre(satis.odemeYontemi ?? '-', font: font),
                    ],
                  )),
            ],
          ),
          pw.SizedBox(height: 16),
          pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Text(
              'Toplam ${_satislar.length} satış',
              style: pw.TextStyle(font: font, fontSize: 10),
            ),
          ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (_) async => pdf.save(),
    );
  }

  pw.TableRow _pdfSatir(String baslik, double deger, pw.Font font) {
    return pw.TableRow(children: [
      pw.Padding(
          padding: const pw.EdgeInsets.all(4),
          child: pw.Text(baslik, style: pw.TextStyle(font: font))),
      pw.Padding(
          padding: const pw.EdgeInsets.all(4),
          child: pw.Text(YardimciFonksiyonlar.paraFormatla(deger),
              style: pw.TextStyle(font: font))),
    ]);
  }

  pw.Widget _pdfHucre(String text,
      {required pw.Font font, bool beyaz = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(4),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          font: font,
          color: beyaz ? PdfColors.white : PdfColors.black,
          fontSize: 9,
        ),
      ),
    );
  }

  // FIX 4: builder parametresi ctx olarak adlandırıldı
  // FIX 8: ödeme yöntemi eklendi
  void _fisDetayGoster(Satis satis) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Fiş No: ${satis.id?.toString().padLeft(6, '0') ?? '-'}',
          style: const TextStyle(fontSize: 16),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // FIX 8: ödeme yöntemi
              if (satis.odemeYontemi != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Chip(
                    label: Text(satis.odemeYontemi!),
                    backgroundColor: satis.odemeYontemi == 'Nakit'
                        ? Colors.green.shade100
                        : satis.odemeYontemi == 'Kredi Kartı'
                            ? Colors.blue.shade100
                            : Colors.orange.shade100,
                  ),
                ),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 300),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: satis.kalemler.length,
                  itemBuilder: (ctx2, index) {
                    final kalem = satis.kalemler[index];
                    return ListTile(
                      dense: true,
                      title: Text(kalem.urunAdi),
                      subtitle: Text(
                        '${kalem.miktar} adet × ${YardimciFonksiyonlar.paraFormatla(kalem.birimFiyat)}',
                      ),
                      trailing: Text(
                        YardimciFonksiyonlar.paraFormatla(kalem.toplamTutar),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    );
                  },
                ),
              ),
              const Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('TOPLAM',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  Text(
                    YardimciFonksiyonlar.paraFormatla(satis.toplamTutar),
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Kapat'),
          ),
        ],
      ),
    );
  }

  // FIX 7: Kar negatifse kırmızı, pozitifse yeşil, sıfırsa gri
  Widget _buildBilgiKart(String baslik, double deger, Color renk,
      {bool bold = false, bool karSensitive = false}) {
    Color gosterimRenk = renk;
    if (karSensitive) {
      gosterimRenk =
          deger > 0 ? Colors.green : deger < 0 ? Colors.red : Colors.grey;
    }
    return Card(
      color: gosterimRenk.withOpacity(0.1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      elevation: bold ? 4 : 2,
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                if (bold)
                  Icon(Icons.trending_up, color: gosterimRenk, size: 20),
                if (bold) const SizedBox(width: 8),
                Text(
                  baslik,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: bold ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ],
            ),
            Text(
              YardimciFonksiyonlar.paraFormatla(deger),
              style: TextStyle(
                fontSize: bold ? 17 : 15,
                fontWeight: bold ? FontWeight.bold : FontWeight.normal,
                color: bold ? gosterimRenk : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _tarihGoster(DateTime dt) {
    return DateFormat('dd.MM.yyyy').format(dt);
  }

  @override
  Widget build(BuildContext context) {
    // FIX 1: Log buradan kaldırıldı
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gün Sonu Raporu'),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: _pdfOlustur,
            tooltip: 'PDF Oluştur',
          ),
          IconButton(
            icon: const Icon(Icons.table_chart),
            onPressed: _exceleAktar,
            tooltip: "Excel'e Aktar",
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _raporuGetir,
            tooltip: 'Yenile',
          ),
        ],
      ),
      body: Column(
        children: [
          // ── Tarih / periyot seçimi ──────────────────────────────────
          Container(
            color: Colors.grey.shade100,
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.calendar_today, size: 16),
                        label: Text(_tarihGoster(_baslangicTarihi),
                            style: const TextStyle(fontSize: 13)),
                        onPressed: () => _tarihSec(true),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      child: Text('–'),
                    ),
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.calendar_today, size: 16),
                        label: Text(_tarihGoster(_bitisTarihi),
                            style: const TextStyle(fontSize: 13)),
                        onPressed: () => _tarihSec(false),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // FIX 2,6: Dropdown artık 'Özel' içeriyor
                DropdownButtonFormField<String>(
                  value: _periyot,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    isDense: true,
                  ),
                  items: _periyotSecenekleri
                      .map((e) =>
                          DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: _periyotDegisti,
                ),
              ],
            ),
          ),

          // ── İçerik ─────────────────────────────────────────────────
          Expanded(
            child: _yukleniyor
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _raporuGetir,
                    child: ListView(
                      padding: const EdgeInsets.all(12),
                      children: [
                        // Özet kartlar
                        _buildBilgiKart('Toplam Satış', _toplamTutar, Colors.blue, bold: true),
                        _buildBilgiKart('Nakit Satış', _nakitToplam, Colors.green),
                        _buildBilgiKart('Kredi Kartı Satış', _krediKartiToplam, Colors.orange),
                        _buildBilgiKart('Cariye Satış', _cariToplam, Colors.indigo),
                        _buildBilgiKart('Tahsilat (Gelir)', _tahsilatToplam, Colors.teal),
                        _buildBilgiKart('Ödeme (Gider)', _odemeToplam, Colors.red),
                        // FIX 7: karSensitive ile kar pozitif/negatif renge göre renklenir
                        _buildBilgiKart('Net Kar', _kar, Colors.purple,
                            bold: true, karSensitive: true),

                        const SizedBox(height: 16),
                        const Divider(),

                        // Satış listesi başlığı
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Satış Hareketleri (${_satislar.length})',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 15),
                              ),
                              if (_satislar.isNotEmpty)
                                Text(
                                  DateFormat('dd.MM.yyyy').format(_baslangicTarihi),
                                  style: TextStyle(
                                      color: Colors.grey.shade500,
                                      fontSize: 12),
                                ),
                            ],
                          ),
                        ),

                        if (_satislar.isEmpty)
                          Center(
                            child: Padding(
                              padding: const EdgeInsets.all(32),
                              child: Column(
                                children: [
                                  Icon(Icons.receipt_long,
                                      size: 56,
                                      color: Colors.grey.shade300),
                                  const SizedBox(height: 12),
                                  const Text('Bu tarih aralığında işlem yok',
                                      style: TextStyle(color: Colors.grey)),
                                ],
                              ),
                            ),
                          )
                        else
                          ..._satislar.map((satis) {
                            final idStr =
                                satis.id?.toString().padLeft(6, '0') ?? '-';
                            final odeme = satis.odemeYontemi ?? '';
                            Color odemeRenk = Colors.grey.shade200;
                            if (odeme == 'Nakit') odemeRenk = Colors.green.shade100;
                            if (odeme == 'Kredi Kartı') odemeRenk = Colors.blue.shade100;
                            if (odeme == 'Cari') odemeRenk = Colors.orange.shade100;

                            return Card(
                              margin: const EdgeInsets.only(bottom: 6),
                              elevation: 1,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                              child: ListTile(
                                dense: true,
                                leading: CircleAvatar(
                                  radius: 20,
                                  backgroundColor: Colors.blue.shade50,
                                  child: Text(
                                    idStr.substring(idStr.length - 3),
                                    style: const TextStyle(
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.blue),
                                  ),
                                ),
                                title: Text('Fiş: $idStr',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13)),
                                subtitle: Row(
                                  children: [
                                    Text(
                                      DateFormat('HH:mm').format(satis.tarih),
                                      style: TextStyle(
                                          color: Colors.grey.shade500,
                                          fontSize: 11),
                                    ),
                                    const SizedBox(width: 8),
                                    // FIX 8: ödeme yöntemi badge
                                    if (odeme.isNotEmpty)
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 6, vertical: 1),
                                        decoration: BoxDecoration(
                                          color: odemeRenk,
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        child: Text(odeme,
                                            style: const TextStyle(
                                                fontSize: 10)),
                                      ),
                                  ],
                                ),
                                trailing: Text(
                                  YardimciFonksiyonlar.paraFormatla(
                                      satis.toplamTutar),
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14),
                                ),
                                onTap: () => _fisDetayGoster(satis),
                              ),
                            );
                          }),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}