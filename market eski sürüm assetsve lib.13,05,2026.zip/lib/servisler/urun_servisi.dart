// lib/servisler/urun_servisi.dart
import 'dart:io';
import 'dart:math';
import 'package:excel/excel.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:path_provider/path_provider.dart';
import 'package:market_uygulamasi/yardimci/yardimci_fonksiyonlar.dart';
import 'package:market_uygulamasi/servisler/barkod_servisi.dart';

class UrunServisi {
  final UrunRepoSitory _urunRepo = UrunRepoSitory();
  final BarkodServisi _barkodServisi = BarkodServisi();

  Future<Urun?> barkodlaUrunGetir(String barkod) async {
    final duzeltilmisBarkod = _barkodServisi.duzeltBarkod(barkod);
    if (!_barkodServisi.gecerliBarkod(duzeltilmisBarkod)) {
      throw Exception('Geçersiz barkod formatı: $barkod');
    }
    return await _urunRepo.barkodlaUrunGetir(duzeltilmisBarkod);
  }

  Future<List<Urun>> tumUrunleriGetir() async {
    return await _urunRepo.tumUrunleriGetir();
  }

  Future<int> urunEkle(Urun urun) async {
    if (urun.barkod.isEmpty || !_barkodServisi.gecerliBarkod(urun.barkod)) {
      throw Exception('Geçersiz barkod: ${urun.barkod}');
    }
    if (urun.ad.isEmpty || urun.satisFiyat <= 0) {
      throw Exception('Zorunlu alanlar: Ürün adı ve satış fiyatı');
    }
    return await _urunRepo.urunEkle(urun);
  }

  Future<int> urunGuncelle(Urun urun) async {
    if (urun.id == null) throw Exception('Güncellenecek ürün ID boş olamaz');
    return await _urunRepo.urunGuncelle(urun);
  }

  Future<int> stokGuncelle(int urunId, double yeniStok) async {
    if (yeniStok < 0) throw Exception('Stok negatif olamaz');
    return await _urunRepo.stokGuncelle(urunId, yeniStok);
  }

  Future<Map<String, dynamic>> urunleriExceldenIceriAl(File excelDosyasi, {bool sadeceFiyat = false}) async {
    var bytes = await excelDosyasi.readAsBytes();
    var excel = Excel.decodeBytes(bytes);
    int eklenen = 0, guncellenen = 0, hatali = 0;
    List<String> hataDetaylari = [];

    for (var table in excel.tables.keys) {
      var sheet = excel.tables[table]!;
      if (sheet.rows.isEmpty) continue;

      var basliklar = sheet.rows[0].map((cell) => cell?.value.toString().trim()).toList();
      int barkodIndex = basliklar.indexWhere((baslik) => baslik?.contains("Barkod") ?? false);
      int urunAdiIndex = basliklar.indexWhere((baslik) => baslik?.contains("Ürün Adı") ?? false);
      int satisFiyatIndex = basliklar.indexWhere((baslik) => baslik?.contains("Satış fiyatı") ?? false);

      if (barkodIndex == -1 || urunAdiIndex == -1 || satisFiyatIndex == -1) {
        throw Exception("Excel dosyasında zorunlu alanlar (Barkod, Ürün Adı, Satış fiyatı) bulunamadı.");
      }

      int stokIndex = basliklar.indexWhere((baslik) => baslik?.contains("Stok") ?? false);
      int alisFiyatIndex = basliklar.indexWhere((baslik) => baslik?.contains("Alış fiyat") ?? false);
      int anagrupIndex = basliklar.indexWhere((baslik) => baslik?.contains("Ana Grup") ?? false);
      int altGrupIndex = basliklar.indexWhere((baslik) => baslik?.contains("Alt Grup") ?? false);
      int kdvIndex = basliklar.indexWhere((baslik) => baslik?.contains("KDV Oran") ?? false);

      for (int i = 1; i < sheet.rows.length; i++) {
        var satir = sheet.rows[i];
        try {
          String barkod = satir[barkodIndex]?.value.toString() ?? "";
          if (barkod.isEmpty) {
            hatali++;
            hataDetaylari.add("$i. satır: Barkod boş");
            continue;
          }

          barkod = _barkodServisi.duzeltBarkod(barkod);
          if (!_barkodServisi.gecerliBarkod(barkod)) {
            hatali++;
            hataDetaylari.add("$i. satır: Geçersiz barkod - $barkod");
            continue;
          }

          Urun? mevcutUrun = await _urunRepo.barkodlaUrunGetir(barkod);
          Urun yeniUrun = Urun(
            barkod: barkod,
            ad: satir[urunAdiIndex]?.value.toString() ?? "Bilinmeyen Ürün",
            satisFiyat: YardimciFonksiyonlar.stringToDouble(satir[satisFiyatIndex]?.value.toString()),
            stokMiktari: stokIndex != -1 ? YardimciFonksiyonlar.stringToDouble(satir[stokIndex]?.value.toString()) : 0,
            alisFiyat: alisFiyatIndex != -1 ? YardimciFonksiyonlar.stringToDouble(satir[alisFiyatIndex]?.value.toString()) : 0,
            anagrup: anagrupIndex != -1 ? satir[anagrupIndex]?.value.toString() : null,
            altGrup: altGrupIndex != -1 ? satir[altGrupIndex]?.value.toString() : null,
            kdvOrani: kdvIndex != -1 ? YardimciFonksiyonlar.stringToDouble(satir[kdvIndex]?.value.toString()) : null,
          );

          if (mevcutUrun != null) {
            if (sadeceFiyat) {
              mevcutUrun.satisFiyat = yeniUrun.satisFiyat;
              mevcutUrun.alisFiyat = yeniUrun.alisFiyat;
              await _urunRepo.urunGuncelle(mevcutUrun);
            } else {
              yeniUrun.id = mevcutUrun.id;
              yeniUrun.stokMiktari += mevcutUrun.stokMiktari;
              await _urunRepo.urunGuncelle(yeniUrun);
            }
            guncellenen++;
          } else {
            await _urunRepo.urunEkle(yeniUrun);
            eklenen++;
          }
        } catch (e) {
          hatali++;
          hataDetaylari.add("$i. satır: $e");
        }
      }
    }

    return {
      'basarili': eklenen,
      'guncellenen': guncellenen,
      'hatali': hatali,
      'detaylar': hataDetaylari,
    };
  }

  Future<File> urunleriExceleDisariAktar() async {
    var excel = Excel.createExcel();
    var sheet = excel['Ürünler'];

    sheet.appendRow([
      'Kod', 'Barkod', 'Barkodlar', 'Ürün Adı', 'Birim Adı', 'Alış fiyat',
      'Alış fiyat kdv dahil', 'Satış fiyatı', 'Stok', 'Alış KDV Oran', 'KDV Oran',
      'Ana Grup', 'Alt Grup', 'Alan1', 'Alan2', 'Para Birimi', 'Marka',
      'Indirim Oranı', 'İndirimli Fiyatı', 'Boy', 'Resim yolu', 'Menşei',
      'Kar oranı', 'Fiyat Güncelleme Tarih', 'Maliyet Güncelleme Tarih', 'Promosyon Aktif'
    ]);

    var urunler = await _urunRepo.tumUrunleriGetir();

    for (var urun in urunler) {
      sheet.appendRow([
        urun.id,
        urun.barkod,
        urun.barkodlar ?? '',
        urun.ad,
        urun.birim,
        urun.alisFiyat,
        urun.alisFiyatKdvDahil ?? (urun.alisFiyat ?? 0) * (1 + (urun.kdvOrani ?? 0) / 100),
        urun.satisFiyat,
        urun.stokMiktari,
        urun.alisKdvOrani,
        urun.kdvOrani,
        urun.anagrup ?? '',
        urun.altGrup ?? '',
        urun.alan1 ?? '',
        urun.alan2 ?? '',
        urun.paraBirimi,
        urun.marka ?? '',
        urun.indirimOrani,
        urun.indirimliFiyat,
        urun.boy ?? '',
        urun.resimYolu ?? '',
        urun.mens ?? '',
        urun.karOrani,
        urun.fiyatGuncellemeTarihi ?? '',
        urun.maliyetGuncellemeTarihi ?? '',
        urun.promosyonAktif ? 'Evet' : 'Hayır'
      ]);
    }

    Directory directory = await getApplicationDocumentsDirectory();
    String filePath = '${directory.path}/urunler_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    File file = File(filePath);
    await file.writeAsBytes(excel.encode()!);
    return file;
  }

  // DÜZELTİLDİ: BarkodServisi'ndeki statik liste kullanılıyor
  String rastgeleBarkodOlustur() {
    final rastgele = Random();
    final prefix = BarkodServisi.GECERLI_ON_EKLER[rastgele.nextInt(BarkodServisi.GECERLI_ON_EKLER.length)];
    final rastgeleSayi = rastgele.nextInt(900000000) + 100000000;
    return '$prefix${rastgeleSayi.toString().substring(0, 13 - prefix.length)}';
  }

  Future<List<Urun>> dusukStokluUrunler(double esikDeger) async {
    final tumUrunler = await _urunRepo.tumUrunleriGetir();
    return tumUrunler.where((urun) => urun.stokMiktari <= esikDeger).toList();
  }

  Future<void> fiyatlariYuzdeGuncelle(double yuzde, bool artis) async {
    final tumUrunler = await _urunRepo.tumUrunleriGetir();
    for (var urun in tumUrunler) {
      if (artis) {
        urun.satisFiyat *= (1 + yuzde / 100);
      } else {
        urun.satisFiyat *= (1 - yuzde / 100);
      }
      await _urunRepo.urunGuncelle(urun);
    }
  }
}