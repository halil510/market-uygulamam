import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:market_uygulamasi/modeller/promosyon.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';

class PromosyonRepo {
  final VeritabaniYardimcisi _dbHelper = VeritabaniYardimcisi();

  /// Tüm promosyonları ürün bilgileriyle birlikte getir
  Future<List<Map<String, dynamic>>> tumPromosyonlariDetayliGetir() async {
    final db = await _dbHelper.db;
    final result = await db.rawQuery('''
      SELECT 
        p.*, 
        u.ad as urun_adi, 
        u.barkod, 
        CAST(u.satisFiyat AS REAL) as kart_satis_fiyati
      FROM Promosyonlar p
      JOIN Urunler u ON p.urun_id = u.id
      ORDER BY u.ad
    ''');
    return result;
  }

  /// Bir ürünün aktif promosyonlarını getir
  Future<List<Promosyon>> urunPromosyonlariniGetir(int urunId) async {
    final db = await _dbHelper.db;
    final result = await db.query(
      'Promosyonlar',
      where: 'urun_id = ? AND aktif = 1',
      whereArgs: [urunId],
    );
    return result.map((m) => Promosyon.fromMap(m)).toList();
  }

  /// Promosyon ekle
  Future<void> promosyonEkle(Promosyon promosyon) async {
    final db = await _dbHelper.db;
    await db.insert('Promosyonlar', promosyon.toMap());
  }

  /// Promosyon güncelle
  Future<void> promosyonGuncelle(Promosyon promosyon) async {
    final db = await _dbHelper.db;
    await db.update(
      'Promosyonlar',
      promosyon.toMap(),
      where: 'id = ?',
      whereArgs: [promosyon.id],
    );
  }

  /// Promosyon sil
  Future<void> promosyonSil(int id) async {
    final db = await _dbHelper.db;
    await db.delete('Promosyonlar', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== YARDIMCI DÖNÜŞÜM ====================
  double _toDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) {
      String clean = value.replaceAll(',', '.').trim();
      return double.tryParse(clean) ?? 0.0;
    }
    return 0.0;
  }

  // ==================== EXCEL İÇE AKTAR ====================
  /// 📥 Excel'den içe aktarma (başlıklar: Stok Kodu, Ürün Adı, Miktar, Iskonto Oran, ...)
  /// Sadece Stok Kodu (barkod), Miktar ve Iskonto Oran kullanılır.
  Future<void> promosyonlariExceldenIceriAktar(File file) async {
    final bytes = await file.readAsBytes();
    final excel = Excel.decodeBytes(bytes);
    final sheet = excel.tables[excel.tables.keys.first];
    if (sheet == null) return;

    final db = await _dbHelper.db;

    // Başlık satırını bul (ilk satır)
    final headerRow = sheet.rows.first;
    int? stokKoduIndex, miktarIndex, iskontoIndex;

    for (int i = 0; i < headerRow.length; i++) {
      final h = headerRow[i]?.value?.toString().trim() ?? '';
      if (h.contains('Stok Kodu') || h.toLowerCase().contains('barkod')) stokKoduIndex = i;
      if (h.contains('Miktar')) miktarIndex = i;
      if (h.contains('Iskonto Oran') || h.contains('İskonto Oran')) iskontoIndex = i;
    }

    if (stokKoduIndex == null || miktarIndex == null || iskontoIndex == null) {
      throw Exception('Excel başlıklarında "Stok Kodu", "Miktar" ve "Iskonto Oran" bulunamadı.');
    }

    // Veri satırlarını işle (1. satır başlık)
    for (int i = 1; i < sheet.rows.length; i++) {
      final row = sheet.rows[i];
      if (row.length <= stokKoduIndex) continue;

      final barkod = row[stokKoduIndex]?.value?.toString().trim();
      if (barkod == null || barkod.isEmpty) continue;

      // Miktar ve iskonto değerlerini virgüllü sayılara karşı güvenli parse et
      final miktarStr = row[miktarIndex]?.value?.toString() ?? '';
      final iskontoStr = row[iskontoIndex]?.value?.toString() ?? '';

      final miktar = _toDouble(miktarStr);
      final iskonto = _toDouble(iskontoStr);

      if (miktar <= 0 || iskonto <= 0) continue;

      // Barkoda göre ürünü bul
      final urun = await db.query(
        'Urunler',
        where: 'barkod = ?',
        whereArgs: [barkod],
      );
      if (urun.isEmpty) continue;
      final urunId = urun.first['id'] as int;

      // Aynı ürün ve aynı eşik miktar için kayıt var mı?
      final varMi = await db.query(
        'Promosyonlar',
        where: 'urun_id = ? AND miktar = ?',
        whereArgs: [urunId, miktar],
      );

      if (varMi.isNotEmpty) {
        // Güncelle
        await db.update(
          'Promosyonlar',
          {'iskonto_orani': iskonto},
          where: 'id = ?',
          whereArgs: [varMi.first['id']],
        );
      } else {
        // Yeni ekle
        await db.insert('Promosyonlar', {
          'urun_id': urunId,
          'miktar': miktar,
          'iskonto_orani': iskonto,
          'aktif': 1,
        });
      }
    }
  }

  // ==================== EXCEL DIŞA AKTAR ====================
  /// 📤 Excel'e dışa aktarma – istenen başlıklar ve hesaplamalar
  Future<File?> promosyonlariExcelDisAktar() async {
    final promosyonlar = await tumPromosyonlariDetayliGetir();
    if (promosyonlar.isEmpty) return null;

    final excel = Excel.createExcel();
    final sheet = excel['Promosyonlar'];

    // Başlıklar (birebir aynı)
    sheet.appendRow([
      'Stok Kodu',
      'Ürün Adı',
      'Miktar',
      'Iskonto Oran',
      'Kart Satış Fiyatı',
      'Birim Fiyat',
      'Promosyon Tutar',
      'Üretici',
      'Maliyet'
    ]);

    for (var p in promosyonlar) {
      final miktar = _toDouble(p['miktar']);
      final iskontoOrani = _toDouble(p['iskonto_orani']);
      final kartSatisFiyati = _toDouble(p['kart_satis_fiyati']);

      final birimFiyat = kartSatisFiyati * (1 - iskontoOrani / 100);
      final promosyonTutar = miktar * birimFiyat;

      sheet.appendRow([
        p['barkod'] ?? '',           // Stok Kodu
        p['urun_adi'] ?? '',         // Ürün Adı
        miktar,                      // Miktar
        iskontoOrani,                // Iskonto Oran
        kartSatisFiyati,             // Kart Satış Fiyatı
        birimFiyat,                  // Birim Fiyat
        promosyonTutar,              // Promosyon Tutar
        '',                          // Üretici (şimdilik boş)
        '',                          // Maliyet (şimdilik boş)
      ]);
    }

    final bytes = excel.encode();
    if (bytes == null) throw Exception('Excel dosyası oluşturulamadı');

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/promosyonlar_${DateTime.now().millisecondsSinceEpoch}.xlsx');
    await file.writeAsBytes(bytes);

    // Dosyanın gerçekten yazıldığını kontrol et
    if (!await file.exists()) {
      throw Exception('Dosya kaydedilemedi: ${file.path}');
    }

    return file;
  }

  /// Paylaşım için yardımcı metod (isteğe bağlı)
  Future<void> paylas(File file) async {
    await Share.shareXFiles([XFile(file.path)], text: 'Promosyon Listesi');
  }
}