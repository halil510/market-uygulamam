import 'package:market_uygulamasi/modeller/stok_hareket.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:sqflite/sqflite.dart';
import 'package:market_uygulamasi/modeller/urun.dart';

class StokRepository {
  final VeritabaniYardimcisi _dbHelper = VeritabaniYardimcisi();

  Future<Database> get db async => _dbHelper.db;

  Future<void> stokHareketEkle(StokHareket hareket) async {
    final database = await db;
    await database.insert(
      'stok_hareketleri',
      hareket.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Düzeltilmiş: DatabaseHelper yerine kendi db getter’ını kullanıyoruz
  Future<List<Urun>> dusukStokluUrunleriGetir(int esikDeger) async {
    final database = await db;
    final List<Map<String, dynamic>> maps = await database.query(
      'urunler',
      where: 'stokMiktari < ?',
      whereArgs: [esikDeger],
    );
    return List.generate(maps.length, (i) {
      return Urun.fromMap(maps[i]);
    });
  }

  Future<void> stokGuncelle(int urunId, double yeniStok) async {
    final database = await db;
    await database.update(
      'urunler',
      {'stokMiktari': yeniStok},
      where: 'id = ?',
      whereArgs: [urunId],
    );
  }

  Future<List<StokHareket>> tumHareketleriGetir() async {
    final database = await db;
    final List<Map<String, dynamic>> maps =
        await database.query('stok_hareketleri');
    return List.generate(maps.length, (i) => StokHareket.fromMap(maps[i]));
  }
}
