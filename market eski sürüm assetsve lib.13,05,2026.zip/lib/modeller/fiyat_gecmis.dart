class FiyatGecmis {
  String id;
  String urunId;
  DateTime tarih;
  double eskiFiyat;
  double yeniFiyat;

  FiyatGecmis({
    required this.id,
    required this.urunId,
    required this.tarih,
    required this.eskiFiyat,
    required this.yeniFiyat,
  });

  factory FiyatGecmis.fromMap(Map<String, dynamic> map) {
    return FiyatGecmis(
      id: map['id'],
      urunId: map['urunId'],
      tarih: DateTime.parse(map['tarih']),
      eskiFiyat: map['eskiFiyat']?.toDouble() ?? 0.0,
      yeniFiyat: map['yeniFiyat']?.toDouble() ?? 0.0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'urunId': urunId,
      'tarih': tarih.toIso8601String(),
      'eskiFiyat': eskiFiyat,
      'yeniFiyat': yeniFiyat,
    };
  }
}