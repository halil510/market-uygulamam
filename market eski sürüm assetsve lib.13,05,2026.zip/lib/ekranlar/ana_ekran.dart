import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modern_ui/widgets/modern_card.dart';
import 'package:market_uygulamasi/rotalar.dart';
import 'package:market_uygulamasi/servisler/auth_servisi.dart';

class AnaEkran extends StatefulWidget {
  const AnaEkran({Key? key}) : super(key: key);

  @override
  State<AnaEkran> createState() => _AnaEkranState();
}

class _AnaEkranState extends State<AnaEkran> {
  // Geri tuşu diyaloğu
  Future<bool> _onWillPop() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Çıkış Yap'),
        content: const Text('Oturumu kapatıp giriş ekranına dönmek istediğinize emin misiniz?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Çıkış Yap', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (result == true && mounted) {
      await AuthServisi().cikisYap();
      if (mounted) {
        Navigator.pushReplacementNamed(context, Rotalar.giris);
      }
    }
    // Her durumda pop edilmesini engellemek için false döndürüyoruz
    return false;
  }

  @override
  Widget build(BuildContext context) {
    // 🔴 Giriş yapılmamışsa girişe yönlendir
    if (!AuthServisi().girisYapilmis) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, Rotalar.giris);
      });
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return PopScope(
      canPop: false,         // geri tuşu ile direkt çıkışı engelle
      onPopInvoked: (didPop) async {
        // Android geri tuşu tetiklendiğinde diyaloğu göster
        await _onWillPop();
      },
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        appBar: AppBar(
  title: SizedBox(
    height: 145, // logo yüksekliği
    child: Image.asset(
      'assets/images/logoYazı.png', // logo dosya adı
      fit: BoxFit.contain,
    ),
  ),
  backgroundColor: Colors.lightBlue.shade300.withOpacity(0.9),
  elevation: 6,
  actions: [
    IconButton(
      icon: const Icon(Icons.settings, color: Colors.white),
      tooltip: "Ayarlar",
      onPressed: () => Navigator.pushNamed(context, Rotalar.ayarlar),
    )
  ],
),
        body: GridView.count(
          crossAxisCount: 2,
          padding: const EdgeInsets.all(16),
          childAspectRatio: 1.05,
          children: [
            _menu(context, 'Hızlı Erişim', Icons.dashboard, Rotalar.dashboard, Colors.blue),
            _menu(context, 'Barkod Yazdırma', Icons.qr_code_2, Rotalar.BarkodYazdirmaEkrani, Colors.orange),
            _menu(context, 'Ürün Listesi', Icons.list, Rotalar.urunListe, Colors.blueAccent),
            _menu(context, 'Stok Listesi', Icons.inventory, Rotalar.stokListe, Colors.deepPurpleAccent),
            _menu(context, 'Hızlı Satış', Icons.shopping_cart, Rotalar.hizliSatis, Colors.green),
            _menu(context, 'Cariler', Icons.people, Rotalar.cariler, Colors.indigo),
            _menu(context, 'Stok Sayım', Icons.calculate, Rotalar.stokSayim, Colors.brown),
            _menu(context, 'Gün Sonu Rapor', Icons.summarize, Rotalar.gunSonuRapor, Colors.redAccent),
            _menu(context, 'Fiyat Güncelle', Icons.price_change, Rotalar.fiyatGuncelle, Colors.pinkAccent),
            _menu(context, 'Veri Yedekle', Icons.backup, Rotalar.veriYedekle, Colors.teal),
            _menu(context, 'Promosyonlar', Icons.local_offer, Rotalar.promosyon, Colors.purple),
          ],
        ),
      ),
    );
  }

  Widget _menu(
    BuildContext context,
    String title,
    IconData icon,
    String route,
    Color color,
  ) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.95, end: 1),
      duration: const Duration(milliseconds: 250),
      builder: (context, scale, child) =>
          Transform.scale(scale: scale, child: child),
      child: ModernCard(
        elevation: 6,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          onTap: () => Navigator.pushNamed(context, route),
          borderRadius: BorderRadius.circular(20),
          splashColor: color.withOpacity(0.25),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, size: 42, color: color),
                ),
                const SizedBox(height: 14),
                Text(
                  title,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}