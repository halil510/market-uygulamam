import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';
import 'package:market_uygulamasi/servisler/uygulama_ayarlari.dart';
import 'package:market_uygulamasi/servisler/yazdirma_servisi.dart';
import 'package:permission_handler/permission_handler.dart'; // izin_handler eklendi
import 'dart:io';

enum YaziciTuru { bluetooth, ag }

class YaziciAyarEkrani extends StatefulWidget {
  @override
  _YaziciAyarEkraniState createState() => _YaziciAyarEkraniState();
}

class _YaziciAyarEkraniState extends State<YaziciAyarEkrani> with TickerProviderStateMixin {
  final VeritabaniYardimcisi _veritabani = VeritabaniYardimcisi();
  final TextEditingController _ipController = TextEditingController();
  final TextEditingController _portController = TextEditingController();

  // Bluetooth için
  List<BluetoothDevice> _bluetoothCihazlar = [];
  BluetoothDevice? _seciliBluetoothCihaz;
  bool _taramaDevamEdiyor = false;
  bool _yukleniyor = false;
  StreamSubscription? _scanSubscription;
  StreamSubscription<List<ScanResult>>? _scanResultsSubscription;

  // Yazıcı türü ve kayıtlı yazıcılar
  late TabController _tabController;
  List<Map<String, dynamic>> _kayitliYazicilar = [];
  Map<String, dynamic>? _seciliYazici;

  // Kategori seçimi için
  String _seciliKategori = 'fis'; // Varsayılan değer

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(_tabDegisti);
    _yaziciListesiniYukle();
    _kayitliYazicilariGetir();

    izinleriIste(); // İzinler istendi
  }

  void _tabDegisti() {
    setState(() {});
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scanSubscription?.cancel();
    _scanResultsSubscription?.cancel();
    FlutterBluePlus.stopScan();
    _ipController.dispose();
    _portController.dispose();
    super.dispose();
  }

  Future<void> _kayitliYazicilariGetir() async {
    final yazicilar = await _veritabani.tumYazicilariGetir();
    setState(() => _kayitliYazicilar = yazicilar);
  }

  Future<void> _yaziciListesiniYukle() async {
    setState(() => _yukleniyor = true);
    
    final aktifYazici = await _veritabani.varsayilanYaziciGetir();
    if (aktifYazici != null) {
      setState(() {
        _seciliYazici = aktifYazici;
      });
    }
    
    setState(() => _yukleniyor = false);
  }

  void _taraCihazlar() {
    FlutterBluePlus.stopScan();
    _scanResultsSubscription?.cancel();

    setState(() {
      _bluetoothCihazlar.clear();
      _taramaDevamEdiyor = true;
    });

    _scanResultsSubscription = FlutterBluePlus.scanResults.listen((results) {
      for (ScanResult result in results) {
        if (!_bluetoothCihazlar.any((d) => d.id == result.device.id)) {
          setState(() => _bluetoothCihazlar.add(result.device));
        }
      }
    });

    _scanSubscription = FlutterBluePlus.isScanning.listen((isScanning) {
      if (!isScanning) setState(() => _taramaDevamEdiyor = false);
    });

    FlutterBluePlus.startScan(
      timeout: const Duration(seconds: 10),
      androidUsesFineLocation: false,
    );
  }

  Future<void> _yaziciKaydet() async {
    // Hangi sekmede olduğumuzu kontrol et
    if (_tabController.index == 2) { // Ağ Yazıcısı sekmesi
      final ip = _ipController.text.trim();
      final port = _portController.text.trim();
      
      if (ip.isEmpty || port.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Lütfen IP ve Port girin')),
        );
        return;
      }
      
      setState(() => _yukleniyor = true);
      
      final yazici = {
        'tur': 'ag',
        'ip': ip,
        'port': int.tryParse(port) ?? 9100,
        'adi': 'Ağ Yazıcısı ($ip:$port)',
        'kategori': _seciliKategori, // Kategori seçimi eklendi
      };
      
      final id = await _veritabani.yaziciEkle(yazici);
      await _veritabani.varsayilanYaziciAyarla(id);
      
      // Yeni eklenen yazıcıyı güncelle
      final yeniYazici = {...yazici, 'id': id};
      
      setState(() {
        _seciliYazici = yeniYazici;
        _yukleniyor = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ağ yazıcısı kaydedildi: $ip:$port')),
      );
    } 
    else if (_tabController.index == 1) { // Bluetooth sekmesi
      if (_seciliBluetoothCihaz == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Lütfen bir yazıcı seçin')),
        );
        return;
      }
      
      setState(() => _yukleniyor = true);
      
      final yazici = {
        'tur': 'bluetooth',
        'cihaz_id': _seciliBluetoothCihaz!.id.id,
        'adi': _seciliBluetoothCihaz!.name.isNotEmpty 
            ? _seciliBluetoothCihaz!.name 
            : 'Bluetooth Yazıcı',
        'kategori': _seciliKategori, // Kategori seçimi eklendi
      };
      
      final id = await _veritabani.yaziciEkle(yazici);
      await _veritabani.varsayilanYaziciAyarla(id);
      
      // Yeni eklenen yazıcıyı güncelle
      final yeniYazici = {...yazici, 'id': id};
      
      setState(() {
        _seciliYazici = yeniYazici;
        _yukleniyor = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Bluetooth yazıcı kaydedildi: ${yeniYazici['adi']}')),
      );
    }
    
    await _kayitliYazicilariGetir();
  }

  Future<void> _yaziciSil(Map<String, dynamic> yazici) async {
    await _veritabani.yaziciSil(yazici['id']);
    await _kayitliYazicilariGetir();
    
    if (_seciliYazici?['id'] == yazici['id']) {
      setState(() => _seciliYazici = null);
    }
  }

  // Test yazdır fonksiyonu
  Future<void> _testYazdir() async {
    setState(() => _yukleniyor = true);
    try {
      if (_seciliKategori == 'fis') {
        // ESC/POS ile basit bir test fişi
        await YazdirmaServisi.hamKomutYazdir(
          '*** TEST FİŞİ ***\nYazıcı bağlantısı başarılı!\n\n\n\n',
          YaziciKategori.fis,
        );
      } else {
        // TSPL ile basit bir test etiketi
        await YazdirmaServisi.hamKomutYazdir(
          'SIZE 50 mm,30 mm\nGAP 2 mm,0 mm\nCLS\nTEXT 100,100,"3",0,1,1,"TEST ETİKETİ"\nPRINT 1,1\n',
          YaziciKategori.etiket,
        );
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Test çıktısı gönderildi')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Yazıcıya bağlanılamadı: $e')),
      );
    } finally {
      setState(() => _yukleniyor = false);
    }
  }

  Widget _buildKategoriSecici() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        children: [
          const Text('Yazıcı Türü:', style: TextStyle(fontSize: 16)),
          const SizedBox(width: 16),
          DropdownButton<String>(
            value: _seciliKategori,
            items: [
              DropdownMenuItem(
                value: 'fis',
                child: Row(
                  children: const [
                    Icon(Icons.receipt, color: Colors.blue),
                    SizedBox(width: 8),
                    Text('Fiş Yazıcısı'),
                  ],
                ),
              ),
              DropdownMenuItem(
                value: 'etiket',
                child: Row(
                  children: const [
                    Icon(Icons.label, color: Colors.green),
                    SizedBox(width: 8),
                    Text('Etiket Yazıcısı'),
                  ],
                ),
              ),
            ],
            onChanged: (value) {
              if (value != null) {
                setState(() => _seciliKategori = value);
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBluetoothListesi() {
    if (_yukleniyor) return const Center(child: CircularProgressIndicator());

    if (_bluetoothCihazlar.isEmpty) {
      return Center(
        child: Text(
          _taramaDevamEdiyor ? 'Tarama devam ediyor...' : 'Cihaz bulunamadı',
          style: const TextStyle(fontSize: 18),
        ),
      );
    }

    return ListView.builder(
      itemCount: _bluetoothCihazlar.length,
      itemBuilder: (context, index) {
        final cihaz = _bluetoothCihazlar[index];
        final seciliMi = _seciliBluetoothCihaz?.id == cihaz.id;
        return ListTile(
          title: Text(cihaz.name.isNotEmpty ? cihaz.name : 'İsimsiz Cihaz'),
          subtitle: Text(cihaz.id.id),
          trailing: seciliMi 
              ? const Icon(Icons.check, color: Colors.green) 
              : null,
          onTap: () => setState(() => _seciliBluetoothCihaz = cihaz),
        );
      },
    );
  }

  Widget _buildAgArayuzu() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextFormField(
            controller: _ipController,
            decoration: const InputDecoration(
              labelText: 'IP Adresi',
              hintText: '192.168.1.100',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _portController,
            decoration: const InputDecoration(
              labelText: 'Port',
              hintText: '9100',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
        ],
      ),
    );
  }

  Widget _buildYaziciListesi() {
    if (_yukleniyor) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_kayitliYazicilar.isEmpty) {
      return const Center(
        child: Text('Kayıtlı yazıcı bulunamadı'),
      );
    }

    return ListView.builder(
      itemCount: _kayitliYazicilar.length,
      itemBuilder: (context, index) {
        final yazici = _kayitliYazicilar[index];
        final aktifMi = _seciliYazici?['id'] == yazici['id'];
        
        // Kategoriye göre ikon belirle
        final kategoriIcon = yazici['kategori'] == 'etiket'
            ? const Icon(Icons.label, color: Colors.green)
            : const Icon(Icons.receipt, color: Colors.blue);
            
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListTile(
            leading: kategoriIcon,
            title: Text(yazici['adi']),
            subtitle: Text(yazici['tur'] == 'ag' 
                ? '${yazici['ip']}:${yazici['port']}' 
                : 'Bluetooth (${yazici['cihaz_id']})'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (aktifMi) 
                  const Icon(Icons.check_circle, color: Colors.green),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _yaziciSil(yazici),
                ),
              ],
            ),
            onTap: () async {
              await _veritabani.varsayilanYaziciAyarla(yazici['id']);
              setState(() => _seciliYazici = yazici);
            },
          ),
        );
      },
    );
  }


Future<void> izinleriIste() async {
  await Permission.bluetoothScan.request();
  await Permission.bluetoothConnect.request();
  await Permission.locationWhenInUse.request();
  
  // Android 12+ için ek izinler
  if (Platform.isAndroid) {
    await Permission.bluetoothAdvertise.request();
    await Permission.bluetooth.request();
  }
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Yazıcı Yönetimi'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.print), text: 'Yazıcılar'),
            Tab(icon: Icon(Icons.bluetooth), text: 'Bluetooth'),
            Tab(icon: Icon(Icons.language), text: 'Ağ Yazıcısı'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildYaziciListesi(),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Bluetooth Yazıcılar',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    IconButton(
                      icon: const Icon(Icons.refresh),
                      onPressed: _taramaDevamEdiyor ? null : _taraCihazlar,
                      tooltip: 'Yeniden Tara',
                    ),
                  ],
                ),
              ),
              _buildKategoriSecici(),
              const SizedBox(height: 8),
              Expanded(child: _buildBluetoothListesi()),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.print),
                  label: const Text('Test Yazdır'),
                  onPressed: _yukleniyor ? null : _testYazdir,
                ),
              ),
            ],
          ),
          SingleChildScrollView(
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    'Ağ Yazıcısı Ekle',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                _buildAgArayuzu(),
                _buildKategoriSecici(),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.print),
                    label: const Text('Test Yazdır'),
                    onPressed: _yukleniyor ? null : _testYazdir,
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text(
                    'Not: Yazıcınızın IP adresini ve port numarasını (genellikle 9100) girin',
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: Builder(
        builder: (context) {
          if (_tabController.index == 1 || _tabController.index == 2) {
            return FloatingActionButton.extended(
              label: const Text('Kaydet'),
              icon: const Icon(Icons.save),
              onPressed: _yaziciKaydet,
            );
          }
          return const SizedBox.shrink();
        },
      ),
    );
  }
}