class Yazici {
  int? id;
  final String tur; // 'bluetooth' or 'ag'
  final String adi;
  final String? cihazId; // For Bluetooth
  final String? ip;      // For network
  final int? port;       // For network
  final bool varsayilan;

  Yazici({
    this.id,
    required this.tur,
    required this.adi,
    this.cihazId,
    this.ip,
    this.port,
    this.varsayilan = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'tur': tur,
      'adi': adi,
      'cihaz_id': cihazId,
      'ip': ip,
      'port': port,
      'varsayilan': varsayilan ? 1 : 0,
    };
  }

  factory Yazici.fromMap(Map<String, dynamic> map) {
    return Yazici(
      id: map['id'],
      tur: map['tur'],
      adi: map['adi'],
      cihazId: map['cihaz_id'],
      ip: map['ip'],
      port: map['port'],
      varsayilan: map['varsayilan'] == 1,
    );
  }

  @override
  String toString() {
    return 'Yazici{id: $id, tur: $tur, adi: $adi, cihazId: $cihazId, ip: $ip, port: $port, varsayilan: $varsayilan}';
  }
}