String formatCurrency(num value) {
  return value.toStringAsFixed(2) + ' TL';
}
