import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../modeller/cari_hareket.dart';
import '../modeller/musteri.dart';
import 'package:market_uygulamasi/core/logger.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';

class CariHareketRepo {
  static final CariHareketRepo _instance = CariHareketRepo._internal();
  factory CariHareketRepo() => _instance;
  CariHareketRepo._internal();

  Future<Database> get _database async {
    return await VeritabaniYardimcisi.getDatabase();
  }

  // Cari bakiyeyi yeniden hesapla ve güncelle
  Future<void> _guncelleCariBakiye(int cariId) async {
    final db = await _database;
    final cariMap = await db.query('Cari', where: 'id = ?', whereArgs: [cariId]);
    if (cariMap.isEmpty) return;
    final String cariTipi = cariMap.first['cari_tipi'] as String;

    final result = await db.rawQuery('''
      SELECT SUM(borc) as toplamBorc, SUM(alacak) as toplamAlacak
      FROM CariHareket
      WHERE cari_id = ?
    ''', [cariId]);

    double toplamBorc = (result.first['toplamBorc'] as num?)?.toDouble() ?? 0.0;
    double toplamAlacak = (result.first['toplamAlacak'] as num?)?.toDouble() ?? 0.0;

    double yeniBakiye;
    if (cariTipi == 'Müşteri') {
      yeniBakiye = toplamBorc - toplamAlacak;
    } else {
      yeniBakiye = toplamAlacak - toplamBorc;
    }

    await db.update('Cari', {'bakiye': yeniBakiye}, where: 'id = ?', whereArgs: [cariId]);
    appLogger.i("Cari $cariId bakiyesi güncellendi: $yeniBakiye");
  }

  Future<void> hareketEkle(CariHareket hareket) async {
    final db = await _database;
    await db.insert('CariHareket', hareket.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
    await _guncelleCariBakiye(hareket.cariId);
  }

  Future<void> hareketSil(int id) async {
    final db = await _database;
    final hareketMap = await db.query('CariHareket', where: 'id = ?', whereArgs: [id]);
    if (hareketMap.isEmpty) return;
    final int cariId = hareketMap.first['cari_id'] as int;

    await db.delete('CariHareket', where: 'id = ?', whereArgs: [id]);
    await _guncelleCariBakiye(cariId);
  }

  // Belirli bir cariye ait tüm "Açılış" tipindeki hareketleri siler
  Future<void> acilisHareketleriniSil(int cariId) async {
    final db = await _database;
    await db.delete(
      'CariHareket',
      where: 'cari_id = ? AND fis_tipi = ?',
      whereArgs: [cariId, 'Açılış'],
    );
    await _guncelleCariBakiye(cariId);
  }

  Future<List<CariHareket>> hareketleriGetirByTarihAralik(
      DateTime baslangic, DateTime bitis, String tip) async {
    final db = await _database;
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
      SELECT * FROM CariHareket 
      WHERE datetime(tarih) BETWEEN datetime(?) AND datetime(?) 
      AND fis_tipi = ?
      ORDER BY tarih ASC
    ''', [baslangic.toIso8601String(), bitis.toIso8601String(), tip]);
    return maps.map((e) => CariHareket.fromMap(e)).toList();
  }

  Future<List<CariHareket>> hareketleriGetir(int cariId) async {
    try {
      final db = await _database;
      final maps = await db.query('CariHareket',
          where: 'cari_id = ?', whereArgs: [cariId], orderBy: 'tarih DESC');
      return maps.map((e) => CariHareket.fromMap(e)).toList();
    } catch (e) {
      appLogger.i("CariHareket getirme hatası: $e");
      throw Exception("Cari hareket getirme hatası: $e");
    }
  }

  Future<List<CariHareket>> tumHareketleriGetir() async {
    try {
      final db = await _database;
      final maps = await db.query('CariHareket', orderBy: 'tarih DESC');
      return maps.map((e) => CariHareket.fromMap(e)).toList();
    } catch (e) {
      appLogger.i("Tüm cari hareketleri getirme hatası: $e");
      throw Exception("Tüm cari hareketleri getirme hatası: $e");
    }
  }

  Future<double> toplamBakiye(String tip) async {
    final db = await _database;
    final result = await db.rawQuery(
        'SELECT SUM(alacak - borc) as bakiye FROM CariHareket WHERE fis_tipi = ?',
        [tip]);
    return (result.first['bakiye'] as num?)?.toDouble() ?? 0.0;
  }

  Future<void> hareketGuncelle(CariHareket hareket) async {
    try {
      final db = await _database;
      await db.update('CariHareket', hareket.toMap(),
          where: 'id = ?', whereArgs: [hareket.id]);
      await _guncelleCariBakiye(hareket.cariId);
    } catch (e) {
      appLogger.i("Cari hareket güncelleme hatası: $e");
      throw Exception("Cari hareket güncelleme hatası: $e");
    }
  }
}