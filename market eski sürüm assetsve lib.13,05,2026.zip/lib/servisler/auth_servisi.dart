import 'package:shared_preferences/shared_preferences.dart';
import 'package:market_uygulamasi/modeller/kullanici.dart';
import 'package:market_uygulamasi/modeller/kullanici_rol.dart';
import 'package:market_uygulamasi/repozitory/kullanici_repo.dart';

class AuthServisi {
  static final AuthServisi _instance = AuthServisi._internal();
  factory AuthServisi() => _instance;
  AuthServisi._internal();

  final KullaniciRepository _repo = KullaniciRepository();
  Kullanici? _aktifKullanici;

  Kullanici? get aktifKullanici => _aktifKullanici;

  bool get girisYapilmis =>
      _aktifKullanici != null && (_aktifKullanici!.kullaniciAdi.isNotEmpty);

  bool get isAdmin => _aktifKullanici?.rol == 'admin';

  KullaniciRol get rol =>
      _aktifKullanici?.rol == 'admin'
          ? KullaniciRol.admin
          : KullaniciRol.personel;

  // 🔐 Giriş deneme limiti
  int _hataliDeneme = 0;
  DateTime? _kilitZamani;

  Future<bool> girisYap(String kullaniciAdi, String sifre) async {
    // 🔴 brute force koruma
    if (_kilitZamani != null &&
        DateTime.now().difference(_kilitZamani!) < const Duration(seconds: 10)) {
      return false;
    }

    final kullanici = await _repo.girisYap(kullaniciAdi, sifre);

    if (kullanici != null) {
      _aktifKullanici = kullanici;
      _hataliDeneme = 0;
      _kilitZamani = null;

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('uid', kullanici.id.toString());
      await prefs.setString('uname', kullanici.kullaniciAdi);
      await prefs.setString('rol', kullanici.rol);
      await prefs.setInt('login_time', DateTime.now().millisecondsSinceEpoch);

      return true;
    } else {
      _hataliDeneme++;

      if (_hataliDeneme >= 3) {
        _kilitZamani = DateTime.now();
      }

      return false;
    }
  }

  Future<void> cikisYap() async {
    _aktifKullanici = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('uid');
await prefs.remove('uname');
await prefs.remove('rol');
await prefs.remove('login_time');
  }

  // 🔥 OTURUM + TIMEOUT KONTROLÜ
Future<void> oturumKontrol() async {
  final prefs = await SharedPreferences.getInstance();
  final uid = prefs.getString('uid');
  final loginTime = prefs.getInt('login_time');

  if (uid == null || loginTime == null) {
    _aktifKullanici = null;
    return;
  }

  

    final kullanicilar = await _repo.kullaniciListesiGetir();
  try {
    _aktifKullanici = kullanicilar.firstWhere((k) => k.id.toString() == uid);
  } catch (_) {
    await cikisYap();
  }
}
}