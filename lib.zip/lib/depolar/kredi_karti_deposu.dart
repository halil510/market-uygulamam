// lib/depolar/kredi_karti_deposu.dart
import 'package:sqflite/sqflite.dart';
import '../modeller/kredi_karti_model.dart';
import '../modeller/kasa_hareket_model.dart';
import '../veri/database/veritabani.dart';
import '../servisler/log_servisi.dart';
import '../servisler/bulut/bulut_manager.dart';
import 'kasa_deposu.dart';
import 'package:uuid/uuid.dart';

class KrediKartiDeposu {
  final Veritabani _db = Veritabani();
  Future<Database> get _d async => _db.db;

  Future<int> ekle(KrediKartiModel kart) async {
    try {
      final db = await _d;
      final m = kart.toMap();
      m.remove('id');
      m['global_id'] ??= const Uuid().v4();
      // 🔴 Derin analizde bulundu (gerçek Supabase hatasından): bazı
      // kayıtlarda kart_no_maskeli NULL/boş kalıp senkronun sürekli
      // "NOT NULL ihlali" ile başarısız olmasına yol açıyordu. Model
      // bunu normalde önlese de (maskele() asla null döndürmez), hangi
      // yoldan gelirse gelsin (ör. eski/farklı bir çağrı) bu alanın hiç
      // boş kalmamasını burada da garanti ediyoruz.
      if (m['kart_no_maskeli'] == null || (m['kart_no_maskeli'] as String).isEmpty) {
        m['kart_no_maskeli'] = '**** **** **** ????';
      }
      final id = await db.insert('kredi_kartlari', m);
      final satir = await db.query('kredi_kartlari', where: 'id = ?', whereArgs: [id], limit: 1);
      if (satir.isNotEmpty) {
        BulutManager().upsert('kredi_kartlari', Map<String, dynamic>.from(satir.first));
      }
      return id;
    } catch (e, st) {
      LogServisi().hata('KrediKartiDeposu.ekle', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<void> guncelle(KrediKartiModel kart) async {
    try {
      final db = await _d;
      final m = kart.toMap();
      m['last_updated'] = DateTime.now().toIso8601String();
      if (m['kart_no_maskeli'] == null || (m['kart_no_maskeli'] as String).isEmpty) {
        m['kart_no_maskeli'] = '**** **** **** ????';
      }
      await db.update('kredi_kartlari', m, where: 'id = ?', whereArgs: [kart.id]);
      // 🔴 Bkz. BankaDeposu.guncelle() içindeki aynı not — kredi kartı
      // kaydının kendisi de bu tabloya sonradan senkron eklendiğinde
      // henüz oluşturulmuşsa global_id'siz kalmış olabilir.
      final mevcut = await db.query('kredi_kartlari', columns: ['global_id'], where: 'id = ?', whereArgs: [kart.id], limit: 1);
      if (mevcut.isNotEmpty && (mevcut.first['global_id'] == null || (mevcut.first['global_id'] as String).isEmpty)) {
        await db.update('kredi_kartlari', {'global_id': const Uuid().v4()}, where: 'id = ?', whereArgs: [kart.id]);
      }
      final satir = await db.query('kredi_kartlari', where: 'id = ?', whereArgs: [kart.id], limit: 1);
      if (satir.isNotEmpty) {
        BulutManager().upsert('kredi_kartlari', Map<String, dynamic>.from(satir.first));
      }
    } catch (e, st) {
      LogServisi().hata('KrediKartiDeposu.guncelle', hata: e, yigin: st);
      rethrow;
    }
  }

  // 🔴🔴 KRİTİK DÜZELTME (kullanıcı bulgusu): Bu depoda hiç sil()
  // fonksiyonu YOKTU — bir kredi kartı eklendikten sonra ASLA
  // silinemiyor veya devre dışı bırakılamıyordu (ne UI'da bir buton
  // ne bir toggle vardı). Tablo 'is_deleted' değil 'aktif' sütununu
  // kullanıyor (bankalar tablosuyla aynı desen) — gerçek silme yerine
  // deaktivasyon kullanılıyor çünkü kredi_karti_hareket tablosu bu
  // karta FK ile bağlı (geçmiş işlem kayıtlarını bozmamak için).
  // tumunuGetir() zaten 'aktif = 1' filtrelediği için, bu işlem
  // sonrası kart standart listeden otomatik olarak kayboluyor.
  Future<void> sil(int id) async {
    try {
      final db = await _d;
      final now = DateTime.now().toIso8601String();
      await db.update('kredi_kartlari', {'aktif': 0, 'last_updated': now},
          where: 'id = ?', whereArgs: [id]);
      final satir = await db.query('kredi_kartlari', where: 'id = ?', whereArgs: [id], limit: 1);
      if (satir.isNotEmpty) {
        BulutManager().upsert('kredi_kartlari', Map<String, dynamic>.from(satir.first));
      }
    } catch (e, st) {
      LogServisi().hata('KrediKartiDeposu.sil', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<List<KrediKartiModel>> tumunuGetir({int? bankaId}) async {
    try {
      final db = await _d;
      final where = bankaId != null ? 'banka_id = ? AND aktif = 1' : 'aktif = 1';
      final args = bankaId != null ? [bankaId] : null;
      final rows = await db.query('kredi_kartlari',
          where: where, whereArgs: args, orderBy: 'kart_adi ASC');
      return rows.map(KrediKartiModel.fromMap).toList();
    } catch (e, st) {
      LogServisi().hata('KrediKartiDeposu.tumunuGetir', hata: e, yigin: st);
      rethrow; // hata artık gizlenmiyor — UI tarafında görünür olacak
    }
  }

  Future<KrediKartiModel?> idileGetir(int id) async {
    try {
      final db = await _d;
      final rows = await db.query('kredi_kartlari',
          where: 'id = ? AND aktif = 1', whereArgs: [id]);
      if (rows.isEmpty) return null;
      return KrediKartiModel.fromMap(rows.first);
    } catch (e, st) {
      LogServisi().hata('KrediKartiDeposu.idileGetir', hata: e, yigin: st);
      rethrow;
    }
  }

  /// ÖNCEDEN bu fonksiyon mutlak bir "kullanilanLimit" değeri alıp
  /// doğrudan yazıyordu — çağıran kod (kart.kullanilanLimit + tutar
  /// gibi) önce OKUYUP hesaplıyordu, bu da borçta/stokta bulup
  /// düzelttiğim AYNI "kayıp güncelleme" riskini taşıyordu (2 cihazdan
  /// aynı karta aynı anda işlem girilirse biri kaybolabilirdi). Artık
  /// bu fonksiyon bir DELTA (değişim miktarı, harcama için pozitif,
  /// ödeme için negatif) alıyor, kendi hareket kaydını oluşturup
  /// gerçek toplamdan hesaplıyor.
  Future<void> limitDegistir(int id, double delta, {String aciklama = ''}) async {
    try {
      final db = await _d;
      int? hareketId;
      await db.transaction((txn) async {
        hareketId = await limitDegistirTxn(txn, id, delta, aciklama: aciklama);
      });
      if (hareketId == null) return; // kart bulunamadı

      // 🔴 Derin analizde bulundu: bu fonksiyon hiçbir zaman BulutManager
      // çağırmıyordu — kredi kartı hareketleri ve limit güncellemeleri
      // sadece manuel "Buluta Gönder" ile senkronize oluyordu.
      final hareketSatir = await db.query('kredi_karti_hareket', where: 'id = ?', whereArgs: [hareketId], limit: 1);
      if (hareketSatir.isNotEmpty) {
        BulutManager().upsert('kredi_karti_hareket', Map<String, dynamic>.from(hareketSatir.first));
      }
      final kartSatir = await db.query('kredi_kartlari', where: 'id = ?', whereArgs: [id], limit: 1);
      if (kartSatir.isNotEmpty) {
        BulutManager().upsert('kredi_kartlari', Map<String, dynamic>.from(kartSatir.first));
      }
    } catch (e, st) {
      LogServisi().hata('KrediKartiDeposu.limitDegistir', hata: e, yigin: st);
      rethrow;
    }
  }

  /// Kredi kartına NAKİT ödeme yapar — bkz.
  /// kredi_karti_detay_ekrani.dart'ın "Karta Ödeme Yap" dialogu (taşındığı
  /// yer). Kartın kullanılan limitini azaltır (limitDegistirTxn, negatif
  /// delta) VE aynı transaction'da bir kasa hareketi (çıkış) oluşturur —
  /// bu ekranın tek tutar alanı olduğu (ödeme kaynağı seçimi yok) için en
  /// yaygın senaryo olan NAKİT ödeme varsayılır. Bu form dışında Nakit
  /// olmayan bir ödeme kaynağı gerekiyorsa borç ödeme ekranlarındaki
  /// (BorcOdemeIslemServisi) daha genel akış kullanılmalı.
  Future<void> nakitOdemeYap(int kartId, double tutar, String kartAdi,
      {String aciklama = 'Elle ödeme girişi'}) async {
    final db = await _d;
    int? kartHareketId;
    int? kasaHareketId;
    await db.transaction((txn) async {
      kartHareketId =
          await limitDegistirTxn(txn, kartId, -tutar, aciklama: aciklama);
      kasaHareketId = await KasaDeposu().hareketEkleTxn(
          txn,
          KasaHareketModel(
            hareketTipi: 'Ödeme',
            tutar: tutar,
            referansId: kartId,
            referansTuru: 'kredi_karti_odeme',
            tarih: DateTime.now(),
            aciklama: 'Kredi kartı ödemesi: $kartAdi',
          ));
    });

    final kartSatir = await db.query('kredi_kartlari',
        where: 'id = ?', whereArgs: [kartId], limit: 1);
    if (kartSatir.isNotEmpty) {
      BulutManager()
          .upsert('kredi_kartlari', Map<String, dynamic>.from(kartSatir.first));
    }
    if (kartHareketId != null) {
      final kartHareketSatir = await db.query('kredi_karti_hareket',
          where: 'id = ?', whereArgs: [kartHareketId], limit: 1);
      if (kartHareketSatir.isNotEmpty) {
        BulutManager().upsert('kredi_karti_hareket',
            Map<String, dynamic>.from(kartHareketSatir.first));
      }
    }
    if (kasaHareketId != null) {
      final kasaSatir = await db.query('kasa_hareketleri',
          where: 'id = ?', whereArgs: [kasaHareketId], limit: 1);
      if (kasaSatir.isNotEmpty) {
        BulutManager().upsert(
            'kasa_hareketleri', Map<String, dynamic>.from(kasaSatir.first));
      }
    }
  }

  /// [limitDegistir] ile aynı mantık, VERİLEN transaction içinde çalışır.
  /// Kart bulunamazsa null döner (sessizce atlar — önceki davranışla aynı).
  Future<int?> limitDegistirTxn(dynamic txn, int id, double delta,
      {String aciklama = '', int? referansId, String? referansTuru}) async {
    final kartRows = await txn.query('kredi_kartlari', where: 'id = ? AND aktif = 1', whereArgs: [id]);
    if (kartRows.isEmpty) return null;
    final kart = KrediKartiModel.fromMap(kartRows.first);

    final hareketId = await txn.insert('kredi_karti_hareket', {
      'global_id': const Uuid().v4(),
      'kredi_karti_id': id,
      'tutar': delta.abs(),
      'yon': delta >= 0 ? 'harcama' : 'odeme',
      'aciklama': aciklama,
      'tarih': DateTime.now().toIso8601String(),
      'last_updated': DateTime.now().toIso8601String(),
      // DEEP_AUDIT (kendi-keşif turu, 2026-09-21): CariDeposu.
      // hareketIptalEt() bu hareketi bulup tersine çevirebilsin diye.
      'referans_id': ?referansId,
      'referans_turu': ?referansTuru,
    });

    final toplamRows = await txn.rawQuery('''
      SELECT COALESCE(SUM(CASE WHEN yon = 'harcama' THEN tutar ELSE -tutar END), 0) as toplam
      FROM kredi_karti_hareket WHERE kredi_karti_id = ? AND is_deleted = 0
    ''', [id]);
    final yeniKullanilan = (toplamRows.first['toplam'] as num?)?.toDouble() ?? 0;
    final kalan = (kart.kartLimit - yeniKullanilan).clamp(0, double.infinity);
    await txn.update('kredi_kartlari', {
      'kullanilan_limit': yeniKullanilan,
      'kalan_limit': kalan,
      'last_updated': DateTime.now().toIso8601String(),
    }, where: 'id = ?', whereArgs: [id]);

    return hareketId;
  }

  /// Aktif kartlardan kullanılan limiti, kendi hareketlerinin net toplamından
  /// (harcama − ödeme) farklı olanlar. Sayım ve düzeltme AYNI tanımı
  /// kullanır; kart başına ayrı SUM sorgusu (N+1) yerine tek sorgu.
  static const String _kartUyumsuzSql = '''
    SELECT * FROM (
      SELECT k.id AS id,
             COALESCE(k.kartlimit, 0) AS kart_limit,
             COALESCE(k.kullanilan_limit, 0) AS mevcut,
             (SELECT COALESCE(SUM(CASE WHEN h.yon = 'harcama' THEN h.tutar ELSE -h.tutar END), 0)
                FROM kredi_karti_hareket h
               WHERE h.kredi_karti_id = k.id AND h.is_deleted = 0) AS dogru
      FROM kredi_kartlari k
      WHERE k.aktif = 1
    ) WHERE ABS(mevcut - dogru) > 0.01
  ''';

  /// [limitMutabakatYap]'ın SALT OKUNUR ön kontrolü (Veri Sağlığı Merkezi).
  /// Hata yutulmaz: 0 döndürmek "uyumlu" ile "kontrol edilemedi"yi ayırt
  /// edilemez kılıyordu.
  Future<int> uyumsuzlukSayisi() async {
    try {
      final db = await _d;
      final rows =
          await db.rawQuery('SELECT COUNT(*) AS n FROM ($_kartUyumsuzSql)');
      return (rows.first['n'] as num?)?.toInt() ?? 0;
    } catch (e, st) {
      LogServisi().hata('KrediKartiDeposu.uyumsuzlukSayisi', hata: e, yigin: st);
      rethrow;
    }
  }

  /// Senkronizasyon sonrası çağrılması önerilir — her kartın
  /// "kullanilan_limit"ini kendi hareketlerinin gerçek toplamından
  /// yeniden hesaplar (stok/borç mutabakatıyla aynı mimari). Okuma ve
  /// yazma aynı transaction'da: araya giren bir harcama ezilemez.
  Future<int> limitMutabakatYap() async {
    try {
      final db = await _d;
      final duzeltilenIdler = <int>[];
      await db.transaction((txn) async {
        final uyumsuzlar = await txn.rawQuery(_kartUyumsuzSql);
        for (final r in uyumsuzlar) {
          final kartId = r['id'] as int?;
          if (kartId == null) continue;
          final dogru = (r['dogru'] as num?)?.toDouble() ?? 0;
          final kartLimit = (r['kart_limit'] as num?)?.toDouble() ?? 0;
          await txn.update('kredi_kartlari', {
            'kullanilan_limit': dogru,
            'kalan_limit': (kartLimit - dogru).clamp(0, double.infinity),
            // Türetilmiş değer: last_updated ilerletilmez (bkz. MasaDeposu.
            // siparisToplamlariMutabakatYap notu).
          }, where: 'id = ?', whereArgs: [kartId]);
          duzeltilenIdler.add(kartId);
        }
      });
      for (final kartId in duzeltilenIdler) {
        final satir = await db.query('kredi_kartlari',
            where: 'id = ?', whereArgs: [kartId], limit: 1);
        if (satir.isNotEmpty) {
          BulutManager().upsert('kredi_kartlari', Map<String, dynamic>.from(satir.first));
        }
      }
      if (duzeltilenIdler.isNotEmpty) {
        LogServisi().bilgi(
            'Kredi kartı limit mutabakatı: ${duzeltilenIdler.length} kart düzeltildi');
      }
      return duzeltilenIdler.length;
    } catch (e, st) {
      LogServisi().hata('KrediKartiDeposu.limitMutabakatYap', hata: e, yigin: st);
      rethrow;
    }
  }

  // 🔴 Derin analizde bulundu (Madde 11 — Kredi Kartı/Banka Mutabakatı
  // denetimi, 2026-09-16): limitGuncelle(id, kullanilanLimit) burada
  // duruyordu ama projede HİÇBİR YERDEN çağrılmıyordu (ölü kod) — ve
  // çağrılsaydı TEHLİKELİYDİ: 'kullanilan_limit'i kredi_karti_hareket
  // tablosuna hiç hareket kaydı düşmeden doğrudan değiştiriyordu. Limit
  // kullanımı, limitDegistirTxn ile stok/cari/kasa/banka'daki gibi
  // event-sourcing modeliyle yönetiliyor — bu fonksiyonla değiştirilen
  // bir limit, bir sonraki limitMutabakatYap() turunda (Veri Sağlığı
  // Merkezi'nden tetiklenebiliyor) sessizce eski değerine geri dönerdi.
  // İleride birinin bu tuzağı fark etmeden kullanmasını önlemek için
  // tamamen kaldırıldı; limit değişikliği gereken her yer
  // limitDegistir/limitDegistirTxn kullanmalı.
}
