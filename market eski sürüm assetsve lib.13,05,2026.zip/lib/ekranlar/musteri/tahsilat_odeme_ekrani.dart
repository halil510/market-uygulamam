// lib/ekranlar/musteri/tahsilat_odeme_ekrani.dart
//
// ═══════════════════════════════════════════════════════════════════════════
// DÜZELTİLEN HATALAR:
//
//  1. BORÇ/ALACAK MANTIK HATASI
//     Müşteri tahsilatı → müşteri bize ödeme yapıyor → bakiye azalıyor
//       hareket: alacak = tutar (müşterinin borcundan düşecek)
//     Tedarikçi ödemesi → biz tedarikçiye ödüyoruz → bakiye azalıyor
//       hareket: alacak = tutar (tedarikçiye olan borcumuzdan düşecek)
//     ESKİ KOD: Tedarikçiye ödeme için borc = tutar yazıyordu — YANLIŞ
//     Muhasebe kuralı: Tahsilat/Ödeme her iki tipte de ALACAK sütununa gider.
//     Bakiye = Borç - Alacak formülünde: alacak artınca bakiye düşer = borç kapanır.
//
//  2. Tutar validator sayısal kontrol yapıyordu ama virgül/nokta kabul etmiyordu.
//     Artık hem nokta hem virgül kabul ediliyor.
//
//  3. Bakiye gösterimi: mevcut bakiyeyi renklendirerek göster (kırmızı/yeşil).
//
//  4. disposed sonrası ScaffoldMessenger çağrısı → mounted kontrolü eklendi.
//
//  5. Tutar sıfır veya negatif girilirse kaydetme engellendi.
//
//  6. MusteriRepo.cariBakiyeGuncelle() burada da çağrılıyor çünkü repo
//     otomatik güncellemesi her zaman güvenilir değil.
//
//  7. Ödeme yöntemi hareket açıklamasına eklendi.
// ═══════════════════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:market_uygulamasi/modeller/musteri.dart';
import 'package:market_uygulamasi/modeller/cari_hareket.dart';
import 'package:market_uygulamasi/repozitory/cari_hareket_repo.dart';
import 'package:market_uygulamasi/repozitory/musteri_repo.dart';

class TahsilatOdemeEkrani extends StatefulWidget {
  final Musteri cari;
  final VoidCallback onIslemTamamlandi;

  const TahsilatOdemeEkrani({
    Key? key,
    required this.cari,
    required this.onIslemTamamlandi,
  }) : super(key: key);

  @override
  _TahsilatOdemeEkraniState createState() => _TahsilatOdemeEkraniState();
}

class _TahsilatOdemeEkraniState extends State<TahsilatOdemeEkrani> {
  final _formKey = GlobalKey<FormState>();
  final _tutarController = TextEditingController();
  final _aciklamaController = TextEditingController();
  final CariHareketRepo _hareketRepo = CariHareketRepo();
  final MusteriRepo _musteriRepo = MusteriRepo();

  String _odemeYontemi = 'Nakit';
  bool _isProcessing = false;

  bool get _isMusteri => widget.cari.cariTipi == 'Müşteri';

  @override
  void initState() {
    super.initState();
    _aciklamaController.text =
        _isMusteri ? 'Müşteri Tahsilatı' : 'Tedarikçi Ödemesi';
  }

  @override
  void dispose() {
    _tutarController.dispose();
    _aciklamaController.dispose();
    super.dispose();
  }

  double? _parseTutar() {
    final text = _tutarController.text.trim().replaceAll(',', '.');
    return double.tryParse(text);
  }

  Future<void> _islemYap() async {
    if (!_formKey.currentState!.validate()) return;
    final tutar = _parseTutar();
    if (tutar == null || tutar <= 0) {
      _showMessage('Geçerli bir tutar giriniz', isError: true);
      return;
    }

    setState(() => _isProcessing = true);
    try {
      // FIX 1: Her iki cari tipinde de tahsilat/ödeme ALACAK sütununa gider.
      // Muhasebe: Bakiye = Borç - Alacak
      //   Müşteri bize ödedi  → alacak artar → bakiye (borç) azalır ✓
      //   Biz tedarikçiye ödedik → tedarikçinin alacağı azalır →
      //     tedarikçi hareketi de alacak sütununa (tersinden bakıldığında) ✓
      //
      // Pratikte: her iki durumda da alacak = tutar, borç = 0
      final String fisTipi = _isMusteri ? 'Tahsilat' : 'Ödeme';
      final String fisPrefix = _isMusteri ? 'TAH' : 'ODE';
      final String fisNo = '$fisPrefix-${DateTime.now().millisecondsSinceEpoch}';

      final hareket = CariHareket(
        cariId: widget.cari.id!,
        tarih: DateTime.now(),
        fisTipi: fisTipi,
        fisId: null,
        fisNo: fisNo,
        aciklama: '${_aciklamaController.text} ($_odemeYontemi)',
        borc: 0,           // FIX 1: Tedarikçi için de borc=0
        alacak: tutar,     // FIX 1: Her zaman alacak
      );

      await _hareketRepo.hareketEkle(hareket);

      // FIX 6: Bakiyeyi DB'ye de yaz
      final yeniBakiye = widget.cari.bakiye - tutar;
      await _musteriRepo.cariBakiyeGuncelle(widget.cari.id!, yeniBakiye);

      if (!mounted) return; // FIX 4

      _showMessage(
        '${_isMusteri ? 'Tahsilat' : 'Ödeme'} başarıyla kaydedildi. '
        'Yeni bakiye: ${yeniBakiye.toStringAsFixed(2)} ₺',
      );
      widget.onIslemTamamlandi();
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      _showMessage('İşlem sırasında hata: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  void _showMessage(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bakiye = widget.cari.bakiye;
    final bakiyeRenk = bakiye > 0
        ? Colors.red.shade700
        : bakiye < 0
            ? Colors.green.shade700
            : Colors.grey.shade700;

    return Scaffold(
      appBar: AppBar(
        title: Text(_isMusteri ? 'Tahsilat Yap' : 'Ödeme Yap'),
        backgroundColor: _isMusteri ? Colors.blue.shade700 : Colors.orange.shade700,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Cari bilgi kartı ────────────────────────────────────
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 28,
                        backgroundColor: _isMusteri
                            ? Colors.blue.shade100
                            : Colors.orange.shade100,
                        child: Icon(
                          _isMusteri ? Icons.person : Icons.business,
                          color: _isMusteri
                              ? Colors.blue.shade700
                              : Colors.orange.shade700,
                          size: 30,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.cari.unvan,
                              style: const TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              widget.cari.cariKodu,
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            'Mevcut Bakiye',
                            style: TextStyle(
                                fontSize: 11, color: Colors.grey.shade500),
                          ),
                          Text(
                            '${bakiye.toStringAsFixed(2)} ₺',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: bakiyeRenk,
                            ),
                          ),
                          Text(
                            bakiye > 0
                                ? (_isMusteri ? 'Borçlu' : 'Ödeyeceğiz')
                                : bakiye < 0
                                    ? 'Alacaklı'
                                    : 'Dengede',
                            style: TextStyle(
                                fontSize: 11, color: bakiyeRenk),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // ── Tutar alanı ─────────────────────────────────────────
              TextFormField(
                controller: _tutarController,
                decoration: InputDecoration(
                  labelText: 'Tutar (₺)',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.money),
                  hintText: '0.00',
                  // Maksimum tutar gösterimi
                  helperText: bakiye > 0
                      ? 'Azami: ${bakiye.toStringAsFixed(2)} ₺'
                      : null,
                ),
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                autofocus: true,
                // FIX 2: Hem virgül hem nokta kabul et
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
                ],
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Tutar giriniz';
                  final parsed =
                      double.tryParse(v.trim().replaceAll(',', '.'));
                  if (parsed == null) return 'Geçerli bir sayı giriniz';
                  // FIX 5: Sıfır veya negatif engellendi
                  if (parsed <= 0) return 'Tutar sıfırdan büyük olmalı';
                  return null;
                },
                onChanged: (_) => setState(() {}), // tahmini bakiye güncelle
              ),

              const SizedBox(height: 12),

              // Tahmini yeni bakiye önizlemesi
              if (_tutarController.text.isNotEmpty)
                Builder(builder: (ctx) {
                  final tutar = _parseTutar() ?? 0;
                  final yeni = widget.cari.bakiye - tutar;
                  return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: yeni > 0
                          ? Colors.red.shade50
                          : Colors.green.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: yeni > 0
                              ? Colors.red.shade200
                              : Colors.green.shade200),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('İşlem sonrası bakiye:',
                            style: TextStyle(fontSize: 13)),
                        Text(
                          '${yeni.toStringAsFixed(2)} ₺',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: yeni > 0
                                ? Colors.red.shade700
                                : Colors.green.shade700,
                          ),
                        ),
                      ],
                    ),
                  );
                }),

              const SizedBox(height: 16),

              // ── Açıklama alanı ──────────────────────────────────────
              TextFormField(
                controller: _aciklamaController,
                decoration: const InputDecoration(
                  labelText: 'Açıklama',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.notes),
                ),
                maxLines: 2,
              ),

              const SizedBox(height: 16),

              // ── Ödeme yöntemi ───────────────────────────────────────
              DropdownButtonFormField<String>(
                value: _odemeYontemi,
                items: ['Nakit', 'Kredi Kartı', 'Banka Havalesi', 'Çek']
                    .map((y) => DropdownMenuItem(value: y, child: Text(y)))
                    .toList(),
                onChanged: (v) => setState(() => _odemeYontemi = v!),
                decoration: const InputDecoration(
                  labelText: 'Ödeme Yöntemi',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.payment),
                ),
              ),

              const SizedBox(height: 32),

              // ── Onay butonu ─────────────────────────────────────────
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: _isProcessing ? null : _islemYap,
                  icon: _isProcessing
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2),
                        )
                      : const Icon(Icons.check_circle),
                  label: Text(
                    _isMusteri ? 'Tahsilatı Onayla' : 'Ödemeyi Onayla',
                    style: const TextStyle(fontSize: 17),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isMusteri
                        ? Colors.blue.shade700
                        : Colors.orange.shade700,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}