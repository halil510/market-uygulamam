// lib/ekranlar/musteri/fis_detay_ekrani.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:excel/excel.dart' as excel;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:market_uygulamasi/repozitory/satis_repo.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/repozitory/cari_hareket_repo.dart';
import 'package:market_uygulamasi/modeller/satis.dart';
import 'package:market_uygulamasi/modeller/satis_kalem.dart';
import 'package:market_uygulamasi/modeller/cari_hareket.dart';

class FisDetayEkrani extends StatefulWidget {
  final int fisId;
  final String fisTipi; // 'Satış', 'Alış', 'Tahsilat', 'Ödeme', 'İade'

  const FisDetayEkrani({
    Key? key,
    required this.fisId,
    required this.fisTipi,
  }) : super(key: key);

  @override
  _FisDetayEkraniState createState() => _FisDetayEkraniState();
}

class _FisDetayEkraniState extends State<FisDetayEkrani> {
  final SatisRepository _satisRepo = SatisRepository();
  final UrunRepoSitory _urunRepo = UrunRepoSitory();
  final CariHareketRepo _cariHareketRepo = CariHareketRepo();

  List<SatisKalem> kalemler = [];
  double toplamTutar = 0;
  bool yukleniyor = true;
  String? aciklama;
  String? fisNo;
  DateTime? tarih;

  @override
  void initState() {
    super.initState();
    _fisDetaylariniGetir();
  }

  Future<void> _fisDetaylariniGetir() async {
    setState(() => yukleniyor = true);
    try {
      if (widget.fisTipi == 'Satış') {
        final fis = await _satisRepo.satisGetir(widget.fisId);
        if (fis != null) {
          kalemler = fis.kalemler;
          toplamTutar = fis.toplamTutar;
          tarih = fis.tarih;
          fisNo = 'FS-${fis.id}';
          aciklama = 'Satış Fişi';
        }
      } 
      else if (widget.fisTipi == 'Alış') {
        // Alış fişleri için benzer bir repository henüz yoksa doğrudan CariHareket'ten alınabilir
        final hareketler = await _cariHareketRepo.hareketleriGetirByTarihAralik(
          DateTime.now().subtract(Duration(days: 30)),
          DateTime.now(),
          'Alış'
        );
        final hareket = hareketler.firstWhere(
          (h) => h.fisId == widget.fisId,
          orElse: () => throw Exception('Alış fişi bulunamadı'),
        );
        // Alış fişinde detay (kalemler) olmayabilir, ürün bazlı detay ayrı tabloda saklanıyorsa oradan çekilir.
        // Bu örnekte basitçe gösteriyoruz.
        toplamTutar = hareket.borc + hareket.alacak; // Alışta borç artar
        tarih = hareket.tarih;
        fisNo = hareket.fisNo ?? 'AL-${hareket.id}';
        aciklama = hareket.aciklama;
        kalemler = []; // Alış detayları için ayrı bir model gerekir
      }
      else if (widget.fisTipi == 'Tahsilat' || widget.fisTipi == 'Ödeme') {
        final hareketler = await _cariHareketRepo.hareketleriGetirByTarihAralik(
          DateTime.now().subtract(Duration(days: 30)),
          DateTime.now(),
          widget.fisTipi
        );
        final hareket = hareketler.firstWhere(
          (h) => h.fisId == widget.fisId,
          orElse: () => throw Exception('${widget.fisTipi} fişi bulunamadı'),
        );
        toplamTutar = widget.fisTipi == 'Tahsilat' ? hareket.alacak : hareket.borc;
        tarih = hareket.tarih;
        fisNo = hareket.fisNo ?? '${widget.fisTipi.substring(0,3)}-${hareket.id}';
        aciklama = hareket.aciklama;
        kalemler = [];
      }
      else {
        // İade veya diğer tipler
        kalemler = [];
        toplamTutar = 0;
      }
      setState(() => yukleniyor = false);
    } catch (e) {
      setState(() => yukleniyor = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Fiş detayı yüklenemedi: $e')),
      );
    }
  }

  Future<void> _exportToExcel() async {
    if (kalemler.isEmpty && widget.fisTipi != 'Satış') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bu fiş türü için Excel aktarımı desteklenmiyor (detay yok)')),
      );
      return;
    }

    var excelObj = excel.Excel.createExcel();
    var sheet = excelObj['Fiş Detayı'];

    sheet.appendRow([
      'Kod', 'Barkod', 'Ürün Adı', 'Miktar', 'Birim Fiyat (KDV li)', 'KDV li Tutar', 'İndirim Oranı (%)'
    ]);

    for (var kalem in kalemler) {
      sheet.appendRow([
        kalem.urunKodu ?? '',
        kalem.barkod ?? '',
        kalem.urunAdi,
        kalem.miktar,
        kalem.birimFiyat,
        kalem.toplamTutar,
        kalem.indirimOrani,
      ]);
    }

    sheet.appendRow(['', '', '', '', 'TOPLAM:', toplamTutar, '']);

    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/fis_detay_${widget.fisId}_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    await File(path).writeAsBytes(excelObj.encode()!);
    await Share.shareFiles([path], text: '${widget.fisTipi} Fiş Detayı (ID: ${widget.fisId})');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.fisTipi} Detayı'),
        actions: [
          IconButton(
            icon: Icon(Icons.table_chart),
            onPressed: _exportToExcel,
            tooltip: 'Excel\'e Aktar',
          ),
        ],
      ),
      body: yukleniyor
          ? Center(child: CircularProgressIndicator())
          : kalemler.isEmpty && widget.fisTipi == 'Satış'
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.receipt_long, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text('Fiş detayı bulunamadı', style: TextStyle(fontSize: 18, color: Colors.grey)),
                      SizedBox(height: 8),
                      Text('Fiş ID: ${widget.fisId}', style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                )
              : Column(
                  children: [
                    Card(
                      margin: EdgeInsets.all(16),
                      elevation: 4,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Fiş No:', style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                                    SizedBox(height: 4),
                                    Text(fisNo ?? widget.fisId.toString(), style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text('Toplam Tutar:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                                    SizedBox(height: 4),
                                    Text('${toplamTutar.toStringAsFixed(2)} ₺', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue)),
                                  ],
                                ),
                              ],
                            ),
                            if (aciklama != null) ...[
                              Divider(),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text('Açıklama: $aciklama', style: TextStyle(fontSize: 14)),
                              ),
                            ],
                            if (tarih != null) ...[
                              SizedBox(height: 8),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text('Tarih: ${tarih!.toLocal().toString().split(' ')[0]}', style: TextStyle(fontSize: 14)),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    if (kalemler.isNotEmpty)
                      Expanded(
                        child: ListView.builder(
                          itemCount: kalemler.length,
                          itemBuilder: (context, index) {
                            final kalem = kalemler[index];
                            return Container(
                              margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.1), spreadRadius: 2, blurRadius: 5, offset: Offset(0, 2))],
                              ),
                              child: ListTile(
                                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                leading: Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(color: Colors.blue[50], borderRadius: BorderRadius.circular(8)),
                                  alignment: Alignment.center,
                                  child: Text((index + 1).toString(), style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue)),
                                ),
                                title: Text(kalem.urunAdi, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                subtitle: Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(children: [Text('Miktar:', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(width: 4), Text('${kalem.miktar}')]),
                                      SizedBox(height: 4),
                                      Row(children: [Text('Birim Fiyat:', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(width: 4), Text('${kalem.birimFiyat.toStringAsFixed(2)} ₺')]),
                                    ],
                                  ),
                                ),
                                trailing: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text('${kalem.toplamTutar.toStringAsFixed(2)} ₺', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.blue)),
                                    if (kalem.indirimOrani > 0)
                                      Padding(padding: const EdgeInsets.only(top: 4), child: Text('%${kalem.indirimOrani.toStringAsFixed(1)} indirim', style: TextStyle(color: Colors.green, fontSize: 12))),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      )
                    else if (widget.fisTipi != 'Satış')
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.info_outline, size: 48, color: Colors.grey),
                              SizedBox(height: 16),
                              Text('Bu fiş türü için detaylı ürün listesi bulunmamaktadır.'),
                              Text('Toplam Tutar: ${toplamTutar.toStringAsFixed(2)} ₺'),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}