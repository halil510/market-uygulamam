// lib/ekranlar/urun/urun_detay_ekrani.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/widgetlar/barkod_tarayici.dart';
import 'package:file_picker/file_picker.dart';
import 'package:market_uygulamasi/widgetlar/barcode_widget.dart';

class UrunDetayEkrani extends StatefulWidget {
  final Urun? duzenlenecekUrun;
  final String? baslangicBarkod;

  const UrunDetayEkrani({Key? key, this.duzenlenecekUrun, this.baslangicBarkod})
      : super(key: key);

  @override
  State<UrunDetayEkrani> createState() => _UrunDetayEkraniState();
}

class _UrunDetayEkraniState extends State<UrunDetayEkrani> {
  final _formKey = GlobalKey<FormState>();
  final UrunRepoSitory _repo = UrunRepoSitory();
  final Map<String, TextEditingController> _controllers = {};

  // Ana/Alt grup
  List<String> anaGrupListesi = [];
  bool anaGrupYukleniyor = true;
  final TextEditingController _anagrupController = TextEditingController();

  List<String> altGrupListesi = [];
  bool altGrupYukleniyor = true;

  // Alan1 için autocomplete verileri
  List<String> alan1Listesi = [];
  bool alan1Yukleniyor = true;
  final TextEditingController _alan1Controller = TextEditingController();

  // Diğer seçimler
  final List<String> paraBirimiListesi = ['TL', 'USD', 'EUR'];
  final List<String> birimListesi = ['ADET', 'KG', 'LİTRE', 'PAKET', 'KOLİ'];
  String? seciliBirim;
  String? seciliAltGrup;
  String? seciliParaBirimi;
  bool promosyonAktif = false;
  bool _isLoading = false;
  File? _seciliResim;
  bool _updating = false;

  @override
  void initState() {
    super.initState();
    _initControllers();

    if (widget.duzenlenecekUrun != null) {
      _verileriYukle();
    } else if (widget.baslangicBarkod != null && widget.baslangicBarkod!.isNotEmpty) {
      _controllers['barkod']?.text = widget.baslangicBarkod!;
      _controllers['kod']?.text = widget.baslangicBarkod!;
    }

    _anaGruplariYukle();
    _altGruplariYukle();
    _alan1ListesiniYukle();

    seciliBirim ??= birimListesi.first;
    seciliParaBirimi ??= paraBirimiListesi.first;

    // Listener'lar
    _controllers['alisFiyat']!.addListener(_onAlisFiyatChanged);
    _controllers['alisFiyatKdvDahil']!.addListener(_onAlisFiyatKdvDahilChanged);
    _controllers['alisKdvOrani']!.addListener(_onAlisKdvOraniChanged);
    _controllers['satisFiyat']!.addListener(_onSatisFiyatChanged);
    _controllers['indirimOrani']!.addListener(_onIndirimOraniChanged);
    _controllers['indirimliFiyat']!.addListener(_onIndirimliFiyatChanged);
  }

  void _initControllers() {
    for (var key in [
      'kod', 'barkod', 'barkodlar', 'ad', 'alisFiyat', 'alisFiyatKdvDahil',
      'satisFiyat', 'alisKdvOrani', 'stokMiktari', 'alan2',
      'marka', 'indirimOrani', 'indirimliFiyat', 'boy', 'resimYolu', 'mens',
      'karOrani', 'fiyatGuncellemeTarihi', 'maliyetGuncellemeTarihi',
    ]) {
      _controllers[key] = TextEditingController();
    }
    _controllers['stokMiktari']!.text = '0';
  }

  void _verileriYukle() {
    final u = widget.duzenlenecekUrun!;
    _controllers['kod']!.text = u.kod ?? '';
    _controllers['barkod']!.text = u.barkod ?? '';
    _controllers['barkodlar']!.text = u.barkodlar ?? '';
    _controllers['ad']!.text = u.ad ?? '';
    _controllers['alisFiyat']!.text = u.alisFiyat?.toString() ?? '';
    _controllers['alisFiyatKdvDahil']!.text = u.alisFiyatKdvDahil?.toString() ?? '';
    _controllers['satisFiyat']!.text = u.satisFiyat?.toString() ?? '';
    _controllers['alisKdvOrani']!.text = u.alisKdvOrani != null ? u.alisKdvOrani!.toInt().toString() : '';
    _controllers['stokMiktari']!.text = u.stokMiktari?.toString() ?? '';
    _controllers['alan2']!.text = u.alan2 ?? '';
    _controllers['marka']!.text = u.marka ?? '';
    _controllers['indirimOrani']!.text = u.indirimOrani?.toString() ?? '';
    _controllers['indirimliFiyat']!.text = u.indirimliFiyat?.toString() ?? '';
    _controllers['boy']!.text = u.boy ?? '';
    _controllers['resimYolu']!.text = u.resimYolu ?? '';
    _controllers['mens']!.text = u.mens ?? '';
    _controllers['karOrani']!.text = u.karOrani?.toString() ?? '';
    _controllers['fiyatGuncellemeTarihi']!.text = u.fiyatGuncellemeTarihi ?? '';
    _controllers['maliyetGuncellemeTarihi']!.text = u.maliyetGuncellemeTarihi ?? '';
    _anagrupController.text = u.anagrup ?? '';
    _alan1Controller.text = u.alan1 ?? '';
    seciliBirim = u.birim;
    seciliAltGrup = u.altGrup;
    seciliParaBirimi = u.paraBirimi;
    promosyonAktif = u.promosyonAktif ?? false;
    if (u.resimYolu != null && u.resimYolu!.isNotEmpty) {
      _seciliResim = File(u.resimYolu!);
    }
  }

  // ================= DÖNGÜ ENGELLEMELİ HESAPLAMALAR =================
  void _onAlisFiyatChanged() {
    if (_updating) return;
    _hesaplaKdvliAlisFiyati();
  }

  void _onAlisFiyatKdvDahilChanged() {
    if (_updating) return;
    _hesaplaKdvHaricAlisFiyati();
  }

  void _onAlisKdvOraniChanged() {
    if (_updating) return;
    final alisFiyatStr = _controllers['alisFiyat']!.text.trim();
    final kdvliStr = _controllers['alisFiyatKdvDahil']!.text.trim();
    if (alisFiyatStr.isNotEmpty && _toDouble(alisFiyatStr) != null) {
      _hesaplaKdvliAlisFiyati();
    } else if (kdvliStr.isNotEmpty && _toDouble(kdvliStr) != null) {
      _hesaplaKdvHaricAlisFiyati();
    }
    _hesaplaKarOrani();
  }

  void _onSatisFiyatChanged() {
    if (_updating) return;
    _hesaplaKarOrani();
    _guncelleFiyatTarihi();

    // Satış fiyatı değiştiğinde indirim alanlarını temizle
    _updating = true;
    _controllers['indirimOrani']!.text = '';
    _controllers['indirimliFiyat']!.text = '';
    _updating = false;
  }

  void _onIndirimOraniChanged() {
    if (_updating) return;
    final indirimOraniStr = _controllers['indirimOrani']!.text.trim();
    if (indirimOraniStr.isEmpty) {
      // İndirim oranı silindiyse indirimli fiyatı da temizle
      _updating = true;
      _controllers['indirimliFiyat']!.text = '';
      _updating = false;
      return;
    }
    _hesaplaIndirimliFiyat();
  }

  void _onIndirimliFiyatChanged() {
    if (_updating) return;
    final indirimliFiyatStr = _controllers['indirimliFiyat']!.text.trim();
    if (indirimliFiyatStr.isEmpty) {
      // İndirimli fiyat silindiyse indirim oranını da temizle
      _updating = true;
      _controllers['indirimOrani']!.text = '';
      _updating = false;
      return;
    }
    _hesaplaIndirimOrani();
  }

  void _hesaplaIndirimliFiyat() {
    if (_updating) return;
    _updating = true;

    final satisFiyat = _toDouble(_controllers['satisFiyat']!.text) ?? 0;
    final indirimOraniStr = _controllers['indirimOrani']!.text.trim();

    if (indirimOraniStr.isEmpty) {
      _controllers['indirimliFiyat']!.text = '';
      _updating = false;
      return;
    }

    final indirimOrani = double.tryParse(indirimOraniStr) ?? 0;
    final indirimliFiyat = satisFiyat * (1 - indirimOrani / 100);
    _controllers['indirimliFiyat']!.text = indirimliFiyat.toStringAsFixed(2);

    _updating = false;
  }

  void _hesaplaIndirimOrani() {
    if (_updating) return;
    _updating = true;

    final satisFiyat = _toDouble(_controllers['satisFiyat']!.text) ?? 0;
    final indirimliFiyatStr = _controllers['indirimliFiyat']!.text.trim();

    if (indirimliFiyatStr.isEmpty) {
      _controllers['indirimOrani']!.text = '';
      _updating = false;
      return;
    }

    final indirimliFiyat = double.tryParse(indirimliFiyatStr) ?? 0;

    if (satisFiyat == 0) {
      _controllers['indirimOrani']!.text = '';
      _updating = false;
      return;
    }

    // İndirimli fiyat satış fiyatından büyük veya eşitse temizle
    if (indirimliFiyat >= satisFiyat) {
      _controllers['indirimOrani']!.text = '';
      _updating = false;
      return;
    }

    final indirimOrani = ((satisFiyat - indirimliFiyat) / satisFiyat) * 100;
    _controllers['indirimOrani']!.text = indirimOrani.toStringAsFixed(3);

    _updating = false;
  }

  void _hesaplaKdvliAlisFiyati() {
    if (_updating) return;
    _updating = true;
    final alisFiyat = _toDouble(_controllers['alisFiyat']!.text) ?? 0;
    int kdvOraniInt = _kdvIntValue(_controllers['alisKdvOrani']!.text);
    final kdvliFiyat = alisFiyat * (1 + kdvOraniInt / 100);
    _controllers['alisFiyatKdvDahil']!.text = kdvliFiyat.toStringAsFixed(2);
    _guncelleMaliyetTarihi();
    _hesaplaKarOrani();
    _updating = false;
  }

  void _hesaplaKdvHaricAlisFiyati() {
    if (_updating) return;
    _updating = true;
    final kdvli = _toDouble(_controllers['alisFiyatKdvDahil']!.text) ?? 0;
    int kdvOraniInt = _kdvIntValue(_controllers['alisKdvOrani']!.text);
    if (kdvOraniInt == 0) {
      _controllers['alisFiyat']!.text = kdvli.toStringAsFixed(2);
    } else {
      final kdvHaric = kdvli / (1 + kdvOraniInt / 100);
      _controllers['alisFiyat']!.text = kdvHaric.toStringAsFixed(2);
    }
    _guncelleMaliyetTarihi();
    _hesaplaKarOrani();
    _updating = false;
  }

  void _hesaplaKarOrani() {
    if (_updating) return;
    final alisFiyatKdvDahil = _toDouble(_controllers['alisFiyatKdvDahil']!.text) ?? 0;
    final satisFiyat = _toDouble(_controllers['satisFiyat']!.text) ?? 0;
    if (alisFiyatKdvDahil == 0) {
      _controllers['karOrani']!.text = '';
      return;
    }
    final karOrani = ((satisFiyat - alisFiyatKdvDahil) / alisFiyatKdvDahil) * 100;
    _controllers['karOrani']!.text = karOrani.toStringAsFixed(2);
  }

  int _kdvIntValue(String text) {
    final normalized = text.trim().replaceAll(',', '.');
    final val = double.tryParse(normalized);
    return val?.toInt() ?? 0;
  }

  String _formatTarih(DateTime tarih) {
    return '${tarih.year}-${tarih.month.toString().padLeft(2, '0')}-${tarih.day.toString().padLeft(2, '0')}';
  }

  void _guncelleMaliyetTarihi() {
    _controllers['maliyetGuncellemeTarihi']!.text = _formatTarih(DateTime.now());
  }

  void _guncelleFiyatTarihi() {
    _controllers['fiyatGuncellemeTarihi']!.text = _formatTarih(DateTime.now());
  }

  // ================= GRUP YÜKLEME =================
  Future<void> _anaGruplariYukle() async {
    setState(() => anaGrupYukleniyor = true);
    try {
      List<String> gruplar = await _repo.tumAnaGruplariGetir();
      setState(() {
        anaGrupListesi = gruplar;
        anaGrupYukleniyor = false;
      });
    } catch (e) {
      setState(() => anaGrupYukleniyor = false);
    }
  }

  Future<void> _alan1ListesiniYukle() async {
    setState(() => alan1Yukleniyor = true);
    try {
      List<String> list = await _repo.tumAlan1DegerleriniGetir();
      setState(() {
        alan1Listesi = list;
        alan1Yukleniyor = false;
      });
    } catch (e) {
      setState(() => alan1Yukleniyor = false);
    }
  }

  Future<void> _altGruplariYukle() async {
    setState(() => altGrupYukleniyor = true);
    try {
      List<String> gruplar = await _repo.tumAltGruplariGetir();
      setState(() {
        altGrupListesi = gruplar;
        altGrupYukleniyor = false;
      });
    } catch (e) {
      setState(() => altGrupYukleniyor = false);
    }
  }

  // ================= BARKOD / RESİM =================
  Future<void> _barkodTara() async {
    try {
      final barkod = await Navigator.push(context, MaterialPageRoute(builder: (_) => BarkodTarayici()));
      if (barkod != null) {
        _controllers['barkod']!.text = barkod;
        _controllers['kod']!.text = barkod;
      }
    } on PlatformException catch (e) {
      _showMessage('Barkod hatası: ${e.message}');
    }
  }

  Future<void> _resimSec() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        allowMultiple: false,
      );
      if (result != null && result.files.single.path != null) {
        setState(() {
          _seciliResim = File(result.files.single.path!);
          _controllers['resimYolu']!.text = result.files.single.path!;
        });
      }
    } catch (e) {
      _showMessage('Resim seçme hatası: $e');
    }
  }

  void _barkodGoster(String kodMetni) {
    if (kodMetni.trim().isEmpty) {
      _showMessage('Barkod gösterilecek metin boş');
      return;
    }
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Barkod Görünümü', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              BarcodeWidget(barkod: kodMetni, width: 250, height: 150, fontSize: 16, drawNumber: true),
              const SizedBox(height: 20),
              Text(kodMetni, style: const TextStyle(fontSize: 18)),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text("Kapat")),
            ],
          ),
        ),
      ),
    );
  }

  // ================= KAYDETME VE KONTROLLER =================
  Future<String?> _barkodCakismasiKontrol(String barkod, String barkodlarStr, {int? kendiId}) async {
    if (barkod.trim().isNotEmpty) {
      var mevcut = await _repo.barkodlaUrunGetir(barkod.trim());
      if (mevcut != null && mevcut.id != kendiId) {
        return 'Ana barkod ($barkod) başka bir üründe kayıtlı!';
      }
    }
    if (barkodlarStr.trim().isNotEmpty) {
      List<String> yardimciBarkodlar = barkodlarStr.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
      for (String yb in yardimciBarkodlar) {
        var mevcut = await _repo.barkodlaUrunGetir(yb);
        if (mevcut != null && mevcut.id != kendiId) {
          return 'Yardımcı barkod ($yb) başka bir üründe kayıtlı!';
        }
      }
    }
    return null;
  }

  Future<void> _kaydet() async {
    if (!_formKey.currentState!.validate()) return _showMessage('Zorunlu alanları doldurun!');

    String barkod = _controllers['barkod']!.text.trim();
    String barkodlar = _controllers['barkodlar']!.text.trim();

    String? cakisma = await _barkodCakismasiKontrol(barkod, barkodlar, kendiId: widget.duzenlenecekUrun?.id);
    if (cakisma != null) return _showMessage(cakisma);

    setState(() => _isLoading = true);
    try {
      int kdvInt = _kdvIntValue(_controllers['alisKdvOrani']!.text);
      final double? alisKdvOrani = kdvInt.toDouble();

      final urun = Urun(
        id: widget.duzenlenecekUrun?.id,
        kod: _controllers['kod']!.text.trim(),
        barkod: barkod,
        ad: _controllers['ad']!.text.trim(),
        satisFiyat: _toDouble(_controllers['satisFiyat']!.text) ?? 0,
        stokMiktari: _toDouble(_controllers['stokMiktari']!.text) ?? 0,
        barkodlar: _nullIfEmpty(_controllers['barkodlar']!.text),
        birim: seciliBirim,
        alisFiyat: _toDouble(_controllers['alisFiyat']!.text),
        alisFiyatKdvDahil: _toDouble(_controllers['alisFiyatKdvDahil']!.text),
        alisKdvOrani: alisKdvOrani,
        kdvOrani: alisKdvOrani,
        anagrup: _anagrupController.text.trim().isEmpty ? null : _anagrupController.text.trim(),
        altGrup: seciliAltGrup,
        alan1: _nullIfEmpty(_alan1Controller.text),
        alan2: _nullIfEmpty(_controllers['alan2']!.text),
        paraBirimi: seciliParaBirimi ?? 'TL',
        marka: _nullIfEmpty(_controllers['marka']!.text),
        indirimOrani: _toDouble(_controllers['indirimOrani']!.text),
        indirimliFiyat: _toDouble(_controllers['indirimliFiyat']!.text),
        boy: _nullIfEmpty(_controllers['boy']!.text),
        resimYolu: _nullIfEmpty(_controllers['resimYolu']!.text),
        mens: _nullIfEmpty(_controllers['mens']!.text),
        karOrani: _toDouble(_controllers['karOrani']!.text),
        fiyatGuncellemeTarihi: _nullIfEmpty(_controllers['fiyatGuncellemeTarihi']!.text),
        maliyetGuncellemeTarihi: _nullIfEmpty(_controllers['maliyetGuncellemeTarihi']!.text),
        promosyonAktif: promosyonAktif,
      );
      if (widget.duzenlenecekUrun == null) {
        await _repo.urunEkle(urun);
        _showMessage('Ürün eklendi');
      } else {
        await _repo.urunGuncelle(urun);
        _showMessage('Ürün güncellendi');
      }
      _anaGruplariYukle();
      _altGruplariYukle();
      _alan1ListesiniYukle();
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      _showMessage('Hata: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _urunSil() async {
    final onay = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Ürünü Sil'),
        content: const Text('Bu ürünü silmek istediğinize emin misiniz?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (onay == true) {
      setState(() => _isLoading = true);
      try {
        await _repo.urunSil(widget.duzenlenecekUrun!.id!);
        _showMessage('Ürün silindi');
        if (mounted) Navigator.pop(context, true);
      } catch (e) {
        _showMessage('Silme hatası: $e');
      } finally {
        if (mounted) setState(() => _isLoading = false);
      }
    }
  }

  String? _nullIfEmpty(String text) => text.trim().isEmpty ? null : text.trim();
  double? _toDouble(String text) => text.trim().isEmpty ? null : double.tryParse(text.trim().replaceAll(',', '.'));

  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ================= UI BİLEŞENLERİ =================
  Widget _buildTextField(
    String key,
    String label, {
    bool required = false,
    void Function(String)? onChanged,
    bool highlightEmpty = false,
  }) {
    bool isNumeric = (key.contains('Fiyat') || key == 'stokMiktari' || key == 'indirimOrani' || key == 'karOrani');
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: ValueListenableBuilder<TextEditingValue>(
        valueListenable: _controllers[key]!,
        builder: (context, value, child) {
          bool isEmpty = value.text.trim().isEmpty;
          Color borderColor = (highlightEmpty && isEmpty) ? Colors.red : Colors.grey;
          return TextFormField(
            controller: _controllers[key],
            decoration: InputDecoration(
              labelText: required ? '$label *' : label,
              border: OutlineInputBorder(borderSide: BorderSide(color: borderColor)),
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: borderColor)),
              focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: (highlightEmpty && isEmpty) ? Colors.red : Colors.blue)),
              filled: true,
              fillColor: Colors.grey.shade100,
            ),
            validator: required ? (val) => val == null || val.trim().isEmpty ? '$label gerekli' : null : null,
            keyboardType: isNumeric ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
            inputFormatters: isNumeric ? [FilteringTextInputFormatter.allow(RegExp(r'^\d*[.,]?\d*'))] : [],
            onChanged: onChanged,
          );
        },
      ),
    );
  }

  Widget _buildResimAlani() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _controllers['resimYolu'],
                  decoration: InputDecoration(
                    labelText: 'Resim Yolu',
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.grey.shade100,
                    suffixIcon: IconButton(icon: const Icon(Icons.folder_open), onPressed: _resimSec),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (_seciliResim != null)
            Container(
              height: 150,
              decoration: BoxDecoration(border: Border.all(color: Colors.grey), borderRadius: BorderRadius.circular(8)),
              child: Image.file(_seciliResim!, fit: BoxFit.cover, width: double.infinity),
            ),
        ],
      ),
    );
  }

  Widget _buildDropdown(String label, List<String> items, String? selected, void Function(String?) onChanged) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DropdownButtonFormField<String>(
        value: selected,
        items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Container(
      width: double.infinity,
      color: Colors.lightBlue.shade50,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      margin: const EdgeInsets.symmetric(vertical: 12),
      child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.duzenlenecekUrun == null ? 'Yeni Ürün' : 'Ürünü Düzenle'),
        actions: [
          if (widget.duzenlenecekUrun != null)
            IconButton(icon: const Icon(Icons.delete), onPressed: _isLoading ? null : _urunSil),
          IconButton(icon: const Icon(Icons.save), onPressed: _isLoading ? null : _kaydet),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSectionTitle('TEMEL BİLGİLER'),
                    Row(
                      children: [
                        Expanded(child: _buildTextField('kod', 'Kod')),
                        IconButton(icon: const Icon(Icons.qr_code, color: Colors.blue), onPressed: () => _barkodGoster(_controllers['kod']!.text.trim())),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(child: _buildTextField('barkod', 'Barkod', required: true)),
                        const SizedBox(width: 8),
                        IconButton(icon: const Icon(Icons.qr_code_scanner, color: Colors.blue), onPressed: _barkodTara),
                      ],
                    ),
                    _buildTextField('ad', 'Ürün Adı', required: true),
                    _buildTextField('barkodlar', 'Barkodlar (virgülle ayırın)'),
                    _buildDropdown('Birim', birimListesi, seciliBirim, (val) => setState(() => seciliBirim = val)),

                    _buildSectionTitle('FİYAT BİLGİLERİ'),
                    Row(
                      children: [
                        Expanded(child: _buildTextField('alisFiyat', 'Alış Fiyat (KDV Hariç)')),
                        const SizedBox(width: 8),
                        Expanded(child: _buildTextField('alisKdvOrani', 'KDV Oranı (%)', required: true)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(child: _buildTextField('alisFiyatKdvDahil', 'Alış Fiyat (KDV Dahil)')),
                        const SizedBox(width: 8),
                        Expanded(child: _buildTextField('karOrani', 'Kar Oranı (%)')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    _buildTextField('satisFiyat', 'Satış Fiyat', required: true, highlightEmpty: true),

                    _buildSectionTitle('İNDİRİM BİLGİLERİ'),
                    Row(
                      children: [
                        Expanded(child: _buildTextField('indirimOrani', 'İndirim Oranı (%)')),
                        const SizedBox(width: 8),
                        Expanded(child: _buildTextField('indirimliFiyat', 'İndirimli Fiyat')),
                      ],
                    ),

                    _buildSectionTitle('STOK BİLGİLERİ'),
                    _buildTextField('stokMiktari', 'Stok Miktarı', required: true),

                    _buildSectionTitle('KATEGORİLER'),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Autocomplete<String>(
                        optionsBuilder: (TextEditingValue textEditingValue) {
                          if (textEditingValue.text.isEmpty) return const Iterable<String>.empty();
                          return anaGrupListesi.where((option) => option.toLowerCase().contains(textEditingValue.text.toLowerCase()));
                        },
                        fieldViewBuilder: (context, textEditingController, focusNode, onFieldSubmitted) {
                          if (_anagrupController.text != textEditingController.text) {
                            textEditingController.text = _anagrupController.text;
                          }
                          return TextFormField(
                            controller: textEditingController,
                            focusNode: focusNode,
                            decoration: const InputDecoration(
                              labelText: 'Ana Grup (yazın veya seçin)',
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (value) => _anagrupController.text = value,
                          );
                        },
                        onSelected: (selection) => _anagrupController.text = selection,
                      ),
                    ),
                    altGrupYukleniyor
                        ? const Padding(padding: EdgeInsets.all(8), child: SizedBox(height: 20, width: 20, child: CircularProgressIndicator()))
                        : _buildDropdown('Alt Grup', altGrupListesi, seciliAltGrup, (val) => setState(() => seciliAltGrup = val)),

                    _buildSectionTitle('DİĞER BİLGİLER'),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Autocomplete<String>(
                        optionsBuilder: (TextEditingValue textEditingValue) {
                          if (textEditingValue.text.isEmpty) return const Iterable<String>.empty();
                          return alan1Listesi.where((option) => option.toLowerCase().contains(textEditingValue.text.toLowerCase()));
                        },
                        fieldViewBuilder: (context, textEditingController, focusNode, onFieldSubmitted) {
                          if (_alan1Controller.text != textEditingController.text) {
                            textEditingController.text = _alan1Controller.text;
                          }
                          return TextFormField(
                            controller: textEditingController,
                            focusNode: focusNode,
                            decoration: const InputDecoration(
                              labelText: 'Alan 1 (yazın veya seçin)',
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (value) => _alan1Controller.text = value,
                          );
                        },
                        onSelected: (selection) => _alan1Controller.text = selection,
                      ),
                    ),
                    _buildTextField('alan2', 'Alan 2'),
                    _buildDropdown('Para Birimi', paraBirimiListesi, seciliParaBirimi, (val) => setState(() => seciliParaBirimi = val)),
                    _buildTextField('marka', 'Marka'),
                    _buildTextField('boy', 'Boy'),
                    _buildResimAlani(),
                    _buildTextField('mens', 'Menşei'),

                    _buildSectionTitle('TARİHLER'),
                    _buildTextField('fiyatGuncellemeTarihi', 'Fiyat Güncelleme Tarihi'),
                    _buildTextField('maliyetGuncellemeTarihi', 'Maliyet Güncelleme Tarihi'),

                    SwitchListTile(
                      title: const Text('Promosyon Aktif'),
                      value: promosyonAktif,
                      onChanged: (val) => setState(() => promosyonAktif = val),
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.save),
                        label: const Text('Kaydet'),
                        onPressed: _isLoading ? null : _kaydet,
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  @override
  void dispose() {
    _controllers['alisFiyat']!.removeListener(_onAlisFiyatChanged);
    _controllers['alisFiyatKdvDahil']!.removeListener(_onAlisFiyatKdvDahilChanged);
    _controllers['alisKdvOrani']!.removeListener(_onAlisKdvOraniChanged);
    _controllers['satisFiyat']!.removeListener(_onSatisFiyatChanged);
    _controllers['indirimOrani']!.removeListener(_onIndirimOraniChanged);
    _controllers['indirimliFiyat']!.removeListener(_onIndirimliFiyatChanged);
    _controllers.forEach((_, c) => c.dispose());
    _anagrupController.dispose();
    _alan1Controller.dispose();
    super.dispose();
  }
}