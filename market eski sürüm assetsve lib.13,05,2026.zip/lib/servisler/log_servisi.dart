import 'dart:developer' as developer;
import 'package:flutter/foundation.dart';
import 'package:market_uygulamasi/core/logger.dart';


enum LogLevel { debug, info, warning, error }

class Log {
  static void d(String message, {String? tag}) {
    _log(LogLevel.debug, message, tag: tag);
  }

  static void i(String message, {String? tag}) {
    _log(LogLevel.info, message, tag: tag);
  }

  static void w(String message, {String? tag}) {
    _log(LogLevel.warning, message, tag: tag);
  }

  static void e(String message, {String? tag, dynamic error, StackTrace? stackTrace}) {
    _log(LogLevel.error, message, tag: tag, error: error, stackTrace: stackTrace);
  }

  static void _log(LogLevel level, String message, {
    String? tag,
    dynamic error,
    StackTrace? stackTrace
  }) {
    if (kReleaseMode) return; // Production'da debug logları gösterme

    final fullMessage = tag != null ? '[$tag] $message' : message;
    
    switch (level) {
      case LogLevel.debug:
        developer.log(fullMessage, level: 0, name: 'DEBUG');
        break;
      case LogLevel.info:
        developer.log(fullMessage, level: 1, name: 'INFO');
        break;
      case LogLevel.warning:
        developer.log(fullMessage, level: 2, name: 'WARNING');
        break;
      case LogLevel.error:
        developer.log(fullMessage, level: 3, name: 'ERROR', 
                     error: error, stackTrace: stackTrace);
        break;
    }

    // Konsol çıktısı (debug modda)
    if (kDebugMode) {
      final prefix = _getLevelPrefix(level);
      appLogger.i('$prefix $fullMessage');
      if (error != null) appLogger.i('Hata: $error');
      if (stackTrace != null) appLogger.i('Stack Trace: $stackTrace');
    }
  }

  static String _getLevelPrefix(LogLevel level) {
    switch (level) {
      case LogLevel.debug: return '🐛 DEBUG';
      case LogLevel.info: return 'ℹ️ INFO';
      case LogLevel.warning: return '⚠️ WARNING';
      case LogLevel.error: return '❌ ERROR';
    }
  }
}