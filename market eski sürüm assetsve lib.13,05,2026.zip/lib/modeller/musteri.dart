class Musteri {
  final int? id;
  final String cariKodu;
  final String unvan;
  final String cariTipi;

  final String? telefon;
  final String? adres;
  final String? email;

  final String? vergiDairesi;
  final String? vergiNo;

  final double bakiye;
  final String? anaGrup;

  const Musteri({
    this.id,
    required this.cariKodu,
    required this.unvan,
    this.cariTipi = 'Müşteri',
    this.telefon,
    this.adres,
    this.email,
    this.vergiDairesi,
    this.vergiNo,
    this.bakiye = 0.0,
    this.anaGrup,
  });

  // ─────────────────────────────────────────────
  // COPYWITH (EN KRİTİK PARÇA)
  // ─────────────────────────────────────────────
Musteri copyWith({
  int? id,
  String? cariKodu,
  String? unvan,
  String? cariTipi,
  String? telefon,
  String? adres,
  String? email,
  String? vergiDairesi,
  String? vergiNo,
  double? bakiye,
  String? anaGrup,
}) {
  return Musteri(
    id: id ?? this.id,
    cariKodu: cariKodu ?? this.cariKodu,
    unvan: unvan ?? this.unvan,
    cariTipi: cariTipi ?? this.cariTipi,
    telefon: telefon ?? this.telefon,
    adres: adres ?? this.adres,
    email: email ?? this.email,
    vergiDairesi: vergiDairesi ?? this.vergiDairesi,
    vergiNo: vergiNo ?? this.vergiNo,
    bakiye: bakiye ?? this.bakiye,
    anaGrup: anaGrup ?? this.anaGrup,
  );
}
  // ─────────────────────────────────────────────
  // MAP (SQLite / API UYUMLU)
  // ─────────────────────────────────────────────
  factory Musteri.fromMap(Map<String, dynamic> map) {
    return Musteri(
      id: _toInt(map['id']),
      cariKodu: (map['cari_kodu'] ?? '').toString(),
      unvan: (map['unvan'] ?? '').toString(),
      cariTipi: (map['cari_tipi'] ?? 'Müşteri').toString(),
      telefon: map['telefon']?.toString(),
      adres: map['adres']?.toString(),
      email: map['email']?.toString(),
      vergiDairesi: map['vergi_dairesi']?.toString(),
      vergiNo: map['vergi_no']?.toString(),
      bakiye: _toDouble(map['bakiye']),
      anaGrup: map['ana_grup']?.toString(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'cari_kodu': cariKodu,
      'unvan': unvan,
      'cari_tipi': cariTipi,
      'telefon': telefon,
      'adres': adres,
      'email': email,
      'vergi_dairesi': vergiDairesi,
      'vergi_no': vergiNo,
      'bakiye': bakiye,
      'ana_grup': anaGrup,
    };
  }

  // ─────────────────────────────────────────────
  // SAFE PARSE (HATA ENGELLEYİCİ)
  // ─────────────────────────────────────────────
  static int? _toInt(dynamic value) {
    if (value == null) return null;
    return int.tryParse(value.toString());
  }

  static double _toDouble(dynamic value) {
    if (value == null) return 0.0;

    if (value is double) return value;
    if (value is int) return value.toDouble();

    String text = value.toString().trim();

    // TR format düzeltme
    text = text.replaceAll('.', '').replaceAll(',', '.');

    return double.tryParse(text) ?? 0.0;
  }

  // ─────────────────────────────────────────────
  // DEBUG
  // ─────────────────────────────────────────────
  @override
  String toString() {
    return 'Musteri(id: $id, cariKodu: $cariKodu, unvan: $unvan, bakiye: $bakiye)';
  }

  // ─────────────────────────────────────────────
  // EQUALITY (SET / MAP için)
  // ─────────────────────────────────────────────
  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is Musteri &&
            runtimeType == other.runtimeType &&
            id == other.id &&
            cariKodu == other.cariKodu;
  }

  @override
  int get hashCode => id.hashCode ^ cariKodu.hashCode;
}