import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/stok_hareket.dart';
import 'package:market_uygulamasi/repozitory/stok_repo.dart';
import 'package:market_uygulamasi/yardimci/yardimci_fonksiyonlar.dart'; // Eksik import eklendi

class StokHareketEkrani extends StatefulWidget {
  @override
  _StokHareketEkraniState createState() => _StokHareketEkraniState();
}

class _StokHareketEkraniState extends State<StokHareketEkrani> {
  final StokRepository _stokRepo = StokRepository();
  List<StokHareket> _hareketler = [];

  @override
  void initState() {
    super.initState();
    _hareketleriYukle();
  }

  Future<void> _hareketleriYukle() async {
    final hareketler = await _stokRepo.tumHareketleriGetir();
    setState(() => _hareketler = hareketler);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Stok Hareketleri')),
      body: ListView.builder(
        itemCount: _hareketler.length,
        itemBuilder: (context, index) {
          final hareket = _hareketler[index];
          return ListTile(
            title: Text(hareket.urunAdi),
            subtitle: Text('${hareket.hareketTipi} - Miktar: ${hareket.miktar}'),
            trailing: Text(YardimciFonksiyonlar.tarihFormatla(hareket.tarih)), // Düzeltildi
          );
        },
      ),
    );
  }
}