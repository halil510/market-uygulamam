import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/widgetlar/stok_uyari.dart';

class UrunKart extends StatelessWidget {
  final Urun urun;
  final VoidCallback onTap;

  const UrunKart({Key? key, required this.urun, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final String urunAdi = urun.ad.trim();
    final String barkod = urun.barkod;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      urunAdi,
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  StokUyari(stok: urun.stokMiktari),
                ],
              ),
              SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Barkod: $barkod', style: TextStyle(color: Colors.grey)),
                  Text('Fiyat: ${urun.satisFiyat.toStringAsFixed(2)} ₺'),
                ],
              ),
              SizedBox(height: 4),
              Text('Stok: ${urun.stokMiktari.toStringAsFixed(2)}'),
            ],
          ),
        ),
      ),
    );
  }
}