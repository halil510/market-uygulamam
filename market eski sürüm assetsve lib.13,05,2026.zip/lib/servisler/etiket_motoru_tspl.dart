// lib/servisler/etiket_motoru_tspl.dart
class TsplEtiketMotoru {
  /// mm cinsinden genişlik & yükseklik, DPI varsayılan 203
  static String olustur({
    required double genislikMm,
    required double yukseklikMm,
    required String barkod,
    String? ad,
    String? fiyat,
    int dpi = 203,
  }) {
    // mm -> dots
    int w = (genislikMm / 25.4 * dpi).round();
    int h = (yukseklikMm / 25.4 * dpi).round();

    final sb = StringBuffer();
    sb.writeln('SIZE ${genislikMm.toStringAsFixed(1)} mm, ${yukseklikMm.toStringAsFixed(1)} mm');
    sb.writeln('GAP 2 mm,0');
    sb.writeln('DENSITY 10');
    sb.writeln('CLS');

    int y = 20;
    if (ad != null && ad.trim().isNotEmpty) {
      sb.writeln('TEXT 20,$y,"0",0,1,1,"${_q(ad)}"');
      y += 40;
    }

    // Code128 barkod
    sb.writeln('BARCODE 20,$y,"128",60,1,0,2,4,"${_q(barkod)}"');
    y += 80;

    if (fiyat != null && fiyat.trim().isNotEmpty) {
      sb.writeln('TEXT 20,$y,"0",0,1,1,"${_q(fiyat)}"');
    }

    sb.writeln('PRINT 1,1');
    return sb.toString();
  }

  static String _q(String v) => v.replaceAll('"', "'");
}