import 'package:flutter/material.dart';

class Sabitler {
  static const String appAdi = "MarketPlus";
  
  // Renkler
  static const Color anaRenk = Color(0xFF2E7D32);
  static const Color ikincilRenk = Color(0xFF43A047);
  static const Color uyariRenk = Color(0xFFFF5722);
  
  // Boyutlar
  static const double kenarBosluk = 16.0;
  static const double kartYukseklik = 120.0;
  
  // Metinler
  static const String stokUyari = "Düşük Stok!";
}
