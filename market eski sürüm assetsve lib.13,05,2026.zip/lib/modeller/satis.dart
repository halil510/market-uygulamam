import 'package:equatable/equatable.dart';
import 'satis_kalem.dart';

class Satis {
  final int? id;
  final DateTime tarih;
  final int? cariId;
  final double toplamTutar;
  final double odenenTutar;
  final String odemeYontemi;
  final List<SatisKalem> kalemler;
  final String fisTipi;

  Satis({
    this.id,
    required this.tarih,
    this.cariId,
    required this.toplamTutar,
    required this.odenenTutar,
    required this.odemeYontemi,
    required this.kalemler,
    required this.fisTipi,
  });

  factory Satis.fromMap(Map<String, dynamic> map) {
    // Kalemleri güvenli bir şekilde işle
    List<SatisKalem> kalemler = [];
    if (map['kalemler'] != null) {
      if (map['kalemler'] is List<SatisKalem>) {
        // Zaten doğru tip
        kalemler = map['kalemler'] as List<SatisKalem>;
      } else if (map['kalemler'] is List) {
        // List<dynamic> gelmiş, her bir elemanı dönüştür
        kalemler = (map['kalemler'] as List)
            .map((e) => e is SatisKalem 
                ? e 
                : SatisKalem.fromMap(e as Map<String, dynamic>))
            .toList();
      }
    }

    return Satis(
      id: _parseIntNullable(map['id']),
      tarih: DateTime.tryParse(map['tarih'] ?? '') ?? DateTime.now(),
      cariId: _parseIntNullable(map['cariId']),
      toplamTutar: _parseDouble(map['toplamTutar']),
      odenenTutar: _parseDouble(map['odenenTutar']),
      odemeYontemi: map['odemeYontemi'] ?? '',
      kalemler: kalemler,
      fisTipi: map['fisTipi'] ?? 'Satış',
    );
  }

  Map<String, dynamic> toMap() {
    final map = {
      'tarih': tarih.toIso8601String(),
      'cariId': cariId,
      'toplamTutar': toplamTutar,
      'odenenTutar': odenenTutar,
      'odemeYontemi': odemeYontemi,
      'fisTipi': fisTipi,
    };
    if (id != null) {
      map['id'] = id;
    }
    return map;
  }

  Satis copyWith({
    int? id,
    DateTime? tarih,
    int? cariId,
    double? toplamTutar,
    double? odenenTutar,
    String? odemeYontemi,
    List<SatisKalem>? kalemler,
    String? fisTipi,
  }) {
    return Satis(
      id: id ?? this.id,
      tarih: tarih ?? this.tarih,
      cariId: cariId ?? this.cariId,
      toplamTutar: toplamTutar ?? this.toplamTutar,
      odenenTutar: odenenTutar ?? this.odenenTutar,
      odemeYontemi: odemeYontemi ?? this.odemeYontemi,
      kalemler: kalemler ?? this.kalemler,
      fisTipi: fisTipi ?? this.fisTipi,
    );
  }
}

int? _parseIntNullable(dynamic value) {
  if (value == null) return null;
  return int.tryParse(value.toString());
}

double _parseDouble(dynamic value) {
  if (value == null) return 0.0;
  return double.tryParse(value.toString()) ?? 0.0;
}