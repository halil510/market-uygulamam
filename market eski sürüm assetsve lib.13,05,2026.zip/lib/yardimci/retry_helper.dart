import 'dart:async';

class RetryHelper {
  static Future<T> retry<T>(
    Future<T> Function() operation, {
    int maxAttempts = 3,
    Duration delay = const Duration(milliseconds: 500),
    bool Function(Exception)? onRetry,
  }) async {
    int attempt = 0;
    while (true) {
      attempt++;
      try {
        return await operation();
      } on Exception catch (e) {
        if (attempt >= maxAttempts) rethrow;
        onRetry?.call(e);
        await Future.delayed(delay * attempt); // Exponential backoff
      }
    }
  }
}

// Kullanım
final urunler = await RetryHelper.retry(
  () => _urunRepo.tumUrunleriGetir(),
  maxAttempts: 3,
  onRetry: (e) => print('Retry after error: $e'),
);