import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:vibration/vibration.dart';
import 'package:market_uygulamasi/core/logger.dart';

class BarkodTarayici extends StatefulWidget {
  final Function(String)? onBarkodOkundu; // Hızlı Satışta ürün ekleme için

  const BarkodTarayici({Key? key, this.onBarkodOkundu}) : super(key: key);

  @override
  State<BarkodTarayici> createState() => _BarkodTarayiciState();
}

class _BarkodTarayiciState extends State<BarkodTarayici> {
  late MobileScannerController cameraController;
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isProcessing = false; // hızlı arka arkaya okuma kilidi
  String? _lastScannedCode;
  bool _flashEnabled = false;
  CameraFacing _cameraFacing = CameraFacing.back;

  @override
  void initState() {
    super.initState();
    cameraController = MobileScannerController(
      torchEnabled: _flashEnabled,
      facing: _cameraFacing,
    );
    _audioPlayer.setPlayerMode(PlayerMode.lowLatency);
  }

  Future<void> _processBarcode(String barkod) async {
    if (_isProcessing) return; // kilit aktifse çık
    _isProcessing = true;
    _lastScannedCode = barkod;

    try {
      // Bip sesi ve titreşim
      await _audioPlayer.play(AssetSource('sounds/bip.mp3'), volume: 1);
      if (await Vibration.hasVibrator() ?? false) {
        Vibration.vibrate(duration: 80);
      }

      // Hızlı Satış ekranı callback ile ekleme
      if (widget.onBarkodOkundu != null) {
        widget.onBarkodOkundu!(barkod);
        // Burada ekran kapanmaz, kamera açık kalır
      } else {
        // Diğer ekranlar: barkod okutulunca geri dön
        if (!mounted) return;
        Navigator.pop(context, barkod);
      }
    } catch (e) {
      appLogger.i("Barkod işleme hatası: $e");
      if (!mounted && widget.onBarkodOkundu == null) return;
      Navigator.pop(context, barkod);
    } finally {
      // Kilidi 0.7 saniye sonra kaldır
      await Future.delayed(const Duration(milliseconds: 700));
      _isProcessing = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Barkod Tarayıcı"),
        actions: [
          IconButton(
            icon: Icon(_flashEnabled ? Icons.flash_on : Icons.flash_off),
            onPressed: () {
              setState(() => _flashEnabled = !_flashEnabled);
              cameraController.toggleTorch();
            },
          ),
          IconButton(
            icon: const Icon(Icons.cameraswitch),
            onPressed: () {
              setState(() {
                _cameraFacing = _cameraFacing == CameraFacing.back
                    ? CameraFacing.front
                    : CameraFacing.back;
              });
              cameraController.switchCamera();
            },
          ),
        ],
      ),
      body: MobileScanner(
        controller: cameraController,
        onDetect: (capture) {
          for (final barcode in capture.barcodes) {
            final code = barcode.rawValue;
            if (code != null) {
              _processBarcode(code);
              break; // sadece ilk barkod
            }
          }
        },
      ),
    );
  }

  @override
  void dispose() {
    cameraController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }
}