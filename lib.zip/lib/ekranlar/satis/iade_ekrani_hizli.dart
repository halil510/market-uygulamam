// ignore_for_file: invalid_use_of_protected_member
//
// NEDEN: Bu dosya `part of 'iade_ekrani.dart'` ve içeriği
// `extension ... on _IadeEkraniState` olarak yazılmış. Bu desen 3000
// satırlık iade ekranını okunabilir parçalara bölmek için bilinçli
// seçilmiş ve ÇALIŞIYOR — `setState` gerçekten kendi State sınıfının
// üzerinde çağrılıyor.
//
// Ama Dart analizcisi `setState`'i @protected gördüğü için, extension
// içinden çağrıyı "korumalı üyeye dışarıdan erişim" sayıyor. Derlemeyi
// engellemez; sadece analiz uyarısıdır.
//
// (analysis_options.yaml'da bu kural bilinçli olarak `error` seviyesine
// çıkarıldı — başka yerlerde gerçek hataları yakalasın diye. Burada
// dosya bazında muaf tutuluyor.)
// lib/ekranlar/satis/iade_ekrani_hizli.dart
//
// "Hızlı" (Hızlı Barkod İade) sekmesinin mantığı buraya taşındı — aynı
// part/part of yöntemiyle. Davranış/mantık AYNEN korunuyor.
part of 'iade_ekrani.dart';

extension _HizliTabExt on _IadeEkraniState {
  Future<void> _hizliBarkod() async {
    final barkod = await _barkodSrv.barkodTara(context);
    if (barkod == null || barkod.isEmpty) return;
    // 🔴 DÜZELTME (Madde 34 — Barkod/POS denetimi, 2026-09-20): terazi
    // barkodu (13 hane, gömülü ürün kodu+ağırlık) ÖNCEDEN burada da
    // literal aranıyordu, hiç eşleşmiyordu — bkz. _barkodOku()'daki AYNI
    // düzeltme. Bu akış adet-bazlı olduğundan (_HizliItem.adet: int),
    // gömülü ağırlık ÖN-DOLDURULMUYOR — sadece doğru ürünü bulmak için
    // kullanılıyor.
    final aranacakKod = BarkodServisi.tartimBarkodCoz(barkod)?.urunKodu ?? barkod;
    final urun = await _urunDepo.barkodlaGetir(aranacakKod);
    if (!mounted) return;
    if (urun != null) {
      setState(() {
        // Aynı barkod tekrar gelirse üstüne ilave et
        if (_hizliMap.containsKey(urun.id)) {
          _hizliMap[urun.id]!.adet++;
          _msg('${urun.urunAdi} — toplam adet: ${_hizliMap[urun.id]!.adet}',
              err: false);
        } else {
          _hizliMap[urun.id!] = _HizliItem(urun: urun);
          _msg('${urun.urunAdi} eklendi', err: false);
        }
      });
    } else {
      _msg('Ürün bulunamadı', err: true);
    }
  }

  Future<void> _hizliKaydet() async {
    if (_hizliMap.isEmpty) {
      _msg('Liste boş', err: true);
      return;
    }
    if (!mounted) return;

    // 🔴🔴 FAZ 1 madde 1 (kullanıcı onayıyla): bu akışın belirli bir
    // orijinal satışa bağlantısı yok (barkod ile serbest iade), bu
    // yüzden "orijinal ödeme yöntemi" bilinmiyor — kullanıcı iade
    // ödeme yöntemini burada seçiyor. Kayıtlı müşteri seçiliyse varsayılan
    // 'Cari' (borcundan düşülür — 2026-09-28), değilse Nakit.
    String secilenYontem = _secilenCari?.id != null ? 'Cari' : 'Nakit';
    final kalemler = _hizliMap.values
        .map((i) => IadeKalemGirdi(urun: i.urun, adet: i.adet))
        .toList();
    // B4 kararı: önizleme, kayıtla AYNI kuralla (satışta ödenen net fiyat)
    // hesaplanır — bugünkü satış fiyatı DEĞİL. Dayanak satış yoksa iade yapılmaz.
    final Map<int, double> fiyatlar;
    try {
      fiyatlar = await IadeIslemServisi()
          .hizliIadeFiyatlari(kalemler, cariId: _secilenCari?.id);
    } on IadeSatisFiyatiBulunamadiHatasi catch (e) {
      _msg(e.toString(), err: true);
      return;
    } catch (e) {
      _msg('İade fiyatları okunamadı: ${kullaniciyaHataMetni(e)}', err: true);
      return;
    }
    if (!mounted) return;
    final toplamOnizleme = _hizliMap.values
        .fold<double>(0.0, (s, i) => s + i.adet * (fiyatlar[i.urun.id] ?? 0));
    final onay = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
          builder: (ctx, setS) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                title: const Text('Toplu İade Onayla'),
                content: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          '${_hizliMap.length} kalem, toplam ${ParaUtils.formatla(toplamOnizleme)} iade edilecek.'),
                      const SizedBox(height: 4),
                      Text(
                          'Tutar, ürünlerin ${_secilenCari != null ? 'bu müşteriye yapılan ' : ''}'
                          'son satışında ödenen fiyattan hesaplandı.',
                          style: TextStyle(fontSize: 12, color: _R.textL(ctx))),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        initialValue: secilenYontem,
                        decoration: const InputDecoration(
                            labelText: 'İade Ödeme Yöntemi',
                            border: OutlineInputBorder(),
                            isDense: true),
                        items: [
                          const DropdownMenuItem(
                              value: 'Nakit', child: Text('Nakit (kasadan)')),
                          const DropdownMenuItem(
                              value: 'Kart/Banka',
                              child: Text('Kart/Banka (POS\'tan)')),
                          // Sadece kayıtlı bir cari seçiliyse gösterilir —
                          // kayıtsız/perakende müşteride bakiyesi olmadığı
                          // için bu seçenek anlamsızdır.
                          if (_secilenCari?.id != null)
                            const DropdownMenuItem(
                                value: 'Cari',
                                child: Text('Veresiye / Cari (borca yaz)')),
                        ],
                        onChanged: (v) =>
                            setS(() => secilenYontem = v ?? secilenYontem),
                      ),
                      if (secilenYontem == 'Cari') ...[
                        const SizedBox(height: 8),
                        Text(
                          'Kasadan nakit çıkışı OLUŞTURULMAZ — tutar ${_secilenCari!.unvan} '
                          'cari hesabının bakiyesinden gerçekten düşülecek/eklenecek.',
                          style: const TextStyle(
                              fontSize: 12, color: TsRenk.bilgi),
                        ),
                      ] else if (secilenYontem != 'Nakit') ...[
                        const SizedBox(height: 8),
                        const Text(
                          'Bu seçenekte kasadan nakit çıkışı OLUŞTURULMAZ — iade '
                          'tutarını POS cihazından ayrıca müşteriye iade etmeniz gerekir.',
                          style: TextStyle(
                              fontSize: 12, color: TsRenk.uyari),
                        ),
                      ],
                    ]),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('İptal')),
                  FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('İade Et')),
                ],
              )),
    );
    if (onay != true || !mounted) return;

    setState(() => _yukleniyor = true);
    try {
      // Tüm transaction + bulut senkron mantığı artık
      // IadeIslemServisi.topluIadeKaydet'te — bkz. o metodun doc yorumu,
      // davranış birebir korundu (iade + kalemler + stok + kasa + cari
      // TEK transaction içinde; ya hep birden yazılır ya hiç).
      final (_, fisNo, iadeFiyatlari) = await IadeIslemServisi().topluIadeKaydet(
        kalemler: kalemler,
        odemeYontemi: secilenYontem,
        kullaniciId: AuthServisi().aktifId,
        kullaniciAdi: AuthServisi().aktifAd,
        cari: _secilenCari,
      );

      for (final item in _hizliMap.values) {
        final fiyat = iadeFiyatlari[item.urun.id] ?? 0;
        _iadeListesi.add({
          'tarih': DateTime.now(),
          'urun_adi': item.urun.urunAdi,
          'barkod': item.urun.barkod ?? '',
          'miktar': item.adet.toDouble(),
          'birim_fiyat': fiyat,
          'toplam_tutar': item.adet * fiyat,
          'musteri_adi': _secilenCari?.unvan ?? 'Perakende',
          'aciklama': 'Toplu iade - $fisNo',
        });
      }

      final n = _hizliMap.length;
      if (!mounted) return;
      _hizliMap.clear();
      if (mounted) setState(() {});
      await _verileriYukle();
      // Cari/Kasa bakiyeleri değişti — başka ekranlarda (Cari Detay/
      // Liste, Kasa Raporu) eski veri kalmasın.
      if (_secilenCari != null) {
        ref.invalidate(cariDetayProvider(_secilenCari!.id!));
        ref.read(carilerProvider.notifier).yukle();
      }
      ref.invalidate(kasaRaporProvider);
      _msg(switch (secilenYontem) {
        'Nakit' => '$n ürün iade edildi (kasadan nakit ödendi)',
        'Cari' => '$n ürün iade edildi (${_secilenCari!.unvan} bakiyesine işlendi)',
        _ => '$n ürün iade edildi — tutarı POS cihazından ayrıca müşteriye iade edin',
      });
    } on IadeSatisFiyatiBulunamadiHatasi catch (e) {
      _msg(e.toString(), err: true); // onaydan sonra başka cihazda satış silinmiş olabilir
    } catch (e) {
      _msg('İade kaydedilemedi: ${kullaniciyaHataMetni(e)}', err: true);
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  Widget _hizliTab() => Column(children: [
        Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(
                  child: FilledButton.icon(
                icon: const Icon(Icons.qr_code_scanner),
                label: const Text('Barkod Okut'),
                style: FilledButton.styleFrom(
                    backgroundColor: _R.primary, foregroundColor: Colors.white),
                onPressed: _hizliBarkod,
              )),
              const SizedBox(width: 8),
              Expanded(
                  child: OutlinedButton.icon(
                icon: const Icon(Icons.search),
                label: const Text('Ürün Ara'),
                onPressed: () {
                  _tab.animateTo(0);
                  _aramaFocus.requestFocus();
                },
              )),
            ])),
        if (_hizliMap.isEmpty)
          Expanded(
              child: Center(
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                        color: _R.blue.withAlpha(20),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.add_shopping_cart,
                        size: 52, color: _R.blue)),
                const SizedBox(height: 16),
                Text('Hızlı iade listesi boş',
                    style: TextStyle(fontSize: 15, color: _R.textL(context))),
                const SizedBox(height: 6),
                Text('Barkod okutarak veya arama yaparak ürün ekleyin',
                    style: TextStyle(fontSize: 12, color: _R.textL(context)),
                    textAlign: TextAlign.center),
              ])))
        else
          Expanded(
              child: Column(children: [
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('${_hizliMap.length} çeşit ürün',
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      TextButton.icon(
                          icon: const Icon(Icons.delete_sweep, size: 16),
                          label: const Text('Temizle'),
                          onPressed: () {
                            _hizliMap.clear();
                            if (mounted) setState(() {});
                          }),
                    ])),
            Expanded(
                child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: _hizliMap.length,
              itemBuilder: (_, i) {
                final item = _hizliMap.values.toList()[i];
                return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                        color: TsRenk.kart(context),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: TsRenk.ayirac(context))),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(children: [
                        Expanded(
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                              Text(item.urun.urunAdi,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13)),
                              Text(item.urun.barkod ?? '',
                                  style: TextStyle(
                                      fontSize: 11, color: _R.textL(context))),
                            ])),
                        Row(children: [
                          IconButton(
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(
                                  minWidth: 32, minHeight: 32),
                              icon: const Icon(Icons.remove_circle_outline,
                                  size: 22),
                              onPressed: () => setState(() {
                                    if (item.adet <= 1) {
                                      _hizliMap.remove(item.urun.id);
                                    } else {
                                      item.adet--;
                                    }
                                  })),
                          Text('${item.adet}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18)),
                          IconButton(
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(
                                  minWidth: 32, minHeight: 32),
                              icon: const Icon(Icons.add_circle_outline,
                                  size: 22),
                              onPressed: () => setState(() => item.adet++)),
                        ]),
                      ]),
                    ));
              },
            )),
            Padding(
                padding: const EdgeInsets.all(12),
                child: SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton.icon(
                      onPressed: _yukleniyor ? null : _hizliKaydet,
                      style: FilledButton.styleFrom(
                          backgroundColor: _R.orange,
                          foregroundColor: Colors.white),
                      icon: const Icon(Icons.assignment_return),
                      label: Text('${_hizliMap.length} Ürünü İade Et',
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold)),
                    ))),
          ])),
      ]);
}
