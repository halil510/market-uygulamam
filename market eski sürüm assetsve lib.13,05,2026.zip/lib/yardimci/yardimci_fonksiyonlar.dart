class YardimciFonksiyonlar {
  static double stringToDouble(String? value) {
    if (value == null || value.isEmpty) return 0.0;
    
    // Virgüllü sayıları düzelt
    value = value.replaceAll(',', '.');
    
    // Sayısal olmayan karakterleri kaldır
    value = value.replaceAll(RegExp(r'[^0-9\.]'), '');
    
    return double.tryParse(value) ?? 0.0;
  }

  static String paraFormatla(double deger) {
    return '₺${deger.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  static String tarihFormatla(DateTime tarih) {
    return '${tarih.day}.${tarih.month}.${tarih.year}';
  }
}