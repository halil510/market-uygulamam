import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';

class FiyatYonetimi {
  final UrunRepoSitory _urunRepository = UrunRepoSitory();

  Future<void> fiyatGuncelleTumUrunler(double yuzde, bool artis) async {
    final urunler = await _urunRepository.tumUrunleriGetir();
    for (var urun in urunler) {
      final yeniFiyat = artis 
          ? urun.satisFiyat * (1 + yuzde / 100)
          : urun.satisFiyat * (1 - yuzde / 100);
      
      final guncellenmisUrun = urun.copyWith(satisFiyat: yeniFiyat);
      await _urunRepository.urunGuncelle(guncellenmisUrun);
    }
  }
}