import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:market_uygulamasi/modeller/urun.dart';

class BildirimServisi {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    final InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    await _notificationsPlugin.initialize(initializationSettings);
  }

  static Future<void> gosterBildirim(String title, String body) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'market_kanal_id',
      'Market Bildirimleri',
      importance: Importance.max,
      priority: Priority.high,
    );

    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);

    await _notificationsPlugin.show(
        0, title, body, platformChannelSpecifics);
  }

  static Future<void> dusukStokBildirimi(List<Urun> dusukStokluUrunler) async {
    if (dusukStokluUrunler.isNotEmpty) {
      await gosterBildirim(
        'Düşük Stok Uyarısı',
        '${dusukStokluUrunler.length} ürünün stoğu azalmış durumda',
      );
    }
  }
}