import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class UygulamaAyarlari {
  // Anahtarlar
  static const String _koyuTemaKey = 'koyu_tema';
  static const String _yazicilarKey = 'yazicilar';
  static const String _aktifYaziciKey = 'aktif_yazici';
  static const String _firmaBilgileriKey = 'firma_bilgileri';

  // Tema modu kaydet (koyu/aydınlık)
  Future<void> temaModuKaydet(bool koyuTema) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_koyuTemaKey, koyuTema);
  }

  // Tema modu getir
  Future<bool> temaModuGetir() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_koyuTemaKey) ?? false;
  }

  // YAZICI YÖNETİMİ ----------------------------------------------------------

  // Tüm yazıcıları kaydet
  Future<void> _yazicilariKaydet(List<Map<String, dynamic>> yazicilar) async {
    final prefs = await SharedPreferences.getInstance();
    final list = yazicilar.map((y) => jsonEncode(y)).toList();
    await prefs.setStringList(_yazicilarKey, list);
  }

  // Tüm yazıcıları getir
  Future<List<Map<String, dynamic>>> tumYazicilariGetir() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_yazicilarKey) ?? [];
    return list.map((jsonStr) {
      final decoded = jsonDecode(jsonStr);
      if (decoded is Map<String, dynamic>) {
        return decoded;
      }
      return <String, dynamic>{}; // Boş map dön
    }).toList();
  }

  // Yeni yazıcı ekle veya güncelle
  Future<void> yaziciEkleGuncelle(Map<String, dynamic> yazici) async {
    final tumYazicilar = await tumYazicilariGetir();
    
    // ID kontrolü - eğer yoksa yeni ID oluştur
    if (yazici['id'] == null) {
      yazici['id'] = DateTime.now().microsecondsSinceEpoch.toString();
    }
    
    final index = tumYazicilar.indexWhere((y) => y['id'] == yazici['id']);
    
    if (index != -1) {
      tumYazicilar[index] = yazici; // Güncelle
    } else {
      tumYazicilar.add(yazici); // Yeni ekle
    }
    
    await _yazicilariKaydet(tumYazicilar);
  }

  // Yazıcı sil
  Future<void> yaziciSil(String id) async {
    final tumYazicilar = await tumYazicilariGetir();
    tumYazicilar.removeWhere((y) => y['id'] == id);
    await _yazicilariKaydet(tumYazicilar);
  }

  // Aktif yazıcıyı ayarla (YAZICI ID'Sİ İLE)
  Future<void> aktifYaziciAyarla(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_aktifYaziciKey, id);
  }

  // Aktif yazıcıyı getir
  Future<Map<String, dynamic>?> aktifYaziciGetir() async {
    final prefs = await SharedPreferences.getInstance();
    final aktifId = prefs.getString(_aktifYaziciKey);
    
    if (aktifId == null) return null;
    
    final tumYazicilar = await tumYazicilariGetir();
    try {
      return tumYazicilar.firstWhere((y) => y['id'] == aktifId);
    } catch (e) {
      return null;
    }
  }

  // FIRMA BİLGİLERİ YÖNETİMİ -------------------------------------------------
  
  // Firma bilgilerini kaydet
  Future<void> firmaBilgileriKaydet(Map<String, String> bilgiler) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_firmaBilgileriKey, jsonEncode(bilgiler));
  }

  // Firma bilgilerini getir
  Future<Map<String, dynamic>?> firmaBilgileriGetir() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = prefs.getString(_firmaBilgileriKey);
    if (jsonStr != null) {
      return jsonDecode(jsonStr) as Map<String, dynamic>;
    }
    return null;
  }

  // Yardımcı Metodlar --------------------------------------------------------
  
  // Bluetooth yazıcı ID getir (eski uyumluluk için)
  Future<String?> bluetoothYaziciIdGetir() async {
    final aktif = await aktifYaziciGetir();
    if (aktif != null && aktif['tur'] == 'bluetooth') {
      return aktif['cihazId'];
    }
    return null;
  }

  // Bluetooth yazıcı adı getir (eski uyumluluk için)
  Future<String?> bluetoothYaziciAdiGetir() async {
    final aktif = await aktifYaziciGetir();
    if (aktif != null && aktif['tur'] == 'bluetooth') {
      return aktif['adi'];
    }
    return null;
  }

  // Ağ yazıcısı IP getir (eski uyumluluk için)
  Future<String?> yaziciIpGetir() async {
    final aktif = await aktifYaziciGetir();
    if (aktif != null && aktif['tur'] == 'ag') {
      return aktif['ip'];
    }
    return null;
  }

  // Ağ yazıcısı port getir (eski uyumluluk için)
  Future<String?> yaziciPortGetir() async {
    final aktif = await aktifYaziciGetir();
    if (aktif != null && aktif['tur'] == 'ag') {
      return aktif['port'];
    }
    return null;
  }
}