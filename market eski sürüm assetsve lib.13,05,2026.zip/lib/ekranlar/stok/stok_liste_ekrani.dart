// lib/ekranlar/stok/stok_liste_ekrani.dart
// Klavye kapanma sorunu düzeltildi

import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/rotalar.dart';
import 'package:market_uygulamasi/widgetlar/barkod_tarayici.dart';
import 'package:excel/excel.dart' hide Border;
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:market_uygulamasi/widgetlar/barcode_widget.dart';
import 'package:market_uygulamasi/ekranlar/urun/urun_detay_ekrani.dart';
import 'package:market_uygulamasi/ekranlar/iade/barkodlu_iade_ekrani.dart';
import 'dart:async';

class StokListeEkrani extends StatefulWidget {
  @override
  _StokListeEkraniState createState() => _StokListeEkraniState();
}

class _StokListeEkraniState extends State<StokListeEkrani> {
  final UrunRepoSitory _repo = UrunRepoSitory();
  List<Urun> _tumUrunler = [];
  List<Urun> _filtreliUrunler = [];
  final _aramaController = TextEditingController();
  Set<int> _seciliUrunler = {};
  String? _seciliGrup;
  bool _secimModu = false;
  Timer? _aramaDebounce;
  bool _yukleniyor = true;
  bool _isSearching = false;
  String _currentSearchQuery = '';

  // Resim açık/kapalı durumu
  Map<int, bool> _resimAcikMap = {};

  final ScrollController _scrollController = ScrollController();
  int _sayfa = 0;
  bool _dahaFazlaVar = true;
  bool _sayfaYukleniyor = false;
  static const int _sayfaBoyutu = 50;

  // Focus node'u korumak için
  final FocusNode _aramaFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _resetAndLoad();
    _aramaController.addListener(_onAramaChanged);
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _aramaDebounce?.cancel();
    _aramaController.removeListener(_onAramaChanged);
    _aramaController.dispose();
    _aramaFocusNode.dispose();
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _resetAndLoad() {
    setState(() {
      _sayfa = 0;
      _dahaFazlaVar = true;
      _tumUrunler.clear();
      _filtreliUrunler.clear();
      _seciliUrunler.clear();
      _secimModu = false;
      _yukleniyor = true;
      _sayfaYukleniyor = false;
      _resimAcikMap.clear();
    });
    if (_isSearching) {
      _aramaYap(_currentSearchQuery, reset: true);
    } else {
      _normalUrunleriYukle(reset: true);
    }
  }

  void _onAramaChanged() {
    _aramaDebounce?.cancel();
    final aramaMetni = _aramaController.text.trim();
    if (aramaMetni.isEmpty) {
      if (_isSearching) {
        setState(() {
          _isSearching = false;
          _currentSearchQuery = '';
        });
        _resetAndLoad();
      }
      return;
    }
    _aramaDebounce = Timer(const Duration(milliseconds: 300), () {
      setState(() {
        _isSearching = true;
        _currentSearchQuery = aramaMetni;
        _sayfa = 0;
        _dahaFazlaVar = true;
        _tumUrunler.clear();
        _yukleniyor = true;
      });
      _aramaYap(_currentSearchQuery, reset: true);
    });
  }

  Future<void> _normalUrunleriYukle({bool reset = false}) async {
    if (_isSearching) return;
    if (reset) {
      setState(() {
        _sayfa = 0;
        _dahaFazlaVar = true;
        _tumUrunler.clear();
        _yukleniyor = true;
      });
    }
    if (_sayfaYukleniyor || !_dahaFazlaVar) return;
    setState(() => _sayfaYukleniyor = true);
    try {
      final yeniUrunler = await _repo.urunleriSayfaliGetir(
        _sayfa * _sayfaBoyutu,
        _sayfaBoyutu,
      );
      if (!mounted) return;
      setState(() {
        _tumUrunler.addAll(yeniUrunler);
        _dahaFazlaVar = yeniUrunler.length >= _sayfaBoyutu;
        _sayfa++;
        _uygulaGrupFiltresi();
        _yukleniyor = false;
        _sayfaYukleniyor = false;
      });
    } catch (e) {
      _showMessage('Ürünler yüklenirken hata: $e', isError: true);
      setState(() {
        _yukleniyor = false;
        _sayfaYukleniyor = false;
      });
    }
  }

  Future<void> _aramaYap(String kelime, {bool reset = false}) async {
    if (!_isSearching) return;
    if (reset) {
      setState(() {
        _sayfa = 0;
        _dahaFazlaVar = true;
        _tumUrunler.clear();
        _yukleniyor = true;
      });
    }
    if (_sayfaYukleniyor || !_dahaFazlaVar) return;
    setState(() => _sayfaYukleniyor = true);
    try {
      final sonuclar = await _repo.urunAraSayfali(
        kelime,
        _sayfaBoyutu,
        _sayfa * _sayfaBoyutu,
      );
      if (!mounted) return;
      setState(() {
        _tumUrunler.addAll(sonuclar);
        _dahaFazlaVar = sonuclar.length >= _sayfaBoyutu;
        _sayfa++;
        _uygulaGrupFiltresi();
        _yukleniyor = false;
        _sayfaYukleniyor = false;
      });
      if (reset && sonuclar.isEmpty) {
        _showMessage('"$kelime" için ürün bulunamadı', isError: true);
      }
    } catch (e) {
      if (mounted) {
        _showMessage('Arama hatası: $e', isError: true);
        setState(() {
          _yukleniyor = false;
          _sayfaYukleniyor = false;
        });
      }
    }
  }

  void _uygulaGrupFiltresi() {
    if (_seciliGrup != null && _seciliGrup!.isNotEmpty) {
      setState(() {
        _filtreliUrunler = _tumUrunler.where((u) => u.anagrup == _seciliGrup).toList();
      });
    } else {
      setState(() {
        _filtreliUrunler = List.from(_tumUrunler);
      });
    }
  }

  void _onScroll() {
    if (_sayfaYukleniyor || !_dahaFazlaVar) return;
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 300) {
      if (_isSearching) {
        _aramaYap(_currentSearchQuery);
      } else {
        _normalUrunleriYukle();
      }
    }
  }

  void _showMessage(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _grupFiltrele() async {
    if (_tumUrunler.isEmpty) await _normalUrunleriYukle(reset: true);
    final gruplar = _tumUrunler.map((e) => e.anagrup).whereType<String>().toSet().toList();
    final secilen = await showDialog<String?>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Grup Seç'),
        children: [
          SimpleDialogOption(child: const Text('Tümü'), onPressed: () => Navigator.pop(context, null)),
          ...gruplar.map((g) => SimpleDialogOption(child: Text(g), onPressed: () => Navigator.pop(context, g))),
        ],
      ),
    );
    if (!mounted) return;
    setState(() {
      _seciliGrup = secilen;
      _uygulaGrupFiltresi();
    });
  }

  void _secimDegistir(int urunId) {
    setState(() {
      if (_seciliUrunler.contains(urunId)) {
        _seciliUrunler.remove(urunId);
      } else {
        _seciliUrunler.add(urunId);
      }
      _secimModu = _seciliUrunler.isNotEmpty;
    });
  }

  Future<void> _seciliUrunleriSil() async {
    if (_seciliUrunler.isEmpty) return;
    final onay = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ürünleri Sil'),
        content: Text('Seçilen ${_seciliUrunler.length} ürünü silmek istediğinize emin misiniz?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (onay == true) {
      setState(() => _yukleniyor = true);
      try {
        for (final id in _seciliUrunler) {
          await _repo.urunSil(id);
        }
        _resetAndLoad();
        _showMessage('${_seciliUrunler.length} ürün silindi');
      } catch (e) {
        _showMessage('Silme hatası: $e', isError: true);
      } finally {
        setState(() => _yukleniyor = false);
      }
    }
  }

  void _seciliUrunleriIadeyeGonder() {
    final seciliUrunlerListesi = _tumUrunler.where((u) => _seciliUrunler.contains(u.id)).toList();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BarkodluIadeEkrani(
          baslangicUrunleri: seciliUrunlerListesi.isNotEmpty ? seciliUrunlerListesi : null,
        ),
      ),
    ).then((_) {
      setState(() {
        _seciliUrunler.clear();
        _secimModu = false;
      });
      _resetAndLoad();
    });
  }

  Future<void> _excelDisariAktar() async {
    final List<Urun> aktarilacak = _secimModu
        ? _tumUrunler.where((u) => _seciliUrunler.contains(u.id)).toList()
        : _filtreliUrunler;
    if (aktarilacak.isEmpty) {
      _showMessage('Aktarılacak veri yok', isError: true);
      return;
    }
    try {
      final excel = Excel.createExcel();
      final sheet = excel['Stok'];
      sheet.appendRow(['Kod', 'Barkod', 'Ürün Adı', 'Stok', 'Alış Fiyat (KDV\'li)', 'Satış Fiyatı']);
      for (var u in aktarilacak) {
        final kdvliAlis = (u.alisFiyatKdvDahil ?? (u.alisFiyat ?? 0) * (1 + (u.kdvOrani ?? 0) / 100));
        sheet.appendRow([
          u.kod ?? '',
          u.barkod ?? '',
          u.ad ?? '',
          (u.stokMiktari ?? 0).toStringAsFixed(2),
          kdvliAlis.toStringAsFixed(2),
          (u.satisFiyat ?? 0).toStringAsFixed(2),
        ]);
      }
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/stok_listesi_${DateTime.now().millisecondsSinceEpoch}.xlsx');
      await file.writeAsBytes(excel.encode()!);
      await Share.shareFiles([file.path], text: 'Stok Listesi');
      _showMessage('Excel dışa aktarıldı');
    } catch (e) {
      _showMessage('Excel hatası: $e', isError: true);
    }
  }

  void _barkodGoster(Urun urun) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(urun.ad ?? "Ürün Adı Yok", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              BarcodeWidget(barkod: urun.barkod ?? "", width: 250, height: 150, fontSize: 16, drawNumber: true),
              const SizedBox(height: 20),
              Text(urun.barkod ?? "", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text("Kapat")),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _barkodOkuVeAra() async {
    final barkod = await Navigator.push(context, MaterialPageRoute(builder: (_) => BarkodTarayici()));
    if (barkod != null && barkod.isNotEmpty) {
      _aramaController.text = barkod;
      // Klavye açık kalacak
      _aramaFocusNode.requestFocus();
    }
  }

  void _toggleResim(int urunId) {
    setState(() {
      final current = _resimAcikMap[urunId] ?? false;
      _resimAcikMap[urunId] = !current;
    });
  }

  Widget _buildUrunTile(Urun urun) {
    final secili = _seciliUrunler.contains(urun.id);
    final kdvliAlis = (urun.alisFiyatKdvDahil ?? (urun.alisFiyat ?? 0) * (1 + (urun.kdvOrani ?? 0) / 100));
    final stokAz = (urun.stokMiktari ?? 0) < 5;
    final resimAcik = _resimAcikMap[urun.id] ?? false;
    final resimVar = urun.resimYolu != null && urun.resimYolu!.isNotEmpty && File(urun.resimYolu!).existsSync();

    return Column(
      children: [
        Card(
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: InkWell(
            onLongPress: () => _secimDegistir(urun.id!),
            onTap: () {
              if (_secimModu) {
                _secimDegistir(urun.id!);
              } else {
                Navigator.pushNamed(context, Rotalar.urunDetay, arguments: urun)
                    .then((_) => _resetAndLoad());
              }
            },
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: secili ? Colors.blue.shade50 : Colors.white,
              ),
              child: ListTile(
                leading: resimVar
                    ? IconButton(
                        icon: Icon(
                          resimAcik ? Icons.image_rounded : Icons.image_outlined,
                          color: Colors.blue,
                        ),
                        onPressed: () => _toggleResim(urun.id!),
                        tooltip: resimAcik ? 'Resmi Gizle' : 'Resmi Göster',
                      )
                    : null,
                title: Text(urun.ad ?? 'İsimsiz Ürün', style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        const Text('KDV\'li Alış: ', style: TextStyle(fontSize: 12)),
                        Text('₺${kdvliAlis.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.green)),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: stokAz ? Colors.red.shade50 : Colors.green.shade50,
                        border: Border.all(color: stokAz ? Colors.red : Colors.green),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        'Stok: ${(urun.stokMiktari ?? 0).toStringAsFixed(2)}',
                        style: TextStyle(color: stokAz ? Colors.red : Colors.green.shade800, fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    ),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (urun.barkod != null && urun.barkod!.isNotEmpty)
                      IconButton(
                        icon: const Icon(Icons.qr_code, size: 20),
                        onPressed: () => _barkodGoster(urun),
                        tooltip: 'Barkod Göster',
                      ),
                    if (secili) const Icon(Icons.check_circle, color: Colors.green),
                  ],
                ),
              ),
            ),
          ),
        ),
        if (resimAcik && resimVar)
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(
                File(urun.resimYolu!),
                height: 200,
                width: double.infinity,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) => Container(
                  height: 200,
                  color: Colors.grey.shade200,
                  child: const Center(child: Text('Resim yüklenemedi', style: TextStyle(color: Colors.grey))),
                ),
              ),
            ),
          )
        else if (resimAcik && !resimVar)
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(child: Text('Resim bulunamadı', style: TextStyle(color: Colors.grey))),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_secimModu ? '${_seciliUrunler.length} Seçildi' : 'Stok Listesi'),
        actions: _secimModu
            ? [
                IconButton(icon: const Icon(Icons.file_download), onPressed: _excelDisariAktar),
                IconButton(icon: const Icon(Icons.delete), onPressed: _seciliUrunleriSil),
                IconButton(icon: const Icon(Icons.assignment_return), onPressed: _seciliUrunleriIadeyeGonder, tooltip: 'İade Yap'),
                IconButton(icon: const Icon(Icons.clear), onPressed: () {
                  setState(() {
                    _seciliUrunler.clear();
                    _secimModu = false;
                  });
                }),
              ]
            : [
                IconButton(icon: const Icon(Icons.filter_alt), onPressed: _grupFiltrele),
                IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: _barkodOkuVeAra),
                IconButton(icon: const Icon(Icons.file_download), onPressed: _excelDisariAktar),
              ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              controller: _aramaController,
              focusNode: _aramaFocusNode,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _aramaController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _aramaController.clear();
                          if (_isSearching) {
                            setState(() => _isSearching = false);
                            _resetAndLoad();
                          }
                          _aramaFocusNode.requestFocus();
                        },
                      )
                    : null,
                labelText: 'Ürün adı veya barkod ara',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          if (_seciliGrup != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Chip(
                label: Text('Grup: $_seciliGrup'),
                onDeleted: () {
                  setState(() => _seciliGrup = null);
                  _uygulaGrupFiltresi();
                },
              ),
            ),
          Expanded(
            child: _yukleniyor && _filtreliUrunler.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: () async {
                      _resetAndLoad();
                    },
                    child: ListView.builder(
                      controller: _scrollController,
                      itemCount: _filtreliUrunler.length + ((_sayfaYukleniyor && _dahaFazlaVar) ? 1 : 0),
                      itemBuilder: (ctx, idx) {
                        if (idx == _filtreliUrunler.length && _sayfaYukleniyor) {
                          return const Padding(
                            padding: EdgeInsets.symmetric(vertical: 16),
                            child: Center(child: CircularProgressIndicator()),
                          );
                        }
                        return _buildUrunTile(_filtreliUrunler[idx]);
                      },
                    ),
                  ),
          ),
          if (!_secimModu)
            Container(
              padding: const EdgeInsets.all(8),
              color: Colors.grey.shade200,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.inventory),
                    label: const Text('Stok Sayımı'),
                    onPressed: () => Navigator.pushNamed(context, Rotalar.stokSayim),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.assignment_return),
                    label: const Text('İade Yap'),
                    onPressed: () => Navigator.pushNamed(context, Rotalar.barkodluIade),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}