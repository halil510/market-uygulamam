// lib/ekranlar/iade/barkodlu_iade_ekrani.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:market_uygulamasi/modeller/iade_kaydi.dart';
import 'package:market_uygulamasi/modeller/musteri.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/iade_repo.dart';
import 'package:market_uygulamasi/repozitory/musteri_repo.dart';
import 'package:market_uygulamasi/repozitory/stok_repo.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/servisler/barkod_servisi.dart';
import 'package:market_uygulamasi/servisler/excel_iade_servisi.dart';
import 'package:market_uygulamasi/widgetlar/barcode_widget.dart';
import 'package:market_uygulamasi/widgetlar/barkod_tarayici.dart';

// ─── Renk paleti ─────────────────────────────────────────────────────────────
class _R {
  static const bg      = Color(0xFFF4F6FB);
  static const card    = Color(0xFFFFFFFF);
  static const primary = Color(0xFF1A2E5A);
  static const orange  = Color(0xFFFF6635);
  static const green   = Color(0xFF22C55E);
  static const red     = Color(0xFFEF4444);
  static const blue    = Color(0xFF3B82F6);
  static const textD   = Color(0xFF0F172A);
  static const textL   = Color(0xFF64748B);
  static const border  = Color(0xFFE2E8F0);
  static const shadow  = Color(0x10000000);
}

// ─── Hızlı mod öğesi ─────────────────────────────────────────────────────────
class _HizliItem {
  final Urun urun;
  int adet;
  _HizliItem({required this.urun, this.adet = 1});
}

// ─────────────────────────────────────────────────────────────────────────────
class BarkodluIadeEkrani extends StatefulWidget {
  final List<Urun>? baslangicUrunleri;
  const BarkodluIadeEkrani({super.key, this.baslangicUrunleri});

  @override
  State<BarkodluIadeEkrani> createState() => _State();
}

class _State extends State<BarkodluIadeEkrani>
    with TickerProviderStateMixin {
  // ── Repo ──────────────────────────────────────────────────────────────────
  final _urunRepo    = UrunRepoSitory();
  final _iadeRepo    = IadeRepository();
  final _stokRepo    = StokRepository();
  final _musteriRepo = MusteriRepo();

  // ── Veri ──────────────────────────────────────────────────────────────────
  List<Musteri>   _tedarikciler = [];
  Musteri?        _tedarikci;
  List<IadeKaydi> _liste        = [];
  List<IadeKaydi> _filtreli     = [];

  // ── Form state ────────────────────────────────────────────────────────────
  Urun?      _secilenUrun;
  IadeKaydi? _duzenle;
  double     _miktar       = 1;
  double     _orijinalFiyat = 0;
  bool       _barkodGor    = false;
  bool       _yukleniyor   = false;

  // ── Hızlı mod ─────────────────────────────────────────────────────────────
  bool _hizli = false;
  final Map<String, _HizliItem> _hizliMap = {};

  // ── Arama ─────────────────────────────────────────────────────────────────
  List<Urun> _aramaListesi = [];
  Timer?     _debounce;

  // ── Filtre ────────────────────────────────────────────────────────────────
  String?   _filtreTedarikci;
  DateTime? _filtreBas, _filtreBit;

  // ── Controllers ───────────────────────────────────────────────────────────
  final _aramaCtrl   = TextEditingController();
  final _miktarCtrl  = TextEditingController(text: '1');
  final _fiyatCtrl   = TextEditingController();
  final _indCtrl     = TextEditingController();
  final _aramaFocus  = FocusNode();

  late final TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _aramaCtrl.addListener(_aramaDebounce);
    _miktarCtrl.addListener(() {
      final v = double.tryParse(_miktarCtrl.text) ?? 1;
      if (v != _miktar) setState(() => _miktar = v);
    });
    _indCtrl.addListener(_indHesapla);

    _yukle();

    if (widget.baslangicUrunleri?.isNotEmpty == true) {
      _hizli = true;
      for (final u in widget.baslangicUrunleri!) {
        if (u.barkod == null) continue;
        _hizliMap.containsKey(u.barkod)
            ? _hizliMap[u.barkod]!.adet++
            : _hizliMap[u.barkod!] = _HizliItem(urun: u);
      }
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _aramaCtrl.dispose(); _miktarCtrl.dispose();
    _fiyatCtrl.dispose(); _indCtrl.dispose();
    _aramaFocus.dispose(); _tab.dispose();
    super.dispose();
  }

  // ── Veri yükleme ──────────────────────────────────────────────────────────
  Future<void> _yukle() async {
    final [t, l] = await Future.wait([
      _musteriRepo.tumTedarikcileriGetir(),
      _iadeRepo.tumIadeKayitlariniGetir(),
    ]);
    if (!mounted) return;
    setState(() {
      _tedarikciler = t as List<Musteri>;
      _liste = (l as List<IadeKaydi>).reversed.toList();
      _filtrele();
    });
  }

  void _filtrele() {
    _filtreli = _liste.where((k) {
      if (_filtreTedarikci != null && k.tedarikci != _filtreTedarikci) return false;
      if (_filtreBas != null && _filtreBit != null) {
        return k.tarih.isAfter(_filtreBas!.subtract(const Duration(days: 1))) &&
            k.tarih.isBefore(_filtreBit!.add(const Duration(days: 1)));
      }
      return true;
    }).toList();
  }

  // ── Arama ─────────────────────────────────────────────────────────────────
  void _aramaDebounce() {
    _debounce?.cancel();
    final q = _aramaCtrl.text.trim();
    if (q.isEmpty) { setState(() => _aramaListesi = []); return; }
    if (q.length < 2) return;
    _debounce = Timer(const Duration(milliseconds: 280), () => _ara(q));
  }

  Future<void> _ara(String q) async {
    final all = await _urunRepo.tumUrunleriGetir();
    final ql = q.toLowerCase();
    final res = all.where((u) =>
        (u.barkod?.toLowerCase().contains(ql) ?? false) ||
        (u.barkodlar?.split(',').any((b) => b.toLowerCase().contains(ql)) ?? false) ||
        (u.ad?.toLowerCase().contains(ql) ?? false)).toList();
    if (!mounted) return;
    setState(() => _aramaListesi = res);
    if (res.length == 1) _secilenUrunSet(res.first);
  }

  // ── Ürün seçimi ───────────────────────────────────────────────────────────
  Future<void> _secilenUrunSet(Urun u) async {
    final temiz = BarkodServisi().duzeltBarkod(u.barkod ?? '');
    final onceki = await _iadeRepo.sonIadeKaydiniGetir(temiz);
    if (!mounted) return;
    setState(() {
      _secilenUrun = u;
      _aramaListesi = [];
      _aramaCtrl.clear();
      if (onceki != null) {
        _duzenle = onceki;
        _orijinalFiyat = onceki.orijinalAlisFiyati;
        _fiyatCtrl.text = onceki.alisFiyati.toStringAsFixed(2);
        _miktar = onceki.iadeMiktari;
        _miktarCtrl.text = _miktar.toString();
        _barkodGor = true;
        _indCtrl.text = _temizInd(onceki.indirimNotu ?? '');
        final t = _tedarikciler.cast<Musteri?>()
            .firstWhere((t) => t?.unvan == onceki.tedarikci, orElse: () => _tedarikci);
        if (t != null) _tedarikci = t;
      } else {
        _duzenle = null;
        _orijinalFiyat = u.alisFiyat ?? 0;
        _fiyatCtrl.text = _orijinalFiyat.toStringAsFixed(2);
        _miktar = 1; _miktarCtrl.text = '1';
        _barkodGor = false; _indCtrl.clear();
      }
    });
    _tab.animateTo(0);
  }

  void _indHesapla() {
    final raw = _indCtrl.text.trim();
    if (raw.isEmpty) { _fiyatCtrl.text = _orijinalFiyat.toStringAsFixed(2); return; }
    final oran = double.tryParse(_temizInd(raw));
    if (oran != null && oran > 0 && oran <= 100) {
      _fiyatCtrl.text = (_orijinalFiyat * (1 - oran / 100)).toStringAsFixed(2);
    }
  }

  String _temizInd(String s) {
    final m = RegExp(r'(\d+[.,]?\d*)').firstMatch(s);
    return m == null ? '' : m.group(0)!.replaceAll(',', '.');
  }

  void _formSifirla() {
    setState(() { _secilenUrun = null; _duzenle = null; _miktar = 1;
      _orijinalFiyat = 0; _barkodGor = false; _aramaListesi = []; });
    _aramaCtrl.clear(); _miktarCtrl.text = '1';
    _fiyatCtrl.clear(); _indCtrl.clear();
  }

  // ── Barkod ────────────────────────────────────────────────────────────────
  Future<void> _barkodOku() async {
    final barkod = await Navigator.push<String>(
        context, MaterialPageRoute(builder: (_) => BarkodTarayici()));
    if (barkod == null || barkod.isEmpty) return;
    if (_hizli) { _hizliEkle(barkod); return; }
    final u = await _urunRepo.barkodlaUrunGetir(barkod);
    if (u != null) { _secilenUrunSet(u); }
    else { _msg('Ürün bulunamadı: $barkod', err: true); }
  }

  Future<void> _hizliEkle(String barkod) async {
    final u = await _urunRepo.barkodlaUrunGetir(barkod);
    if (u == null) { _msg('Ürün bulunamadı', err: true); return; }
    setState(() {
      _hizliMap.containsKey(u.barkod)
          ? _hizliMap[u.barkod]!.adet++
          : _hizliMap[u.barkod!] = _HizliItem(urun: u);
    });
    _msg('${u.ad} eklendi');
  }

  // ── Kaydet ────────────────────────────────────────────────────────────────
  Future<void> _kaydet() async {
    if (_secilenUrun == null) { _msg('Ürün seçin', err: true); return; }
    if (_miktar <= 0) { _msg('Geçerli miktar girin', err: true); return; }
    if (_tedarikci == null) { _msg('Tedarikçi seçin', err: true); return; }
    final fiyat = double.tryParse(_fiyatCtrl.text) ?? (_secilenUrun!.alisFiyat ?? 0);
    final indStr = _indCtrl.text.trim();
    final iade = IadeKaydi(
      urunId: _secilenUrun!.id!, urunAdi: _secilenUrun!.ad ?? '',
      barkod: BarkodServisi().duzeltBarkod(_secilenUrun!.barkod ?? ''),
      alisFiyati: fiyat, orijinalAlisFiyati: _orijinalFiyat,
      satisFiyati: _secilenUrun!.satisFiyat, iadeMiktari: _miktar,
      kdvOrani: _secilenUrun!.kdvOrani ?? 0, nedeni: 'Belirtilmedi',
      tarih: DateTime.now(), indirimNotu: indStr.isNotEmpty ? _temizInd(indStr) : null,
      tedarikci: _tedarikci!.unvan,
    );
    setState(() => _yukleniyor = true);
    try {
      await _iadeRepo.iadeKaydet(iade);
      await _stokRepo.stokGuncelle(_secilenUrun!.id!, (_secilenUrun!.stokMiktari ?? 0) + _miktar);
      await _yukle(); _formSifirla();
      _msg('${iade.urunAdi} iade kaydedildi');
    } catch (e) { _msg('Hata: $e', err: true); }
    finally { if (mounted) setState(() => _yukleniyor = false); }
  }

  Future<void> _guncelle() async {
    if (_duzenle == null || _tedarikci == null) return;
    final fiyat = double.tryParse(_fiyatCtrl.text) ?? _duzenle!.alisFiyati;
    final indStr = _indCtrl.text.trim();
    final guncel = _duzenle!.copyWith(
      alisFiyati: fiyat, iadeMiktari: _miktar,
      indirimNotu: indStr.isNotEmpty ? _temizInd(indStr) : null,
      tedarikci: _tedarikci!.unvan,
    );
    setState(() => _yukleniyor = true);
    try {
      final u = await _urunRepo.idyeGoreUrunGetir(_duzenle!.urunId);
      if (u != null) {
        await _stokRepo.stokGuncelle(u.id!, (u.stokMiktari ?? 0) - _duzenle!.iadeMiktari + _miktar);
      }
      await _iadeRepo.iadeKaydiGuncelle(guncel);
      await _yukle(); _formSifirla();
      _msg('İade güncellendi');
    } catch (e) { _msg('Güncelleme hatası: $e', err: true); }
    finally { if (mounted) setState(() => _yukleniyor = false); }
  }

  Future<void> _hizliKaydet() async {
    if (_hizliMap.isEmpty) { _msg('Liste boş', err: true); return; }
    if (_tedarikci == null) { _msg('Tedarikçi seçin', err: true); return; }
    setState(() => _yukleniyor = true);
    try {
      for (final item in _hizliMap.values) {
        final iade = IadeKaydi(
          urunId: item.urun.id!, urunAdi: item.urun.ad ?? '',
          barkod: BarkodServisi().duzeltBarkod(item.urun.barkod ?? ''),
          alisFiyati: item.urun.alisFiyat ?? 0, orijinalAlisFiyati: item.urun.alisFiyat ?? 0,
          satisFiyati: item.urun.satisFiyat, iadeMiktari: item.adet.toDouble(),
          kdvOrani: item.urun.kdvOrani ?? 0, nedeni: 'Toplu iade',
          tarih: DateTime.now(), tedarikci: _tedarikci!.unvan,
        );
        await _iadeRepo.iadeKaydet(iade);
        await _stokRepo.stokGuncelle(item.urun.id!, (item.urun.stokMiktari ?? 0) + item.adet);
      }
      final n = _hizliMap.length;
      setState(() => _hizliMap.clear());
      await _yukle();
      _msg('$n ürün iade edildi');
    } catch (e) { _msg('Hata: $e', err: true); }
    finally { if (mounted) setState(() => _yukleniyor = false); }
  }

  Future<void> _sil(IadeKaydi iade) async {
    final u = await _urunRepo.idyeGoreUrunGetir(iade.urunId);
    if (u != null) await _stokRepo.stokGuncelle(u.id!, (u.stokMiktari ?? 0) - iade.iadeMiktari);
    await _iadeRepo.iadeKaydiSil(iade.id!);
    await _yukle();
    _msg('${iade.urunAdi} iadesi silindi');
  }

  Future<void> _excel() async {
    if (_filtreli.isEmpty) { _msg('Kayıt yok', err: true); return; }
    final f = await ExcelIadeServisi.iadeKayitlariniExceleAktar(_filtreli);
    await ExcelIadeServisi.dosyayiPaylas(f);
  }

  Future<void> _yeniTedarikci() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Yeni Tedarikçi'),
        content: TextField(controller: ctrl, autofocus: true,
            decoration: const InputDecoration(labelText: 'Ünvan', border: OutlineInputBorder())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')),
          FilledButton(
            onPressed: () async {
              if (ctrl.text.trim().isEmpty) return;
              await _musteriRepo.cariEkle(Musteri(
                cariKodu: 'TED-${DateTime.now().millisecondsSinceEpoch}',
                unvan: ctrl.text.trim(), cariTipi: 'Tedarikçi', bakiye: 0,
              ));
              final list = await _musteriRepo.tumTedarikcileriGetir();
              if (mounted) setState(() => _tedarikciler = list);
              if (ctx.mounted) Navigator.pop(ctx, true);
            },
            child: const Text('Ekle'),
          ),
        ],
      ),
    );
    if (ok == true) _msg('Tedarikçi eklendi');
  }

  void _msg(String s, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(err ? Icons.error_outline : Icons.check_circle_outline,
            color: Colors.white, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(s, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: err ? _R.red : _R.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
      duration: const Duration(seconds: 2),
    ));
  }

  Future<bool> _onay(String s) async =>
      await showDialog<bool>(context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Onay'), content: Text(s),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true),
                style: FilledButton.styleFrom(backgroundColor: _R.red),
                child: const Text('Sil')),
          ],
        ),
      ) ?? false;

  // ══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final hizliAdet = _hizliMap.values.fold(0, (s, i) => s + i.adet);
    return Scaffold(
      backgroundColor: _R.bg,
      body: Column(children: [
        _appBar(hizliAdet),
        _tedarikciSatiri(),
        _tabSatiri(),
        Expanded(child: TabBarView(controller: _tab, children: [
          _yeniIadeTab(),
          _gecmisTab(),
        ])),
      ]),
    );
  }

  // ── AppBar ────────────────────────────────────────────────────────────────
  Widget _appBar(int hizliAdet) {
    return Container(
      color: _R.primary,
      padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 8, bottom: 10, left: 4, right: 4),
      child: Row(children: [
        IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context)),
        const Expanded(
          child: Text('İade Yönetimi', style: TextStyle(color: Colors.white,
              fontSize: 18, fontWeight: FontWeight.w700)),
        ),
        // Hızlı mod badge
        GestureDetector(
          onTap: () => setState(() => _hizli = !_hizli),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.only(right: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _hizli ? _R.orange : Colors.white10,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(_hizli ? Icons.flash_on : Icons.flash_off,
                  color: Colors.white, size: 16),
              const SizedBox(width: 4),
              Text(_hizli ? 'Hızlı${hizliAdet > 0 ? ' ($hizliAdet)' : ''}' : 'Hızlı',
                  style: const TextStyle(color: Colors.white,
                      fontSize: 12, fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
        IconButton(icon: const Icon(Icons.download_rounded, color: Colors.white),
            tooltip: "Excel'e aktar", onPressed: _excel),
        IconButton(icon: const Icon(Icons.filter_list_rounded, color: Colors.white),
            tooltip: 'Filtrele', onPressed: _filtreSheet),
      ]),
    );
  }

  // ── Tedarikçi satırı ──────────────────────────────────────────────────────
  Widget _tedarikciSatiri() {
    return Container(
      color: _R.primary,
      padding: const EdgeInsets.fromLTRB(16, 0, 8, 12),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.13),
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
        child: Row(children: [
          const Icon(Icons.business_rounded, color: Colors.white60, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<Musteri>(
                value: _tedarikci,
                hint: const Text('Tedarikçi seçin…',
                    style: TextStyle(color: Colors.white54, fontSize: 14)),
                dropdownColor: _R.primary,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                iconEnabledColor: Colors.white38,
                isExpanded: true,
                items: _tedarikciler.map((t) => DropdownMenuItem(
                    value: t,
                    child: Text(t.unvan,
                        style: const TextStyle(color: Colors.white)))).toList(),
                onChanged: (v) => setState(() => _tedarikci = v),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.add_circle_outline, color: Colors.white60, size: 20),
            onPressed: _yeniTedarikci,
          ),
        ]),
      ),
    );
  }

  // ── Tab bar ───────────────────────────────────────────────────────────────
  Widget _tabSatiri() => Container(
    color: _R.primary,
    child: TabBar(
      controller: _tab,
      indicatorColor: _R.orange,
      indicatorWeight: 3,
      labelColor: Colors.white,
      unselectedLabelColor: Colors.white38,
      labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
      tabs: const [Tab(text: '  YENİ İADE  '), Tab(text: '  GEÇMİŞ  ')],
    ),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // TAB 1 — YENİ İADE
  // ══════════════════════════════════════════════════════════════════════════
  Widget _yeniIadeTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        _aramaKutusu(),
        if (_aramaListesi.isNotEmpty) ...[const SizedBox(height: 8), _aramaPanel()],
        if (_hizli) ...[const SizedBox(height: 12), _hizliPanel()],
        if (_secilenUrun != null || _duzenle != null) ...[
          const SizedBox(height: 12), _urunFormu()],
        if (_secilenUrun == null && _duzenle == null &&
            _aramaListesi.isEmpty && !_hizli) ...[
          const SizedBox(height: 48), _bosEkran()],
      ]),
    );
  }

  Widget _aramaKutusu() {
    return Row(children: [
      Expanded(
        child: Container(
          decoration: BoxDecoration(
            color: _R.card,
            borderRadius: BorderRadius.circular(14),
            boxShadow: const [BoxShadow(color: _R.shadow, blurRadius: 8, offset: Offset(0, 2))],
          ),
          child: TextField(
            controller: _aramaCtrl,
            focusNode: _aramaFocus,
            style: const TextStyle(color: _R.textD, fontSize: 15),
            decoration: InputDecoration(
              hintText: 'Barkod veya ürün adı…',
              hintStyle: const TextStyle(color: _R.textL, fontSize: 14),
              prefixIcon: const Icon(Icons.search_rounded, color: _R.textL, size: 20),
              suffixIcon: _aramaCtrl.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear_rounded, color: _R.textL, size: 18),
                      onPressed: () { _aramaCtrl.clear(); setState(() => _aramaListesi = []); })
                  : null,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 4),
            ),
            onSubmitted: _ara,
          ),
        ),
      ),
      const SizedBox(width: 10),
      _ikonBtn(icon: Icons.qr_code_scanner_rounded, color: _R.orange, onTap: _barkodOku),
    ]);
  }

  Widget _aramaPanel() => Container(
    decoration: BoxDecoration(
      color: _R.card,
      borderRadius: BorderRadius.circular(16),
      boxShadow: const [BoxShadow(color: _R.shadow, blurRadius: 8, offset: Offset(0, 2))],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
        child: Text('${_aramaListesi.length} ürün bulundu',
            style: const TextStyle(fontSize: 12, color: _R.textL, fontWeight: FontWeight.w500))),
      ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 200),
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: _aramaListesi.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 16),
          itemBuilder: (_, i) {
            final u = _aramaListesi[i];
            return ListTile(
              dense: true,
              leading: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: _R.orange.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.inventory_2_outlined, color: _R.orange, size: 18),
              ),
              title: Text(u.ad ?? '', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              subtitle: Text(u.barkod ?? '', style: const TextStyle(fontSize: 11, color: _R.textL)),
              trailing: Text('${(u.alisFiyat ?? 0).toStringAsFixed(2)} ₺',
                  style: const TextStyle(fontWeight: FontWeight.w700, color: _R.blue, fontSize: 13)),
              onTap: () => _secilenUrunSet(u),
            );
          },
        ),
      ),
      const SizedBox(height: 6),
    ]),
  );

  Widget _hizliPanel() {
    final items = _hizliMap.values.toList();
    return Container(
      decoration: BoxDecoration(
        color: _R.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _R.orange.withOpacity(0.25)),
        boxShadow: const [BoxShadow(color: _R.shadow, blurRadius: 8, offset: Offset(0, 2))],
      ),
      child: Column(children: [
        // Başlık
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _R.orange.withOpacity(0.07),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
          ),
          child: Row(children: [
            const Icon(Icons.flash_on_rounded, color: _R.orange, size: 18),
            const SizedBox(width: 8),
            Text(
              'Hızlı İade — ${_hizliMap.values.fold(0, (s, i) => s + i.adet)} ürün',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: _R.textD),
            ),
            const Spacer(),
            if (items.isNotEmpty)
              _yukleniyor
                  ? const SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: _R.orange))
                  : FilledButton(
                      onPressed: _hizliKaydet,
                      style: FilledButton.styleFrom(
                        backgroundColor: _R.orange,
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                      ),
                      child: const Text('Kaydet'),
                    ),
          ]),
        ),
        // Ürün listesi
        if (items.isEmpty)
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              Icon(Icons.qr_code_scanner_rounded, size: 36, color: Colors.grey.shade300),
              const SizedBox(height: 8),
              const Text('Barkod okutarak ürün ekleyin',
                  style: TextStyle(color: _R.textL, fontSize: 13)),
            ]),
          )
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 1, indent: 16),
            itemBuilder: (_, i) {
              final item = items[i];
              return ListTile(
                dense: true,
                title: Text(item.urun.ad ?? '',
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                subtitle: Text(item.urun.barkod ?? '',
                    style: const TextStyle(fontSize: 11, color: _R.textL)),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  _miniBtn(Icons.remove_rounded, () => setState(() {
                    item.adet > 1 ? item.adet-- : _hizliMap.remove(item.urun.barkod);
                  })),
                  SizedBox(width: 32,
                    child: Text('${item.adet}', textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: _R.orange))),
                  _miniBtn(Icons.add_rounded, () => setState(() => item.adet++)),
                ]),
              );
            },
          ),
        // Barkod okut
        Padding(
          padding: const EdgeInsets.all(12),
          child: OutlinedButton.icon(
            onPressed: _barkodOku,
            icon: const Icon(Icons.qr_code_scanner_rounded, color: _R.orange, size: 18),
            label: const Text('Barkod Okut', style: TextStyle(color: _R.orange)),
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _R.orange.withOpacity(0.4)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              minimumSize: const Size(double.infinity, 42),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _urunFormu() {
    final isUpdate = _duzenle != null;
    final ad  = _secilenUrun?.ad ?? _duzenle?.urunAdi ?? '';
    final bar = _secilenUrun?.barkod ?? _duzenle?.barkod ?? '';
    final indirimliF = double.tryParse(_fiyatCtrl.text) ?? _orijinalFiyat;
    final indYuzde = _orijinalFiyat > 0
        ? ((_orijinalFiyat - indirimliF) / _orijinalFiyat * 100)
        : 0.0;

    return Container(
      decoration: BoxDecoration(
        color: _R.card,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [BoxShadow(color: _R.shadow, blurRadius: 10, offset: Offset(0, 3))],
      ),
      child: Column(children: [
        // ── Ürün başlığı ──────────────────────────────────────────────
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_R.orange.withOpacity(0.07), Colors.transparent],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _R.orange.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.assignment_return_rounded, color: _R.orange, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(ad, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: _R.textD),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              if (bar.isNotEmpty)
                Text(bar, style: const TextStyle(fontSize: 11, color: _R.textL)),
            ])),
            IconButton(
              icon: Icon(_barkodGor ? Icons.visibility_off_outlined : Icons.barcode_reader,
                  color: _R.textL, size: 18),
              onPressed: () => setState(() => _barkodGor = !_barkodGor),
            ),
            IconButton(
              icon: const Icon(Icons.close_rounded, color: _R.textL, size: 20),
              onPressed: _formSifirla,
            ),
          ]),
        ),

        if (_barkodGor && bar.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: SizedBox(height: 64, child: BarcodeWidget(barkod: bar)),
          ),

        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Column(children: [
            // Miktar & İndirim
            Row(children: [
              Expanded(child: _field(ctrl: _miktarCtrl, label: 'Miktar',
                  icon: Icons.numbers_rounded,
                  fmt: FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')))),
              const SizedBox(width: 12),
              Expanded(child: _field(ctrl: _indCtrl, label: 'İndirim %',
                  icon: Icons.percent_rounded, suffix: '%',
                  fmt: FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?,?\d*')))),
            ]),
            const SizedBox(height: 12),
            _field(ctrl: _fiyatCtrl, label: 'Alış Fiyatı',
                icon: Icons.attach_money_rounded, suffix: '₺',
                fmt: FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*'))),

            // Fiyat özeti
            if (_orijinalFiyat > 0) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: _R.bg, borderRadius: BorderRadius.circular(12)),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Orijinal: ${_orijinalFiyat.toStringAsFixed(2)} ₺',
                      style: const TextStyle(fontSize: 12, color: _R.textL)),
                  if (indYuzde > 0.05)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _R.green.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(8)),
                      child: Text('%${indYuzde.toStringAsFixed(1)} indirim',
                          style: const TextStyle(fontSize: 11, color: _R.green,
                              fontWeight: FontWeight.w600)),
                    ),
                ]),
              ),
            ],
            const SizedBox(height: 16),

            // Buton
            SizedBox(
              width: double.infinity, height: 52,
              child: _yukleniyor
                  ? const Center(child: CircularProgressIndicator(color: _R.orange))
                  : FilledButton.icon(
                      onPressed: isUpdate ? _guncelle : _kaydet,
                      icon: Icon(isUpdate ? Icons.update_rounded : Icons.save_rounded, size: 20),
                      label: Text(isUpdate ? 'GÜNCELLE' : 'İADE KAYDET',
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 0.4)),
                      style: FilledButton.styleFrom(
                        backgroundColor: isUpdate ? _R.blue : _R.orange,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _bosEkran() => Column(children: [
    Container(
      padding: const EdgeInsets.all(26),
      decoration: BoxDecoration(color: _R.orange.withOpacity(0.08), shape: BoxShape.circle),
      child: const Icon(Icons.assignment_return_rounded, size: 50, color: _R.orange),
    ),
    const SizedBox(height: 16),
    const Text('Yeni iade başlatın', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: _R.textD)),
    const SizedBox(height: 6),
    const Text('Barkod okutun veya ürün adı arayın', style: TextStyle(fontSize: 13, color: _R.textL)),
    const SizedBox(height: 20),
    OutlinedButton.icon(
      onPressed: _barkodOku,
      icon: const Icon(Icons.qr_code_scanner_rounded, color: _R.orange),
      label: const Text('Barkod Okut', style: TextStyle(color: _R.orange, fontSize: 14)),
      style: OutlinedButton.styleFrom(
        side: BorderSide(color: _R.orange.withOpacity(0.5)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
      ),
    ),
  ]);

  // ══════════════════════════════════════════════════════════════════════════
  // TAB 2 — GEÇMİŞ
  // ══════════════════════════════════════════════════════════════════════════
  Widget _gecmisTab() {
    final toplamTutar = _filtreli.fold(0.0,
        (s, k) => s + k.alisFiyati * k.iadeMiktari * (1 + (k.kdvOrani ?? 0) / 100));

    return Column(children: [
      if (_filtreli.isNotEmpty) _gecmisOzet(toplamTutar),
      if (_filtreTedarikci != null || _filtreBas != null) _filtreChipler(),
      Expanded(
        child: _filtreli.isEmpty
            ? _bosGecmis()
            : RefreshIndicator(
                onRefresh: _yukle, color: _R.orange,
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                  itemCount: _filtreli.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) => _iadeKarti(_filtreli[i]),
                ),
              ),
      ),
    ]);
  }

  Widget _gecmisOzet(double toplam) => Container(
    margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
          colors: [_R.primary, Color(0xFF2A4080)],
          begin: Alignment.topLeft, end: Alignment.bottomRight),
      borderRadius: BorderRadius.circular(16),
      boxShadow: [BoxShadow(color: _R.primary.withOpacity(0.25), blurRadius: 12, offset: const Offset(0, 4))],
    ),
    child: Row(children: [
      _ozItem('Toplam Kayıt', _filtreli.length.toDouble(), Colors.white, isSayi: true),
      _ozDiv(),
      _ozItem('Toplam Tutar', toplam, _R.orange),
    ]),
  );

  Widget _ozItem(String l, double v, Color c, {bool isSayi = false}) => Expanded(
    child: Column(children: [
      Text(l, style: const TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w500)),
      const SizedBox(height: 2),
      Text(isSayi ? v.toInt().toString() : '${v.toStringAsFixed(2)} ₺',
          style: TextStyle(color: c, fontSize: 16, fontWeight: FontWeight.w800)),
    ]),
  );

  Widget _ozDiv() => Container(
      width: 1, height: 28, color: Colors.white12,
      margin: const EdgeInsets.symmetric(horizontal: 8));

  Widget _filtreChipler() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
    child: Wrap(spacing: 8, children: [
      if (_filtreTedarikci != null)
        _chip('Tedarikçi: $_filtreTedarikci', () => setState(() { _filtreTedarikci = null; _filtrele(); })),
      if (_filtreBas != null && _filtreBit != null)
        _chip(
          '${DateFormat('dd.MM').format(_filtreBas!)} – ${DateFormat('dd.MM.yy').format(_filtreBit!)}',
          () => setState(() { _filtreBas = null; _filtreBit = null; _filtrele(); }),
        ),
    ]),
  );

  Widget _chip(String s, VoidCallback onDel) => Chip(
    label: Text(s, style: const TextStyle(fontSize: 11, color: _R.textD)),
    deleteIcon: const Icon(Icons.close_rounded, size: 13, color: _R.textL),
    onDeleted: onDel,
    backgroundColor: _R.bg,
    side: const BorderSide(color: _R.border),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    padding: EdgeInsets.zero,
  );

  Widget _bosGecmis() => Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Container(padding: const EdgeInsets.all(26),
        decoration: const BoxDecoration(color: _R.border, shape: BoxShape.circle),
        child: const Icon(Icons.history_rounded, size: 48, color: _R.textL)),
    const SizedBox(height: 16),
    const Text('İade kaydı bulunamadı',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: _R.textL)),
  ]));

  Widget _iadeKarti(IadeKaydi iade) {
    final tutar = iade.alisFiyati * iade.iadeMiktari * (1 + (iade.kdvOrani ?? 0) / 100);
    final tarih = DateFormat('dd.MM.yyyy').format(iade.tarih);
    final saat  = DateFormat('HH:mm').format(iade.tarih);

    return Dismissible(
      key: ValueKey('iade_${iade.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        decoration: BoxDecoration(color: _R.red, borderRadius: BorderRadius.circular(16)),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Icon(Icons.delete_outline_rounded, color: Colors.white, size: 26),
      ),
      confirmDismiss: (_) => _onay('${iade.urunAdi} iadesini sil?'),
      onDismissed: (_) => _sil(iade),
      child: InkWell(
        onTap: () { _duzenlenenSet(iade); _tab.animateTo(0); },
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _R.card,
            borderRadius: BorderRadius.circular(16),
            boxShadow: const [BoxShadow(color: _R.shadow, blurRadius: 6, offset: Offset(0, 2))],
          ),
          child: Row(children: [
            // Miktar badge
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                color: _R.orange.withOpacity(0.10),
                borderRadius: BorderRadius.circular(12)),
              alignment: Alignment.center,
              child: Text(
                iade.iadeMiktari % 1 == 0
                    ? iade.iadeMiktari.toInt().toString()
                    : iade.iadeMiktari.toStringAsFixed(1),
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: _R.orange),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(iade.urunAdi,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: _R.textD),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 3),
              Row(children: [
                const Icon(Icons.business_outlined, size: 11, color: _R.textL),
                const SizedBox(width: 3),
                Text(iade.tedarikci ?? '—', style: const TextStyle(fontSize: 11, color: _R.textL)),
                const SizedBox(width: 8),
                const Icon(Icons.schedule_rounded, size: 11, color: _R.textL),
                const SizedBox(width: 3),
                Text('$tarih $saat', style: const TextStyle(fontSize: 11, color: _R.textL)),
              ]),
              if ((iade.indirimNotu ?? '').isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: _R.green.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(6)),
                    child: Text('%${iade.indirimNotu} indirim',
                        style: const TextStyle(fontSize: 10, color: _R.green, fontWeight: FontWeight.w600)),
                  ),
                ),
            ])),
            const SizedBox(width: 8),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('${tutar.toStringAsFixed(2)} ₺',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: _R.textD)),
              Text('${iade.alisFiyati.toStringAsFixed(2)} ₺/ad',
                  style: const TextStyle(fontSize: 11, color: _R.textL)),
            ]),
          ]),
        ),
      ),
    );
  }

  void _duzenlenenSet(IadeKaydi iade) {
    setState(() {
      _duzenle = iade; _secilenUrun = null;
      _orijinalFiyat = iade.orijinalAlisFiyati;
      _fiyatCtrl.text = iade.alisFiyati.toStringAsFixed(2);
      _miktar = iade.iadeMiktari; _miktarCtrl.text = _miktar.toString();
      _barkodGor = false;
      _indCtrl.text = _temizInd(iade.indirimNotu ?? '');
      final t = _tedarikciler.cast<Musteri?>()
          .firstWhere((t) => t?.unvan == iade.tedarikci, orElse: () => _tedarikci);
      if (t != null) _tedarikci = t;
    });
  }

  // ── Filtre bottom sheet ───────────────────────────────────────────────────
  void _filtreSheet() => showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      String? ted = _filtreTedarikci;
      DateTime? bas = _filtreBas, bit = _filtreBit;
      return StatefulBuilder(builder: (ctx, ss) {
        return Container(
          decoration: const BoxDecoration(
            color: _R.card,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          padding: EdgeInsets.fromLTRB(20, 12, 20,
              24 + MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(color: _R.border, borderRadius: BorderRadius.circular(2))),
            const Text('Filtrele', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 16),
            DropdownButtonFormField<String?>(
              value: ted,
              isExpanded: true,
              decoration: InputDecoration(
                labelText: 'Tedarikçi',
                filled: true, fillColor: _R.bg,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text('Tümü')),
                ..._tedarikciler.map((t) => DropdownMenuItem(value: t.unvan, child: Text(t.unvan))),
              ],
              onChanged: (v) => ss(() => ted = v),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: OutlinedButton(
                onPressed: () async {
                  final d = await showDatePicker(
                    context: ctx, initialDate: bas ?? DateTime.now(),
                    firstDate: DateTime(2020), lastDate: DateTime.now());
                  if (d != null) ss(() => bas = d);
                },
                style: OutlinedButton.styleFrom(side: const BorderSide(color: _R.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: Text(bas == null ? 'Başlangıç' : DateFormat('dd.MM.yyyy').format(bas!),
                    style: const TextStyle(color: _R.textD, fontSize: 13)),
              )),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text('–', style: TextStyle(color: _R.textL))),
              Expanded(child: OutlinedButton(
                onPressed: () async {
                  final d = await showDatePicker(
                    context: ctx, initialDate: bit ?? DateTime.now(),
                    firstDate: DateTime(2020), lastDate: DateTime.now());
                  if (d != null) ss(() => bit = d);
                },
                style: OutlinedButton.styleFrom(side: const BorderSide(color: _R.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: Text(bit == null ? 'Bitiş' : DateFormat('dd.MM.yyyy').format(bit!),
                    style: const TextStyle(color: _R.textD, fontSize: 13)),
              )),
            ]),
            const SizedBox(height: 20),
            Row(children: [
              Expanded(child: OutlinedButton(
                onPressed: () {
                  setState(() { _filtreTedarikci = null; _filtreBas = null; _filtreBit = null; _filtrele(); });
                  Navigator.pop(ctx);
                },
                style: OutlinedButton.styleFrom(side: const BorderSide(color: _R.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 14)),
                child: const Text('Temizle', style: TextStyle(color: _R.textL)),
              )),
              const SizedBox(width: 12),
              Expanded(flex: 2, child: FilledButton(
                onPressed: () {
                  setState(() { _filtreTedarikci = ted; _filtreBas = bas; _filtreBit = bit; _filtrele(); });
                  Navigator.pop(ctx);
                },
                style: FilledButton.styleFrom(
                  backgroundColor: _R.primary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text('Uygula', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
              )),
            ]),
          ]),
        );
      });
    },
  );

  // ── Yardımcı widget'lar ───────────────────────────────────────────────────
  Widget _ikonBtn({required IconData icon, required Color color, required VoidCallback onTap}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          width: 50, height: 50,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 3))],
          ),
          child: Icon(icon, color: Colors.white, size: 22),
        ),
      );

  Widget _miniBtn(IconData icon, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(8),
    child: Container(
      width: 28, height: 28,
      decoration: BoxDecoration(color: _R.bg, borderRadius: BorderRadius.circular(8)),
      child: Icon(icon, size: 16, color: _R.textL),
    ),
  );

  Widget _field({
    required TextEditingController ctrl,
    required String label,
    required IconData icon,
    String? suffix,
    TextInputFormatter? fmt,
  }) =>
      TextField(
        controller: ctrl,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: fmt != null ? [fmt] : null,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(fontSize: 13, color: _R.textL),
          prefixIcon: Icon(icon, size: 18, color: _R.textL),
          suffixText: suffix,
          suffixStyle: const TextStyle(color: _R.textL, fontSize: 13),
          filled: true, fillColor: _R.bg,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _R.orange, width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        ),
      );
}