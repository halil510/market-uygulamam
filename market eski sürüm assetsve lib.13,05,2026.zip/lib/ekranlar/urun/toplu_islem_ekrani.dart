import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';

class TopluIslemEkrani extends StatefulWidget {
  final List<Urun> seciliUrunler;

  const TopluIslemEkrani({Key? key, required this.seciliUrunler}) : super(key: key);

  @override
  _TopluIslemEkraniState createState() => _TopluIslemEkraniState();
}

class _TopluIslemEkraniState extends State<TopluIslemEkrani> {
  final UrunRepoSitory _urunRepo = UrunRepoSitory();
  bool _isLoading = false;
  String? _seciliAlan;
  String? _islemTuru;
  final TextEditingController _degerController = TextEditingController();

  // Kullanılabilir alanlar (yeni alanlar eklendi)
  final List<String> _alanlar = [
    'alisFiyat',
    'alisFiyatKdvDahil',
    'satisFiyat',
    'stokMiktari',
    'indirimOrani',
    'indirimliFiyat',
    'kdvOrani',
    'birim',
    'anagrup',
    'altGrup',
    'alan1',
    'alan2',
    'marka',
    'mens'
  ];

  // Alanların Türkçe karşılıkları
  final Map<String, String> _alanAdlari = {
    'alisFiyat': 'Alış Fiyatı',
    'alisFiyatKdvDahil': 'KDV Dahil Alış Fiyatı',
    'satisFiyat': 'Satış Fiyatı',
    'stokMiktari': 'Stok Miktarı',
    'indirimOrani': 'İndirim Oranı',
    'indirimliFiyat': 'İndirimli Fiyat',
    'kdvOrani': 'KDV Oranı',
    'birim': 'Birim',
    'anagrup': 'Ana Grup',
    'altGrup': 'Alt Grup',
    'alan1': 'Alan 1',
    'alan2': 'Alan 2',
    'marka': 'Marka',
    'mens': 'Menşei',
  };

  @override
  void initState() {
    super.initState();
    _islemTuru = 'degistir';
  }

  @override
  void dispose() {
    _degerController.dispose();
    super.dispose();
  }

  Future<void> _topluGuncelle() async {
    if (_seciliAlan == null) {
      _showMessage('Lütfen bir alan seçin');
      return;
    }

    if (_degerController.text.isEmpty) {
      _showMessage('Lütfen bir değer girin');
      return;
    }

    setState(() => _isLoading = true);

    try {
      for (var urun in widget.seciliUrunler) {
        var guncellenenUrun = _urunuGuncelle(urun);
        await _urunRepo.urunGuncelle(guncellenenUrun);
      }
      
      _showMessage('${widget.seciliUrunler.length} ürün güncellendi');
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      _showMessage('Hata: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Urun _urunuGuncelle(Urun urun) {
    var guncellenenUrun = Urun(
      id: urun.id,
      kod: urun.kod,
      barkod: urun.barkod,
      ad: urun.ad,
      satisFiyat: urun.satisFiyat,
      stokMiktari: urun.stokMiktari,
      barkodlar: urun.barkodlar,
      birim: urun.birim,
      alisFiyat: urun.alisFiyat,
      alisFiyatKdvDahil: urun.alisFiyatKdvDahil,
      alisKdvOrani: urun.alisKdvOrani,
      kdvOrani: urun.kdvOrani,
      anagrup: urun.anagrup,
      altGrup: urun.altGrup,
      alan1: urun.alan1,
      alan2: urun.alan2,
      paraBirimi: urun.paraBirimi,
      marka: urun.marka,
      indirimOrani: urun.indirimOrani,
      indirimliFiyat: urun.indirimliFiyat,
      boy: urun.boy,
      resimYolu: urun.resimYolu,
      mens: urun.mens,
      karOrani: urun.karOrani,
      fiyatGuncellemeTarihi: urun.fiyatGuncellemeTarihi,
      maliyetGuncellemeTarihi: urun.maliyetGuncellemeTarihi,
      promosyonAktif: urun.promosyonAktif,
    );

    final deger = _degerController.text;
    final artisMiktari = double.tryParse(deger) ?? 0.0;

    // Alan güncelleme
    switch (_seciliAlan) {
      case 'alisFiyat':
        if (_islemTuru == 'degistir') {
          guncellenenUrun.alisFiyat = artisMiktari;
          _hesaplaKdvliAlisFiyati(guncellenenUrun); // KDV'li fiyatı hesapla
        } else if (_islemTuru == 'arttir') {
          guncellenenUrun.alisFiyat = (urun.alisFiyat ?? 0) + artisMiktari;
          _hesaplaKdvliAlisFiyati(guncellenenUrun); // KDV'li fiyatı hesapla
        }
        break;
        
      case 'alisFiyatKdvDahil':
        if (_islemTuru == 'degistir') {
          guncellenenUrun.alisFiyatKdvDahil = artisMiktari;
          _hesaplaAlisFiyati(guncellenenUrun); // Alış fiyatını hesapla
        } else if (_islemTuru == 'arttir') {
          guncellenenUrun.alisFiyatKdvDahil = (urun.alisFiyatKdvDahil ?? 0) + artisMiktari;
          _hesaplaAlisFiyati(guncellenenUrun); // Alış fiyatını hesapla
        }
        break;
        
      case 'kdvOrani':
        if (_islemTuru == 'degistir') {
          guncellenenUrun.kdvOrani = artisMiktari;
          _hesaplaKdvliAlisFiyati(guncellenenUrun); // KDV'li fiyatı hesapla
        } else if (_islemTuru == 'arttir') {
          guncellenenUrun.kdvOrani = (urun.kdvOrani ?? 0) + artisMiktari;
          _hesaplaKdvliAlisFiyati(guncellenenUrun); // KDV'li fiyatı hesapla
        }
        break;
        
      case 'satisFiyat':
        if (_islemTuru == 'degistir') {
          guncellenenUrun.satisFiyat = artisMiktari;
        } else if (_islemTuru == 'arttir') {
          guncellenenUrun.satisFiyat = (urun.satisFiyat ?? 0) + artisMiktari;
        }
        break;
        
      case 'stokMiktari':
        if (_islemTuru == 'degistir') {
          guncellenenUrun.stokMiktari = artisMiktari;
        } else if (_islemTuru == 'arttir') {
          guncellenenUrun.stokMiktari = (urun.stokMiktari ?? 0) + artisMiktari;
        }
        break;
        
      case 'indirimOrani':
        if (_islemTuru == 'degistir') {
          guncellenenUrun.indirimOrani = artisMiktari;
        } else if (_islemTuru == 'arttir') {
          guncellenenUrun.indirimOrani = (urun.indirimOrani ?? 0) + artisMiktari;
        }
        break;
        
      case 'indirimliFiyat':
        if (_islemTuru == 'degistir') {
          guncellenenUrun.indirimliFiyat = artisMiktari;
        } else if (_islemTuru == 'arttir') {
          guncellenenUrun.indirimliFiyat = (urun.indirimliFiyat ?? 0) + artisMiktari;
        }
        break;
        
      // Metinsel alanlar
      case 'birim':
        guncellenenUrun.birim = deger;
        break;
        
      case 'anagrup':
        guncellenenUrun.anagrup = deger;
        break;
        
      case 'altGrup':
        guncellenenUrun.altGrup = deger;
        break;
        
      case 'alan1':
        guncellenenUrun.alan1 = deger;
        break;
        
      case 'alan2':
        guncellenenUrun.alan2 = deger;
        break;
        
      case 'marka':
        guncellenenUrun.marka = deger;
        break;
        
      case 'mens':
        guncellenenUrun.mens = deger;
        break;
    }

    return guncellenenUrun;
  }

  // KDV'li alış fiyatını hesapla
  void _hesaplaKdvliAlisFiyati(Urun urun) {
    if (urun.alisFiyat != null && urun.kdvOrani != null) {
      urun.alisFiyatKdvDahil = urun.alisFiyat! * (1 + urun.kdvOrani! / 100);
    }
  }

  // Alış fiyatını hesapla
  void _hesaplaAlisFiyati(Urun urun) {
    if (urun.alisFiyatKdvDahil != null && urun.kdvOrani != null) {
      urun.alisFiyat = urun.alisFiyatKdvDahil! / (1 + urun.kdvOrani! / 100);
    }
  }

  void _showMessage(String mesaj) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mesaj)));
  }

  @override
  Widget build(BuildContext context) {
    // Metinsel alanlar için işlem türü kontrolü
    final metinselAlanlar = ['birim', 'anagrup', 'altGrup', 'alan1', 'alan2', 'marka', 'mens'];
    final sayisalAlan = _seciliAlan != null && !metinselAlanlar.contains(_seciliAlan);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text("Toplu İşlem Ekranı"),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _isLoading ? null : _topluGuncelle,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${widget.seciliUrunler.length} Ürün Seçildi',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  
                  // Alan Seçimi
                  const Text('Hangi Alanı Güncellemek İstiyorsunuz?'),
                  DropdownButtonFormField<String>(
                    value: _seciliAlan,
                    items: _alanlar.map((alan) {
                      return DropdownMenuItem<String>(
                        value: alan,
                        child: Text(_alanAdlari[alan] ?? alan),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() => _seciliAlan = value);
                    },
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Alan Seçin',
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // İşlem Türü (Sadece sayısal alanlar için)
                  if (sayisalAlan)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('İşlem Türü:'),
                        Row(
                          children: [
                            Expanded(
                              child: RadioListTile<String>(
                                title: const Text('Değiştir'),
                                value: 'degistir',
                                groupValue: _islemTuru,
                                onChanged: (value) {
                                  setState(() => _islemTuru = value);
                                },
                              ),
                            ),
                            Expanded(
                              child: RadioListTile<String>(
                                title: const Text('Arttır'),
                                value: 'arttir',
                                groupValue: _islemTuru,
                                onChanged: (value) {
                                  setState(() => _islemTuru = value);
                                },
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  
                  // Değer Girişi
                  const SizedBox(height: 20),
                  TextField(
                    controller: _degerController,
                    decoration: InputDecoration(
                      labelText: _seciliAlan != null && metinselAlanlar.contains(_seciliAlan) 
                          ? 'Yeni Değer' 
                          : (_islemTuru == 'degistir' ? 'Yeni Değer' : 'Artış Miktarı'),
                      border: const OutlineInputBorder(),
                    ),
                    keyboardType: sayisalAlan
                        ? TextInputType.number
                        : TextInputType.text,
                  ),
                  const SizedBox(height: 20),
                  
                  // Açıklama
                  if (_seciliAlan != null)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Text(
                        _islemTuru == 'degistir' || !sayisalAlan
                            ? 'Tüm seçili ürünlerin ${_alanAdlari[_seciliAlan]} değerini belirlediğiniz değere SET edecek'
                            : 'Tüm seçili ürünlerin ${_alanAdlari[_seciliAlan]} değerini belirlediğiniz miktarda ARTTIRACAK',
                        style: TextStyle(
                          color: Colors.blue[700],
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                  
                  // Özel hesaplama açıklamaları
                  if (_seciliAlan == 'alisFiyat' || _seciliAlan == 'kdvOrani')
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Text(
                        'KDV Dahil Alış Fiyatı otomatik hesaplanacak',
                        style: TextStyle(color: Colors.green[700], fontStyle: FontStyle.italic),
                      ),
                    ),
                  
                  if (_seciliAlan == 'alisFiyatKdvDahil')
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Text(
                        'Alış Fiyatı otomatik hesaplanacak',
                        style: TextStyle(color: Colors.green[700], fontStyle: FontStyle.italic),
                      ),
                    ),
                  
                  // Seçilen Ürünler Listesi
                  const SizedBox(height: 20),
                  const Text('Seçilen Ürünler:', style: TextStyle(fontWeight: FontWeight.bold)),
                  Expanded(
                    child: ListView.builder(
                      itemCount: widget.seciliUrunler.length,
                      itemBuilder: (context, index) {
                        final urun = widget.seciliUrunler[index];
                        return ListTile(
                          title: Text(urun.ad ?? 'İsimsiz Ürün'),
                          subtitle: Text('Barkod: ${urun.barkod ?? '-'}'),
                          trailing: _seciliAlan != null 
                              ? _getAlanDegeri(urun, _seciliAlan!) 
                              : null,
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _getAlanDegeri(Urun urun, String alan) {
    String deger = '';
    String ek = '';
    
    switch (alan) {
      case 'alisFiyat': 
        deger = urun.alisFiyat?.toStringAsFixed(2) ?? '-';
        ek = ' ₺';
        break;
      case 'alisFiyatKdvDahil': 
        deger = urun.alisFiyatKdvDahil?.toStringAsFixed(2) ?? '-';
        ek = ' ₺';
        break;
      case 'satisFiyat': 
        deger = urun.satisFiyat?.toStringAsFixed(2) ?? '-';
        ek = ' ₺';
        break;
      case 'stokMiktari': 
        deger = urun.stokMiktari?.toStringAsFixed(2) ?? '-';
        break;
      case 'indirimOrani': 
        deger = urun.indirimOrani?.toStringAsFixed(2) ?? '-';
        ek = '%';
        break;
      case 'indirimliFiyat': 
        deger = urun.indirimliFiyat?.toStringAsFixed(2) ?? '-';
        ek = ' ₺';
        break;
      case 'kdvOrani': 
        deger = urun.kdvOrani?.toStringAsFixed(2) ?? '-';
        ek = '%';
        break;
      case 'birim': 
        deger = urun.birim ?? '-';
        break;
      case 'anagrup': 
        deger = urun.anagrup ?? '-';
        break;
      case 'altGrup': 
        deger = urun.altGrup ?? '-';
        break;
      case 'alan1': 
        deger = urun.alan1 ?? '-';
        break;
      case 'alan2': 
        deger = urun.alan2 ?? '-';
        break;
      case 'marka': 
        deger = urun.marka ?? '-';
        break;
      case 'mens': 
        deger = urun.mens ?? '-';
        break;
    }
    
    return Text('$deger$ek', style: TextStyle(
      fontWeight: FontWeight.bold,
      color: Colors.blue[700],
      fontSize: 14
    ));
  }
}