// lib/ekranlar/musteri/cari_kayit_ekrani.dart
import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modeller/musteri.dart';
import 'package:market_uygulamasi/repozitory/musteri_repo.dart';

class CariKayitEkrani extends StatefulWidget {
  final Musteri? duzenlenecekCari;

  const CariKayitEkrani({Key? key, this.duzenlenecekCari}) : super(key: key);

  @override
  _CariKayitEkraniState createState() => _CariKayitEkraniState();
}

class _CariKayitEkraniState extends State<CariKayitEkrani> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _cariKoduController = TextEditingController();
  final TextEditingController _unvanController = TextEditingController();
  final TextEditingController _telefonController = TextEditingController();
  final TextEditingController _adresController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _vergiDairesiController = TextEditingController();
  final TextEditingController _vergiNoController = TextEditingController();
  final TextEditingController _bakiyeController = TextEditingController();
  final TextEditingController _anaGrupController = TextEditingController();

  String cariTipi = 'Müşteri';
  final MusteriRepo _musteriRepo = MusteriRepo();

  @override
  void initState() {
    super.initState();
    if (widget.duzenlenecekCari != null) {
      final m = widget.duzenlenecekCari!;
      _cariKoduController.text = m.cariKodu;
      _unvanController.text = m.unvan;
      cariTipi = m.cariTipi;
      _telefonController.text = m.telefon ?? '';
       _adresController.text = m.adres ?? '';
      _emailController.text = m.email ?? '';
      _vergiDairesiController.text = m.vergiDairesi ?? '';
      _vergiNoController.text = m.vergiNo ?? '';
      _bakiyeController.text = m.bakiye.toString();
      _anaGrupController.text = m.anaGrup ?? '';
    }
  }

  void _kaydet() async {
    if (_formKey.currentState!.validate()) {
      final yeniCari = Musteri(
        id: widget.duzenlenecekCari?.id,
        cariKodu: _cariKoduController.text,
        unvan: _unvanController.text,
        cariTipi: cariTipi,
        telefon: _telefonController.text,
        adres: _adresController.text,
        email: _emailController.text.isNotEmpty ? _emailController.text : null,
        vergiDairesi: _vergiDairesiController.text.isNotEmpty
            ? _vergiDairesiController.text
            : null,
        vergiNo:
            _vergiNoController.text.isNotEmpty ? _vergiNoController.text : null,
        bakiye: double.tryParse(_bakiyeController.text) ?? 0.0,
        anaGrup: _anaGrupController.text.isNotEmpty
            ? _anaGrupController.text
            : null,
      );

      if (widget.duzenlenecekCari == null) {
        await _musteriRepo.cariEkle(yeniCari);
      } else {
        await _musteriRepo.cariGuncelle(yeniCari);
      }

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.duzenlenecekCari == null
            ? 'Yeni Cari'
            : 'Cari Düzenle'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _cariKoduController,
                decoration: InputDecoration(
                  labelText: 'Cari Kodu',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Cari Kodu giriniz' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _unvanController,
                decoration: InputDecoration(
                  labelText: 'Unvan',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Unvan giriniz' : null,
              ),
              SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: cariTipi,
                items: const [
                  DropdownMenuItem(value: 'Müşteri', child: Text('Müşteri')),
                  DropdownMenuItem(
                      value: 'Tedarikçi', child: Text('Tedarikçi')),
                ],
                onChanged: (v) {
                  if (v != null) {
                    setState(() => cariTipi = v);
                  }
                },
                decoration: InputDecoration(
                  labelText: 'Cari Tipi',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _telefonController,
                decoration: InputDecoration(
                  labelText: 'Telefon',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
                validator: (v) =>
                    v == null || v.isEmpty ? 'Telefon giriniz' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _adresController,
                decoration: InputDecoration(
                  labelText: 'Adres',
                  border: OutlineInputBorder(),
                ),
                maxLines: 2,
                validator: (v) =>
                    v == null || v.isEmpty ? 'Adres giriniz' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _vergiDairesiController,
                decoration: InputDecoration(
                  labelText: 'Vergi Dairesi',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _vergiNoController,
                decoration: InputDecoration(
                  labelText: 'Vergi No',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _bakiyeController,
                decoration: InputDecoration(
                  labelText: 'Bakiye',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _anaGrupController,
                decoration: InputDecoration(
                  labelText: 'Ana Grup',
                  border: OutlineInputBorder(),
                ),
              ),
             SizedBox(height: 24),
ElevatedButton(
  onPressed: _kaydet,
  style: ElevatedButton.styleFrom(
    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 16),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10),
    ), // RoundedRectangleBorder kapatıldı
  ), // styleFrom kapatıldı
  child: Text('Kaydet', style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}