import 'package:flutter/material.dart';
import 'package:market_uygulamasi/modern_ui/widgets/modern_button.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../servisler/veritabani_yardimcisi.dart';

class VeritabaniYonetimiEkrani extends StatelessWidget {
  const VeritabaniYonetimiEkrani({super.key});

  Future<void> veritabaniYedekle(BuildContext context) async {
    try {
      final dbPath = await getDatabasesPath();
      final kaynakDb = File(join(dbPath, 'market.db'));
      final externalDir = await getExternalStorageDirectory();
      if (externalDir == null) {
        _gosterSnackbar(context, '❌ Dış depolama dizini bulunamadı.');
        return;
      }
      final hedefDb = File('${externalDir.path}/market_yedek.db');

      if (await kaynakDb.exists()) {
        await kaynakDb.copy(hedefDb.path);
        _gosterSnackbar(context, '✅ Veritabanı yedeklendi:\n${hedefDb.path}');
      } else {
        _gosterSnackbar(context, '❌ Orijinal veritabanı bulunamadı.');
      }
    } catch (e) {
      _gosterSnackbar(context, '⚠️ Yedekleme hatası: $e');
    }
  }

  Future<void> veritabaniYukle(BuildContext context) async {
    try {
      final externalDir = await getExternalStorageDirectory();
      if (externalDir == null) {
        _gosterSnackbar(context, '❌ Dış depolama dizini bulunamadı.');
        return;
      }
      final kaynakDb = File('${externalDir.path}/market_yedek.db');

      if (!await kaynakDb.exists()) {
        _gosterSnackbar(context, '❌ Yedek veritabanı bulunamadı:\n${kaynakDb.path}');
        return;
      }

      final dbPath = await getDatabasesPath();
      final hedefDb = File(join(dbPath, 'market.db'));

      if (await hedefDb.exists()) {
        final sonuc = await _onayAl(context, 'Mevcut veritabanının üzerine yazılacak. Devam edilsin mi?');
        if (!sonuc) return;
      }

      await kaynakDb.copy(hedefDb.path);
      _gosterSnackbar(context, '✅ Veritabanı geri yüklendi:\n${hedefDb.path}');
    } catch (e) {
      _gosterSnackbar(context, '⚠️ Yükleme hatası: $e');
    }
  }

  Future<void> veritabaniPaylas(BuildContext context) async {
    try {
      final dbPath = await getDatabasesPath();
      final dbFile = File(join(dbPath, 'market.db'));

      if (await dbFile.exists()) {
        await Share.shareXFiles([XFile(dbFile.path)], text: 'market.db veritabanı yedeği');
      } else {
        _gosterSnackbar(context, '❌ Veritabanı bulunamadı');
      }
    } catch (e) {
      _gosterSnackbar(context, '⚠️ Paylaşım hatası: $e');
    }
  }

  Future<void> veritabaniSifirla(BuildContext context) async {
    try {
      final onay = await _onayAl(context, 'Veritabanı sıfırlanacak. Emin misiniz? Bu işlem geri alınamaz.');
      if (!onay) return;

      await VeritabaniYardimcisi.resetDatabase();

      _gosterSnackbar(context, '✅ Veritabanı sıfırlandı ve yeniden oluşturuldu.');
    } catch (e) {
      _gosterSnackbar(context, '⚠️ Sıfırlama hatası: $e');
    }
  }

  void _gosterSnackbar(BuildContext context, String mesaj) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mesaj), duration: const Duration(seconds: 4)),
    );
  }

  Future<bool> _onayAl(BuildContext context, String mesaj) async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Onay Gerekli'),
            content: Text(mesaj),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Vazgeç'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Evet'),
              ),
            ],
          ),
        ) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    const double spacing = 20;
    return Scaffold(
      appBar: AppBar(title: const Text('Veritabanı Yönetimi')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Veritabanı yedekleme, yükleme, paylaşma ve sıfırlama işlemlerini buradan yapabilirsiniz.',
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: spacing),

              ModernButton(
                icon: Icons.upload_file,
                text: '💾 Veritabanını Yükle',
                onPressed: () => veritabaniYukle(context),
                width: double.infinity,
                borderRadius: 16,
              ),
              const SizedBox(height: spacing),

              ModernButton(
                icon: Icons.download,
                text: '📤 Veritabanını Yedekle',
                onPressed: () => veritabaniYedekle(context),
                width: double.infinity,
                borderRadius: 16,
              ),
              const SizedBox(height: spacing),

              ModernButton(
                icon: Icons.share,
                text: '📤 Veritabanını Paylaş',
                onPressed: () => veritabaniPaylas(context),
                width: double.infinity,
                borderRadius: 16,
              ),
              const SizedBox(height: spacing),

              ModernButton(
                icon: Icons.restart_alt,
                text: '🔁 Veritabanını Sıfırla',
                onPressed: () => veritabaniSifirla(context),
                width: double.infinity,
                borderRadius: 16,
                gradientColors: [Colors.red.shade400, Colors.red.shade700],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
