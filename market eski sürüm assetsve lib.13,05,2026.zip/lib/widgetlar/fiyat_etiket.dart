import 'package:flutter/material.dart';
import 'package:market_uygulamasi/yardimci/sabitler.dart';

class FiyatEtiket extends StatelessWidget {
  const FiyatEtiket({Key? key}) : super(key: key);

  final double fiyat;
  final double? indirimliFiyat;

  const FiyatEtiket({Key? key, required this.fiyat, this.indirimliFiyat}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (indirimliFiyat == null) {
      return Text(
        '$fiyat ₺',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Sabitler.anaRenk,
        ),
      );
    } else {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$indirimliFiyat ₺',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Sabitler.uyariRenk,
            ),
          ),
          Text(
            '$fiyat ₺',
            style: TextStyle(
              decoration: TextDecoration.lineThrough,
              color: Colors.grey,
            ),
          ),
        ],
      );
    }
  }
}