// lib/ekranlar/promosyon/promosyon.dart

import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:market_uygulamasi/modeller/promosyon.dart';
import 'package:market_uygulamasi/modeller/urun.dart';
import 'package:market_uygulamasi/repozitory/promosyon_repo.dart';
import 'package:market_uygulamasi/repozitory/urun_repo.dart';
import 'package:market_uygulamasi/widgetlar/barkod_tarayici.dart';

// ─── Renk paleti (açık/ferah tonlar) ────────────────────────────────────────
class _R {
  static const bg      = Color(0xFFF8FAFF);   // çok açık mavi-beyaz
  static const card    = Color(0xFFFFFFFF);
  static const primary = Color(0xFF2C3E66);   // yumuşak lacivert
  static const purple  = Color(0xFF9B6BFF);   // pastel mor
  static const green   = Color(0xFF34D399);
  static const red     = Color(0xFFF87171);
  static const orange  = Color(0xFFFBBF24);
  static const textD   = Color(0xFF1E293B);
  static const textL   = Color(0xFF94A3B8);
  static const border  = Color(0xFFE2E8F0);
  static const shadow  = Color(0x0A000000);   // hafif gölge
}

// ─────────────────────────────────────────────────────────────────────────────
class PromosyonEkrani extends StatefulWidget {
  final Urun?       seciliUrun;
  final List<Urun>? baslangicUrunleri;
  const PromosyonEkrani({super.key, this.seciliUrun, this.baslangicUrunleri});

  @override
  State<PromosyonEkrani> createState() => _State();
}

class _State extends State<PromosyonEkrani> {
  final _promoRepo = PromosyonRepo();
  final _urunRepo  = UrunRepoSitory();

  List<Map<String, dynamic>> _promosyonlar = [];
  List<Map<String, dynamic>> _filtreli     = [];
  List<Urun>                 _tumUrunler   = [];
  List<Urun>                 _aramaSonuclari = [];
  List<Urun>                 _bekleyenler  = [];

  bool   _yukleniyor = false;
  String _aramaMetni = '';
  bool?  _aktifFiltre; // null = tümü

  final _aramaCtrl  = TextEditingController();
  final _aramaFocus = FocusNode();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _aramaCtrl.addListener(_aramaDebounce);
    _yukle();

    if (widget.baslangicUrunleri?.isNotEmpty == true) {
      _bekleyenler = List.from(widget.baslangicUrunleri!);
    } else if (widget.seciliUrun != null) {
      _bekleyenler = [widget.seciliUrun!];
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_bekleyenler.isNotEmpty && mounted) _bekleyenDialog();
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _aramaCtrl.dispose();
    _aramaFocus.dispose();
    super.dispose();
  }

  // ── Veri ──────────────────────────────────────────────────────────────────
  Future<void> _yukle() async {
    setState(() => _yukleniyor = true);
    try {
      final [p, u] = await Future.wait([
        _promoRepo.tumPromosyonlariDetayliGetir(),
        _urunRepo.tumUrunleriGetir(),
      ]);
      if (!mounted) return;
      setState(() {
        _promosyonlar = p as List<Map<String, dynamic>>;
        _tumUrunler   = u as List<Urun>;
        _filtrele();
      });
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  void _filtrele() {
    var list = List<Map<String, dynamic>>.from(_promosyonlar);
    if (_aramaMetni.isNotEmpty) {
      final q = _aramaMetni.toLowerCase();
      list = list.where((p) =>
          (p['urun_adi'] as String).toLowerCase().contains(q) ||
          (p['barkod']?.toString().toLowerCase().contains(q) ?? false)).toList();
    }
    if (_aktifFiltre != null) {
      list = list.where((p) => (p['aktif'] == 1) == _aktifFiltre).toList();
    }
    _filtreli = list;
  }

  // ── Arama ─────────────────────────────────────────────────────────────────
  void _aramaDebounce() {
    _debounce?.cancel();
    final q = _aramaCtrl.text.trim();
    if (q.isEmpty) { setState(() { _aramaMetni = ''; _aramaSonuclari = []; _filtrele(); }); return; }
    if (q.length < 2) return;
    _debounce = Timer(const Duration(milliseconds: 280), () => _aramaYap(q));
  }

  void _aramaYap(String kelime) {
    final ql = kelime.toLowerCase();
    final res = _tumUrunler.where((u) =>
        (u.ad?.toLowerCase().contains(ql) ?? false) ||
        (u.barkod?.toLowerCase().contains(ql) ?? false) ||
        (u.barkodlar?.toLowerCase().contains(ql) ?? false)).toList();
    setState(() { _aramaMetni = kelime; _aramaSonuclari = res; _filtrele(); });
  }

  // ── Barkod ────────────────────────────────────────────────────────────────
  Future<void> _barkodOku() async {
    final barkod = await Navigator.push<String>(
        context, MaterialPageRoute(builder: (_) => BarkodTarayici()));
    if (barkod == null || barkod.isEmpty) return;
    final urun = await _urunRepo.barkodlaUrunGetir(barkod);
    if (urun != null) { _promoDialog(secilenUrun: urun); }
    else { _msg('Ürün bulunamadı!', err: true); }
  }

  // ── Bekleyen ürünler ──────────────────────────────────────────────────────
  void _bekleyenDialog() {
    if (_bekleyenler.isEmpty) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: _R.purple.withOpacity(0.10), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.local_offer_rounded, color: _R.purple, size: 20)),
          const SizedBox(width: 10),
          const Text('Promosyon Ekle', style: TextStyle(fontSize: 16)),
        ]),
        content: SizedBox(
          width: double.maxFinite,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 320),
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: _bekleyenler.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final u = _bekleyenler[i];
                return ListTile(
                  dense: true,
                  leading: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                        color: _R.purple.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.inventory_2_outlined, color: _R.purple, size: 18)),
                  title: Text(u.ad ?? '', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  subtitle: Text(u.barkod ?? '', style: const TextStyle(fontSize: 11, color: _R.textL)),
                  trailing: FilledButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _promoDialog(secilenUrun: u).then((_) {
                        setState(() => _bekleyenler.remove(u));
                        if (_bekleyenler.isNotEmpty) _bekleyenDialog();
                      });
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: _R.purple,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      textStyle: const TextStyle(fontSize: 12),
                    ),
                    child: const Text('Ekle'),
                  ),
                );
              },
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () { Navigator.pop(ctx); setState(() => _bekleyenler.clear()); },
            child: const Text('Vazgeç'),
          ),
        ],
      ),
    );
  }

  // ── Promosyon ekle / düzenle dialog ───────────────────────────────────────
  Future<void> _promoDialog({Map<String, dynamic>? mevcut, Urun? secilenUrun}) async {
    Urun? urun = secilenUrun;
    if (urun == null) {
      if (mevcut != null) {
        urun = await _urunRepo.urunGetir(mevcut['urun_id']);
      } else {
        urun = await _urunSecDialog();
      }
    }
    if (urun == null || !mounted) return;

    final miktarCtrl  = TextEditingController(text: mevcut?['miktar']?.toString() ?? '');
    final iskontoCtrl = TextEditingController(text: mevcut?['iskonto_orani']?.toString() ?? '');
    final tutarCtrl   = TextEditingController();
    bool aktif        = (mevcut?['aktif'] ?? 1) == 1;
    final kartFiyat   = urun.satisFiyat;

    void hesapla({bool fromIskonto = false, bool fromTutar = false}) {
      final miktar = double.tryParse(miktarCtrl.text) ?? 0;
      if (miktar <= 0) return;
      if (fromIskonto) {
        final isc = double.tryParse(iskontoCtrl.text) ?? 0;
        tutarCtrl.text = (miktar * kartFiyat * (1 - isc / 100)).toStringAsFixed(2);
      } else if (fromTutar) {
        final tot = double.tryParse(tutarCtrl.text) ?? 0;
        if (tot > 0 && miktar > 0) {
          final birim = tot / miktar;
          iskontoCtrl.text = ((kartFiyat - birim) / kartFiyat * 100).toStringAsFixed(2);
        }
      }
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, ss) {
          final miktar  = double.tryParse(miktarCtrl.text) ?? 0;
          final iskonto = double.tryParse(iskontoCtrl.text) ?? 0;
          final birimF  = iskonto > 0 ? kartFiyat * (1 - iskonto / 100) : kartFiyat;
          final tasarruf = kartFiyat - birimF;

          return AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            titlePadding: EdgeInsets.zero,
            title: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _R.purple.withOpacity(0.06),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(20))),
              child: Row(children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: _R.purple.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.local_offer_rounded, color: _R.purple, size: 20)),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(mevcut == null ? 'Yeni Promosyon' : 'Promosyonu Düzenle',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  Text(urun!.ad ?? '', style: const TextStyle(fontSize: 12, color: _R.textL),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                ])),
              ]),
            ),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                // Kart fiyat bilgisi
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: _R.bg, borderRadius: BorderRadius.circular(12)),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Kart Satış Fiyatı',
                        style: TextStyle(fontSize: 12, color: _R.textL)),
                    Text('${kartFiyat.toStringAsFixed(2)} ₺',
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: _R.purple)),
                  ]),
                ),
                const SizedBox(height: 14),

                // Eşik miktar
                _dialogField(
                  ctrl: miktarCtrl,
                  label: 'Eşik Miktar (adet)',
                  icon: Icons.production_quantity_limits_rounded,
                  onChanged: (_) { ss(() {}); if (iskontoCtrl.text.isNotEmpty) hesapla(fromIskonto: true); },
                ),
                const SizedBox(height: 12),

                // İskonto & Tutar
                Row(children: [
                  Expanded(child: _dialogField(
                    ctrl: iskontoCtrl,
                    label: 'İskonto %',
                    icon: Icons.percent_rounded,
                    onChanged: (_) { hesapla(fromIskonto: true); ss(() {}); },
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: _dialogField(
                    ctrl: tutarCtrl,
                    label: 'Toplam Tutar (₺)',
                    icon: Icons.attach_money_rounded,
                    onChanged: (_) { hesapla(fromTutar: true); ss(() {}); },
                  )),
                ]),
                const SizedBox(height: 12),

                // Önizleme
                if (miktar > 0 && iskonto > 0)
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          colors: [_R.purple.withOpacity(0.06), _R.green.withOpacity(0.04)]),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _R.purple.withOpacity(0.15))),
                    child: Column(children: [
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        const Text('Promosyon Birim Fiyat',
                            style: TextStyle(fontSize: 12, color: _R.textL)),
                        Text('${birimF.toStringAsFixed(2)} ₺',
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: _R.purple)),
                      ]),
                      const SizedBox(height: 4),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        const Text('Birim Tasarruf',
                            style: TextStyle(fontSize: 12, color: _R.textL)),
                        Text('${tasarruf.toStringAsFixed(2)} ₺',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: _R.green)),
                      ]),
                    ]),
                  ),

                const SizedBox(height: 14),

                // Aktif toggle
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: _R.bg, borderRadius: BorderRadius.circular(12)),
                  child: Row(children: [
                    const Icon(Icons.toggle_on_rounded, size: 18, color: _R.textL),
                    const SizedBox(width: 8),
                    const Expanded(child: Text('Promosyon Aktif',
                        style: TextStyle(fontSize: 14, color: _R.textD))),
                    Switch.adaptive(
                      value: aktif,
                      activeColor: _R.purple,
                      onChanged: (v) => ss(() => aktif = v),
                    ),
                  ]),
                ),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')),
              FilledButton(
                onPressed: () {
                  final m = double.tryParse(miktarCtrl.text);
                  final isc = double.tryParse(iskontoCtrl.text);
                  if (m == null || m <= 0) { _msg('Geçerli miktar girin', err: true); return; }
                  if ((isc == null || isc <= 0) && tutarCtrl.text.isEmpty) {
                    _msg('İskonto veya tutar girin', err: true); return; }
                  Navigator.pop(ctx, true);
                },
                style: FilledButton.styleFrom(backgroundColor: _R.purple),
                child: const Text('Kaydet'),
              ),
            ],
          );
        },
      ),
    );

    if (ok != true) return;

    final miktar  = double.parse(miktarCtrl.text);
    double iskonto = double.tryParse(iskontoCtrl.text) ?? 0;
    if (iskonto <= 0 && tutarCtrl.text.isNotEmpty) {
      final tot = double.parse(tutarCtrl.text);
      if (tot > 0 && miktar > 0) {
        iskonto = ((kartFiyat - tot / miktar) / kartFiyat) * 100;
      }
    }

    final promo = Promosyon(
      id: mevcut?['id'],
      urunId: urun.id!,
      miktar: miktar,
      iskontoOrani: iskonto,
      aktif: aktif,
    );

    setState(() => _yukleniyor = true);
    try {
      if (mevcut == null) {
        await _promoRepo.promosyonEkle(promo);
        _msg('Promosyon eklendi');
      } else {
        await _promoRepo.promosyonGuncelle(promo);
        _msg('Promosyon güncellendi');
      }
      await _yukle();
    } catch (e) {
      _msg('Hata: $e', err: true);
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  // ── Ürün seç dialog ───────────────────────────────────────────────────────
  Future<Urun?> _urunSecDialog() async {
    final aramaCtrl = TextEditingController();
    List<Urun> liste = List.from(_tumUrunler);

    return showDialog<Urun>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, ss) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Ürün Seç'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                controller: aramaCtrl,
                autofocus: true,
                onChanged: (q) {
                  final ql = q.toLowerCase();
                  ss(() => liste = _tumUrunler.where((u) =>
                      (u.ad?.toLowerCase().contains(ql) ?? false) ||
                      (u.barkod?.toLowerCase().contains(ql) ?? false)).toList());
                },
                decoration: InputDecoration(
                  hintText: 'Ürün ara…',
                  prefixIcon: const Icon(Icons.search_rounded, size: 18),
                  filled: true, fillColor: _R.bg,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                  contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                ),
              ),
              const SizedBox(height: 8),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 300),
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: liste.length,
                  separatorBuilder: (_, __) => const Divider(height: 1, indent: 16),
                  itemBuilder: (_, i) {
                    final u = liste[i];
                    return ListTile(
                      dense: true,
                      leading: Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                            color: _R.purple.withOpacity(0.09),
                            borderRadius: BorderRadius.circular(8)),
                        child: const Icon(Icons.inventory_2_outlined, color: _R.purple, size: 16)),
                      title: Text(u.ad ?? '', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      subtitle: Text(u.barkod ?? '',
                          style: const TextStyle(fontSize: 11, color: _R.textL)),
                      trailing: Text('${u.satisFiyat.toStringAsFixed(2)} ₺',
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _R.purple)),
                      onTap: () => Navigator.pop(ctx, u),
                    );
                  },
                ),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal')),
          ],
        ),
      ),
    );
  }

  // ── Sil ───────────────────────────────────────────────────────────────────
  Future<void> _sil(Map<String, dynamic> p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Promosyonu Sil'),
        content: Text('${p['urun_adi']} ürününün promosyonu silinecek. Emin misiniz?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: _R.red),
            child: const Text('Sil'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _yukleniyor = true);
    try {
      await _promoRepo.promosyonSil(p['id']);
      await _yukle();
      _msg('Promosyon silindi');
    } catch (e) {
      _msg('Silme hatası: $e', err: true);
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  // ── Excel ─────────────────────────────────────────────────────────────────
  Future<void> _excelIceri() async {
    final result = await FilePicker.platform.pickFiles(
        type: FileType.custom, allowedExtensions: ['xlsx']);
    if (result?.files.single.path == null) return;
    setState(() => _yukleniyor = true);
    try {
      await _promoRepo.promosyonlariExceldenIceriAktar(File(result!.files.single.path!));
      await _yukle();
      _msg('Promosyonlar içe aktarıldı');
    } catch (e) {
      _msg('Hata: $e', err: true);
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  Future<void> _excelDisari() async {
    setState(() => _yukleniyor = true);
    try {
      final file = await _promoRepo.promosyonlariExcelDisAktar();
      if (file == null) { _msg('Aktarılacak promosyon yok', err: true); return; }
      await Share.shareFiles([file.path], text: 'Promosyon Listesi');
      _msg('Excel dışa aktarıldı');
    } catch (e) {
      _msg('Hata: $e', err: true);
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  void _msg(String s, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(err ? Icons.error_outline : Icons.check_circle_outline, color: Colors.white, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(s, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: err ? _R.red : _R.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final aktifSayi   = _promosyonlar.where((p) => p['aktif'] == 1).length;
    final pasifSayi   = _promosyonlar.length - aktifSayi;
    final ortalama    = _promosyonlar.isEmpty ? 0.0
        : _promosyonlar.fold(0.0, (s, p) => s + (p['iskonto_orani'] as num).toDouble()) / _promosyonlar.length;

    return Scaffold(
      backgroundColor: _R.bg,
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [_sliverBar(aktifSayi, pasifSayi, ortalama)],
        body: Column(children: [
          _aramaBar(),
          if (_aramaSonuclari.isNotEmpty) _aramaSonucPanel(),
          _filterChips(),
          Expanded(child: _icerik()),
        ]),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _promoDialog(),
        backgroundColor: _R.purple,
        foregroundColor: Colors.white,
        elevation: 4,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Yeni Promosyon', style: TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }

  // ── Sliver AppBar ─────────────────────────────────────────────────────────
  Widget _sliverBar(int aktif, int pasif, double ort) {
    return SliverAppBar(
      expandedHeight: 160,
      floating: false,
      pinned: true,
      backgroundColor: _R.primary,
      foregroundColor: Colors.white,
      flexibleSpace: FlexibleSpaceBar(
        titlePadding: const EdgeInsets.fromLTRB(16, 0, 0, 56),
        title: const Text('Promosyonlar',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [_R.primary, Color(0xFF5A4B8C)],
              begin: Alignment.topLeft, end: Alignment.bottomRight)),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 80, 16, 16),
            child: Row(children: [
              _statKart('Aktif', aktif.toString(), _R.green),
              const SizedBox(width: 10),
              _statKart('Pasif', pasif.toString(), _R.orange),
              const SizedBox(width: 10),
              _statKart('Ort. İskonto', '%${ort.toStringAsFixed(1)}', const Color(0xFFBB86FC)),
            ]),
          ),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.qr_code_scanner_rounded),
          tooltip: 'Barkod Okut',
          onPressed: _barkodOku,
        ),
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          onSelected: (v) {
            if (v == 'import') _excelIceri();
            else _excelDisari();
          },
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'import',
                child: ListTile(dense: true, leading: Icon(Icons.upload_file),
                    title: Text('Excel\'den İçe Aktar'))),
            const PopupMenuItem(value: 'export',
                child: ListTile(dense: true, leading: Icon(Icons.download),
                    title: Text('Excel\'e Dışa Aktar'))),
          ],
        ),
      ],
    );
  }

  Widget _statKart(String label, String val, Color valRenk) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.10),
        borderRadius: BorderRadius.circular(12)),
      child: Column(children: [
        Text(val, style: TextStyle(color: valRenk, fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
      ]),
    ),
  );

  // ── Arama bar ─────────────────────────────────────────────────────────────
  Widget _aramaBar() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
    child: Container(
      decoration: BoxDecoration(
        color: _R.card,
        borderRadius: BorderRadius.circular(14),
        boxShadow: const [BoxShadow(color: _R.shadow, blurRadius: 6, offset: Offset(0, 2))],
      ),
      child: TextField(
        controller: _aramaCtrl,
        focusNode: _aramaFocus,
        style: const TextStyle(color: _R.textD, fontSize: 15),
        decoration: InputDecoration(
          hintText: 'Ürün adı veya barkod ara…',
          hintStyle: const TextStyle(color: _R.textL, fontSize: 14),
          prefixIcon: const Icon(Icons.search_rounded, color: _R.textL, size: 20),
          suffixIcon: _aramaCtrl.text.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear_rounded, color: _R.textL, size: 18),
                  onPressed: () { _aramaCtrl.clear(); setState(() { _aramaMetni = ''; _aramaSonuclari = []; _filtrele(); }); })
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 4),
        ),
      ),
    ),
  );

  // ── Arama sonuç paneli ────────────────────────────────────────────────────
  Widget _aramaSonucPanel() => Container(
    margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
    decoration: BoxDecoration(
      color: _R.card,
      borderRadius: BorderRadius.circular(16),
      boxShadow: const [BoxShadow(color: _R.shadow, blurRadius: 6, offset: Offset(0, 2))],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
        child: Text('${_aramaSonuclari.length} ürün — promosyon eklemek için seçin',
            style: const TextStyle(fontSize: 12, color: _R.textL))),
      ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 200),
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: _aramaSonuclari.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 16),
          itemBuilder: (_, i) {
            final u = _aramaSonuclari[i];
            final mevcutPromo = _promosyonlar.where((p) => p['urun_id'] == u.id).length;
            return ListTile(
              dense: true,
              leading: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                    color: _R.purple.withOpacity(0.09), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.inventory_2_outlined, color: _R.purple, size: 18)),
              title: Text(u.ad ?? '', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              subtitle: Text(u.barkod ?? '', style: const TextStyle(fontSize: 11, color: _R.textL)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                if (mevcutPromo > 0)
                  Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                        color: _R.orange.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
                    child: Text('$mevcutPromo promo',
                        style: const TextStyle(fontSize: 10, color: _R.orange, fontWeight: FontWeight.w600))),
                Text('${u.satisFiyat.toStringAsFixed(2)} ₺',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _R.purple)),
              ]),
              onTap: () { _promoDialog(secilenUrun: u); setState(() { _aramaCtrl.clear(); _aramaSonuclari = []; }); },
            );
          },
        ),
      ),
      const SizedBox(height: 6),
    ]),
  );

  // ── Filtre chip'leri ──────────────────────────────────────────────────────
  Widget _filterChips() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
    child: SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: [
        _filterChip('Tümü', _aktifFiltre == null, () => setState(() { _aktifFiltre = null; _filtrele(); })),
        const SizedBox(width: 8),
        _filterChip('Aktif', _aktifFiltre == true, () => setState(() { _aktifFiltre = true; _filtrele(); }), color: _R.green),
        const SizedBox(width: 8),
        _filterChip('Pasif', _aktifFiltre == false, () => setState(() { _aktifFiltre = false; _filtrele(); }), color: _R.red),
        const SizedBox(width: 8),
        Text('${_filtreli.length} promosyon',
            style: const TextStyle(fontSize: 12, color: _R.textL)),
      ]),
    ),
  );

  Widget _filterChip(String label, bool secili, VoidCallback onTap, {Color? color}) =>
      GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: secili ? (color ?? _R.purple).withOpacity(0.12) : _R.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
                color: secili ? (color ?? _R.purple) : _R.border,
                width: secili ? 1.5 : 1),
          ),
          child: Text(label,
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: secili ? FontWeight.w700 : FontWeight.w500,
                  color: secili ? (color ?? _R.purple) : _R.textL)),
        ),
      );

  // ── İçerik ───────────────────────────────────────────────────────────────
  Widget _icerik() {
    if (_yukleniyor) return const Center(child: CircularProgressIndicator(color: _R.purple));
    if (_filtreli.isEmpty) return _bosEkran();
    return RefreshIndicator(
      onRefresh: _yukle,
      color: _R.purple,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        itemCount: _filtreli.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, i) => _promoKart(_filtreli[i]),
      ),
    );
  }

  Widget _bosEkran() => Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(color: _R.purple.withOpacity(0.07), shape: BoxShape.circle),
      child: const Icon(Icons.local_offer_rounded, size: 52, color: _R.purple),
    ),
    const SizedBox(height: 18),
    const Text('Promosyon bulunamadı',
        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: _R.textL)),
    const SizedBox(height: 6),
    const Text('Yeni eklemek için + butonuna basın',
        style: TextStyle(fontSize: 13, color: _R.textL)),
  ]));

  // ── Promosyon kartı (yeni: toplam tutar eklendi) ──────────────────────────
  Widget _promoKart(Map<String, dynamic> p) {
    final aktif    = p['aktif'] == 1;
    final urunAdi  = p['urun_adi'] as String? ?? '—';
    final miktar   = (p['miktar'] as num?)?.toDouble() ?? 0;
    final iskonto  = (p['iskonto_orani'] as num?)?.toDouble() ?? 0;
    final kartF    = (p['satis_fiyati'] as num?)?.toDouble() ?? 0;
    final promoF   = kartF > 0 ? kartF * (1 - iskonto / 100) : 0.0;
    final tasarruf = kartF - promoF;
    final toplamPromoTutar = miktar * promoF;   // eşik miktar için promosyonlu toplam tutar

    return Dismissible(
      key: ValueKey('promo_${p['id']}'),
      direction: DismissDirection.endToStart,
      background: Container(
        decoration: BoxDecoration(color: _R.red, borderRadius: BorderRadius.circular(18)),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Icon(Icons.delete_outline_rounded, color: Colors.white, size: 26),
      ),
      confirmDismiss: (_) async {
        final ok = await showDialog<bool>(context: context,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: const Text('Promosyonu Sil'),
            content: Text('$urunAdi promosyonunu silmek istiyor musunuz?'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true),
                  style: FilledButton.styleFrom(backgroundColor: _R.red), child: const Text('Sil')),
            ],
          ),
        );
        return ok ?? false;
      },
      onDismissed: (_) => _sil(p),
      child: Container(
        decoration: BoxDecoration(
          color: _R.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: aktif ? _R.purple.withOpacity(0.2) : _R.border,
            width: aktif ? 1.5 : 1,
          ),
          boxShadow: [BoxShadow(
              color: aktif ? _R.purple.withOpacity(0.08) : _R.shadow,
              blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Column(children: [
          // Üst bölüm
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              // İkon
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(
                  color: aktif ? _R.purple.withOpacity(0.10) : _R.bg,
                  borderRadius: BorderRadius.circular(13)),
                child: Icon(Icons.local_offer_rounded,
                    color: aktif ? _R.purple : _R.textL, size: 22),
              ),
              const SizedBox(width: 12),
              // Ürün bilgisi
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(urunAdi,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: _R.textD),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: _R.orange.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(6)),
                    child: Text(
                      '${miktar.toInt()} adet üzeri',
                      style: const TextStyle(fontSize: 11, color: _R.orange, fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: _R.purple.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(6)),
                    child: Text(
                      '%${iskonto.toStringAsFixed(1)} indirim',
                      style: const TextStyle(fontSize: 11, color: _R.purple, fontWeight: FontWeight.w600)),
                  ),
                ]),
              ])),
              // Aktif badge & menu
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: aktif ? _R.green.withOpacity(0.12) : _R.red.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(20)),
                  child: Text(aktif ? 'Aktif' : 'Pasif',
                      style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                          color: aktif ? _R.green : _R.red)),
                ),
                const SizedBox(height: 6),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  _miniBtn(Icons.edit_outlined, () => _promoDialog(mevcut: p), color: _R.textL),
                  _miniBtn(Icons.delete_outline, () => _sil(p), color: _R.red),
                ]),
              ]),
            ]),
          ),

          // Fiyat bilgisi şeridi (yeni: toplam tutar eklendi)
          if (kartF > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: aktif ? _R.purple.withOpacity(0.04) : _R.bg,
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(18))),
              child: Row(children: [
                _fiyatItem('Normal Fiyat', kartF, _R.textL),
                _fiyatDiv(),
                _fiyatItem('Promo Fiyat', promoF, _R.purple),
                _fiyatDiv(),
                _fiyatItem('Tasarruf', tasarruf, _R.green),
                _fiyatDiv(),
                _fiyatItem('Toplam (${miktar.toInt()} adet)', toplamPromoTutar, _R.orange),
              ]),
            ),
        ]),
      ),
    );
  }

  Widget _fiyatItem(String label, double val, Color c) => Expanded(
    child: Column(children: [
      Text(label, style: const TextStyle(fontSize: 10, color: _R.textL, fontWeight: FontWeight.w500)),
      const SizedBox(height: 2),
      Text('${val.toStringAsFixed(2)} ₺',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: c)),
    ]),
  );

  Widget _fiyatDiv() => Container(
      width: 1, height: 28, color: _R.border,
      margin: const EdgeInsets.symmetric(horizontal: 4));

  Widget _miniBtn(IconData icon, VoidCallback onTap, {required Color color}) =>
      InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(padding: const EdgeInsets.all(4),
            child: Icon(icon, size: 17, color: color.withOpacity(0.7))),
      );

  Widget _dialogField({
    required TextEditingController ctrl,
    required String label,
    required IconData icon,
    void Function(String)? onChanged,
  }) =>
      TextField(
        controller: ctrl,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*'))],
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(fontSize: 13, color: _R.textL),
          prefixIcon: Icon(icon, size: 18, color: _R.textL),
          filled: true, fillColor: _R.bg,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _R.purple, width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        ),
      );
}