import '../servisler/bulut/bulut_manager.dart';
// lib/depolar/urun_deposu.dart
//
// Düzeltmeler:
//   - ara(): aktif = 1 filtresi eklendi (pasif ürünler arama sonucuna gelmesin)
//   - ara(): alternatif_urun_adi ve marka alanları da aranıyor
//   - sayfaliGetir(): aynı iyileştirmeler uygulandı
import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import '../servisler/log_servisi.dart';
import '../veri/database/veritabani.dart';
import '../cekirdek/sabitler/db_sabitleri.dart';
import '../modeller/urun_model.dart';

class UrunDeposu {
  final Veritabani _db = Veritabani();
  Future<Database> get _d async => _db.db;
  Future<Database> get db async => _db.db;

  /// Kullanıcı geri bildirimi: "Excel'den 4000 ürünü içe aktarırken
  /// uzun sürdü." Kök neden: normal `ekle()`/`guncelle()` fonksiyonları
  /// HER SATIR için ayrı ayrı veritabanı işlemi açıyor (4000 satır için
  /// binlerce ayrı disk yazması demek). Bu fonksiyon, mevcut ekle()/
  /// guncelle()'ye HİÇ DOKUNMADAN (diğer tüm çağıranlar aynı şekilde
  /// çalışmaya devam ediyor), SADECE toplu içe aktarım gibi
  /// performans-kritik senaryolar için TEK bir transaction içinde
  /// çalışan, çok daha hızlı bir alternatif sunuyor. Stok değişikliği
  /// takibi (event sourcing) burada da korunuyor.
  Future<Map<String, int>> topluEkleGuncelle(
      List<({UrunModel urun, int? mevcutId})> satirlar) async {
    final db = await _d;
    var eklenen = 0, guncellenen = 0;
    // ÖNCEDEN BURADA CİDDİ BİR HATA VARDI: TÜM satırlar TEK bir
    // transaction'a konmuştu — bu, hız için doğruydu AMA eğer
    // Excel'de TEK BİR satır bile sorunlu ise (örn. mükerrer barkod,
    // geçersiz veri), o TEK satırın hatası TÜM transaction'ı iptal
    // edip GERİ ALIYORDU — kullanıcının bildirdiği gibi "önceden
    // çalışıyordu, şimdi hiç çalışmıyor" tam olarak buydu. Artık her
    // satır KENDİ İÇ transaction'ında işleniyor — bir satır hata
    // verirse SADECE o satır atlanır, diğerleri (hız avantajı
    // korunarak) yine de kaydedilir.
    for (final s in satirlar) {
      try {
        int? etkilenenId;
        String? hareketGid;
        await db.transaction((txn) async {
          final m = s.urun.toMap()..remove('id');
          m['global_id'] ??= const Uuid().v4();
          m['last_updated'] = DateTime.now().toIso8601String();

          if (s.mevcutId == null) {
            final id = await txn.insert(DbSabitler.urunler, m,
                conflictAlgorithm: ConflictAlgorithm.replace);
            etkilenenId = id;
            if (s.urun.stok > 0) {
              hareketGid = const Uuid().v4();
              await txn.insert('stok_hareket', {
                'global_id': hareketGid,
                'urun_id': id,
                'hareket_turu': 'İlk Stok',
                'miktar': s.urun.stok,
                'onceki_stok': 0,
                'sonraki_stok': s.urun.stok,
                'tarih': DateTime.now().toIso8601String(),
                'last_updated': DateTime.now().toIso8601String(),
                'referans_turu': 'excel_toplu_iceri_aktarim',
              });
            }
            eklenen++;
          } else {
            etkilenenId = s.mevcutId;
            final eskiRows = await txn.query(DbSabitler.urunler,
                columns: ['stok', 'satis_fiyati', 'alis_fiyat'],
                where: 'id = ?', whereArgs: [s.mevcutId]);
            if (eskiRows.isNotEmpty) {
              final eskiStok = (eskiRows.first['stok'] as num?)?.toDouble() ?? 0;
              if (eskiStok != s.urun.stok) {
                hareketGid = const Uuid().v4();
                await txn.insert('stok_hareket', {
                  'global_id': hareketGid,
                  'urun_id': s.mevcutId,
                  'hareket_turu': 'Manuel Düzeltme',
                  'miktar': (s.urun.stok - eskiStok).abs(),
                  'onceki_stok': eskiStok,
                  'sonraki_stok': s.urun.stok,
                  'tarih': DateTime.now().toIso8601String(),
                  'last_updated': DateTime.now().toIso8601String(),
                  'referans_turu': 'excel_toplu_iceri_aktarim',
                });
              }
              final eskiSatis = (eskiRows.first['satis_fiyati'] as num?)?.toDouble() ?? 0;
              final eskiAlis  = (eskiRows.first['alis_fiyat'] as num?)?.toDouble() ?? 0;
              if (eskiSatis != s.urun.satisFiyati || eskiAlis != s.urun.alisFiyat) {
                m['fiyat_guncelleme_tarih'] = DateTime.now().toIso8601String();
              }
            }
            await txn.update(DbSabitler.urunler, m,
                where: 'id = ?', whereArgs: [s.mevcutId]);
            guncellenen++;
          }
        });
        // 🔴 Derin analizde bulundu: bu fonksiyon (Excel toplu içe
        // aktarım — yüzlerce ürünü aynı anda etkileyebilir) hem
        // 'urunler' hem 'stok_hareket' için BulutManager'ı HİÇ
        // çağırmıyordu, global_id de atamıyordu — toplu aktarılan
        // ürünler sadece manuel senkronla buluta gidiyordu.
        if (etkilenenId != null) {
          final urunSatir = await db.query(DbSabitler.urunler, where: 'id = ?', whereArgs: [etkilenenId], limit: 1);
          if (urunSatir.isNotEmpty) {
            BulutManager().upsert('urunler', Map<String, dynamic>.from(urunSatir.first));
          }
        }
        if (hareketGid != null) {
          final hareketSatir = await db.query('stok_hareket', where: 'global_id = ?', whereArgs: [hareketGid], limit: 1);
          if (hareketSatir.isNotEmpty) {
            BulutManager().upsert('stok_hareket', Map<String, dynamic>.from(hareketSatir.first));
          }
        }
      } catch (e) {
        LogServisi().hata('UrunDeposu.topluEkleGuncelle (satır atlandı)', hata: e);
        // Bu satır atlanıyor, döngü DEVAM EDİYOR — diğer satırlar etkilenmiyor.
      }
    }
    return {'eklenen': eklenen, 'guncellenen': guncellenen};
  }

  // ── CRUD ────────────────────────────────────────────────────────────────

  /// Görsel buluta yüklendikten sonra oluşan adresi kaydeder.
  /// Kasıtlı olarak SADECE bu tek sütunu günceller — tam guncelle()
  /// çağrılmıyor, böylece stok/fiyat karşılaştırma mantığı gereksiz
  /// yere tekrar tetiklenmiyor.
  Future<void> resimUrlGuncelle(int urunId, String resimUrl) async {
    try {
      final db = await _d;
      await db.update(DbSabitler.urunler, {
        'resim_url': resimUrl,
        'last_updated': DateTime.now().toIso8601String(),
      }, where: 'id = ?', whereArgs: [urunId]);
      // 🔴 DÜZELTME: last_updated doğru bümleniyordu (manuel "Buluta
      // Gönder" bu değişikliği zaten yakalardı) AMA BulutManager'a
      // hiç haber verilmiyordu — yani resim ANINDA/OTOMATİK olarak
      // gönderilmiyordu, sadece kullanıcı elle "Buluta Gönder"e
      // basarsa gidiyordu. Artık diğer güncelleme fonksiyonlarıyla
      // aynı desen: tam satır okunup kuyruğa veriliyor.
      final guncelSatir = await db.query(DbSabitler.urunler,
          where: 'id = ?', whereArgs: [urunId], limit: 1);
      if (guncelSatir.isNotEmpty) {
        BulutManager().upsert('urunler', Map<String, dynamic>.from(guncelSatir.first));
      }
    } catch (e, st) {
      LogServisi().hata('UrunDeposu.resimUrlGuncelle', hata: e, yigin: st);
    }
  }

  Future<int> ekle(UrunModel urun) async {
    final db = await _d;
    final m = urun.toMap()..remove('id');
    m['global_id'] ??= const Uuid().v4();
    final _id = await db.insert(DbSabitler.urunler, m,
        conflictAlgorithm: ConflictAlgorithm.replace);
    BulutManager().upsert('urunler', {...m, 'id': _id});
    // ÖNCEDEN başlangıç stoğu (yeni ürün eklenirken "50 adet ile
    // başla" gibi) hiçbir zaman bir hareket olarak kaydedilmiyordu.
    // Stok mutabakat sistemi (hareketlerin toplamı) bu ürünü hiç
    // görmediği bir "hayalet" başlangıç stoğuyla karşılaşırdı. Artık
    // stok > 0 ile eklenen her ürün için "İlk Stok" hareketi de
    // kaydediliyor.
    if (urun.stok > 0) {
      final hareketGid = const Uuid().v4();
      await db.insert('stok_hareket', {
        'global_id': hareketGid,
        'urun_id': _id,
        'hareket_turu': 'İlk Stok',
        'miktar': urun.stok,
        'onceki_stok': 0,
        'sonraki_stok': urun.stok,
        'tarih': DateTime.now().toIso8601String(),
        'last_updated': DateTime.now().toIso8601String(),
        'referans_turu': 'ilk_stok',
        'aciklama': 'Ürün eklenirken girilen başlangıç stoğu',
      });
      // 🔴 Derin analizde bulundu: global_id atanmıyordu, BulutManager
      // hiç çağrılmıyordu — yeni ürün başlangıç stoğu hareketi sadece
      // manuel senkronla buluta gidiyordu.
      final hareketSatir = await db.query('stok_hareket', where: 'global_id = ?', whereArgs: [hareketGid], limit: 1);
      if (hareketSatir.isNotEmpty) {
        BulutManager().upsert('stok_hareket', Map<String, dynamic>.from(hareketSatir.first));
      }
    }
    return _id;
  }

  /// Kullanıcı sorusu "kur değişti o zaman nasıl olacak?" için: döviz
  /// bazında takip edilen (dovizKodu dolu) tüm ürünleri getirir — "Toplu
  /// Döviz Güncelleme" ekranı bunları güncel kurla yeniden fiyatlandırır.
  Future<List<UrunModel>> dovizBazliUrunleriGetir() async {
    final db = await _d;
    final rows = await db.query(DbSabitler.urunler,
        where: "doviz_kodu IS NOT NULL AND doviz_kodu != '' AND is_deleted = 0",
        orderBy: 'urun_adi ASC');
    return rows.map(UrunModel.fromMap).toList();
  }

  /// Tek bir ürünün alış fiyatını (döviz tutarı × güncel kur ile) günceller.
  /// ÖNCEDEN BURADA GERÇEK BİR HATA VARDI: sadece KDV HARİÇ alış fiyatı
  /// güncelleniyordu, "KDV Dahil Alış" alanı ESKİ (yanlış/tutarsız)
  /// değerinde kalıyordu — kullanıcının bulduğu "kur değişti, KDV'li
  /// alışı yenilemiyor" sorunu tam olarak buydu. Artık ürünün kendi KDV
  /// oranı okunup, KDV dahil fiyat da (aynı formülle Ürün Ekle
  /// ekranındaki gibi) doğru şekilde yeniden hesaplanıp kaydediliyor.
  Future<void> alisFiyatiGuncelle(int urunId, double yeniAlisFiyat) async {
    final db = await _d;
    final rows = await db.query(DbSabitler.urunler,
        columns: ['alis_kdv_oran'], where: 'id = ?', whereArgs: [urunId]);
    final kdvOrani = rows.isNotEmpty
        ? ((rows.first['alis_kdv_oran'] as num?)?.toDouble() ?? 0)
        : 0.0;
    final yeniKdvDahil = yeniAlisFiyat * (1 + kdvOrani / 100);
    final now = DateTime.now().toIso8601String();
    await db.update(DbSabitler.urunler,
        {'alis_fiyat': yeniAlisFiyat, 'alis_fiyat_kdv_dahil': yeniKdvDahil, 'last_updated': now},
        where: 'id = ?', whereArgs: [urunId]);
    final guncelSatir = await db.query(DbSabitler.urunler, where: 'id = ?', whereArgs: [urunId], limit: 1);
    if (guncelSatir.isNotEmpty) {
      BulutManager().upsert('urunler', Map<String, dynamic>.from(guncelSatir.first));
    }
  }

  Future<List<UrunModel>> idListesiyleGetir(List<int> idler) async {
    if (idler.isEmpty) return [];
    final db = await _d;
    final phs = idler.map((_) => '?').join(',');
    final rows = await db.rawQuery(
        'SELECT * FROM urunler WHERE id IN ($phs) ORDER BY urun_adi',
        idler);
    return rows.map(UrunModel.fromMap).toList();
  }

  Future<void> guncelle(UrunModel urun) async {
    try {
      final db  = await _d;
      final now = DateTime.now().toIso8601String();
      final m   = urun.toMap()
        ..['guncelleme_tarihi'] = now
        ..['last_updated']      = now;

      // Kullanıcı isteği: "aynı ürünü başka cihazdan güncelleme nasıl
      // olacak" — alan bazlı çakışma koruması için, fiyat GERÇEKTEN
      // değiştiyse fiyat_guncelleme_tarih damgalanıyor (önceden bu
      // sütun veritabanında vardı ama HİÇBİR YERDE kullanılmıyordu).
      // Bu, senkronizasyon sırasında "fiyatı kim en son değiştirdi"
      // sorusunu, TÜM kaydın zaman damgasından BAĞIMSIZ olarak doğru
      // cevaplamamızı sağlıyor.
      if (urun.id != null) {
        final eski = await db.query(DbSabitler.urunler,
            columns: ['satis_fiyati', 'alis_fiyat'],
            where: 'id = ?', whereArgs: [urun.id]);
        if (eski.isNotEmpty) {
          final eskiSatis = (eski.first['satis_fiyati'] as num?)?.toDouble() ?? 0;
          final eskiAlis  = (eski.first['alis_fiyat'] as num?)?.toDouble() ?? 0;
          if (eskiSatis != urun.satisFiyati || eskiAlis != urun.alisFiyat) {
            m['fiyat_guncelleme_tarih'] = now;
          }
        } else {
          m['fiyat_guncelleme_tarih'] = now; // yeni kayıt gibi davran
        }
      }

      // plu ve plu_kart_boyut korunur — ürün güncelleme PLU ayarını sıfırlamaz
      if (urun.id != null) {
        final mevcut = await db.query(DbSabitler.urunler,
            columns: ['plu', 'plu_kart_boyut', 'stok'],
            where: 'id = ?', whereArgs: [urun.id]);
        if (mevcut.isNotEmpty) {
          final mplu   = mevcut.first['plu']           as int? ?? 0;
          final mboyut = mevcut.first['plu_kart_boyut'] as int? ?? 2;
          if (mplu == 1) {
            m['plu']           = mplu;
            m['plu_kart_boyut'] = mboyut;
          }
          // ÖNCEDEN BURADA: kullanıcı Ürün Güncelle formundan stoğu
          // doğrudan değiştirip kaydettiğinde, bu değişiklik HİÇBİR
          // hareket kaydına dönüşmüyordu — stok mutabakat sistemi için
          // tamamen görünmezdi. Artık stok gerçekten değiştiyse,
          // otomatik bir "Manuel Düzeltme" hareketi oluşturuluyor.
          final eskiStok = (mevcut.first['stok'] as num?)?.toDouble() ?? 0;
          if (eskiStok != urun.stok) {
            final hareketGid = const Uuid().v4();
            await db.insert('stok_hareket', {
              'global_id': hareketGid,
              'urun_id': urun.id,
              'hareket_turu': 'Manuel Düzeltme',
              'miktar': (urun.stok - eskiStok).abs(),
              'onceki_stok': eskiStok,
              'sonraki_stok': urun.stok,
              'tarih': now,
              'last_updated': now,
              'referans_turu': 'urun_guncelle',
              'aciklama': 'Ürün Güncelle ekranından stok değiştirildi',
            });
            // 🔴 Derin analizde bulundu: global_id atanmıyordu,
            // BulutManager hiç çağrılmıyordu.
            final hareketSatir = await db.query('stok_hareket', where: 'global_id = ?', whereArgs: [hareketGid], limit: 1);
            if (hareketSatir.isNotEmpty) {
              BulutManager().upsert('stok_hareket', Map<String, dynamic>.from(hareketSatir.first));
            }
          }
        }
      }

      await db.update(DbSabitler.urunler, m,
          where: 'id = ?', whereArgs: [urun.id]);
      BulutManager().upsert('urunler', m);
    } catch (e, st) {
      LogServisi().hata('UrunDeposu.guncelle', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<void> sil(int id) async {
    final db = await _d;
    final now = DateTime.now().toIso8601String();
    await db.update(
      DbSabitler.urunler,
      {'is_deleted': 1, 'aktif': 0, 'last_updated': now},
      where: 'id = ?',
      whereArgs: [id],
    );
    final guncelSatir = await db.query(DbSabitler.urunler, where: 'id = ?', whereArgs: [id], limit: 1);
    if (guncelSatir.isNotEmpty) {
      BulutManager().upsert('urunler', Map<String, dynamic>.from(guncelSatir.first));
    }
  }

  // ── TEK KAYIT SORGULARI ────────────────────────────────────────────────

  Future<UrunModel?> idileGetir(int id) async {
    final db = await _d;
    final rows = await db.query(
      DbSabitler.urunler,
      where: 'id = ? AND is_deleted = 0',
      whereArgs: [id],
    );
    return rows.isEmpty ? null : UrunModel.fromMap(rows.first);
  }

  Future<UrunModel?> barkodlaGetir(String barkod) async {
    final db = await _d;
    // 1. Tam barkod eşleşmesi
    var rows = await db.query(
      DbSabitler.urunler,
      where: 'barkod = ? AND is_deleted = 0 AND aktif = 1',
      whereArgs: [barkod],
    );
    if (rows.isNotEmpty) return UrunModel.fromMap(rows.first);
    // 2. barkodlar (virgülle ayrılmış) içinde ara
    rows = await db.rawQuery(
      "SELECT * FROM ${DbSabitler.urunler}"
      " WHERE (',' || barkodlar || ',') LIKE ?"
      "   AND is_deleted = 0 AND aktif = 1 LIMIT 1",
      ['%,$barkod,%'],
    );
    return rows.isEmpty ? null : UrunModel.fromMap(rows.first);
  }

  Future<UrunModel?> kodlaGetir(String kod) async {
    final db = await _d;
    final rows = await db.query(
      DbSabitler.urunler,
      where: 'kod = ? AND is_deleted = 0',
      whereArgs: [kod],
    );
    return rows.isEmpty ? null : UrunModel.fromMap(rows.first);
  }

  // ── LİSTE SORGULARI ────────────────────────────────────────────────────

  /// QR menüde gösterilecek/gösterilmeyecek ürünleri toplu olarak
  /// günceller. Kullanıcı isteği: 400 üründen sadece işaretlenenler
  /// (Kafe/Restoran ürünleri gibi) QR menüde görünsün.
  // 🔥 ÖNCEDEN qrMenuSecimleriniKaydet() TEK bir ürünü işaretlemek
  // için bile TÜM ürün ID listesini (4660 ürün!) döngüyle
  // güncelliyordu — kullanıcının yeni isteği doğrultusunda ("anlık
  // ekle/kaldır, ayrı kaydet butonu yok") bu, HER dokunuşta binlerce
  // gereksiz UPDATE çalıştırırdı. Artık tek satırlık, verimli bir
  // fonksiyon var.
  Future<void> qrMenuDurumDegistir(int urunId, bool deger) async {
    final db = await _d;
    final now = DateTime.now().toIso8601String();
    // 🔴🔴 KÖK NEDEN DÜZELTMESİ ("QR menüye ekliyorum, kayboluyor"):
    // Önceden bu fonksiyon SADECE 'qr_menude' sütununu güncelliyordu —
    // 'last_updated' hiç bümlenmiyordu VE BulutManager'a (kuyruğa) hiç
    // haber verilmiyordu. Sonuç: bu değişiklik ASLA buluta gönderilmedi.
    // Arka planda çalışan indirme (buluttan al) döngüsü, bir süre sonra
    // bulut'taki ESKİ değeri (qr_menude=0) geri getirip yerel
    // değişikliğin üzerine sessizce yazıyordu — kullanıcı ürünü
    // ekliyor, birkaç saniye/dakika sonra "kayboluyordu". Artık hem
    // last_updated bümleniyor hem de TAM satır BulutManager'a
    // (upsert kuyruğuna) veriliyor — diğer tüm güncelleme
    // fonksiyonlarıyla AYNI, kanıtlanmış desen.
    await db.update(DbSabitler.urunler,
        {'qr_menude': deger ? 1 : 0, 'last_updated': now},
        where: 'id = ?', whereArgs: [urunId]);
    final guncelSatir = await db.query(DbSabitler.urunler,
        where: 'id = ?', whereArgs: [urunId], limit: 1);
    if (guncelSatir.isNotEmpty) {
      BulutManager().upsert('urunler', Map<String, dynamic>.from(guncelSatir.first));
    }
  }

  // Kullanıcı isteği: "toptan satış tıkladık, o listede gözüksün,
  // diğerleri gözükmesin" — qrMenuDurumDegistir ile AYNI, kanıtlanmış
  // desen (last_updated + BulutManager bildirimi baştan doğru kurulu).
  Future<void> toptanSatistaDurumDegistir(int urunId, bool deger) async {
    final db = await _d;
    final now = DateTime.now().toIso8601String();
    await db.update(DbSabitler.urunler,
        {'toptan_satista': deger ? 1 : 0, 'last_updated': now},
        where: 'id = ?', whereArgs: [urunId]);
    final guncelSatir = await db.query(DbSabitler.urunler,
        where: 'id = ?', whereArgs: [urunId], limit: 1);
    if (guncelSatir.isNotEmpty) {
      BulutManager().upsert('urunler', Map<String, dynamic>.from(guncelSatir.first));
    }
  }

  /// Şu an toptan satışta işaretli olan ürünleri getirir.
  Future<List<UrunModel>> toptanSatisUrunleriGetir() async {
    final db = await _d;
    final rows = await db.query(DbSabitler.urunler,
        where: 'toptan_satista = 1 AND is_deleted = 0', orderBy: 'urun_adi');
    return rows.map(UrunModel.fromMap).toList();
  }

  /// Şu an QR menüde işaretli olan ürünleri getirir (yeni "boş liste,
  /// arayarak ekle" tasarımının başlangıç listesi).
  Future<List<UrunModel>> qrMenuUrunleriGetir() async {
    final db = await _d;
    final rows = await db.query(DbSabitler.urunler,
        where: 'qr_menude = 1 AND is_deleted = 0', orderBy: 'urun_adi ASC');
    return rows.map(UrunModel.fromMap).toList();
  }

  Future<void> qrMenuSecimleriniKaydet(Set<int> secilenIdler, List<int> tumIdler) async {
    try {
      final db = await _d;
      final now = DateTime.now().toIso8601String();
      await db.transaction((txn) async {
        for (final id in tumIdler) {
          await txn.update(DbSabitler.urunler,
              {'qr_menude': secilenIdler.contains(id) ? 1 : 0, 'last_updated': now},
              where: 'id = ?', whereArgs: [id]);
        }
      });
      // 🔴 Derin analizde bulundu (şu an kullanılmıyor ama gelecek için
      // düzeltildi): last_updated hiç bump edilmiyordu, BulutManager
      // hiçbir ürün için çağrılmıyordu.
      for (final id in tumIdler) {
        final satir = await db.query(DbSabitler.urunler, where: 'id = ?', whereArgs: [id], limit: 1);
        if (satir.isNotEmpty) {
          BulutManager().upsert('urunler', Map<String, dynamic>.from(satir.first));
        }
      }
    } catch (e, st) {
      LogServisi().hata('UrunDeposu.qrMenuSecimleriniKaydet', hata: e, yigin: st);
      rethrow;
    }
  }

  Future<List<UrunModel>> tumunuGetir({bool sadecaAktif = true, int limit = 2000}) async {
    final db = await _d;
    final where = sadecaAktif
        ? 'is_deleted = 0 AND aktif = 1'
        : 'is_deleted = 0';
    final rows = await db.query(
      DbSabitler.urunler,
      where: where,
      orderBy: 'urun_adi ASC',
      // limit kaldırıldı - tüm ürünleri getirir
    );
    return rows.map(UrunModel.fromMap).toList();
  }

  /// Sayfalı arama — ürün listesi ekranı için kullanılır.
  Future<List<UrunModel>> sayfaliGetir(
    int offset,
    int limit, {
    String? aramaMetni,
    String? grup,
    bool sadecaAktif = true,
    // Kullanıcı isteği: filtreleme ekranına "stok azalan, en son
    // güncellenen, satış fiyatı, grup, alan1 gibi" daha çok sıralama
    // seçeneği eklenmesi. Aşağıdaki değerler destekleniyor:
    // 'isim' (varsayılan), 'stok_azalan', 'stok_artan',
    // 'guncelleme_yeni', 'fiyat_yuksek', 'fiyat_dusuk', 'grup', 'alan1'
    String siralama = 'isim',
  }) async {
    final db = await _d;
    final whereParts = ['is_deleted = 0'];
    final args = <dynamic>[];
    if (sadecaAktif) whereParts.add('aktif = 1');
    if (grup != null) {
      whereParts.add('ana_grup = ?');
      args.add(grup);
    }
    if (aramaMetni != null && aramaMetni.isNotEmpty) {
      final q = '%$aramaMetni%';
      whereParts.add(
        '(urun_adi LIKE ? OR barkod LIKE ? OR kod LIKE ?'
        ' OR ana_grup LIKE ? OR alternatif_urun_adi LIKE ? OR marka LIKE ?)',
      );
      args.addAll([q, q, q, q, q, q]);
    }
    final orderBy = switch (siralama) {
      'stok_azalan'     => 'stok DESC',
      'stok_artan'      => 'stok ASC',
      'guncelleme_yeni' => 'last_updated DESC',
      'fiyat_yuksek'    => 'satis_fiyati DESC',
      'fiyat_dusuk'     => 'satis_fiyati ASC',
      'grup'            => 'ana_grup ASC, urun_adi ASC',
      'alan1'           => 'alan1 ASC, urun_adi ASC',
      _                 => 'urun_adi ASC',
    };
    final rows = await db.query(
      DbSabitler.urunler,
      where: whereParts.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: orderBy,
      limit: limit,
      offset: offset,
    );
    return rows.map(UrunModel.fromMap).toList();
  }

  /// Hızlı satış arama — aktif ürünler, DB'ye sorgu atar (bellekte tam liste tutmaz).
  Future<List<UrunModel>> ara(String sorgu,
      {int limit = 80, int offset = 0, bool sadecaAktif = true}) async {
    if (sorgu.isEmpty) return [];
    final db = await _d;
    final q = '%$sorgu%';
    final aktifFiltre = sadecaAktif ? ' AND aktif = 1' : '';
    // ÖNCEDEN bu fonksiyonun offset parametresi yoktu — "daha fazla
    // yükle" (sonsuz kaydırma) her zaman AYNI ilk sonuçları tekrar
    // getiriyordu, listeye aynı ürünler tekrar tekrar ekleniyordu
    // (arama sonucu 50'den fazla eşleşme varsa). Artık gerçek
    // sayfalama destekleniyor.
    final rows = await db.rawQuery(
      'SELECT * FROM ${DbSabitler.urunler}'
      ' WHERE (urun_adi LIKE ? OR barkod LIKE ? OR kod LIKE ?'
      '       OR alternatif_urun_adi LIKE ? OR marka LIKE ?)'
      '   AND is_deleted = 0$aktifFiltre'
      ' ORDER BY urun_adi ASC LIMIT ? OFFSET ?',
      [q, q, q, q, q, limit, offset],
    );
    return rows.map(UrunModel.fromMap).toList();
  }

  // ── ÖZEL SORGULAR ──────────────────────────────────────────────────────

  Future<List<UrunModel>> kritikStoklar({int limit = 50}) async {
    final db = await _d;
    final rows = await db.rawQuery(
      'SELECT * FROM ${DbSabitler.urunler}'
      ' WHERE is_deleted = 0 AND aktif = 1'
      '   AND minimum_stok > 0 AND stok <= minimum_stok'
      ' ORDER BY stok ASC LIMIT ?',
      [limit],
    );
    return rows.map(UrunModel.fromMap).toList();
  }

  Future<Map<String, dynamic>> istatistikler() async {
    final db = await _d;
    final res = await db.rawQuery('''
      SELECT
        COUNT(*)                                                           AS toplam,
        COUNT(CASE WHEN aktif = 1 AND is_deleted = 0 THEN 1 END)          AS aktif,
        COUNT(CASE WHEN stok <= minimum_stok AND minimum_stok > 0
                        AND is_deleted = 0 THEN 1 END)                    AS kritik,
        COUNT(CASE WHEN stok <= 0 AND is_deleted = 0 THEN 1 END)          AS stoksuz,
        COALESCE(SUM(CASE WHEN is_deleted = 0 AND aktif = 1
                          THEN stok * alis_fiyat END), 0)                 AS stok_degeri
      FROM ${DbSabitler.urunler}
      WHERE is_deleted = 0
    ''');
    if (res.isEmpty) return {};
    final r = res.first;
    return {
      'toplam':      (r['toplam']      as int?)    ?? 0,
      'aktif':       (r['aktif']       as int?)    ?? 0,
      'kritik':      (r['kritik']      as int?)    ?? 0,
      'stoksuz':     (r['stoksuz']     as int?)    ?? 0,
      'stok_degeri': (r['stok_degeri'] as num?)?.toDouble() ?? 0.0,
    };
  }

  Future<List<String>> anaGruplariGetir() async {
    final db = await _d;
    final rows = await db.rawQuery(
      'SELECT DISTINCT ana_grup FROM ${DbSabitler.urunler}'
      ' WHERE ana_grup IS NOT NULL AND is_deleted = 0'
      ' ORDER BY ana_grup',
    );
    return rows.map((r) => r['ana_grup'] as String).toList();
  }

  Future<void> topluFiyatGuncelle(
    List<int> ids,
    double oran, {
    String tip = 'satis',
    String yon = 'artir',
  }) async {
    final db = await _d;
    final kolon = tip == 'alis' ? 'alis_fiyat' : 'satis_fiyati';
    final now = DateTime.now().toIso8601String();
    for (final id in ids) {
      try {
        // 🔴 DÜZELTME: Bu fonksiyon (toplu fiyat güncelleme — tek
        // seferde yüzlerce ürünü etkileyebilir) senkron sisteminin
        // izlediği 'last_updated' sütununu DEĞİL, ayrı/farklı bir alan
        // olan 'guncelleme_tarihi'ni güncelliyordu — bulk fiyat
        // değişiklikleri ne otomatik ne de manuel senkrona hiç
        // yakalanmıyordu. Artık last_updated da bump ediliyor ve her
        // ürün için BulutManager çağrılıyor.
        if (yon == 'esitle') {
          await db.rawUpdate(
            'UPDATE ${DbSabitler.urunler}'
            ' SET $kolon = ?, guncelleme_tarihi = ?, last_updated = ? WHERE id = ?',
            [oran, now, now, id],
          );
        } else if (yon == 'azalt') {
          await db.rawUpdate(
            'UPDATE ${DbSabitler.urunler}'
            ' SET $kolon = $kolon * ?, guncelleme_tarihi = ?, last_updated = ? WHERE id = ?',
            [1 - (oran / 100), now, now, id],
          );
        } else {
          await db.rawUpdate(
            'UPDATE ${DbSabitler.urunler}'
            ' SET $kolon = $kolon * ?, guncelleme_tarihi = ?, last_updated = ? WHERE id = ?',
            [1 + (oran / 100), now, now, id],
          );
        }
        final satir = await db.query(DbSabitler.urunler, where: 'id = ?', whereArgs: [id], limit: 1);
        if (satir.isNotEmpty) {
          BulutManager().upsert('urunler', Map<String, dynamic>.from(satir.first));
        }
      } catch (e) {
        if (kDebugMode) debugPrint('topluFiyatGuncelle id=$id hata: $e');
      }
    }
  }

  Future<void> stokGuncelle(int id, double yeniStok) async {
    final db = await _d;
    await db.update(
      DbSabitler.urunler,
      {'stok': yeniStok, 'last_updated': DateTime.now().toIso8601String()},
      where: 'id = ?',
      whereArgs: [id],
    );
    final guncelSatir = await db.query(DbSabitler.urunler, where: 'id = ?', whereArgs: [id], limit: 1);
    if (guncelSatir.isNotEmpty) {
      BulutManager().upsert('urunler', Map<String, dynamic>.from(guncelSatir.first));
    }
  }
  /// PLU — barkodsuz veya plu=1 işaretli aktif ürünler
  Future<List<UrunModel>> pluUrunleriGetir() async {
    try {
      final db = await _d;
      // Sadece plu=1 işaretlenen ürünler (barkod zorunlu, barkodsuz kabul edilmez)
      final rows = await db.rawQuery('''
        SELECT * FROM urunler
        WHERE aktif = 1
          AND plu = 1
          AND is_deleted = 0
        ORDER BY ana_grup, plu_kart_boyut DESC, urun_adi
        LIMIT 200
      ''');
      return rows.map(UrunModel.fromMap).toList();
    } catch (e, st) {
      LogServisi().hata('UrunDeposu.pluUrunleriGetir', hata: e, yigin: st);
      return [];
    }
  }

  Future<String?> _globalIdGetir(int id) async {
    final db = await _d;
    final rows = await db.query(
      DbSabitler.urunler,
      columns: ['global_id'],
      where: 'id = ?',
      whereArgs: [id],
    );
    return rows.isEmpty ? null : rows.first['global_id'] as String?;
  }

}
