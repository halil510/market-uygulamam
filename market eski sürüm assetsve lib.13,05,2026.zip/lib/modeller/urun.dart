// lib/modeller/urun.dart
class Urun {
  int? id;
  String barkod;
  String ad;
  double satisFiyat;
  double stokMiktari;
  
  String kod;
  String? barkodlar;
  String? birim;
  double? alisFiyat;
  double? alisFiyatKdvDahil;
  double? alisKdvOrani;
  double? kdvOrani;
  String? anagrup;
  String? altGrup;
  String? alan1;
  String? alan2;
  String paraBirimi;
  String? marka;
  double? indirimOrani;
  double? indirimliFiyat;
  String? boy;
  String? resimYolu;
  String? mens;
  double? karOrani;
  String? fiyatGuncellemeTarihi;
  String? maliyetGuncellemeTarihi;
  bool promosyonAktif;

  Urun({
    this.id,
    required this.barkod,
    required this.ad,
    required this.satisFiyat,
    this.stokMiktari = 0,
    this.kod = '',
    this.barkodlar,
    this.birim = 'Adet',
    this.alisFiyat,
    this.alisFiyatKdvDahil,
    this.alisKdvOrani,
    this.kdvOrani,
    this.anagrup,
    this.altGrup,
    this.alan1,
    this.alan2,
    this.paraBirimi = 'TL',
    this.marka,
    this.indirimOrani,
    this.indirimliFiyat,
    this.boy,
    this.resimYolu,
    this.mens,
    this.karOrani,
    this.fiyatGuncellemeTarihi,
    this.maliyetGuncellemeTarihi,
    this.promosyonAktif = false,
  });

  factory Urun.fromMap(Map<String, dynamic> map) {
    return Urun(
      id: _toInt(map['id']),
      kod: map['kod']?.toString() ?? '',
      barkod: map['barkod']?.toString() ?? '',
      barkodlar: map['barkodlar']?.toString(),
      ad: map['ad']?.toString() ?? '',
      birim: map['birim']?.toString() ?? 'Adet',
      alisFiyat: _toDouble(map['alisFiyat']),
      alisFiyatKdvDahil: _toDouble(map['alisFiyatKdvDahil']),
      satisFiyat: _toDouble(map['satisFiyat']) ?? 0.0,
      alisKdvOrani: _toDouble(map['alisKdvOrani']),
      kdvOrani: _toDouble(map['kdvOrani']),
      stokMiktari: _toDouble(map['stokMiktari']) ?? 0.0,
      anagrup: map['anagrup']?.toString(),
      altGrup: map['altGrup']?.toString(),
      alan1: map['alan1']?.toString(),
      alan2: map['alan2']?.toString(),
      paraBirimi: map['paraBirimi']?.toString() ?? 'TL',
      marka: map['marka']?.toString(),
      indirimOrani: _toDouble(map['indirimOrani']),
      indirimliFiyat: _toDouble(map['indirimliFiyat']),
      boy: map['boy']?.toString(),
      resimYolu: map['resimYolu']?.toString(),
      mens: map['mens']?.toString(),
      karOrani: _toDouble(map['karOrani']),
      fiyatGuncellemeTarihi: map['fiyatGuncellemeTarihi']?.toString(),
      maliyetGuncellemeTarihi: map['maliyetGuncellemeTarihi']?.toString(),
      promosyonAktif: map['promosyonAktif'] == 1 ||
                     map['promosyonAktif'] == true ||
                     (map['promosyonAktif']?.toString().toLowerCase() == 'true'),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'kod': kod,
      'barkod': barkod,
      'barkodlar': barkodlar,
      'ad': ad,
      'birim': birim,
      'alisFiyat': alisFiyat,
      'alisFiyatKdvDahil': alisFiyatKdvDahil,
      'satisFiyat': satisFiyat,
      'alisKdvOrani': alisKdvOrani,
      'kdvOrani': kdvOrani,
      'stokMiktari': stokMiktari,
      'anagrup': anagrup,
      'altGrup': altGrup,
      'alan1': alan1,
      'alan2': alan2,
      'paraBirimi': paraBirimi,
      'marka': marka,
      'indirimOrani': indirimOrani,
      'indirimliFiyat': indirimliFiyat,
      'boy': boy,
      'resimYolu': resimYolu,
      'mens': mens,
      'karOrani': karOrani,
      'fiyatGuncellemeTarihi': fiyatGuncellemeTarihi,
      'maliyetGuncellemeTarihi': maliyetGuncellemeTarihi,
      'promosyonAktif': promosyonAktif ? 1 : 0,
    };
  }

  Map<String, dynamic> toParameters() => toMap();

  Urun copyWith({
    int? id,
    String? barkod,
    String? ad,
    double? satisFiyat,
    double? stokMiktari,
    String? kod,
    String? barkodlar,
    String? birim,
    double? alisFiyat,
    double? alisFiyatKdvDahil,
    double? alisKdvOrani,
    double? kdvOrani,
    String? anagrup,
    String? altGrup,
    String? alan1,
    String? alan2,
    String? paraBirimi,
    String? marka,
    double? indirimOrani,
    double? indirimliFiyat,
    String? boy,
    String? resimYolu,
    String? mens,
    double? karOrani,
    String? fiyatGuncellemeTarihi,
    String? maliyetGuncellemeTarihi,
    bool? promosyonAktif,
  }) {
    return Urun(
      id: id ?? this.id,
      barkod: barkod ?? this.barkod,
      ad: ad ?? this.ad,
      satisFiyat: satisFiyat ?? this.satisFiyat,
      stokMiktari: stokMiktari ?? this.stokMiktari,
      kod: kod ?? this.kod,
      barkodlar: barkodlar ?? this.barkodlar,
      birim: birim ?? this.birim,
      alisFiyat: alisFiyat ?? this.alisFiyat,
      alisFiyatKdvDahil: alisFiyatKdvDahil ?? this.alisFiyatKdvDahil,
      alisKdvOrani: alisKdvOrani ?? this.alisKdvOrani,
      kdvOrani: kdvOrani ?? this.kdvOrani,
      anagrup: anagrup ?? this.anagrup,
      altGrup: altGrup ?? this.altGrup,
      alan1: alan1 ?? this.alan1,
      alan2: alan2 ?? this.alan2,
      paraBirimi: paraBirimi ?? this.paraBirimi,
      marka: marka ?? this.marka,
      indirimOrani: indirimOrani ?? this.indirimOrani,
      indirimliFiyat: indirimliFiyat ?? this.indirimliFiyat,
      boy: boy ?? this.boy,
      resimYolu: resimYolu ?? this.resimYolu,
      mens: mens ?? this.mens,
      karOrani: karOrani ?? this.karOrani,
      fiyatGuncellemeTarihi: fiyatGuncellemeTarihi ?? this.fiyatGuncellemeTarihi,
      maliyetGuncellemeTarihi: maliyetGuncellemeTarihi ?? this.maliyetGuncellemeTarihi,
      promosyonAktif: promosyonAktif ?? this.promosyonAktif,
    );
  }

  static double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    return double.tryParse(value.toString());
  }

  static int? _toInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    return int.tryParse(value.toString());
  }

  @override
  String toString() {
    return 'Urun(id: $id, barkod: $barkod, ad: $ad, satisFiyat: $satisFiyat)';
  }
}