// lib/modern_ui/widgets/modern_card.dart
import 'package:flutter/material.dart';

class ModernCard extends StatelessWidget {
  final Widget child; // Kart içeriği
  final double? elevation; // Gölge yüksekliği
  final Color? color; // Kart rengi
  final EdgeInsetsGeometry? padding; // İç boşluk
  final double? width; // Kart genişliği
  final double? height; // Kart yüksekliği
  final BorderRadius? borderRadius; // 🔹 Yeni: Köşe yuvarlama

  const ModernCard({
    super.key,
    required this.child,
    this.elevation,
    this.color,
    this.padding,
    this.width,
    this.height,
    this.borderRadius, // 🔹 Yeni parametre
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: Card(
        color: color ?? Theme.of(context).cardColor,
        elevation: elevation ?? 4,
        shape: RoundedRectangleBorder(
          borderRadius: borderRadius ?? BorderRadius.circular(16), // 🔹 Dışarıdan gelirse onu kullan
        ),
        child: Padding(
          padding: padding ?? const EdgeInsets.all(16),
          child: child,
        ),
      ),
    );
  }
}
