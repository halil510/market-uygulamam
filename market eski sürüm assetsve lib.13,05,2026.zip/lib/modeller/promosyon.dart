class Promosyon {
  int? id;
  int urunId;
  double miktar;
  double iskontoOrani;
  bool aktif;

  Promosyon({
    this.id,
    required this.urunId,
    required this.miktar,
    required this.iskontoOrani,
    this.aktif = true,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'urun_id': urunId,
      'miktar': miktar,
      'iskonto_orani': iskontoOrani,
      'aktif': aktif ? 1 : 0,
    };
  }

  factory Promosyon.fromMap(Map<String, dynamic> map) {
    return Promosyon(
      id: map['id'],
      urunId: map['urun_id'],
      miktar: map['miktar'],
      iskontoOrani: map['iskonto_orani'],
      aktif: map['aktif'] == 1,
    );
  }
}