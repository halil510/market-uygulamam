// lib/servisler/veritabani_yardimcisi.dart
import 'dart:io';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:market_uygulamasi/servisler/log_servisi.dart';

class VeritabaniYardimcisi {
  static final VeritabaniYardimcisi _instance = VeritabaniYardimcisi._internal();
  factory VeritabaniYardimcisi() => _instance;
  VeritabaniYardimcisi._internal();

  static Database? _database;
  static const int _currentVersion = 13;

  Future<Database> get db async {
    if (_database != null) return _database!;
    try {
      _database = await _initDb();
    } catch (e) {
      Log.e("VERİTABANI AÇILAMADI! Sıfırlanıp yeniden oluşturulacak.", tag: "DB");
      await _resetAndRecreate();
      _database = await _initDb();
    }
    return _database!;
  }

  static String sifreHashle(String sifre) {
    final bytes = utf8.encode(sifre);
    return sha256.convert(bytes).toString();
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'market.db');
    final file = File(path);

    if (!await file.exists()) {
      try {
        ByteData data = await rootBundle.load('assets/db/market.db');
        List<int> bytes = data.buffer.asUint8List();
        await File(path).writeAsBytes(bytes, flush: true);
      } catch (e) {
        await _createNewDatabase(path);
      }
    }

    return await openDatabase(
      path,
      version: _currentVersion,
      onCreate: _createDatabase,
      onUpgrade: _upgradeDatabase,
    );
  }

  Future<void> _createNewDatabase(String path) async {
    final db = await openDatabase(path, version: _currentVersion);
    await _createAllTables(db);
    await db.close();
  }

  Future<void> _createDatabase(Database db, int version) async {
    await _createAllTables(db);
  }

  Future<void> _upgradeDatabase(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) await _v2Upgrade(db);
    if (oldVersion < 3) await _v3Upgrade(db);
    if (oldVersion < 4) await _v4Upgrade(db);
    if (oldVersion < 5) await _v5Upgrade(db);
    if (oldVersion < 6) await _v6Upgrade(db);
    if (oldVersion < 7) await _v7Upgrade(db);
    if (oldVersion < 8) await _v8Upgrade(db);
    if (oldVersion < 9) await _v9Upgrade(db);
    if (oldVersion < 10) await _v10Upgrade(db);
    if (oldVersion < 11) await _v11Upgrade(db);
    if (oldVersion < 12) await _v12Upgrade(db);
     if (oldVersion < 13) await _v13Upgrade(db);



  }

  Future<void> _createAllTables(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS "Cari" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "cari_kodu" TEXT UNIQUE,
        "unvan" TEXT NOT NULL,
        "cari_tipi" TEXT NOT NULL CHECK("cari_tipi" IN ('Müşteri', 'Tedarikçi')),
        "telefon" TEXT,
        "adres" TEXT,
        "email" TEXT,
        "vergi_dairesi" TEXT,
        "vergi_no" TEXT,
        "bakiye" REAL NOT NULL DEFAULT 0,
        "ana_grup" TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS "kullanicilar" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "kullaniciAdi" TEXT UNIQUE NOT NULL,
        "sifre" TEXT NOT NULL,
        "rol" TEXT NOT NULL DEFAULT 'personel',
        "email" TEXT,
        "telefon" TEXT,
        "adSoyad" TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS "Promosyonlar" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "urun_id" INTEGER NOT NULL,
        "miktar" REAL NOT NULL,
        "iskonto_orani" REAL NOT NULL,
        "aktif" INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY("urun_id") REFERENCES "Urunler"("id") ON DELETE CASCADE
      )
    ''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_promosyon_urun ON Promosyonlar(urun_id)');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS "Urunler" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "barkod" TEXT UNIQUE,
        "barkodlar" TEXT,
        "ad" TEXT NOT NULL,
        "aciklama" TEXT,
        "kategori" TEXT,
        "anagrup" TEXT,
        "altGrup" TEXT,
        "marka" TEXT,
        "model" TEXT,
        "alisFiyat" REAL NOT NULL DEFAULT 0,
        "satisFiyat" REAL NOT NULL DEFAULT 0,
        "kdvOrani" REAL NOT NULL DEFAULT 18,
        "stokMiktari" REAL NOT NULL DEFAULT 0,
        "stokUyarisi" REAL NOT NULL DEFAULT 5,
        "birim" TEXT NOT NULL DEFAULT 'adet',
        "aktif" INTEGER NOT NULL DEFAULT 1,
        "olusturmaTarihi" DATETIME DEFAULT CURRENT_TIMESTAMP,
        "guncellemeTarihi" DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    ''');

await db.execute('''
  CREATE TABLE IF NOT EXISTS gun_sonu_raporlari (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tarih TEXT,
    rapor_json TEXT
  )
''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS "Satislar" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "fisNo" TEXT,
        "tarih" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "cariId" INTEGER,
        "toplamTutar" REAL NOT NULL,
        "indirim" REAL DEFAULT 0,
        "odenenTutar" REAL NOT NULL,
        "odemeYontemi" TEXT CHECK("odemeYontemi" IN ('Nakit', 'Kredi Kartı', 'Cari')),
        "fisTipi" TEXT NOT NULL DEFAULT 'Satış',
        "aciklama" TEXT,
        FOREIGN KEY("cariId") REFERENCES "Cari"("id")
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS "satis_detay" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "satisId" INTEGER NOT NULL,
        "urunId" INTEGER NOT NULL,
        "urunAdi" TEXT NOT NULL,
        "miktar" REAL NOT NULL,
        "birimFiyat" REAL NOT NULL,
        "indirimOrani" REAL DEFAULT 0,
        "toplamTutar" REAL NOT NULL,
        "kdvliFiyat" REAL NOT NULL,
        "kdvliTutar" REAL NOT NULL,
        FOREIGN KEY("satisId") REFERENCES "Satislar"("id") ON DELETE CASCADE,
        FOREIGN KEY("urunId") REFERENCES "Urunler"("id")
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS "CariHareket" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "cari_id" INTEGER NOT NULL,
        "tarih" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "fis_tipi" TEXT NOT NULL CHECK("fis_tipi" IN ('Satış', 'Alış', 'Tahsilat', 'Ödeme', 'Açılış')),
        "fis_id" INTEGER,
        "fis_no" TEXT,
        "aciklama" TEXT NOT NULL,
        "borc" REAL NOT NULL DEFAULT 0,
        "alacak" REAL NOT NULL DEFAULT 0,
        "bakiye" REAL,
        FOREIGN KEY("cari_id") REFERENCES "Cari"("id") ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS "StokHareketleri" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "urunId" INTEGER NOT NULL,
        "hareketTuru" TEXT NOT NULL CHECK("hareketTuru" IN ('Giriş', 'Çıkış', 'Sayım')),
        "miktar" REAL NOT NULL,
        "tarih" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "referansId" INTEGER,
        "referansTuru" TEXT,
        "aciklama" TEXT,
        FOREIGN KEY("urunId") REFERENCES "Urunler"("id")
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS "iade_kayitlari" (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        barkod TEXT NOT NULL,
        urun_adi TEXT NOT NULL,
        miktar INTEGER NOT NULL,
        iade_nedeni TEXT,
        tarih TEXT NOT NULL,
        kullanici TEXT,
        FOREIGN KEY (barkod) REFERENCES Urunler(barkod)
      )
    ''');

    await _createYaziciTable(db);

    await db.execute('''
      CREATE TABLE IF NOT EXISTS "GeciciSayim" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "urun_id" INTEGER NOT NULL UNIQUE,
        "mevcutStok" REAL NOT NULL,
        "yeniStok" REAL NOT NULL,
        FOREIGN KEY("urun_id") REFERENCES "Urunler"("id") ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TRIGGER IF NOT EXISTS Urunler_UpdateTimestamp
      AFTER UPDATE ON Urunler
      BEGIN
        UPDATE Urunler SET guncellemeTarihi = CURRENT_TIMESTAMP WHERE id = NEW.id;
      END;
    ''');

    await db.execute('CREATE INDEX IF NOT EXISTS idx_satislar_tarih ON Satislar(tarih)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_satislar_cariId ON Satislar(cariId)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_carihareket_cari_id ON CariHareket(cari_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_carihareket_tarih ON CariHareket(tarih)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_carihareket_fis_tipi ON CariHareket(fis_tipi)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_stokhareketleri_urunId ON StokHareketleri(urunId)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_satis_detay_satisId ON satis_detay(satisId)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_satis_detay_urunId ON satis_detay(urunId)');

    final count = await db.rawQuery('SELECT COUNT(*) as cnt FROM kullanicilar');
    if ((count.first['cnt'] as int) == 0) {
      await db.insert('kullanicilar', {
        'kullaniciAdi': 'admin',
        'sifre': sifreHashle('1234'),
        'rol': 'admin',
      });
    }
  }

  Future<void> _createYaziciTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS Yazicilar (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tur TEXT NOT NULL CHECK(tur IN ('bluetooth', 'ag')),
        adi TEXT NOT NULL,
        cihaz_id TEXT,
        ip TEXT,
        port INTEGER,
        kategori TEXT NOT NULL DEFAULT 'fis' CHECK(kategori IN ('fis', 'etiket')),
        varsayilan INTEGER DEFAULT 0 CHECK(varsayilan IN (0, 1)),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    ''');
    await db.execute('''
      CREATE TRIGGER IF NOT EXISTS update_yazici_timestamp
      AFTER UPDATE ON Yazicilar
      BEGIN
        UPDATE Yazicilar SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
      END;
    ''');
  }

 
    Future<void> _v2Upgrade(Database db) async {
  try {
    await db.execute(
      'ALTER TABLE Urunler ADD COLUMN resim_yolu TEXT'
    );
  } catch (_) {}
}
 
  Future<void> _v3Upgrade(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS Kategoriler (id INTEGER PRIMARY KEY AUTOINCREMENT, ad TEXT NOT NULL UNIQUE, ust_kategori_id INTEGER, FOREIGN KEY(ust_kategori_id) REFERENCES Kategoriler(id))''');
  }
  Future<void> _v4Upgrade(Database db) async {
    try { await db.execute('ALTER TABLE Satislar ADD COLUMN kargo_ucreti REAL DEFAULT 0'); } catch (_) {}
  }
  Future<void> _v5Upgrade(Database db) async {
    await db.execute('CREATE INDEX IF NOT EXISTS idx_urunler_barkod ON Urunler(barkod)');
  }
  Future<void> _v6Upgrade(Database db) async {
    await _createYaziciTable(db);
  }
  Future<void> _v7Upgrade(Database db) async {
    try { await db.execute('ALTER TABLE Cari ADD COLUMN vergi_dairesi TEXT'); } catch (_) {}
  }
  Future<void> _v8Upgrade(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS "GeciciSayim" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "urun_id" INTEGER NOT NULL UNIQUE, "mevcutStok" REAL NOT NULL, "yeniStok" REAL NOT NULL, FOREIGN KEY("urun_id") REFERENCES "Urunler"("id") ON DELETE CASCADE)''');
  }
  Future<void> _v9Upgrade(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS "Promosyonlar" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "urun_id" INTEGER NOT NULL, "miktar" REAL NOT NULL, "iskonto_orani" REAL NOT NULL, "aktif" INTEGER NOT NULL DEFAULT 1, FOREIGN KEY("urun_id") REFERENCES "Urunler"("id") ON DELETE CASCADE)''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_promosyon_urun ON Promosyonlar(urun_id)');
  }
  Future<void> _v10Upgrade(Database db) async {
    try {
      await db.execute('ALTER TABLE CariHareket RENAME TO CariHareket_old');
      await db.execute('''
        CREATE TABLE "CariHareket" (
          "id" INTEGER PRIMARY KEY AUTOINCREMENT,
          "cari_id" INTEGER NOT NULL,
          "tarih" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "fis_tipi" TEXT NOT NULL CHECK("fis_tipi" IN ('Satış', 'Alış', 'Tahsilat', 'Ödeme', 'Açılış')),
          "fis_id" INTEGER,
          "fis_no" TEXT,
          "aciklama" TEXT NOT NULL,
          "borc" REAL NOT NULL DEFAULT 0,
          "alacak" REAL NOT NULL DEFAULT 0,
          "bakiye" REAL,
          FOREIGN KEY("cari_id") REFERENCES "Cari"("id") ON DELETE CASCADE
        )
      ''');
      await db.execute('''INSERT INTO CariHareket (id, cari_id, tarih, fis_tipi, fis_id, fis_no, aciklama, borc, alacak, bakiye) SELECT id, cari_id, tarih, fis_tipi, fis_id, fis_no, aciklama, borc, alacak, bakiye FROM CariHareket_old''');
      await db.execute('DROP TABLE CariHareket_old');
    } catch (e) {
      Log.i("ℹ️ CariHareket upgrade hatası veya zaten güncel: $e", tag: "DB");
    }
  }
  Future<void> _v11Upgrade(Database db) async {
    try {
      await db.execute('''CREATE TABLE IF NOT EXISTS "kullanicilar" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "kullaniciAdi" TEXT UNIQUE NOT NULL, "sifre" TEXT NOT NULL, "rol" TEXT NOT NULL DEFAULT 'personel', "email" TEXT, "telefon" TEXT, "adSoyad" TEXT)''');
      final count = await db.rawQuery('SELECT COUNT(*) as cnt FROM kullanicilar');
      if ((count.first['cnt'] as int) == 0) {
        await db.insert('kullanicilar', {'kullaniciAdi': 'admin', 'sifre': sifreHashle('1234'), 'rol': 'admin'});
      }
    } catch (e) {
      Log.i("ℹ️ v11 upgrade hatası: $e", tag: "DB");
    }
  }

  // ================== DÜZELTİLMİŞ V12 UPGRADE (VERİ KAYBI YOK) ==================
  Future<void> _v12Upgrade(Database db) async {
    // 1. Kullanıcı şifrelerini hash'le (önceki işlem)
    try {
      final kullanicilar = await db.query('kullanicilar');
      for (var k in kullanicilar) {
        final rawSifre = k['sifre'] as String;
        if (rawSifre.length != 64) {
          await db.update('kullanicilar', {'sifre': sifreHashle(rawSifre)}, where: 'id = ?', whereArgs: [k['id']]);
        }
      }
    } catch (e) {
      Log.w("Şifre hash'leme hatası: $e", tag: "DB");
    }

    // 2. satis_detay tablosunu veri kaybı olmadan yeniden oluştur
    try {
      // Eski tablo var mı kontrol et
      final tableExists = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='satis_detay'"
      );
      if (tableExists.isNotEmpty) {
        // Geçici tablo oluştur
        await db.execute('ALTER TABLE satis_detay RENAME TO satis_detay_old');
        
        // Yeni tabloyu oluştur
        await db.execute('''
          CREATE TABLE satis_detay (
            "id" INTEGER PRIMARY KEY AUTOINCREMENT,
            "satisId" INTEGER NOT NULL,
            "urunId" INTEGER NOT NULL,
            "urunAdi" TEXT NOT NULL,
            "miktar" REAL NOT NULL,
            "birimFiyat" REAL NOT NULL,
            "indirimOrani" REAL DEFAULT 0,
            "toplamTutar" REAL NOT NULL,
            "kdvliFiyat" REAL NOT NULL,
            "kdvliTutar" REAL NOT NULL,
            FOREIGN KEY("satisId") REFERENCES "Satislar"("id") ON DELETE CASCADE,
            FOREIGN KEY("urunId") REFERENCES "Urunler"("id")
          )
        ''');
        
        // Eski verileri yeni tabloya kopyala (sütun eşlemesi yap)
        await db.execute('''
          INSERT INTO satis_detay (
            id, satisId, urunId, urunAdi, miktar, birimFiyat, 
            indirimOrani, toplamTutar, kdvliFiyat, kdvliTutar
          )
          SELECT 
            id, satisId, urunId, urunAdi, miktar, birimFiyat,
            indirimOrani, toplamTutar, kdvliFiyat, kdvliTutar
          FROM satis_detay_old
        ''');
        
        // Eski tabloyu sil
        await db.execute('DROP TABLE satis_detay_old');
      } else {
        // Tablo yoksa direkt oluştur
        await db.execute('''
          CREATE TABLE IF NOT EXISTS satis_detay (
            "id" INTEGER PRIMARY KEY AUTOINCREMENT,
            "satisId" INTEGER NOT NULL,
            "urunId" INTEGER NOT NULL,
            "urunAdi" TEXT NOT NULL,
            "miktar" REAL NOT NULL,
            "birimFiyat" REAL NOT NULL,
            "indirimOrani" REAL DEFAULT 0,
            "toplamTutar" REAL NOT NULL,
            "kdvliFiyat" REAL NOT NULL,
            "kdvliTutar" REAL NOT NULL,
            FOREIGN KEY("satisId") REFERENCES "Satislar"("id") ON DELETE CASCADE,
            FOREIGN KEY("urunId") REFERENCES "Urunler"("id")
          )
        ''');
      }
      
      // İndeksleri yeniden oluştur
      await db.execute('CREATE INDEX IF NOT EXISTS idx_satis_detay_satisId ON satis_detay(satisId)');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_satis_detay_urunId ON satis_detay(urunId)');
      
      Log.i("✅ satis_detay tablosu veri kaybı olmadan güncellendi", tag: "DB");
    } catch (e) {
      Log.e("❌ satis_detay upgrade hatası: $e", tag: "DB");
      // Hata durumunda eski tabloyu geri getirmek için
      try {
        await db.execute('ALTER TABLE satis_detay_old RENAME TO satis_detay');
      } catch (_) {}
      rethrow;
    }
  }

  // ================== GEÇİCİ SAYIM METOTLARI ==================
  Future<List<Map<String, dynamic>>> geciciSayimListesiGetir() async {
    final database = await db;
    return await database.query('GeciciSayim');
  }
  Future<void> geciciSayimEkleveyaGuncelle(int urunId, double mevcutStok, double yeniStok) async {
    final database = await db;
    final varMi = await database.query('GeciciSayim', where: 'urun_id = ?', whereArgs: [urunId]);
    if (varMi.isNotEmpty) {
      await database.update('GeciciSayim', {'mevcutStok': mevcutStok, 'yeniStok': yeniStok}, where: 'urun_id = ?', whereArgs: [urunId]);
    } else {
      await database.insert('GeciciSayim', {'urun_id': urunId, 'mevcutStok': mevcutStok, 'yeniStok': yeniStok});
    }
  }
  Future<void> geciciSayimSil(int urunId) async {
    final database = await db;
    await database.delete('GeciciSayim', where: 'urun_id = ?', whereArgs: [urunId]);
  }
  Future<void> geciciSayimTemizle() async {
    final database = await db;
    await database.delete('GeciciSayim');
  }

  // ================== YAZICI METOTLARI ==================
  Future<int> yaziciEkle(Map<String, dynamic> yazici) async {
    final database = await db;
    return await database.insert('Yazicilar', yazici);
  }
  Future<int> yaziciGuncelle(Map<String, dynamic> yazici) async {
    final database = await db;
    return await database.update('Yazicilar', yazici, where: 'id = ?', whereArgs: [yazici['id']]);
  }
  Future<int> yaziciSil(int id) async {
    final database = await db;
    return await database.delete('Yazicilar', where: 'id = ?', whereArgs: [id]);
  }
  Future<List<Map<String, dynamic>>> tumYazicilariGetir() async {
    final database = await db;
    return await database.query('Yazicilar');
  }
  Future<Map<String, dynamic>?> varsayilanYaziciGetir() async {
    final database = await db;
    final sonuc = await database.query('Yazicilar', where: 'varsayilan = ?', whereArgs: [1], limit: 1);
    return sonuc.isNotEmpty ? sonuc.first : null;
  }
  Future<void> varsayilanYaziciAyarla(int id) async {
    final database = await db;
    await database.update('Yazicilar', {'varsayilan': 0});
    await database.update('Yazicilar', {'varsayilan': 1}, where: 'id = ?', whereArgs: [id]);
  }

  // ================== SIFIRLAMA ==================
  Future<void> veritabaniSifirla() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'market.db');
    final file = File(path);
    if (await file.exists()) {
      await file.delete();
    }
    _database = null;
    await db;
  }
  Future<void> _resetAndRecreate() async => await veritabaniSifirla();
 // ================== V13 INDEX OPTİMİZASYONU ==================
  Future<void> _v13Upgrade(Database db) async {
    try {

      // ================== SATIŞLAR ==================
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_satislar_fisNo ON Satislar(fisNo)'
      );

      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_satislar_odemeYontemi ON Satislar(odemeYontemi)'
      );

      // ================== SATIŞ DETAY ==================
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_satis_detay_urunAdi ON satis_detay(urunAdi)'
      );

      // ================== ÜRÜNLER ==================
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_urunler_ad ON Urunler(ad)'
      );

      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_urunler_kategori ON Urunler(kategori)'
      );

      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_urunler_anagrup ON Urunler(anagrup)'
      );

      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_urunler_stok ON Urunler(stokMiktari)'
      );

      // ================== CARİ ==================
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_cari_unvan ON Cari(unvan)'
      );

      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_cari_kodu ON Cari(cari_kodu)'
      );

      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_cari_tip ON Cari(cari_tipi)'
      );

      // ================== STOK HAREKET ==================
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_stokhareketleri_tarih ON StokHareketleri(tarih)'
      );

      // ================== İADE ==================
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_iade_barkod ON iade_kayitlari(barkod)'
      );

      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_iade_tarih ON iade_kayitlari(tarih)'
      );

      Log.i(
        "✅ V13 index optimizasyonları tamamlandı",
        tag: "DB",
      );

    } catch (e) {

      Log.e(
        "❌ V13 upgrade hatası: $e",
        tag: "DB",
      );
    }
  }

  static Future<Database> getDatabase() async =>
      await VeritabaniYardimcisi().db;

  static Future<void> resetDatabase() async =>
      await VeritabaniYardimcisi().veritabaniSifirla();
}

