import 'package:market_uygulamasi/modeller/fiyat_gecmis.dart';
import 'package:market_uygulamasi/servisler/veritabani_yardimcisi.dart';

class FiyatRepository {
  final VeritabaniYardimcisi _dbHelper = VeritabaniYardimcisi();

  Future<List<FiyatGecmis>> urunFiyatGecmisiGetir(String urunId) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'fiyat_gecmis',
      where: 'urunId = ?',
      whereArgs: [urunId],
    );
    return List.generate(maps.length, (i) => FiyatGecmis.fromMap(maps[i]));
  }

  Future<void> fiyatGecmisiEkle(FiyatGecmis fiyatGecmis) async {
    final db = await _dbHelper.database;
    await db.insert('fiyat_gecmis', fiyatGecmis.toMap());
  }
}